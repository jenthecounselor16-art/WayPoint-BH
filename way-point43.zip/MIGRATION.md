# WayPoint Migration Inventory & HIPAA Rebuild Checklist

Generated 2026-10-01. Use this alongside the source ZIP (Code view → Export project as ZIP).
The React frontend transfers nearly as-is; everything below describes what must be **rebuilt** on a BAA-covered platform (AWS / GCP / Azure), because the running versions are Base44 platform services, not self-hostable code.

---

## 1. Data Model — 30 entities to re-create

Re-implement every entity in a BAA-covered database (e.g. Postgres/DynamoDB/Cloud SQL) **plus every row-level security (RLS) rule** — the access rules below are as critical as the fields.

### Client-clinical data (HIPAA-sensitive core)
| Entity | Purpose | Access model (must re-implement) |
|---|---|---|
| Client | Therapist's client roster (email, name, therapist link) | Therapist + the client themselves |
| ClientInvitation | Client invite + identity-match (name, DOB, state) with claim/approval states | Therapist, matched client, admin |
| AssessmentResult | Standardized test results (PHQ9, GAD7, BDI, BAI, PCL-5, C-SSRS + 15 more) with score/severity/answers | Client + their therapist |
| TherapyGoal | Treatment goals with client & therapist 0–10 progress ratings | Shared client/therapist write |
| GoalProgressCheckin | Historical rating snapshots for goal trend charts | Shared client/therapist |
| MoodEntry | Emotion-wheel mood logs (emotion, path, intensity, note) | Owner only (never shared) |
| JournalEntry | Private journal text | Owner only (never shared) |
| ThoughtRecord | CBT thought records (situation → evidence → balanced thought) | Client + therapist |
| NervousSystemMetric | Daily check-ins: sleep, stress, anxiety, depression, energy, social, hydration, movement | Client + therapist |
| FunctionalImpairment | 0–4 ratings across 11 daily-functioning domains | Client + therapist |
| CrisisPlan | Safety plan: warning signs, coping skills, emergency contacts, reasons to live | Client + therapist |
| ValuesChecklist | Values inventory with top-3 values and 1–5 importance ratings | Shared |
| BehaviorActivationActivity | BA activities (enjoyable/valuable/routine) linked to values, with status | Shared |
| CopingFavorite | Client's favorited coping tools | Client + therapist |
| ClinicalNote | Therapist's session notes | Therapist |
| HomeworkAssignment | Assigned homework with checklist, due date, completion %, client reflection, reminder flag | Client + therapist |
| AssessmentAssignment | Therapist-assigned assessments | Client + therapist |
| FunctionalImpairmentAssignment | Therapist-assigned functioning check-ins | Client + therapist |
| Parent | Parent/guardian link to a child client with consent gate (pending/active/revoked) — therapist cannot bypass child consent | Parent, child, therapist, admin |
| UserBadge | Earned badges / celebrations | Owner |

### Business / platform data
| Entity | Purpose |
|---|---|
| Base44Purchase | Payment purchases (checkout session id + status: pending/paid) |
| ClientFeatureAccess | Per-client feature gating |
| ClientDemoParticipant / DemoParticipant | 7-day client & clinician demo tracking (seats, expiry, feedback status) |
| ClientDemoFeedback / DemoFeedback | Demo survey responses (ratings, NPS, verbatims) |
| DemoFeatureInteraction | Demo usage analytics |
| TherapistBurnoutCheckin | Clinician self-care check-ins |
| AuditLog | Security-relevant audit trail (alert outcomes, admin actions) |

**Built-in User entity:** accounts, roles (admin/therapist-client), Google login, OTP verification, password reset — all currently platform-provided auth.

---

## 2. Backend functions — 39 to port to new runtime (e.g. AWS Lambda)

### Safety & clinical alerts
- **safety-risk-alert** — evaluates C-SSRS / PHQ-9 / BDI results for high risk and notifies therapist
- **crisis-symptom-alert** — crisis-plan updates & high-risk-symptom email alerts with audit logging
- **assessment-alert** — notifies therapist of completed assessments (de-identified emails)

### Email & notifications
- **welcome-email** — role-specific onboarding sequences (day 0/2/5)
- **homework-alerts** — due-soon / overdue homework reminders
- **badge-notification** — milestone badge emails
- **streak-reminder** — engagement streak nudges
- **burnout-tips** — clinician burnout tips

### Demo trial lifecycle
- **demo-signup** / **client-demo-signup** — seat claiming, anti-bot checks, account invites
- **demo-status** — remaining seat count
- **demo-trial-sequence** — multi-day onboarding emails
- **demo-last-day-email** — final-day feedback request
- **demo-7day-feedback-alert**, **demo-feedback-notify**, **demo-feedback-request** — feedback workflows
- **expire-demo-trials** — expire lapsed demos
- **grant-demo-therapist-role** — temporary therapist access for demo
- **purge-demo-bots** — cleanup of fake signups
- **send-demo-apology** — follow-up to non-converters

### Client onboarding & linking
- **verify-client-invitation** — DOB/state identity match at registration
- **claim-client-invitation** — bind registered client to inviting therapist
- **link-client-records** — backfill data linkage
- **sync-shared-care** / **manage-shared-provider** — shared-care records

### Payments
- **create-checkout** — Wix/Base44 Payments checkout session (persists checkoutSessionId on Base44Purchase)
- **wix-payments-webhook** — JWT-verified ORDER_APPROVED webhook; grants access, marks paid, idempotent
- **stripe-checkout** — legacy Stripe path ( retire or port to your new processor )

### Reports & analytics
- **monthly-clinical-report**, **quarterly-progress-report** — generated clinical summaries (PDF via report components; note: inline styles, not Tailwind, for PDF rendering)
- **weekly-revenue-report** — revenue dashboard data
- **organization-metrics** — org-wide KPIs
- **save-report-to-drive** — export reports to Google Drive
- **parent-child-data** — parent-portal data aggregation (respecting consent gate)

### Misc
- **sync-calendar-event** — Google Calendar session sync
- **contact-sales** — enterprise lead capture
- **seed-demo-clients** — demo data seeding

### Shared modules (port alongside functions)
`emailTemplate.js`, `emailUtils.ts`, `gmailSend.ts` (branded Gmail sending via MIME), `linkClientRecords.ts`, `planCatalog.ts` (centralized pricing), `sharedCare.ts`, `clientReportUtils.ts`

---

## 3. Workflows — 19 to rebuild as cron jobs / queues

| Workflow | Type |
|---|---|
| Assessment Alert | event → email |
| Crisis Plan Alert | event → email |
| High-Risk Functional Impairment Alert | event → email |
| High-Risk Nervous System Alert | event → email |
| Homework Alerts (via homework-alerts fn) | scheduled |
| Streak Reminder | scheduled |
| Burnout Tips | scheduled |
| Welcome Email | event (signup/login) |
| Demo Trial Sequence | scheduled multi-step |
| Demo Last Day Email | scheduled |
| Expire Demo Trials | scheduled |
| Grant Demo Therapist Role | event |
| Demo Feedback Request / Notify / 7-Day Alert | scheduled + event |
| Client Demo Feedback Request | scheduled |
| Shared Care Sync | event/scheduled |
| Weekly Revenue Report | scheduled (weekly) |
| Monthly Clinical Report | scheduled (monthly, month-guard in code) |
| Quarterly Client Report | scheduled (quarterly) |

---

## 4. AI agents — 8 conversation experiences to re-implement

`onboarding_guide`, `assessment_setup_guide`, `thought_record_coach`, `crisis_plan_coach`, `goal_checkin`, `goal_self_checkin`, `nervous_system_coach`, `mood_thought_inviter`
→ Rebuild with a BAA-covered LLM provider (e.g. AWS Bedrock / Azure OpenAI) or de-identify all prompts before calling an uncovered provider. Each also needs its in-app chat UI wiring (src/components/chat/, respective pages).

---

## 5. Integrations to re-establish

1. **Gmail (send-only)** — all outbound email (currently MIME via Gmail API). Replace with BAA-covered email service or SMTP.
2. **Google Calendar** — session event sync.
3. **Google Drive** — report storage.
4. **Payments** — Wix Payments checkout/webhook or alternate HIPAA-eligible processor; re-enter `WIX_PAYMENTS_*` / webhook public key as platform secrets.
5. **File storage** — private uploads with signed URLs (e.g. S3 + presigned URLs).
6. **Secrets management** — re-enter payment keys and webhook public key in the new platform's secret store.

---

## 6. Auth & permissions to rebuild (critical for HIPAA)

- Email/password + OTP verification + password reset + Google sign-in
- Role model: admin / therapist / client / parent
- All RLS rules (see column in §1) — client-therapist isolation, parent consent gate, admin-only demo data
- "Never gate paid access on is_verified" — use a webhook-written entitlement field
- 2FA for admins (on the open todo list at export time)

---

## 7. Data migration (one-time)

- Export all entity records (SQL/CSV from the new platform's side once rebuilt; Base44 does not provide a bulk DB dump tool).
- Re-establish the client↔therapist↔parent relationship links.
- Existing Gmail/Drive connections must be re-authorized by the practice.

---

## 8. Frontend — transfers nearly as-is

React + Vite + Tailwind app (~90 pages/components). Adjustments needed:
- Replace `@/api/base44Client` SDK calls (`base44.entities.*`, `base44.functions.invoke`, `base44.auth.*`, agents, file upload) with your new backend's API layer.
- Rebuild `src/components/ProtectedRoute.jsx` logic against your auth provider.
- Keep: `src/lib/` business logic (assessments scoring, goalProgress, badges, plans, careTemplates, etc.) — portable as-is.
- PDF export uses html2canvas + jspdf with inline styles (Tailwind does not render off-screen) — preserve that pattern.

---

## Also worth noting

- The BAA conversation with the Base44 enterprise team was open at time of export — if a BAA becomes available, a full migration may not be necessary.
- No HIPAA compliance badge may be displayed on any platform until a BAA is signed, in writing, with the hosting provider.