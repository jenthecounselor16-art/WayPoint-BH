import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Globe, PhoneCall, Check } from "lucide-react";

const ENTERPRISE_TIERS = [
  {
    key: "enterprise",
    name: "Enterprise",
    icon: Globe,
    clinicians: "26+ clinicians",
    features: [
      "Everything in Professional",
      "Unlimited clinician seats across locations",
      "Multi-site / multi-program dashboards",
      "Custom integrations & data exports",
      "SSO & advanced admin controls",
      "Priority SLA & dedicated support team",
    ],
  },
];

export default function EnterpriseTiers() {
  return (
    <div className="mt-14">
      <div className="text-center mb-8">
        <h2 className="font-heading text-2xl md:text-3xl font-semibold mb-2">Enterprise Plan</h2>
        <p className="text-muted-foreground text-lg">
          For practices and health systems with 26+ clinicians. Custom pricing based on clinician count and scope — let's talk.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6 max-w-xl mx-auto">
        {ENTERPRISE_TIERS.map((tier) => {
          const Icon = tier.icon;
          return (
            <motion.div
              key={tier.key}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="pp-card p-6 flex flex-col"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  <Icon className="text-primary" size={20} />
                </div>
                <div className="min-w-0">
                  <h3 className="font-heading text-xl font-semibold">{tier.name}</h3>
                  <p className="text-xs text-muted-foreground">{tier.clinicians}</p>
                </div>
              </div>

              <div className="mb-4">
                <p className="text-sm text-muted-foreground">Custom pricing — tailored to your organization</p>
              </div>

              <ul className="space-y-2 mb-6 flex-1">
                {tier.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <Check size={16} className="text-primary shrink-0 mt-0.5" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>

              <Link
                to="/contact-sales"
                className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:opacity-90 transition flex items-center justify-center gap-1.5"
              >
                <PhoneCall size={16} /> Contact Sales
              </Link>
            </motion.div>
          );
        })}
      </div>

      <p className="text-center text-xs text-muted-foreground mt-6">
        All enterprise plans include implementation, training, and a dedicated support contact. Annual contracts with flexible terms.
      </p>
    </div>
  );
}