import React from "react";
import { Link } from "react-router-dom";
import { Lock, CreditCard, Sparkles } from "lucide-react";

export default function Paywall({
  title = "This is a premium clinician feature",
  description = "The full workbook library and progress analytics are included with a WayPoint clinician subscription. Subscribe to unlock them.",
}) {
  return (
    <div className="p-6 md:p-10 max-w-2xl mx-auto">
      <div className="pp-card p-8 md:p-10 text-center">
        <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-5">
          <Lock className="text-primary" size={30} />
        </div>
        <h1 className="font-heading text-2xl md:text-3xl font-semibold mb-3">{title}</h1>
        <p className="text-muted-foreground mb-7">{description}</p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            to="/billing"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition"
          >
            <CreditCard size={18} /> View plans & subscribe
          </Link>
          <Link
            to="/"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl border border-border font-medium hover:bg-secondary/50 transition"
          >
            Back to home
          </Link>
        </div>
        <p className="text-xs text-muted-foreground mt-6 flex items-center justify-center gap-1.5">
          <Sparkles size={13} /> On a 7-day demo? You keep full access until your trial ends.
        </p>
      </div>
    </div>
  );
}