import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ShieldCheck, ShieldAlert, Check, X, Loader2, UserCircle } from "lucide-react";

// Shown to a client (account holder) when someone has requested access to
// their progress. New links start "pending" — no data is shared until the
// client approves here. The client can also revoke access they've granted.
export default function ParentAccessRequests() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [acting, setActing] = useState(null);

  async function load() {
    try {
      const me = await base44.auth.me();
      if (!me?.email) { setLoading(false); return; }
      const links = await base44.entities.Parent.filter({ child_email: me.email }, "-created_date", 50);
      setRequests(links || []);
    } catch {}
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  async function setStatus(link, status) {
    setActing(link.id);
    try {
      await base44.entities.Parent.update(link.id, { status });
      setRequests((r) => r.map((l) => (l.id === link.id ? { ...l, status } : l)));
    } catch {}
    setActing(null);
  }

  if (loading) return null;
  const pending = requests.filter((r) => r.status === "pending");
  const active = requests.filter((r) => r.status === "active");
  if (!pending.length && !active.length) return null;

  return (
    <div className="mb-6 space-y-3">
      {pending.map((link) => (
        <div key={link.id} className="pp-card p-4 border-amber-500/30 bg-amber-500/5">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 flex items-center justify-center shrink-0">
              <ShieldAlert className="text-amber-600" size={18} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">
                {link.parent_name || link.parent_email} ({link.relationship}) requested access to your progress.
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Your therapist set this up. Your data stays private until you approve.
              </p>
              <div className="flex gap-2 mt-3">
                <button
                  onClick={() => setStatus(link, "active")}
                  disabled={acting === link.id}
                  className="px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center gap-1"
                >
                  {acting === link.id ? <Loader2 size={13} className="animate-spin" /> : <Check size={13} />} Approve access
                </button>
                <button
                  onClick={() => setStatus(link, "revoked")}
                  disabled={acting === link.id}
                  className="px-3 py-1.5 rounded-lg bg-secondary text-secondary-foreground text-xs font-medium hover:opacity-80 transition disabled:opacity-50 flex items-center gap-1"
                >
                  <X size={13} /> Deny
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}

      {active.length > 0 && (
        <div className="pp-card p-4">
          <div className="flex items-center gap-2 mb-2 text-sm font-medium">
            <ShieldCheck size={16} className="text-accent" /> People with access to your progress
          </div>
          <div className="space-y-2">
            {active.map((link) => (
              <div key={link.id} className="flex items-center justify-between gap-2">
                <span className="text-sm flex items-center gap-2">
                  <UserCircle size={14} className="text-muted-foreground" />
                  {link.parent_name || link.parent_email}
                  <span className="text-xs text-muted-foreground">({link.relationship})</span>
                </span>
                <button
                  onClick={() => setStatus(link, "revoked")}
                  disabled={acting === link.id}
                  className="px-2.5 py-1 rounded-lg bg-destructive/10 text-destructive text-xs font-medium hover:bg-destructive/20 transition disabled:opacity-50"
                >
                  Revoke
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}