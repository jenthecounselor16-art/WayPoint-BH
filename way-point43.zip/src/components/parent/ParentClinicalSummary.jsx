import React, { useMemo } from "react";
import { ASSESSMENTS } from "@/lib/assessments";
import { ClipboardList, TrendingUp, TrendingDown, Minus, Activity, CheckCircle2, Target } from "lucide-react";

const DAY = 86400000;

// Wellbeing % — higher is always better. Symptom scales inverted; WHO-5 direct.
function wellbeing(testType, score) {
  const test = ASSESSMENTS[testType];
  if (!test) return null;
  const maxScore = test.items.length * (test.scale.length - 1);
  if (!maxScore) return null;
  const ratio = score / maxScore;
  return testType === "WHO5" ? ratio * 100 : (1 - ratio) * 100;
}

// Composite wellbeing (0–100) from the most recent score of each assessment
// type on or before asOfMs — mirrors the therapist-facing barometer.
function barometerAt(assessments, asOfMs) {
  const latest = {};
  assessments.forEach((a) => {
    if (new Date(a.created_date).getTime() > asOfMs) return;
    if (!latest[a.test_type] || new Date(a.created_date) > new Date(latest[a.test_type].created_date)) {
      latest[a.test_type] = a;
    }
  });
  const scores = Object.values(latest).map((a) => wellbeing(a.test_type, a.score)).filter((s) => s !== null);
  if (!scores.length) return null;
  return scores.reduce((x, y) => x + y, 0) / scores.length;
}

// A parent-appropriate clinical summary. Deliberately omits raw risk flags and
// raw symptom numbers — only engagement, a composite wellbeing trend, goal
// progress, and recent assessment labels, with a plain-language narrative.
export default function ParentClinicalSummary({ assessments = [], goals = [], nervous = [] }) {
  const summary = useMemo(() => {
    const now = Date.now();
    const current = barometerAt(assessments, now);
    const previous = barometerAt(assessments, now - 30 * DAY);
    const trend = current !== null && previous !== null ? current - previous : null;

    const recent = [...assessments]
      .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
      .slice(0, 5)
      .map((a) => {
        const test = ASSESSMENTS[a.test_type];
        const scored = test?.score?.(a.score);
        return {
          id: a.id,
          abbr: test?.abbr || a.test_type,
          name: test?.name || a.test_type,
          score: a.score,
          severity: a.severity || scored?.severity,
          color: scored?.color,
          date: a.created_date,
        };
      });

    const goalsTotal = goals.length;
    const goalsAchieved = goals.filter((g) => g.status === "achieved").length;
    const goalsActive = goalsTotal - goalsAchieved;
    const checkins30 = nervous.filter((n) => now - new Date(n.created_date).getTime() <= 30 * DAY).length;

    const parts = [];
    if (checkins30 > 0) parts.push(`logged ${checkins30} check-in${checkins30 === 1 ? "" : "s"} with their care team in the last 30 days`);
    else parts.push("no check-ins logged in the last 30 days");
    if (current !== null) {
      const trendWord = trend === null ? ""
        : trend > 3 ? ", improving from last month"
        : trend < -3 ? ", a little lower than last month"
        : ", steady compared to last month";
      parts.push(`overall wellbeing is around ${Math.round(current)} out of 100${trendWord}`);
    }
    if (goalsTotal > 0) parts.push(`${goalsAchieved} of ${goalsTotal} treatment goals achieved`);
    if (recent[0]) {
      const d = new Date(recent[0].date).toLocaleDateString("en-US", { month: "short", day: "numeric" });
      parts.push(`most recent assessment was ${recent[0].name} on ${d}`);
    }
    let text = parts.join("; ") + ".";
    text = text.charAt(0).toUpperCase() + text.slice(1);

    return { current, trend, recent, goalsTotal, goalsAchieved, goalsActive, checkins30, narrative: text };
  }, [assessments, goals, nervous]);

  const trendUp = summary.trend !== null && summary.trend > 3;
  const trendDown = summary.trend !== null && summary.trend < -3;
  const TrendIcon = trendUp ? TrendingUp : trendDown ? TrendingDown : Minus;
  const wellbeingColor = summary.current === null ? "#6B7280"
    : summary.current >= 50 ? "#1995A1"
    : summary.current >= 30 ? "#D4A055" : "#E07856";

  return (
    <div className="pp-card p-5 mb-4">
      <div className="flex items-center gap-2 mb-4">
        <ClipboardList size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Shared Clinical Summary</h3>
      </div>

      <p className="text-sm text-foreground/90 leading-relaxed mb-4">{summary.narrative}</p>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
        <StatChip icon={TrendIcon} label="Wellbeing" value={summary.current !== null ? `${Math.round(summary.current)}/100` : "—"} sub={summary.trend !== null ? (trendUp ? "improving" : trendDown ? "lower" : "steady") : undefined} color={wellbeingColor} />
        <StatChip icon={Activity} label="Check-ins (30d)" value={String(summary.checkins30)} color="#5B8FB9" />
        <StatChip icon={Target} label="Goals" value={String(summary.goalsTotal)} sub={summary.goalsTotal ? `${summary.goalsAchieved} achieved` : undefined} color="#D4A055" />
        <StatChip icon={CheckCircle2} label="Recent scores" value={String(summary.recent.length)} color="#8B7CB6" />
      </div>

      {summary.recent.length > 0 && (
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Recent Assessments</p>
          <div className="flex flex-wrap gap-1.5">
            {summary.recent.map((r) => (
              <span
                key={r.id}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium"
                style={{ backgroundColor: r.color ? `${r.color}15` : "hsl(var(--secondary))", color: r.color || "hsl(var(--muted-foreground))" }}
                title={`${r.name} — ${new Date(r.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}`}
              >
                <span className="font-bold">{r.abbr}</span>
                <span>{r.score}</span>
                {r.severity && <span className="opacity-80">· {r.severity}</span>}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StatChip({ icon: Icon, label, value, sub, color }) {
  return (
    <div className="rounded-xl border border-border/60 bg-secondary/30 px-3 py-2.5">
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-0.5">
        <Icon size={12} /> {label}
      </div>
      <p className="font-heading text-lg font-semibold leading-none" style={{ color }}>{value}</p>
      {sub && <p className="text-[11px] text-muted-foreground mt-1">{sub}</p>}
    </div>
  );
}