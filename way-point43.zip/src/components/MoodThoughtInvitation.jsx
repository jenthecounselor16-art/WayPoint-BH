import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Lightbulb, Loader2, ArrowRight } from "lucide-react";

export default function MoodThoughtInvitation({ emotion, emotionPath, intensity, note }) {
  const [invitation, setInvitation] = useState("");
  const [loading, setLoading] = useState(true);
  const doneRef = useRef(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const conv = await base44.agents.createConversation({
          agent_name: "mood_thought_inviter",
          metadata: { name: "Mood to Thought invitation" },
        });
        const seed = `I just logged a mood:\n- Emotion: ${emotion}\n- Path: ${emotionPath}\n- Intensity: ${intensity}/5${note ? `\n- Note: ${note}` : ""}\n\nSend me a personalized invitation to complete a ThoughtRecord.`;
        const unsub = base44.agents.subscribeToConversation(conv.id, (data) => {
          if (cancelled || doneRef.current) return;
          const msgs = data.messages || [];
          const lastAssistant = [...msgs].reverse().find((m) => m.role === "assistant" && m.content);
          if (lastAssistant) {
            doneRef.current = true;
            setInvitation(lastAssistant.content);
            setLoading(false);
          }
        });
        await base44.agents.addMessage(conv, { role: "user", content: seed });
        const fallback = setTimeout(() => {
          if (cancelled || doneRef.current) return;
          doneRef.current = true;
          setLoading(false);
        }, 15000);
        return () => {
          unsub();
          clearTimeout(fallback);
        };
      } catch (e) {
        console.error("MoodThoughtInvitation agent error:", e);
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  if (loading) {
    return (
      <div className="mt-6 pp-card p-5 flex items-center gap-3 text-muted-foreground">
        <Loader2 size={18} className="animate-spin text-primary shrink-0" />
        <span className="text-sm">Crafting a personalized invitation…</span>
      </div>
    );
  }

  if (!invitation) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="mt-6 pp-card p-5 border-accent/20"
    >
      <div className="flex items-start gap-3 mb-3">
        <div className="w-9 h-9 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
          <Lightbulb size={18} className="text-accent" />
        </div>
        <p className="text-sm text-foreground leading-relaxed">{invitation}</p>
      </div>
      <Link
        to="/cbt-journal"
        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-accent text-accent-foreground text-sm font-medium hover:opacity-90 transition"
      >
        Try a ThoughtRecord <ArrowRight size={15} />
      </Link>
    </motion.div>
  );
}