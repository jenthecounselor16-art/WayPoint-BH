import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { ChevronLeft, ChevronRight, Loader2, Sparkles, Save } from "lucide-react";

const STEPS = [
  {
    key: "situation",
    title: "Situation",
    prompt: "What happened? Describe the situation that triggered this thought.",
    placeholder: "e.g., My boss sent me a short email asking to talk tomorrow morning...",
    type: "text",
  },
  {
    key: "emotion",
    title: "Emotions",
    prompt: "What emotions are you feeling? And how intense are they right now?",
    type: "emotion",
  },
  {
    key: "automatic_thought",
    title: "Automatic Thought",
    prompt: "What went through your mind? What's the thought that's bothering you?",
    placeholder: "e.g., They're going to fire me. I'm not good enough...",
    type: "thought",
  },
  {
    key: "evidence_for",
    title: "Evidence For",
    prompt: "What evidence supports this thought? Be honest — what facts make it seem true?",
    placeholder: "List the facts that support your thought...",
    type: "text",
  },
  {
    key: "evidence_against",
    title: "Evidence Against",
    prompt: "What evidence contradicts this thought? What facts don't fit with it?",
    placeholder: "List the facts that contradict your thought...",
    type: "text",
  },
  {
    key: "balanced_thought",
    title: "Balanced Thought",
    prompt: "What's a more balanced way to think about this, considering all the evidence?",
    placeholder: "Write a balanced alternative thought...",
    type: "balanced",
  },
  {
    key: "new_emotion_intensity",
    title: "Re-rate Emotion",
    prompt: "Now that you've challenged the thought, how intense is the emotion?",
    type: "intensity",
  },
];

export default function ThoughtRecordForm({ onSave, onCancel }) {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    situation: "",
    emotion: "",
    emotion_intensity: 50,
    automatic_thought: "",
    evidence_for: "",
    evidence_against: "",
    balanced_thought: "",
    new_emotion_intensity: 50,
  });
  const [distortions, setDistortions] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);

  function update(key, value) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function analyzeThought() {
    if (!form.automatic_thought.trim()) return;
    setAnalyzing(true);
    setDistortions(null);
    try {
      const prompt = `You are a CBT assistant. The user's automatic thought is: "${form.automatic_thought}"

Identify cognitive distortions present in this thought. Common distortions: all-or-nothing thinking, overgeneralization, mental filter, disqualifying the positive, jumping to conclusions (mind reading/fortune telling), magnification/minimization, emotional reasoning, should statements, labeling, personalization.

Return JSON with a "distortions" array. Each item has "name" and "explanation" (1 sentence). Only include genuinely present distortions. Be concise and compassionate. If none found, return an empty array.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            distortions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  explanation: { type: "string" },
                },
              },
            },
          },
        },
      });
      setDistortions(result?.distortions || []);
    } catch {
      setDistortions([]);
    }
    setAnalyzing(false);
  }

  async function generateBalancedThought() {
    setGenerating(true);
    try {
      const prompt = `You are a CBT assistant helping someone craft a balanced alternative thought.

Situation: ${form.situation || "Not provided"}
Emotion: ${form.emotion || "Not provided"} (intensity: ${form.emotion_intensity}/100)
Automatic thought: ${form.automatic_thought}
Evidence for: ${form.evidence_for || "Not provided"}
Evidence against: ${form.evidence_against || "Not provided"}

Write a balanced thought (1-3 sentences) that acknowledges valid concerns, incorporates the evidence against, and is realistic and compassionate. Return only the thought — no preamble or explanation.`;

      const result = await base44.integrations.Core.InvokeLLM({ prompt });
      if (result) update("balanced_thought", typeof result === "string" ? result : String(result));
    } catch {}
    setGenerating(false);
  }

  async function handleSave() {
    setSaving(true);
    await onSave(form);
    setSaving(false);
  }

  const currentStep = STEPS[step];
  const isLastStep = step === STEPS.length - 1;
  const canProceed = form.automatic_thought.trim().length > 0 || currentStep.key !== "automatic_thought";

  return (
    <div className="pp-card p-6">
      <div className="flex items-center gap-2 mb-4">
        {STEPS.map((_, i) => (
          <div
            key={i}
            className={`h-1.5 flex-1 rounded-full transition-colors ${i <= step ? "bg-primary" : "bg-secondary"}`}
          />
        ))}
      </div>
      <p className="text-xs text-muted-foreground mb-4">Step {step + 1} of {STEPS.length}</p>

      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.2 }}
        >
          <h3 className="font-heading text-xl font-semibold mb-2">{currentStep.title}</h3>
          <p className="text-sm text-muted-foreground mb-4">{currentStep.prompt}</p>

          {(currentStep.type === "text" || currentStep.type === "thought") && (
            <textarea
              value={form[currentStep.key]}
              onChange={(e) => update(currentStep.key, e.target.value)}
              placeholder={currentStep.placeholder}
              className="pp-input min-h-[120px] resize-none"
            />
          )}

          {currentStep.type === "emotion" && (
            <div className="space-y-4">
              <input
                value={form.emotion}
                onChange={(e) => update("emotion", e.target.value)}
                placeholder="e.g., Anxious, embarrassed, worried..."
                className="pp-input"
              />
              <IntensitySlider value={form.emotion_intensity} onChange={(v) => update("emotion_intensity", v)} />
            </div>
          )}

          {currentStep.type === "intensity" && (
            <div>
              <IntensitySlider value={form.new_emotion_intensity} onChange={(v) => update("new_emotion_intensity", v)} />
              {form.emotion_intensity !== form.new_emotion_intensity && (
                <p className="text-sm text-center mt-4 text-primary">
                  {form.new_emotion_intensity < form.emotion_intensity
                    ? `Your intensity dropped from ${form.emotion_intensity} to ${form.new_emotion_intensity} — great work.`
                    : `Your intensity went from ${form.emotion_intensity} to ${form.new_emotion_intensity}. That's okay — challenging thoughts takes practice.`}
                </p>
              )}
            </div>
          )}

          {currentStep.type === "balanced" && (
            <div className="space-y-3">
              <textarea
                value={form.balanced_thought}
                onChange={(e) => update("balanced_thought", e.target.value)}
                placeholder={currentStep.placeholder}
                className="pp-input min-h-[120px] resize-none"
              />
              <button
                onClick={generateBalancedThought}
                disabled={generating}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-secondary text-secondary-foreground hover:opacity-80 transition text-sm disabled:opacity-50"
              >
                {generating ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
                {generating ? "Generating..." : "Suggest a balanced thought"}
              </button>
            </div>
          )}

          {currentStep.key === "automatic_thought" && (
            <div className="mt-4">
              <button
                onClick={analyzeThought}
                disabled={analyzing || !form.automatic_thought.trim()}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-secondary text-secondary-foreground hover:opacity-80 transition text-sm disabled:opacity-50"
              >
                {analyzing ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
                {analyzing ? "Analyzing..." : "Identify cognitive distortions"}
              </button>
              {distortions && (
                <div className="mt-3 space-y-2">
                  {distortions.length > 0 ? (
                    distortions.map((d, i) => (
                      <div key={i} className="p-3 rounded-xl bg-amber-500/5 border border-amber-500/20">
                        <p className="text-sm font-medium text-amber-700">{d.name}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{d.explanation}</p>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      No clear distortions detected — but that doesn't mean the thought is accurate. Continue to examine the evidence.
                    </p>
                  )}
                </div>
              )}
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      <div className="flex justify-between mt-6">
        <button
          onClick={() => (step === 0 ? onCancel() : setStep(step - 1))}
          className="flex items-center gap-1 px-4 py-2 rounded-xl text-sm text-muted-foreground hover:text-foreground transition"
        >
          <ChevronLeft size={16} /> {step === 0 ? "Cancel" : "Back"}
        </button>
        {isLastStep ? (
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 px-5 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition disabled:opacity-50"
          >
            {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
            {saving ? "Saving..." : "Save Thought Record"}
          </button>
        ) : (
          <button
            onClick={() => setStep(step + 1)}
            disabled={!canProceed}
            className="flex items-center gap-1 px-5 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition disabled:opacity-50"
          >
            Next <ChevronRight size={16} />
          </button>
        )}
      </div>
    </div>
  );
}

function IntensitySlider({ value, onChange }) {
  return (
    <div>
      <div className="flex justify-between items-center text-sm text-muted-foreground mb-2">
        <span>Not intense</span>
        <span className="font-heading text-2xl font-semibold text-foreground">{value}</span>
        <span>Very intense</span>
      </div>
      <input
        type="range"
        min="0"
        max="100"
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value))}
        className="w-full accent-primary"
      />
    </div>
  );
}