import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import {
  Activity, Gauge as GaugeIcon, Bell, ClipboardList, AlertTriangle, ShieldAlert,
  Moon, Zap, HeartPulse, Brain, TrendingDown, TrendingUp, CheckCircle2,
} from "lucide-react";

const ACCENT = "hsl(172 68% 34%)";
const ACCENT2 = "hsl(152 52% 38%)";
const ROSE = "hsl(0 70% 50%)";
const AMBER = "hsl(30 85% 58%)";
const BLUE = "hsl(200 55% 42%)";

const CLIENTS = [
  {
    name: "Jordan M.",
    status: "Improving",
    barometer: 68,
    trendDir: "up",
    vitals: [
      { label: "Mood", value: 74, icon: HeartPulse, color: ACCENT2 },
      { label: "Sleep", value: 7.5, unit: "h", icon: Moon, color: BLUE, max: 10 },
      { label: "Stress", value: 4, icon: Zap, color: AMBER, max: 10 },
      { label: "Anxiety", value: 5, icon: Brain, color: ACCENT, max: 10 },
    ],
    trend: [
      { month: "Mar", gad7: 16, phq9: 19, pcl5: 34 },
      { month: "Apr", gad7: 14, phq9: 17, pcl5: 31 },
      { month: "May", gad7: 12, phq9: 14, pcl5: 28 },
      { month: "Jun", gad7: 10, phq9: 11, pcl5: 25 },
      { month: "Jul", gad7: 8, phq9: 9, pcl5: 22 },
      { month: "Aug", gad7: 6, phq9: 7, pcl5: 19 },
    ],
    alerts: [
      { time: "2d ago", type: "good", icon: CheckCircle2, color: ACCENT2, text: "Completed PHQ-9 — score dropped to 7 (mild)" },
      { time: "5d ago", type: "good", icon: TrendingDown, color: ACCENT2, text: "Behavior activation streak: 5 days" },
      { time: "1w ago", type: "info", icon: ClipboardList, color: ACCENT, text: "Homework 'Thought record' marked complete" },
    ],
    assessments: [
      { test: "PHQ-9", score: 7, severity: "Mild", color: ACCENT2, date: "Aug 2" },
      { test: "GAD-7", score: 6, severity: "Mild", color: ACCENT2, date: "Aug 2" },
      { test: "WHO-5", score: 68, severity: "Good", color: ACCENT, date: "Jul 28" },
      { test: "PCL-5", score: 19, severity: "Low", color: ACCENT2, date: "Jul 21" },
    ],
  },
  {
    name: "Casey R.",
    status: "At risk",
    barometer: 31,
    trendDir: "down",
    vitals: [
      { label: "Mood", value: 22, icon: HeartPulse, color: ROSE },
      { label: "Sleep", value: 4, unit: "h", icon: Moon, color: ROSE, max: 10 },
      { label: "Stress", value: 9, icon: Zap, color: ROSE, max: 10 },
      { label: "Anxiety", value: 8, icon: Brain, color: ROSE, max: 10 },
    ],
    trend: [
      { month: "Mar", gad7: 12, phq9: 14, pcl5: 28 },
      { month: "Apr", gad7: 15, phq9: 17, pcl5: 30 },
      { month: "May", gad7: 17, phq9: 19, pcl5: 33 },
      { month: "Jun", gad7: 19, phq9: 21, pcl5: 36 },
      { month: "Jul", gad7: 20, phq9: 22, pcl5: 38 },
      { month: "Aug", gad7: 21, phq9: 23, pcl5: 39 },
    ],
    alerts: [
      { time: "12m ago", type: "critical", icon: ShieldAlert, color: ROSE, text: "High-risk symptom logged — anxiety 8/10" },
      { time: "1h ago", type: "critical", icon: AlertTriangle, color: ROSE, text: "Crisis plan updated by client" },
      { time: "3h ago", type: "critical", icon: ShieldAlert, color: ROSE, text: "Self-harm item endorsed on functional check-in" },
    ],
    assessments: [
      { test: "PHQ-9", score: 23, severity: "Severe", color: ROSE, date: "Aug 8" },
      { test: "GAD-7", score: 21, severity: "Severe", color: ROSE, date: "Aug 8" },
      { test: "PCL-5", score: 39, severity: "High", color: AMBER, date: "Aug 5" },
    ],
  },
  {
    name: "Sam L.",
    status: "Stable",
    barometer: 74,
    trendDir: "up",
    vitals: [
      { label: "Mood", value: 80, icon: HeartPulse, color: ACCENT2 },
      { label: "Sleep", value: 8, unit: "h", icon: Moon, color: BLUE, max: 10 },
      { label: "Stress", value: 3, icon: Zap, color: ACCENT2, max: 10 },
      { label: "Anxiety", value: 3, icon: Brain, color: ACCENT, max: 10 },
    ],
    trend: [
      { month: "Mar", gad7: 9, phq9: 10, pcl5: 24 },
      { month: "Apr", gad7: 8, phq9: 9, pcl5: 22 },
      { month: "May", gad7: 7, phq9: 8, pcl5: 20 },
      { month: "Jun", gad7: 6, phq9: 7, pcl5: 19 },
      { month: "Jul", gad7: 6, phq9: 7, pcl5: 18 },
      { month: "Aug", gad7: 5, phq9: 6, pcl5: 17 },
    ],
    alerts: [
      { time: "4d ago", type: "good", icon: CheckCircle2, color: ACCENT2, text: "Goal 'Daily grounding' reached 30-day milestone" },
      { time: "1w ago", type: "info", icon: ClipboardList, color: ACCENT, text: "WHO-5 wellbeing score 80 (good)" },
    ],
    assessments: [
      { test: "GAD-7", score: 5, severity: "Mild", color: ACCENT2, date: "Aug 6" },
      { test: "PHQ-9", score: 6, severity: "Mild", color: ACCENT2, date: "Aug 6" },
      { test: "WHO-5", score: 80, severity: "Good", color: ACCENT, date: "Jul 30" },
    ],
  },
];

const TABS = [
  { key: "barometer", label: "Barometer", icon: GaugeIcon },
  { key: "trends", label: "Symptom Trends", icon: LineChart },
  { key: "alerts", label: "Safety Alerts", icon: Bell },
  { key: "assessments", label: "Assessments", icon: ClipboardList },
];

function Gauge({ value }) {
  const r = 70;
  const circ = 2 * Math.PI * r;
  const offset = circ - (value / 100) * circ;
  const color = value >= 60 ? ACCENT2 : value >= 40 ? AMBER : ROSE;
  return (
    <div className="relative w-44 h-44 shrink-0">
      <svg className="w-full h-full -rotate-90" viewBox="0 0 160 160">
        <circle cx="80" cy="80" r={r} fill="none" stroke="hsl(var(--border))" strokeWidth="12" />
        <motion.circle
          cx="80" cy="80" r={r} fill="none" stroke={color} strokeWidth="12" strokeLinecap="round"
          strokeDasharray={circ}
          initial={{ strokeDashoffset: circ }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 0.9, ease: "easeOut" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <motion.span
          key={value}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="font-heading text-4xl font-bold"
          style={{ color }}
        >
          {Math.round(value)}
        </motion.span>
        <span className="text-[11px] text-muted-foreground uppercase tracking-wider mt-0.5">Wellbeing</span>
      </div>
    </div>
  );
}

function VitalBar({ v }) {
  const max = v.max || 100;
  const pct = Math.min(100, (v.value / max) * 100);
  const Icon = v.icon;
  return (
    <div className="flex items-center gap-2.5">
      <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: `${v.color}1a` }}>
        <Icon size={15} style={{ color: v.color }} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex justify-between text-xs mb-1">
          <span className="text-muted-foreground">{v.label}</span>
          <span className="font-medium">{v.value}{v.unit || ""}</span>
        </div>
        <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
          <motion.div className="h-full rounded-full" style={{ background: v.color }}
            initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.7, ease: "easeOut" }} />
        </div>
      </div>
    </div>
  );
}

function BarometerView({ client }) {
  return (
    <div className="flex flex-col sm:flex-row gap-6 items-center">
      <Gauge value={client.barometer} />
      <div className="grid grid-cols-2 gap-3 flex-1 w-full">
        {client.vitals.map((v, i) => (
          <motion.div key={v.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 + i * 0.08 }}>
            <VitalBar v={v} />
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function TrendsView({ client }) {
  const [show, setShow] = useState({ gad7: true, phq9: true, pcl5: true });
  const series = [
    { key: "gad7", label: "GAD-7", color: ACCENT },
    { key: "phq9", label: "PHQ-9", color: BLUE },
    { key: "pcl5", label: "PCL-5", color: AMBER },
  ];
  return (
    <div className="w-full">
      <div className="flex gap-2 mb-3">
        {series.map((s) => (
          <button
            key={s.key}
            onClick={() => setShow((p) => ({ ...p, [s.key]: !p[s.key] }))}
            className="px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5"
            style={show[s.key]
              ? { background: `${s.color}1a`, color: s.color, border: `1px solid ${s.color}40` }
              : { background: "hsl(var(--secondary))", color: "hsl(var(--muted-foreground))", border: "1px solid transparent" }}
          >
            <span className="w-2 h-2 rounded-full" style={{ background: s.color }} />
            {s.label}
          </button>
        ))}
      </div>
      <div className="h-52 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={client.trend} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
            <XAxis dataKey="month" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ fontSize: 12, borderRadius: 12, border: "1px solid hsl(var(--border))" }} />
            {series.filter((s) => show[s.key]).map((s) => (
              <Line key={s.key} type="monotone" dataKey={s.key} stroke={s.color} strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 5 }} />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function AlertsView({ client }) {
  return (
    <div className="space-y-2.5 w-full">
      {client.alerts.map((a, i) => {
        const Icon = a.icon;
        return (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="flex items-start gap-3 p-3 rounded-xl"
            style={{ background: `${a.color}0d`, border: `1px solid ${a.color}26` }}
          >
            <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: `${a.color}1a` }}>
              <Icon size={16} style={{ color: a.color }} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm text-foreground/90">{a.text}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{a.time} · auto-notified therapist</p>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}

function AssessmentsView({ client }) {
  return (
    <div className="w-full">
      <div className="space-y-2">
        {client.assessments.map((a, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className="flex items-center gap-3 p-3 rounded-xl bg-secondary/40"
          >
            <span className="px-2.5 py-1 rounded-md text-xs font-bold" style={{ background: `${a.color}1a`, color: a.color }}>{a.test}</span>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">{a.severity}</p>
              <p className="text-xs text-muted-foreground">{a.date}</p>
            </div>
            <span className="font-heading text-2xl font-semibold" style={{ color: a.color }}>{a.score}</span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export default function InteractiveMonitoringSlide({ slide }) {
  const [clientIdx, setClientIdx] = useState(0);
  const [tab, setTab] = useState("barometer");
  const client = CLIENTS[clientIdx];
  const Icon = slide.icon;

  return (
    <div className="flex flex-col justify-center min-h-full max-w-5xl mx-auto px-4 md:px-2 w-full">
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.4 }}
        className="flex items-center gap-3 mb-3"
      >
        <div className="w-11 h-11 rounded-2xl flex items-center justify-center" style={{ background: `${ACCENT}1a` }}>
          <Icon size={22} style={{ color: ACCENT }} />
        </div>
        <span className="text-sm font-semibold tracking-widest uppercase" style={{ color: ACCENT }}>{slide.eyebrow}</span>
      </motion.div>

      <motion.h2
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.12 }}
        className="font-heading text-2xl md:text-4xl font-bold mb-1.5 leading-[1.1]"
      >
        {slide.title}
      </motion.h2>
      <motion.p
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="text-sm md:text-base text-muted-foreground mb-4 max-w-2xl"
      >
        {slide.body}
      </motion.p>

      {/* Client switcher */}
      <div className="flex flex-wrap gap-2 mb-3">
        {CLIENTS.map((c, i) => {
          const active = i === clientIdx;
          const dot = c.barometer >= 60 ? ACCENT2 : c.barometer >= 40 ? AMBER : ROSE;
          return (
            <button
              key={c.name}
              onClick={() => setClientIdx(i)}
              className="px-3 py-2 rounded-xl text-sm font-medium transition flex items-center gap-2"
              style={active
                ? { background: "hsl(var(--card))", border: `1px solid ${ACCENT}66`, boxShadow: "0 1px 3px rgba(0,0,0,0.05)" }
                : { background: "hsl(var(--secondary))", border: "1px solid transparent", color: "hsl(var(--muted-foreground))" }}
            >
              <span className="w-2 h-2 rounded-full" style={{ background: dot }} />
              {c.name}
              <span className="text-xs opacity-70">· {c.status}</span>
            </button>
          );
        })}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-3 border-b border-border/60 overflow-x-auto pp-scroll-hide">
        {TABS.map((t) => {
          const TabIcon = t.icon;
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium transition relative shrink-0"
              style={{ color: active ? ACCENT : "hsl(var(--muted-foreground))" }}
            >
              <TabIcon size={15} />
              {t.label}
              {active && (
                <motion.div layoutId="tab-underline" className="absolute bottom-[-1px] left-0 right-0 h-0.5 rounded-full" style={{ background: ACCENT }} />
              )}
            </button>
          );
        })}
      </div>

      {/* Panel */}
      <div className="pp-card p-5 min-h-[230px] flex items-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={`${clientIdx}-${tab}`}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.28 }}
            className="w-full"
          >
            {tab === "barometer" && <BarometerView client={client} />}
            {tab === "trends" && <TrendsView client={client} />}
            {tab === "alerts" && <AlertsView client={client} />}
            {tab === "assessments" && <AssessmentsView client={client} />}
          </motion.div>
        </AnimatePresence>
      </div>

      <p className="text-xs text-muted-foreground text-center mt-2 flex items-center justify-center gap-1.5">
        <Activity size={12} style={{ color: ACCENT }} />
        Tap a client or tab to explore live — this is the same view your therapists get, in real time.
      </p>
    </div>
  );
}