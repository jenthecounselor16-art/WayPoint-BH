import React, { useState, useEffect } from "react";
import { Outlet, Link, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import {
  Home, LayoutDashboard, BookCheck, Heart, Gauge, Activity, Wrench, Bot,
  ShieldAlert, Lightbulb, ClipboardCheck, Compass, Sparkles, Target, Trophy,
  ListChecks, Building2, Users, TrendingUp, Stethoscope, Library, UserCheck,
  Rocket, BarChart3, LineChart, Settings, LogOut, LogIn, BookOpen, Pencil,
  Check, X, Phone, Menu, CreditCard,
} from "lucide-react";
import DemoBanner from "@/components/DemoBanner";
import DemoSurveyModal from "@/components/DemoSurveyModal";
import { getDemoView, onDemoViewChange } from "@/lib/demoView";
import { trackDemoFeature, isDemoParticipant } from "@/lib/demoTracking";

const CLIENT_NAV = [
  { label: "Home", path: "/", icon: Home },
  { label: "My Portal", path: "/client-portal", icon: LayoutDashboard },
  { label: "Homework", path: "/homework", icon: BookCheck },
  { label: "Emotion Wheel", path: "/emotions", icon: Heart },
  { label: "Nervous System", path: "/dashboard", icon: Gauge },
  { label: "Function Check-in", path: "/functional-impairment", icon: Activity },
  { label: "Coping Toolbox", path: "/toolbox", icon: Wrench },
  { label: "AI Coach", path: "/coach", icon: Bot },
  { label: "Crisis Plan", path: "/crisis-plan", icon: ShieldAlert },
  { label: "Thought Record", path: "/cbt-journal", icon: Lightbulb },
  { label: "Assessments", path: "/assessments", icon: ClipboardCheck },
  { label: "Values", path: "/values-inventory", icon: Compass },
  { label: "Behavior Activation", path: "/behavior-activation", icon: Sparkles },
  { label: "Therapy Goals", path: "/therapy-goals", icon: Target },
  { label: "Badges", path: "/badges", icon: Trophy },
  { label: "Setup Guide", path: "/assessment-setup-guide", icon: ListChecks },
];

const ADMIN_NAV = [
  { label: "Home", path: "/", icon: Home },
  { label: "Organization", path: "/organization", icon: Building2 },
  { label: "Demo Engagement", path: "/demo-engagement", icon: Users },
];

const SUPERVISOR_NAV = [
  { label: "Home", path: "/", icon: Home },
  { label: "Organization", path: "/organization", icon: Building2 },
  { label: "Assessment Charts", path: "/assessment-charts", icon: BarChart3 },
  { label: "Insights", path: "/insights", icon: TrendingUp },
];

const THERAPIST_NAV = [
  { label: "Home", path: "/", icon: Home },
  { label: "Therapist Portal", path: "/therapist", icon: Stethoscope },
  { label: "Care Library", path: "/care-library", icon: Library },
  { label: "Registrations", path: "/client-registrations", icon: UserCheck },
  { label: "Onboarding", path: "/onboarding-guide", icon: Rocket },
  { label: "Assessment Charts", path: "/assessment-charts", icon: BarChart3 },
  { label: "Progress", path: "/progress-dashboard", icon: LineChart },
  { label: "Insights", path: "/insights", icon: TrendingUp },
];

function getNavItems(role) {
  if (role === "admin") return ADMIN_NAV;
  if (role === "supervisor") return SUPERVISOR_NAV;
  if (role === "therapist") return THERAPIST_NAV;
  return CLIENT_NAV;
}

export default function Layout() {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [editName, setEditName] = useState(false);
  const [nameValue, setNameValue] = useState("");
  const [savingName, setSavingName] = useState(false);
  const [editPractice, setEditPractice] = useState(false);
  const [practice, setPractice] = useState({ practice_name: "", practice_address: "", npi: "" });
  const [savingPractice, setSavingPractice] = useState(false);
  const [demoUser, setDemoUser] = useState(false);
  const [isParent, setIsParent] = useState(false);
  const [demoView, setDemoViewState] = useState(() => getDemoView());

  useEffect(() => onDemoViewChange(setDemoViewState), []);
  useEffect(() => { setSidebarOpen(false); setShowSettings(false); }, [location.pathname]);

  const displayName = user?.display_name || user?.full_name || user?.email || "";

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        if (me?.email) {
          setDemoUser(await isDemoParticipant(me.email));
          try {
            const links = await base44.entities.Parent.filter({ parent_email: me.email, status: "active" });
            if (links?.length) setIsParent(true);
          } catch {}
        }
      } catch {}
    })();
  }, []);

  useEffect(() => {
    if (demoUser && user?.email) trackDemoFeature(location.pathname, user.email);
  }, [location.pathname, demoUser, user]);

  const isAdmin = user?.role === "admin" || user?.account_type === "admin";
  const isSupervisor = user?.role === "supervisor" || user?.account_type === "supervisor";
  const isTherapist = user?.role === "therapist" || user?.account_type === "therapist";
  const isClinician = isAdmin || isSupervisor || isTherapist;
  const role = isAdmin ? "admin" : isSupervisor ? "supervisor" : isTherapist ? "therapist" : "client";
  const showClientNav = demoUser && isClinician && demoView === "client";
  // Clients (and parents, and demo clinicians previewing the client view) get the
  // mobile-app shell. Real clinicians/corporate/enterprise get the desktop sidebar.
  const useClientShell = !isClinician || showClientNav;
  const navItems = showClientNav
    ? CLIENT_NAV
    : (isParent ? [...getNavItems(role), { label: "Parent Portal", path: "/parent-portal", icon: Users }] : getNavItems(role));

  async function saveName() {
    if (!nameValue.trim()) return;
    setSavingName(true);
    try {
      await base44.auth.updateMe({ display_name: nameValue.trim() });
      setUser({ ...user, display_name: nameValue.trim() });
      setEditName(false);
    } catch {}
    setSavingName(false);
  }

  async function savePractice() {
    setSavingPractice(true);
    try {
      const next = {
        practice_name: practice.practice_name.trim(),
        practice_address: practice.practice_address.trim(),
        npi: practice.npi.trim(),
      };
      await base44.auth.updateMe(next);
      setUser({ ...user, ...next });
      setEditPractice(false);
    } catch {}
    setSavingPractice(false);
  }

  // Shared nav list (used in both the desktop sidebar and the mobile drawer)
  const navList = (
    <div className="space-y-0.5">
      {navItems.map((item) => {
        const active = location.pathname === item.path;
        const Icon = item.icon;
        return (
          <Link
            key={item.path}
            to={item.path}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all
              ${active ? "bg-primary text-primary-foreground shadow-sm" : "text-foreground/70 hover:text-foreground hover:bg-secondary/60"}`}
          >
            <Icon size={18} className="shrink-0" />
            <span className="truncate">{item.label}</span>
          </Link>
        );
      })}
    </div>
  );

  // Shared user card + settings dropdown (used in sidebar bottom and drawer bottom)
  const userCardBlock = (
    <div className="relative border-t border-border/60 p-3">
      {showSettings && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setShowSettings(false)} />
          <div className="absolute bottom-full left-3 right-3 mb-2 z-50 pp-card p-2 shadow-lg">
            {user && (
              <div className="px-3 py-2 mb-1 border-b border-border/60">
                {editName ? (
                  <div className="flex items-center gap-1.5">
                    <input
                      value={nameValue}
                      onChange={(e) => setNameValue(e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter") saveName(); if (e.key === "Escape") setEditName(false); }}
                      className="pp-input !py-1.5 !px-2 text-sm flex-1"
                      autoFocus
                    />
                    <button onClick={saveName} disabled={savingName || !nameValue.trim()} className="p-1.5 rounded-md bg-primary/10 text-primary hover:bg-primary/20 transition disabled:opacity-50 shrink-0" title="Save name">
                      <Check size={14} />
                    </button>
                    <button onClick={() => setEditName(false)} className="p-1.5 rounded-md bg-secondary text-secondary-foreground hover:opacity-80 transition shrink-0" title="Cancel">
                      <X size={14} />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-medium truncate">{displayName}</p>
                    <button onClick={() => { setNameValue(user.display_name || user.full_name || ""); setEditName(true); }} className="p-1 rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 transition shrink-0" title="Edit name">
                      <Pencil size={13} />
                    </button>
                  </div>
                )}
                <p className="text-xs text-muted-foreground truncate mt-0.5">{user.email}</p>
              </div>
            )}
            {isClinician && (
              <div className="px-3 py-2 mb-1 border-b border-border/60">
                {editPractice ? (
                  <div className="space-y-2">
                    <input value={practice.practice_name} onChange={(e) => setPractice({ ...practice, practice_name: e.target.value })} placeholder="Practice name" className="pp-input !py-1.5 !px-2 text-sm" />
                    <input value={practice.practice_address} onChange={(e) => setPractice({ ...practice, practice_address: e.target.value })} placeholder="Practice address" className="pp-input !py-1.5 !px-2 text-sm" />
                    <input value={practice.npi} onChange={(e) => setPractice({ ...practice, npi: e.target.value })} placeholder="NPI number" className="pp-input !py-1.5 !px-2 text-sm" />
                    <div className="flex items-center gap-1.5">
                      <button onClick={savePractice} disabled={savingPractice} className="flex-1 py-1.5 rounded-md bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition disabled:opacity-50">
                        {savingPractice ? "Saving…" : "Save"}
                      </button>
                      <button onClick={() => setEditPractice(false)} className="p-1.5 rounded-md bg-secondary text-secondary-foreground hover:opacity-80 transition shrink-0" title="Cancel">
                        <X size={14} />
                      </button>
                    </div>
                  </div>
                ) : (
                  <button onClick={() => { setPractice({ practice_name: user.practice_name || "", practice_address: user.practice_address || "", npi: user.npi || "" }); setEditPractice(true); }} className="w-full flex items-center justify-between gap-2 text-sm transition hover:bg-secondary/50 -mx-1 px-1 py-1 rounded-md">
                    <span className="text-muted-foreground truncate">{user.practice_name || "Practice details"}</span>
                    <Pencil size={13} className="text-muted-foreground shrink-0" />
                  </button>
                )}
              </div>
            )}
            <Link to="/references" onClick={() => setShowSettings(false)} className={`block px-3 py-2 rounded-lg text-sm transition flex items-center gap-2 ${location.pathname === "/references" ? "bg-primary/10 text-primary font-medium" : "hover:bg-secondary/50"}`}>
              <BookOpen size={14} /> References
            </Link>
            {isClinician && (
              <Link to="/billing" onClick={() => setShowSettings(false)} className={`block px-3 py-2 rounded-lg text-sm transition flex items-center gap-2 ${location.pathname === "/billing" ? "bg-primary/10 text-primary font-medium" : "hover:bg-secondary/50"}`}>
                <CreditCard size={14} /> Billing &amp; Plans
              </Link>
            )}
            <div className="h-px bg-border my-1" />
            {user ? (
              <button
                onClick={() => base44.auth.logout()}
                className="block w-full text-left px-3 py-2 rounded-lg text-sm transition hover:bg-secondary/50 flex items-center gap-2"
              >
                <LogOut size={14} /> Log out
              </button>
            ) : (
              <Link
                to="/login"
                onClick={() => setShowSettings(false)}
                className="block px-3 py-2 rounded-lg text-sm transition hover:bg-secondary/50 flex items-center gap-2"
              >
                <LogIn size={14} /> Log in
              </Link>
            )}
          </div>
        </>
      )}
      <button
        onClick={() => setShowSettings(!showSettings)}
        className="w-full flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-secondary/60 transition text-left"
      >
        <div className="w-9 h-9 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 text-sm font-semibold uppercase">
          {displayName ? displayName[0] : "?"}
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium truncate">{displayName || "Not signed in"}</p>
          {user?.email && <p className="text-xs text-muted-foreground truncate">{user.email}</p>}
        </div>
        <Settings size={16} className="text-muted-foreground shrink-0" />
      </button>
    </div>
  );

  // ── Client mobile-app shell ───────────────────────────────────────────
  if (useClientShell) {
    return (
      <div className="min-h-screen pp-gradient-bg lg:py-6">
        {sidebarOpen && (
          <div className="fixed inset-0 z-40 bg-black/40 print:hidden" onClick={() => setSidebarOpen(false)} />
        )}
        {/* Mobile drawer */}
        <aside className={`fixed inset-y-0 left-0 z-50 w-72 bg-card border-r border-border/60 flex flex-col transform transition-transform duration-300 print:hidden
          ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`}>
          <div className="h-16 px-5 flex items-center border-b border-border/60 shrink-0">
            <Link to="/" className="font-display text-2xl font-bold text-primary">WayPoint</Link>
            <button onClick={() => setSidebarOpen(false)} className="ml-auto p-1.5 rounded-lg hover:bg-secondary/60 transition" aria-label="Close menu">
              <X size={18} />
            </button>
          </div>
          <nav className="flex-1 overflow-y-auto px-3 py-4 pp-scroll-hide">{navList}</nav>
          {userCardBlock}
        </aside>

        {/* Phone-width centered column */}
        <div className="max-w-xl mx-auto min-h-screen bg-background lg:min-h-[calc(100vh-3rem)] lg:rounded-[2rem] lg:shadow-2xl flex flex-col">
          <header className="sticky top-0 lg:static z-30 bg-card/95 backdrop-blur border-b border-border/60 print:hidden">
            <div className="px-4 py-3 flex items-center justify-between">
              <button onClick={() => setSidebarOpen(true)} className="p-2 -ml-2 rounded-lg hover:bg-secondary/60 transition" aria-label="Open menu">
                <Menu size={20} />
              </button>
              <Link to="/" className="font-display text-xl font-bold text-primary">WayPoint</Link>
              <div className="w-9" />
            </div>
          </header>

          <DemoBanner user={user} />
          <DemoSurveyModal user={user} />

          <main className="flex-1">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
            >
              <Outlet />
            </motion.div>
          </main>

          <footer className="px-4 py-6 print:hidden">
            <div className="p-4 rounded-2xl border-2 border-primary/25 bg-primary/5 text-center">
              <div className="flex items-center justify-center gap-2 text-primary mb-1">
                <Phone size={15} />
                <span className="text-xs font-semibold">In crisis?</span>
              </div>
              <p className="text-xs text-foreground/60 leading-relaxed">
                Call or text <span className="font-bold text-foreground">988</span> — Suicide &amp; Crisis Lifeline, 24/7.
              </p>
            </div>
          </footer>
        </div>
      </div>
    );
  }

  // ── Clinician / corporate / enterprise desktop shell ──────────────────
  return (
    <div className="min-h-screen pp-gradient-bg">
      {/* Mobile top bar */}
      <header className="lg:hidden sticky top-0 z-30 bg-card/95 backdrop-blur border-b border-border/60 print:hidden">
        <div className="px-4 py-3 flex items-center justify-between">
          <button onClick={() => setSidebarOpen(true)} className="p-2 -ml-2 rounded-lg hover:bg-secondary/60 transition" aria-label="Open menu">
            <Menu size={20} />
          </button>
          <Link to="/" className="font-display text-xl font-bold text-primary">WayPoint</Link>
          <div className="w-9" />
        </div>
      </header>

      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-black/40 lg:hidden print:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Desktop sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-card border-r border-border/60 flex flex-col transform transition-transform duration-300 lg:translate-x-0 print:hidden
        ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="h-16 px-5 flex items-center border-b border-border/60 shrink-0">
          <Link to="/" className="font-display text-2xl font-bold text-primary">WayPoint</Link>
          <button onClick={() => setSidebarOpen(false)} className="ml-auto lg:hidden p-1.5 rounded-lg hover:bg-secondary/60 transition" aria-label="Close menu">
            <X size={18} />
          </button>
        </div>
        <nav className="flex-1 overflow-y-auto px-3 py-4 pp-scroll-hide">{navList}</nav>
        {userCardBlock}
      </aside>

      <div className="lg:pl-64 flex flex-col min-h-screen">
        <DemoBanner user={user} />
        <DemoSurveyModal user={user} />

        <main className="flex-1">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          >
            <Outlet />
          </motion.div>
        </main>

        <footer className="w-full px-6 lg:px-10 py-8 print:hidden">
          <div className="max-w-7xl mx-auto">
            <div className="flex gap-6 justify-center mb-6 text-sm">
              <Link to="/about" className="text-muted-foreground hover:text-foreground transition">About</Link>
              <Link to="/contact" className="text-muted-foreground hover:text-foreground transition">Contact</Link>
            </div>
            <div className="p-5 rounded-2xl border-2 border-primary/25 bg-primary/5 text-center">
              <div className="flex items-center justify-center gap-2 text-primary mb-1.5">
                <Phone size={16} />
                <span className="text-sm font-semibold">In crisis?</span>
              </div>
              <p className="text-sm text-foreground/60 leading-relaxed">
                Call or text <span className="font-bold text-foreground">988</span> for the Suicide &amp; Crisis Lifeline, available 24/7.
              </p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}