import React from "react";
import { ShieldCheck, Lock, UserCheck, FileCheck, Eye, Users } from "lucide-react";

// Trust/privacy section for the demo signup pages. Wording is deliberately
// accurate: it describes the safeguards this app enforces (row-level data
// isolation, consent gates, TLS, audit logging) without claiming a formal
// HIPAA certification — which doesn't exist. Reusable on any public page.
export default function HIPAAAssurance({ compact = false }) {
  if (compact) {
    return (
      <div className="pp-card p-5 border-primary/20 bg-primary/[0.03]">
        <div className="flex items-center gap-2 mb-3">
          <ShieldCheck size={18} className="text-primary" />
          <h3 className="font-heading text-lg font-semibold">Your privacy, protected</h3>
        </div>
        <ul className="space-y-2.5 text-sm text-muted-foreground">
          <li className="flex items-start gap-2.5">
            <Lock size={15} className="text-primary shrink-0 mt-0.5" /> Only you and your therapist can see your entries — enforced at the database level, for every single record.
          </li>
          <li className="flex items-start gap-2.5">
            <UserCheck size={15} className="text-primary shrink-0 mt-0.5" /> Parents or other providers only see your progress if you approve access first.
          </li>
          <li className="flex items-start gap-2.5">
            <Eye size={15} className="text-primary shrink-0 mt-0.5" /> Your entries stay with your care team — never sold, never shared beyond it.
          </li>
        </ul>
      </div>
    );
  }

  return (
    <div className="pp-card p-5 md:p-6 mb-8 border-primary/20 bg-primary/[0.03]">
      <div className="flex items-center gap-2.5 mb-4">
        <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <ShieldCheck size={20} className="text-primary" />
        </div>
        <div>
          <h3 className="font-heading text-lg font-semibold">Private by design, built for clinical work</h3>
          <p className="text-xs text-muted-foreground">How WayPoint protects client information every step of the way.</p>
        </div>
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="p-3.5 rounded-xl bg-card">
          <p className="flex items-center gap-1.5 text-sm font-medium mb-1"><Lock size={14} className="text-primary" /> Isolated client records</p>
          <p className="text-xs text-muted-foreground leading-relaxed">
            A client's data is visible only to them and their linked clinician(s) — enforced at the database level on every record, so no other user can ever see it.
          </p>
        </div>
        <div className="p-3.5 rounded-xl bg-card">
          <p className="flex items-center gap-1.5 text-sm font-medium mb-1"><UserCheck size={14} className="text-primary" /> Consent-first sharing</p>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Parents and co-providers can only view a client's progress after the client approves access. Clients verify their identity when joining a clinician's care.
          </p>
        </div>
        <div className="p-3.5 rounded-xl bg-card">
          <p className="flex items-center gap-1.5 text-sm font-medium mb-1"><FileCheck size={14} className="text-primary" /> Encrypted &amp; accountable</p>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Every session runs over an encrypted connection. Clinical exports live behind your login, and sensitive actions are logged for accountability.
          </p>
        </div>
        <div className="p-3.5 rounded-xl bg-card">
          <p className="flex items-center gap-1.5 text-sm font-medium mb-1"><Users size={14} className="text-primary" /> Your demo is a sandbox</p>
          <p className="text-xs text-muted-foreground leading-relaxed">
            During your trial, invite fictional clients or use yourself as the test client — nothing is shared across accounts, ever.
          </p>
        </div>
      </div>
      <p className="text-xs text-muted-foreground mt-4">
        Have compliance questions before subscribing? <span className="text-primary font-medium">Contact us</span> — we'll walk you through our safeguards and answer your security review.
      </p>
    </div>
  );
}