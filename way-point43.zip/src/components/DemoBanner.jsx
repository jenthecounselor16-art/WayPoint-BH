import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Sparkles, Clock, MessageSquareHeart } from "lucide-react";

export default function DemoBanner({ user }) {
  const [participant, setParticipant] = useState(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!user?.email) { setLoaded(true); return; }
    let cancelled = false;
    (async () => {
      try {
        const list = await base44.entities.DemoParticipant.filter({ email: user.email }, "-created_date", 1);
        if (!cancelled) setParticipant(list?.[0] || null);
      } catch (e) {
        // Read may be restricted; ignore silently
      }
      if (!cancelled) setLoaded(true);
    })();
    return () => { cancelled = true; };
  }, [user?.email]);

  if (!loaded || !participant) return null;

  const now = Date.now();
  const expires = participant.expires_at ? new Date(participant.expires_at).getTime() : 0;
  const expired = now > expires;
  const daysLeft = Math.max(0, Math.ceil((expires - now) / (24 * 60 * 60 * 1000)));

  if (expired) {
    return (
      <div className="max-w-5xl mx-auto px-4 pt-4">
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 flex items-start gap-3">
          <Clock className="text-amber-600 shrink-0 mt-0.5" size={20} />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-amber-700">Your 7-day demo has ended</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Thanks for trying WayPoint! We'd love your honest feedback — email it to jenthecounselor16@gmail.com — or subscribe to keep full clinician access.
            </p>
            <div className="flex flex-wrap gap-2 mt-2.5">
              <Link to="/demo-survey" className="shrink-0 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition flex items-center gap-1.5">
                <MessageSquareHeart size={14} /> Share feedback
              </Link>
              <Link to="/billing" className="shrink-0 px-4 py-2 rounded-lg bg-secondary text-secondary-foreground text-sm font-medium hover:opacity-80 transition">
                View plans
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 pt-4">
      <div className="rounded-xl border border-primary/30 bg-gradient-to-br from-primary/10 to-accent/10 p-4 flex items-start gap-3">
        <Sparkles className="text-primary shrink-0 mt-0.5" size={20} />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-primary">
            7-day demo — {daysLeft} {daysLeft === 1 ? "day" : "days"} left
          </p>
          <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1.5">
            <MessageSquareHeart size={12} /> Use the app all 7 days, then email your honest feedback to jenthecounselor16@gmail.com — it directly shapes what we build next.
          </p>
        </div>
      </div>
    </div>
  );
}