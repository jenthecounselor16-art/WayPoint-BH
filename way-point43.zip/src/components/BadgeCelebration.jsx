import React, { useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { TIER_COLORS, TIER_GLOW } from "@/lib/badges";
import { celebrateBadge } from "@/lib/celebrate";

export default function BadgeCelebration({ badges, onClose }) {
  const firedRef = useRef(false);

  useEffect(() => {
    if (badges.length > 0 && !firedRef.current) {
      firedRef.current = true;
      celebrateBadge();
    }
    if (badges.length === 0) {
      firedRef.current = false;
    }
  }, [badges]);

  return (
    <AnimatePresence>
      {badges.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
        >
          <motion.div
            initial={{ scale: 0.8, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.8, y: 20 }}
            transition={{ type: "spring", stiffness: 200, damping: 20 }}
            onClick={(e) => e.stopPropagation()}
            className="bg-card rounded-3xl p-8 max-w-md w-full text-center shadow-2xl border border-border"
          >
            <p className="text-sm font-semibold uppercase tracking-widest text-primary mb-2">
              {badges.length > 1 ? "Badges Earned!" : "Badge Earned!"}
            </p>
            <div className="space-y-5 my-6">
              {badges.map((badge, i) => {
                const Icon = badge.icon;
                const color = TIER_COLORS[badge.tier];
                const glow = TIER_GLOW[badge.tier];
                return (
                  <motion.div
                    key={badge.key}
                    initial={{ scale: 0, rotate: -20 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ delay: 0.15 + i * 0.15, type: "spring", stiffness: 200 }}
                    className="flex flex-col items-center"
                  >
                    <div className="w-28 h-28 rounded-full flex items-center justify-center mb-2" style={{ background: `radial-gradient(circle, ${glow}, transparent)` }}>
                      <div className="w-20 h-20 rounded-full flex items-center justify-center border-4" style={{ borderColor: color, backgroundColor: `${color}15` }}>
                        <Icon size={36} style={{ color }} />
                      </div>
                    </div>
                    <h3 className="font-heading text-lg font-semibold">{badge.title}</h3>
                    <p className="text-sm text-muted-foreground">{badge.description}</p>
                    <span className="text-xs font-medium uppercase tracking-wider mt-1" style={{ color }}>{badge.tier}</span>
                  </motion.div>
                );
              })}
            </div>
            <button onClick={onClose} className="px-6 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition">
              Continue
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}