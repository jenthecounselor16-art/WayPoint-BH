import React, { useState, useEffect, useMemo } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { ASSESSMENTS } from "@/lib/assessments";
import { NEGATIVE_ITEMS, MAX_IMPAIRMENT } from "@/lib/functionalImpairment";
import { TrendingUp, Gauge, RefreshCw, Heart, Activity, Wrench, ClipboardList, Target } from "lucide-react";

function polarToCartesian(cx, cy, r, angleDeg) {
  const angleRad = (angleDeg * Math.PI) / 180;
  return { x: cx + r * Math.cos(angleRad), y: cy - r * Math.sin(angleRad) };
}

function describeArc(cx, cy, r, startAngle, endAngle) {
  const start = polarToCartesian(cx, cy, r, startAngle);
  const end = polarToCartesian(cx, cy, r, endAngle);
  const largeArcFlag = Math.abs(endAngle - startAngle) > 180 ? 1 : 0;
  const sweepFlag = startAngle > endAngle ? 1 : 0;
  return `M ${start.x} ${start.y} A ${r} ${r} 0 ${largeArcFlag} ${sweepFlag} ${end.x} ${end.y}`;
}

const SEGMENTS = [
  { from: 0, to: 30, color: "#D9534F", label: "Concerning" },
  { from: 30, to: 50, color: "#D4A055", label: "Needs Attention" },
  { from: 50, to: 75, color: "#1995A1", label: "Stable" },
  { from: 75, to: 100, color: "#7CB69D", label: "Thriving" },
];

function getSegment(score) {
  return SEGMENTS.find((s) => score >= s.from && score < s.to) || SEGMENTS[SEGMENTS.length - 1];
}

const ENGAGEMENT_WINDOW_DAYS = 30;

function withinDays(dateStr, days) {
  const t = new Date(dateStr).getTime();
  return Number.isFinite(t) && t >= Date.now() - days * 86400000;
}

function engagementScore(count, target) {
  if (target <= 0) return 0;
  return Math.min(100, (count / target) * 100);
}

export default function MentalHealthBarometer() {
  const [assessments, setAssessments] = useState([]);
  const [moods, setMoods] = useState([]);
  const [nervous, setNervous] = useState([]);
  const [copingFavorites, setCopingFavorites] = useState([]);
  const [functional, setFunctional] = useState([]);
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    (async () => {
      let me = null;
      try { me = await base44.auth.me(); } catch {}
      if (!me) { setLoading(false); return; }
      try {
        const [a, m, n, c, f, g] = await Promise.all([
          base44.entities.AssessmentResult.filter({ client_email: me.email }, "-created_date", 50),
          base44.entities.MoodEntry.filter({ created_by_id: me.id }, "-created_date", 100),
          base44.entities.NervousSystemMetric.filter({ client_email: me.email }, "-created_date", 100),
          base44.entities.CopingFavorite.filter({ created_by_id: me.id }, "-created_date", 100),
          base44.entities.FunctionalImpairment.filter({ client_email: me.email }, "-created_date", 50),
          base44.entities.TherapyGoal.filter({ client_email: me.email }, "-created_date", 100),
        ]);
        setAssessments(a || []);
        setMoods(m || []);
        setNervous(n || []);
        setCopingFavorites(c || []);
        setFunctional(f || []);
        setGoals(g || []);
      } catch (err) {
        console.error("Barometer fetch error:", err);
      }
      setLoading(false);
    })();
  }, [refreshKey]);

  useEffect(() => {
    const subs = [
      base44.entities.AssessmentResult.subscribe(() => setRefreshKey((k) => k + 1)),
      base44.entities.MoodEntry.subscribe(() => setRefreshKey((k) => k + 1)),
      base44.entities.NervousSystemMetric.subscribe(() => setRefreshKey((k) => k + 1)),
      base44.entities.CopingFavorite.subscribe(() => setRefreshKey((k) => k + 1)),
      base44.entities.FunctionalImpairment.subscribe(() => setRefreshKey((k) => k + 1)),
      base44.entities.TherapyGoal.subscribe(() => setRefreshKey((k) => k + 1)),
    ];
    return () => subs.forEach((u) => u && u());
  }, []);

  const data = useMemo(() => {
    // Assessment component — severe symptoms lower the score; improvement raises it.
    const latest = {};
    (assessments || []).forEach((a) => {
      if (!latest[a.test_type] || new Date(a.created_date) > new Date(latest[a.test_type].created_date)) {
        latest[a.test_type] = a;
      }
    });
    const latestList = Object.values(latest);
    let assessmentScore = null;
    if (latestList.length > 0) {
      const scores = latestList
        .map((a) => {
          const test = ASSESSMENTS[a.test_type];
          if (!test) return null;
          const maxScore = test.items.length * (test.scale.length - 1);
          const ratio = a.score / maxScore;
          // WHO5: higher wellbeing ratio -> higher score. All others: lower symptom ratio -> higher score.
          return a.test_type === "WHO5" ? ratio * 100 : (1 - ratio) * 100;
        })
        .filter((s) => s !== null);
      if (scores.length > 0) {
        assessmentScore = scores.reduce((a, b) => a + b, 0) / scores.length;
      }
    }

    // Coping skills — adopted coping tools (favorited).
    const copingCount = (copingFavorites || []).length;
    const copingScore = engagementScore(copingCount, 5);

    // Nervous system check-ins — wellbeing averaged across the last 7 days.
    // High anxiety/depression/stress and low energy lower the score.
    const recentNervous = (nervous || []).filter((x) => withinDays(x.created_date, 7));
    const nervousCount = recentNervous.length;
    let nervousScore = null;
    if (nervousCount > 0) {
      const perCheckin = recentNervous
        .map((x) => {
          const parts = [];
          [x.anxiety_level, x.depression_level, x.stress_level].forEach((v) => {
            if (Number.isFinite(v)) parts.push(((10 - v) / 9) * 100);
          });
          if (Number.isFinite(x.energy_level)) parts.push(((x.energy_level - 1) / 9) * 100);
          return parts.length ? parts.reduce((a, b) => a + b, 0) / parts.length : null;
        })
        .filter((v) => v !== null);
      if (perCheckin.length > 0) {
        nervousScore = perCheckin.reduce((a, b) => a + b, 0) / perCheckin.length;
      }
    }

    // Emotions log (last 30 days) — pleasant moods raise the score, unpleasant moods lower it.
    const recentMoods = (moods || []).filter((x) => withinDays(x.created_date, ENGAGEMENT_WINDOW_DAYS));
    const moodCount = recentMoods.length;
    let moodScore = null;
    if (moodCount > 0) {
      const pleasant = recentMoods.filter((x) => (x.emotion_path || x.emotion || "").split("/")[0].trim() === "happy").length;
      moodScore = (pleasant / moodCount) * 100;
    }

    // Functional impairment check-in — lower functioning lowers the score.
    const latestFunctional = (functional || [])
      .filter((x) => x.created_date)
      .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0] || null;
    let functionScore = null;
    if (latestFunctional) {
      const negSum = NEGATIVE_ITEMS.reduce(
        (sum, item) => sum + (Number(latestFunctional[item.key]) || 0),
        0
      );
      functionScore = (1 - negSum / MAX_IMPAIRMENT) * 100;
    }

    // Therapy goal completion — higher completion ratio raises the score.
    const totalGoals = (goals || []).length;
    const achievedGoals = (goals || []).filter((x) => x.status === "achieved").length;
    let goalScore = null;
    if (totalGoals > 0) {
      goalScore = (achievedGoals / totalGoals) * 100;
    }

    // Weighted overall — normalize over components that have data.
    const weights = {
      assessment: { value: assessmentScore, weight: 0.3 },
      function: { value: functionScore, weight: 0.2 },
      nervous: { value: nervousScore, weight: 0.2 },
      emotions: { value: moodScore, weight: 0.15 },
      goals: { value: goalScore, weight: 0.1 },
      coping: { value: copingScore, weight: 0.05 },
    };
    let weightedSum = 0;
    let weightSum = 0;
    Object.values(weights).forEach(({ value, weight }) => {
      if (value !== null && Number.isFinite(value)) {
        weightedSum += value * weight;
        weightSum += weight;
      }
    });
    const overall = weightSum > 0 ? weightedSum / weightSum : null;

    return {
      overall,
      assessmentScore,
      functionScore,
      goalScore,
      achievedGoals,
      totalGoals,
      copingScore,
      nervousScore,
      moodScore,
      copingCount,
      nervousCount,
      moodCount,
      latestList,
      hasData: overall !== null,
    };
  }, [assessments, moods, nervous, copingFavorites, functional, goals]);

  if (loading) {
    return (
      <div className="pp-card p-6 mb-8 flex items-center justify-center" style={{ minHeight: 180 }}>
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!data.hasData) {
    return (
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-6 mb-8 text-center">
        <Gauge className="mx-auto mb-3 text-muted-foreground/40" size={40} />
        <h2 className="font-heading text-xl font-semibold mb-1">Your Mental Health Barometer</h2>
        <p className="text-sm text-muted-foreground">
          Log an emotion, check in with your nervous system, save coping tools, or take an assessment to see your mental health snapshot here.
        </p>
      </motion.div>
    );
  }

  const score = Math.round(data.overall);
  const segment = getSegment(score);
  const needleAngle = 180 * (1 - score / 100);
  const needleEnd = polarToCartesian(150, 150, 95, needleAngle);

  const components = [];
  if (data.assessmentScore !== null) {
    components.push({
      icon: TrendingUp,
      color: "primary",
      label: "Assessment Score",
      sub: `${data.latestList.length} recent ${data.latestList.length === 1 ? "assessment" : "assessments"}`,
      value: Math.round(data.assessmentScore),
    });
  }
  if (data.functionScore !== null) {
    components.push({
      icon: ClipboardList,
      color: "accent",
      label: "Function Check-in",
      sub: "Latest functional impairment",
      value: Math.round(data.functionScore),
    });
  }
  if (data.goalScore !== null) {
    components.push({
      icon: Target,
      color: "primary",
      label: "Therapy Goals",
      sub: `${data.achievedGoals}/${data.totalGoals} achieved`,
      value: Math.round(data.goalScore),
    });
  }
  components.push({
    icon: Wrench,
    color: "accent",
    label: "Coping Skills",
    sub: `${data.copingCount} ${data.copingCount === 1 ? "tool" : "tools"} saved`,
    value: Math.round(data.copingScore),
  });
  if (data.nervousScore !== null) {
    components.push({
      icon: Activity,
      color: "primary",
      label: "Nervous System Check-in",
      sub: `${data.nervousCount} check-in${data.nervousCount === 1 ? "" : "s"} · 7-day avg`,
      value: Math.round(data.nervousScore),
    });
  }
  if (data.moodScore !== null) {
    components.push({
      icon: Heart,
      color: "accent",
      label: "Mood Balance",
      sub: `${data.moodCount} mood${data.moodCount === 1 ? "" : "s"} · 30-day`,
      value: Math.round(data.moodScore),
    });
  }

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-6 mb-8">
      <div className="flex items-center justify-between mb-1">
        <h2 className="font-heading text-xl font-semibold">Your Mental Health Barometer</h2>
        <button onClick={() => { setLoading(true); setRefreshKey((k) => k + 1); }} className="text-muted-foreground hover:text-primary transition" title="Refresh">
          <RefreshCw size={16} />
        </button>
      </div>
      <p className="text-sm text-muted-foreground mb-4">
        Combines your assessment scores, functional check-ins, nervous-system check-ins, mood balance, therapy goals, and coping skills. Severe assessment ratings (GAD-7, PHQ-9, PCL-5, BDI, BAI), impaired functioning, low check-in wellbeing, and unpleasant moods lower the score; it rises as symptoms ease, wellbeing and functioning improve, pleasant moods are logged, and goals are achieved.
      </p>

      <div className="flex flex-col md:flex-row items-center gap-6">
        <div className="shrink-0">
          <svg viewBox="0 0 300 180" className="w-60 md:w-72">
            {SEGMENTS.map((seg) => (
              <path
                key={seg.label}
                d={describeArc(150, 150, 120, 180 * (1 - seg.to / 100), 180 * (1 - seg.from / 100))}
                fill="none"
                stroke={seg.color}
                strokeWidth="22"
                opacity="0.25"
              />
            ))}
            <path
              d={describeArc(150, 150, 120, 180, needleAngle)}
              fill="none"
              stroke={segment.color}
              strokeWidth="22"
              strokeLinecap="round"
            />
            <line x1="150" y1="150" x2={needleEnd.x} y2={needleEnd.y} stroke="hsl(var(--foreground))" strokeWidth="3" strokeLinecap="round" />
            <circle cx="150" cy="150" r="8" fill="hsl(var(--foreground))" />
            <text x="150" y="135" textAnchor="middle" fontSize="38" fontWeight="700" fill="hsl(var(--foreground))" fontFamily="var(--font-heading)">
              {score}
            </text>
            <text x="150" y="160" textAnchor="middle" fontSize="13" fill={segment.color} fontWeight="600">
              {segment.label}
            </text>
          </svg>
        </div>

        <div className="flex-1 w-full space-y-3">
          {components.map((c, i) => {
            const Icon = c.icon;
            return (
              <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-secondary/50">
                <div className={`w-10 h-10 rounded-lg ${c.color === "primary" ? "bg-primary/10" : "bg-accent/10"} flex items-center justify-center shrink-0`}>
                  <Icon className={c.color === "primary" ? "text-primary" : "text-accent"} size={20} />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{c.label}</p>
                  <p className="text-xs text-muted-foreground">{c.sub}</p>
                </div>
                <span className="font-heading text-2xl font-semibold">{c.value}</span>
              </div>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
}