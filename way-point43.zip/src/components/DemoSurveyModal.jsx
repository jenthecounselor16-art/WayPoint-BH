import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { MessageSquareHeart, Star, Send, Loader2, X } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const FEATURES = [
  "Therapist Portal",
  "Clinical Insights",
  "Assessments",
  "Homework",
  "Coping Tools",
  "AI Coping Coach",
  "Behavior Activation",
  "Values Inventory",
  "Other",
];

// Final-day = within 24h of expiry, not yet expired.
function isFinalDay(participant) {
  if (!participant || participant.status !== "active" || !participant.expires_at) return false;
  const expires = new Date(participant.expires_at).getTime();
  const now = Date.now();
  return expires > now && expires - now <= 24 * 60 * 60 * 1000;
}

export default function DemoSurveyModal({ user }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    overall_rating: 0,
    nps: -1,
    most_valuable_feature: "",
    additional: "",
  });
  const [hover, setHover] = useState(0);

  useEffect(() => {
    if (!user?.email) return;
    let cancelled = false;
    (async () => {
      // Already submitted or dismissed this session?
      if (localStorage.getItem(`wp_demo_survey_done_${user.email}`)) return;

      let participant = null;
      try {
        const list = await base44.entities.DemoParticipant.filter({ email: user.email }, "-created_date", 1);
        participant = list?.[0] || null;
      } catch {
        return;
      }
      if (cancelled || !isFinalDay(participant)) return;

      // Already submitted feedback on the server?
      try {
        const prior = await base44.entities.DemoFeedback.filter({ participant_email: user.email }, "-created_date", 1);
        if (prior?.length) {
          localStorage.setItem(`wp_demo_survey_done_${user.email}`, "1");
          return;
        }
      } catch {}

      if (!cancelled) setOpen(true);
    })();
    return () => { cancelled = true; };
  }, [user?.email]);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function dismiss() {
    setOpen(false);
    if (user?.email) localStorage.setItem(`wp_demo_survey_done_${user.email}`, "1");
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (submitting) return;
    if (form.overall_rating < 1) { toast({ title: "Please rate your overall experience", variant: "destructive" }); return; }
    if (form.nps < 0) { toast({ title: "Please pick a likelihood-to-recommend score", variant: "destructive" }); return; }
    setSubmitting(true);
    try {
      await base44.entities.DemoFeedback.create({
        participant_email: user?.email || "",
        participant_name: user?.full_name || user?.display_name || "",
        overall_rating: form.overall_rating,
        nps: form.nps,
        most_valuable_feature: form.most_valuable_feature || null,
        additional: form.additional.trim() || null,
        submitted_at: new Date().toISOString(),
      });
      setSubmitted(true);
      if (user?.email) localStorage.setItem(`wp_demo_survey_done_${user.email}`, "1");
    } catch (err) {
      toast({ title: "Couldn't submit feedback", description: err.message || "Please try again.", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={dismiss}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.25 }}
            className="w-full max-w-lg bg-card rounded-2xl shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="bg-gradient-to-br from-primary/10 to-accent/10 px-6 pt-6 pb-5 relative">
              <button onClick={dismiss} className="absolute top-4 right-4 p-1.5 rounded-lg text-muted-foreground hover:bg-secondary transition">
                <X size={18} />
              </button>
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-primary/15 flex items-center justify-center shrink-0">
                  <MessageSquareHeart className="text-primary" size={22} />
                </div>
                <div>
                  <h2 className="font-heading text-xl font-semibold">Your final day with WayPoint</h2>
                  <p className="text-sm text-muted-foreground">Before your demo ends — we'd love your honest take.</p>
                </div>
              </div>
            </div>

            {submitted ? (
              <div className="p-8 text-center">
                <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="w-14 h-14 rounded-full bg-accent/15 flex items-center justify-center mx-auto mb-4">
                  <MessageSquareHeart className="text-accent" size={30} />
                </motion.div>
                <h3 className="font-heading text-lg font-semibold mb-2">Thank you — truly.</h3>
                <p className="text-sm text-muted-foreground mb-5">Your feedback helps shape WayPoint for clinicians like you.</p>
                <button onClick={dismiss} className="px-5 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition">
                  Close
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="p-6 space-y-6">
                {/* Overall rating */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Overall, how was your WayPoint demo experience? *</label>
                  <div className="flex items-center gap-1.5">
                    {[1, 2, 3, 4, 5].map((n) => (
                      <button
                        key={n}
                        type="button"
                        onClick={() => update("overall_rating", n)}
                        onMouseEnter={() => setHover(n)}
                        onMouseLeave={() => setHover(0)}
                        className="p-0.5 transition-transform hover:scale-110"
                        aria-label={`${n} star${n > 1 ? "s" : ""}`}
                      >
                        <Star
                          size={28}
                          className={`transition-colors ${(hover || form.overall_rating) >= n ? "fill-amber-400 text-amber-400" : "text-muted-foreground/30"}`}
                        />
                      </button>
                    ))}
                    {form.overall_rating > 0 && <span className="ml-2 text-sm font-medium text-muted-foreground">{form.overall_rating}/5</span>}
                  </div>
                </div>

                {/* NPS */}
                <div>
                  <label className="text-sm font-medium mb-2 block">How likely are you to recommend WayPoint to a colleague? *</label>
                  <div className="flex items-end gap-1 flex-wrap">
                    {Array.from({ length: 11 }, (_, n) => n).map((n) => {
                      const active = form.nps === n;
                      const tone = n <= 6 ? "bg-rose-100 text-rose-700 border-rose-200" : n <= 8 ? "bg-amber-100 text-amber-700 border-amber-200" : "bg-emerald-100 text-emerald-700 border-emerald-200";
                      return (
                        <button
                          key={n}
                          type="button"
                          onClick={() => update("nps", n)}
                          className={`w-8 h-9 rounded-lg border text-sm font-semibold transition ${active ? `${tone} ring-2 ring-primary/40` : "bg-card border-border text-muted-foreground hover:bg-secondary"}`}
                        >
                          {n}
                        </button>
                      );
                    })}
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground mt-1.5">
                    <span>Not at all</span>
                    <span>Extremely likely</span>
                  </div>
                </div>

                {/* Most valuable feature */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Which feature was most valuable? <span className="text-muted-foreground font-normal">(optional)</span></label>
                  <div className="flex flex-wrap gap-1.5">
                    {FEATURES.map((f) => (
                      <button
                        key={f}
                        type="button"
                        onClick={() => update("most_valuable_feature", f)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition ${form.most_valuable_feature === f ? "bg-primary/10 border-primary text-primary" : "bg-card border-border text-foreground hover:bg-secondary"}`}
                      >
                        {f}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Honest thoughts */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Your honest thoughts <span className="text-muted-foreground font-normal">(optional)</span></label>
                  <textarea
                    value={form.additional}
                    onChange={(e) => update("additional", e.target.value)}
                    rows={3}
                    maxLength={2000}
                    className="pp-input resize-none"
                    placeholder="What worked, what didn't, what's missing — the unfiltered version."
                  />
                </div>

                <div className="flex gap-3 pt-1">
                  <button type="button" onClick={dismiss} className="px-4 py-2.5 rounded-xl bg-secondary text-secondary-foreground text-sm font-medium hover:opacity-80 transition">
                    Maybe later
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex-1 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {submitting ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                    {submitting ? "Submitting…" : "Submit feedback"}
                  </button>
                </div>
                <p className="text-xs text-muted-foreground text-center">Your responses are confidential and reviewed only by the WayPoint team.</p>
              </form>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}