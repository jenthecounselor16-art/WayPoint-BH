import React from "react";
import { useClinicianAccess } from "@/hooks/useClinicianAccess";
import Paywall from "@/components/Paywall";

// Wraps a premium clinician page so its (hook-heavy) contents only mount when
// the user has an active clinician subscription. Blocked users see the
// paywall instead — and the wrapped page's data-fetching/audit side effects
// never run.
export default function ClinicianGate({ children }) {
  const { loading, hasAccess } = useClinicianAccess();

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!hasAccess) return <Paywall />;

  return children;
}