import React from "react";
import { motion } from "framer-motion";

export default function OrgMetricCard({ icon: Icon, label, value, subtitle, detail, color, delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="pp-card p-5 flex flex-col"
    >
      <div className="flex items-center gap-2 mb-3">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: `${color}15` }}>
          <Icon size={16} style={{ color }} />
        </div>
        <span className="text-sm font-medium text-muted-foreground">{label}</span>
      </div>
      <p className="font-heading text-2xl md:text-3xl font-semibold mb-1 leading-tight">{value}</p>
      {subtitle && <p className="text-sm text-muted-foreground mb-1">{subtitle}</p>}
      {detail && <p className="text-xs text-muted-foreground/70 mt-auto pt-1">{detail}</p>}
    </motion.div>
  );
}