import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { UserPlus, Users, AlertCircle, CheckCircle2, Mail } from "lucide-react";

const SEAT_LIMITS = {
  solo_monthly: 1,
  solo_annual: 1,
  practice_monthly: 5,
  practice_annual: 5,
  large_practice_monthly: 10,
  large_practice_annual: 10,
};

const PLAN_LABELS = {
  solo_monthly: "Solo Clinician",
  solo_annual: "Solo Clinician",
  practice_monthly: "Counseling Practice",
  practice_annual: "Counseling Practice",
  large_practice_monthly: "Large Group Practice",
  large_practice_annual: "Large Group Practice",
};

export default function InviteTherapists() {
  const [user, setUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [purchases, setPurchases] = useState([]);
  const [email, setEmail] = useState("");
  const [inviting, setInviting] = useState(false);
  const [message, setMessage] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        if (me?.role !== "admin") {
          setLoading(false);
          return;
        }
        const [u, p] = await Promise.all([
          base44.entities.User.list("-created_date", 200),
          base44.entities.Base44Purchase.list("-created_date", 50),
        ]);
        setUsers(u || []);
        setPurchases(p || []);
      } catch (e) {
        console.error("InviteTherapists load error:", e);
      }
      setLoading(false);
    })();
  }, []);

  if (loading || user?.role !== "admin") return null;

  const therapists = (users || []).filter(
    (u) => u.role === "therapist" || u.role === "admin" || u.account_type === "therapist"
  );
  const paidPlans = (purchases || []).filter((p) => p.status === "paid" && p.plan);
  const currentPlan = paidPlans[0]?.plan || "";
  const seatLimit = SEAT_LIMITS[currentPlan] || 1;
  const seatsUsed = therapists.length;
  const seatsAvailable = Math.max(0, seatLimit - seatsUsed);
  const isGroupPlan = currentPlan.startsWith("practice") || currentPlan.startsWith("large_practice");
  const canInvite = isGroupPlan && seatsAvailable > 0;

  async function invite() {
    const trimmed = email.trim();
    if (!trimmed) return;
    setInviting(true);
    setMessage(null);
    try {
      await base44.users.inviteUser(trimmed, "therapist");
      setMessage({ type: "success", text: `Invitation sent to ${trimmed}. They'll appear here once they accept.` });
      setEmail("");
      const u = await base44.entities.User.list("-created_date", 200);
      setUsers(u || []);
    } catch (e) {
      const msg = e?.response?.data?.message || e?.message || "Unable to send invitation.";
      setMessage({ type: "error", text: msg });
    }
    setInviting(false);
  }

  return (
    <div className="pp-card p-5 mb-8">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <UserPlus className="text-primary" size={20} />
        </div>
        <div className="flex-1 min-w-0">
          <h2 className="font-heading text-lg font-semibold">Therapist Seats</h2>
          <p className="text-sm text-muted-foreground">
            {currentPlan
              ? `Plan: ${PLAN_LABELS[currentPlan] || currentPlan} · ${seatsUsed} of ${seatLimit} seats used · ${seatsAvailable} invite${seatsAvailable === 1 ? "" : "s"} remaining`
              : "Subscribe to a group practice plan to invite clinicians."}
          </p>
        </div>
      </div>

      <div className="mb-4">
        <div className="h-2 rounded-full bg-secondary overflow-hidden">
          <div
            className="h-full bg-primary transition-all"
            style={{ width: `${seatLimit ? Math.min(100, (seatsUsed / seatLimit) * 100) : 0}%` }}
          />
        </div>
      </div>

      {therapists.length > 0 && (
        <div className="mb-4 space-y-2">
          {therapists.slice(0, 12).map((t) => (
            <div key={t.id} className="flex items-center gap-2 text-sm">
              <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0">
                <Users size={14} className="text-muted-foreground" />
              </div>
              <div className="min-w-0">
                <p className="font-medium truncate">{t.display_name || t.full_name || t.email}</p>
                <p className="text-xs text-muted-foreground truncate">
                  {t.email} {t.role === "admin" ? "· Admin" : ""}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}

      {message && (
        <div
          className={`mb-3 p-3 rounded-xl text-sm flex items-start gap-2 ${
            message.type === "success" ? "bg-accent/10 text-accent" : "bg-destructive/10 text-destructive"
          }`}
        >
          {message.type === "success" ? <CheckCircle2 size={16} className="shrink-0 mt-0.5" /> : <AlertCircle size={16} className="shrink-0 mt-0.5" />}
          <span>{message.text}</span>
        </div>
      )}

      {isGroupPlan ? (
        canInvite ? (
          <>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") invite(); }}
                placeholder="therapist@email.com"
                className="pp-input pl-9"
              />
            </div>
            <button
              onClick={invite}
              disabled={inviting || !email.trim()}
              className="px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:opacity-90 transition disabled:opacity-50 flex items-center gap-1.5 shrink-0"
            >
              <UserPlus size={16} /> {inviting ? "Inviting…" : "Invite"}
            </button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            We'll email this clinician a secure sign-up link to join your practice.
          </p>
          </>
        ) : (
          <div className="p-3 rounded-xl bg-amber-500/10 text-amber-700 text-sm flex items-start gap-2">
            <AlertCircle size={16} className="shrink-0 mt-0.5" />
            <span>You've reached your plan's {seatLimit} clinician seats. Upgrade to invite more therapists.</span>
          </div>
        )
      ) : (
        <div className="p-3 rounded-xl bg-secondary/50 text-sm text-muted-foreground">
          Group practice subscriptions include additional clinician seats. Visit Billing &amp; Plans to subscribe.
        </div>
      )}
    </div>
  );
}