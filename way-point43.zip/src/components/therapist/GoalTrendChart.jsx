import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from "recharts";
import { Target } from "lucide-react";

const CLIENT_COLOR = "#1995A1";
const THERAPIST_COLOR = "#D4A055";

// Therapist-facing chart of goal progress over time. Each time the client or
// therapist rates a goal, a snapshot is logged (GoalProgressCheckin); this
// graphs those snapshots as two lines (client self-rating, therapist rating)
// on a 0-10 axis so between-session progress is visible at a glance.
export default function GoalTrendChart({ clientEmail }) {
  const [goals, setGoals] = useState([]);
  const [checkins, setCheckins] = useState([]);
  const [selectedGoalId, setSelectedGoalId] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!clientEmail) {
      setGoals([]);
      setCheckins([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    (async () => {
      try {
        const [g, c] = await Promise.all([
          base44.entities.TherapyGoal.filter({ client_email: clientEmail }, "-created_date", 50),
          base44.entities.GoalProgressCheckin.filter({ client_email: clientEmail }, "created_date", 500),
        ]);
        setGoals(g || []);
        setCheckins(c || []);
      } catch {}
      setLoading(false);
    })();
  }, [clientEmail]);

  useEffect(() => {
    if (goals.length && !goals.some((g) => g.id === selectedGoalId)) {
      setSelectedGoalId(goals[0].id);
    }
  }, [goals]);

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 160 }}>
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!goals.length) {
    return (
      <div className="pp-card p-6">
        <div className="flex items-center gap-2 mb-2">
          <Target size={18} className="text-primary" />
          <h3 className="font-heading text-lg font-semibold">Goal Progress Over Time</h3>
        </div>
        <p className="text-sm text-muted-foreground py-6 text-center">No goals set yet for this client.</p>
      </div>
    );
  }

  const goal = goals.find((g) => g.id === selectedGoalId) || goals[0];
  const snapshots = checkins.filter((c) => c.goal_id === goal.id);

  const fmtDate = (d) =>
    new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric" });

  let points = snapshots.map((c) => ({
    date: fmtDate(c.created_date),
    Client: c.client_rating ?? 0,
    Therapist: c.therapist_rating ?? 0,
  }));

  // No history yet: show the goal's current ratings as today's point so the
  // chart is immediately useful; snapshots fill in the trend over time.
  if (!points.length) {
    points = [{ date: fmtDate(Date.now()), Client: goal.client_rating ?? 0, Therapist: goal.therapist_rating ?? 0 }];
  }

  return (
    <div className="pp-card p-5">
      <div className="flex flex-wrap items-center gap-2 mb-4">
        <Target size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Goal Progress Over Time</h3>
        <select
          value={goal.id}
          onChange={(e) => setSelectedGoalId(e.target.value)}
          className="pp-input !w-auto ml-auto max-w-[220px]"
        >
          {goals.map((g) => (
            <option key={g.id} value={g.id}>{g.title}</option>
          ))}
        </select>
      </div>
      {snapshots.length <= 1 && (
        <p className="text-xs text-muted-foreground mb-3">
          {snapshots.length === 0
            ? "No rating history yet — this shows the goal's current ratings. As you and your client check in over time, the trend will build here."
            : "Only one check-in so far — more check-ins will draw the trend between sessions."}
        </p>
      )}
      <div style={{ width: "100%", height: 260 }}>
        <ResponsiveContainer>
          <LineChart data={points} margin={{ top: 8, right: 16, left: -16, bottom: 4 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
            <YAxis domain={[0, 10]} ticks={[0, 2, 4, 6, 8, 10]} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
            <Tooltip
              contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))", fontSize: 13 }}
              formatter={(value, name) => [`${value}/10`, name === "Client" ? "Client self-rating" : "Your rating"]}
            />
            <Legend
              formatter={(value) => (value === "Client" ? "Client self-rating" : "Your rating")}
              wrapperStyle={{ fontSize: 13 }}
            />
            <Line type="monotone" dataKey="Client" stroke={CLIENT_COLOR} strokeWidth={2.5} dot={{ r: 4 }} connectNulls />
            <Line type="monotone" dataKey="Therapist" stroke={THERAPIST_COLOR} strokeWidth={2.5} dot={{ r: 4 }} connectNulls />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}