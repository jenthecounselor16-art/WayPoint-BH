import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getChildAge, requiresConsent, CONSENT_AGE } from "@/lib/childAge";
import { X, UserPlus, Loader2, CheckCircle2, Copy, ShieldCheck } from "lucide-react";

export default function InviteParentModal({ clientEmail, clientName, therapistEmail, onClose }) {
  const [form, setForm] = useState({ parent_name: "", parent_email: "", relationship: "parent" });
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(null); // { status, age }
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const [childAge, setChildAge] = useState(null);
  const [ageLoading, setAgeLoading] = useState(true);

  const portalUrl = `${window.location.origin}/parent-portal`;
  const needsConsent = requiresConsent(childAge);

  useEffect(() => {
    let active = true;
    (async () => {
      const age = await getChildAge(clientEmail);
      if (active) {
        setChildAge(age);
        setAgeLoading(false);
      }
    })();
    return () => { active = false; };
  }, [clientEmail]);

  async function submit(e) {
    e.preventDefault();
    if (saving || ageLoading) return;
    if (!form.parent_email.trim()) { setError("Parent email is required."); return; }
    setSaving(true);
    setError("");
    try {
      // 12+ clients must explicitly approve from their own account — the link
      // stays "pending" and shares no data until they do. Under-12 clients
      // have no account, so the therapist's authorization grants access now.
      const status = needsConsent ? "pending" : "active";
      await base44.entities.Parent.create({
        parent_email: form.parent_email.trim(),
        parent_name: form.parent_name.trim() || undefined,
        child_email: clientEmail,
        child_name: clientName,
        therapist_email: therapistEmail || "",
        relationship: form.relationship,
        status,
      });
      setDone({ status, age: childAge });
    } catch (err) {
      setError(err?.message || "Couldn't link this parent. Please try again.");
    }
    setSaving(false);
  }

  function copyLink() {
    navigator.clipboard?.writeText(portalUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40" onClick={onClose}>
      <div className="w-full max-w-md bg-card rounded-2xl shadow-2xl p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
              <UserPlus className="text-primary" size={18} />
            </div>
            <h2 className="font-heading text-xl font-semibold">Invite a Parent</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-muted-foreground hover:bg-secondary transition">
            <X size={18} />
          </button>
        </div>

        <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-secondary/40 mb-4 text-xs text-muted-foreground">
          {ageLoading ? (
            <><Loader2 size={13} className="animate-spin" /> Checking {clientName}'s age…</>
          ) : needsConsent ? (
            <><ShieldCheck size={13} className="text-amber-600" />
              {childAge !== null
                ? `${clientName} is ${childAge} (${CONSENT_AGE}+), so they must approve this access from their own account before any progress is shared.`
                : `${clientName}'s age is on file as ${CONSENT_AGE}+ — their explicit approval is required before any progress is shared.`}
            </>
          ) : (
            <><ShieldCheck size={13} className="text-accent" />
              {clientName} is {childAge} (under {CONSENT_AGE}), so your authorization grants access immediately — no client approval needed.
            </>
          )}
        </div>

        {done ? (
          <div className="text-center py-4">
            {done.status === "pending" ? (
              <>
                <CheckCircle2 className="mx-auto mb-4 text-amber-500" size={44} />
                <h3 className="font-heading text-lg font-semibold mb-2">Approval required</h3>
                <p className="text-sm text-muted-foreground mb-5 leading-relaxed">
                  Share this link with the parent and ask them to register using{" "}
                  <span className="font-medium text-foreground">{form.parent_email}</span>. {clientName} will be asked to approve
                  this access from their own WayPoint account before any progress is shared — required for clients {CONSENT_AGE} and older.
                </p>
              </>
            ) : (
              <>
                <CheckCircle2 className="mx-auto mb-4 text-accent" size={44} />
                <h3 className="font-heading text-lg font-semibold mb-2">Parent linked</h3>
                <p className="text-sm text-muted-foreground mb-5 leading-relaxed">
                  {form.parent_email} can now register and view {clientName}'s progress. Because {clientName} is under {CONSENT_AGE},
                  your authorization is sufficient — no client approval is required.
                </p>
              </>
            )}
            <div className="flex items-center gap-2 p-3 rounded-xl bg-secondary/40 mb-3">
              <input readOnly value={portalUrl} className="flex-1 bg-transparent text-sm outline-none" />
              <button onClick={copyLink} className="px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-medium hover:opacity-90 transition flex items-center gap-1">
                <Copy size={13} /> {copied ? "Copied" : "Copy"}
              </button>
            </div>
            <button onClick={onClose} className="w-full py-2.5 rounded-xl bg-secondary text-secondary-foreground font-medium hover:opacity-80 transition">
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Parent / guardian name</label>
              <input
                value={form.parent_name}
                onChange={(e) => setForm({ ...form, parent_name: e.target.value })}
                placeholder="e.g. Jordan Avery"
                className="pp-input"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Parent email *</label>
              <input
                type="email"
                required
                value={form.parent_email}
                onChange={(e) => setForm({ ...form, parent_email: e.target.value })}
                placeholder="parent@email.com"
                className="pp-input"
              />
              <p className="text-xs text-muted-foreground mt-1">They must register with this exact email to see {clientName}'s progress.</p>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Relationship</label>
              <select
                value={form.relationship}
                onChange={(e) => setForm({ ...form, relationship: e.target.value })}
                className="pp-input"
              >
                <option value="parent">Parent</option>
                <option value="guardian">Guardian</option>
                <option value="other">Other</option>
              </select>
            </div>
            <p className="text-xs text-muted-foreground">
              For clients {CONSENT_AGE} and older, {clientName} must approve this access from their own account before the parent can see anything. Only {clientName} can grant or revoke that approval.
            </p>
            {error && (
              <div className="p-3 rounded-xl bg-destructive/10 text-destructive text-sm">{error}</div>
            )}
            <button
              type="submit"
              disabled={saving || ageLoading}
              className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {saving || ageLoading ? <Loader2 size={16} className="animate-spin" /> : <UserPlus size={16} />}
              {ageLoading ? "Checking age…" : saving ? "Linking…" : needsConsent ? "Request parent access" : "Link parent"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}