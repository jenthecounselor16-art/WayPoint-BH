import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ShieldAlert, AlertTriangle, Check, Phone, Heart, X } from "lucide-react";

const SECTIONS = [
  { key: "warning_signs", label: "Warning Signs", icon: AlertTriangle },
  { key: "coping_skills", label: "Coping Skills", icon: Check },
  { key: "emergency_contacts", label: "Emergency Contacts", icon: Phone },
  { key: "reasons_to_live", label: "Reasons to Live", icon: Heart },
];

export default function CrisisPlanModal({ clientEmail, clientName, onClose }) {
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.CrisisPlan.filter({ client_email: clientEmail }, "-created_date", 1);
        setPlan(data?.[0] || null);
      } catch {}
      setLoading(false);
    })();
  }, [clientEmail]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4" onClick={onClose}>
      <div className="bg-card rounded-2xl shadow-xl w-full max-w-lg p-6 max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <ShieldAlert size={18} className="text-red-500" />
            <h3 className="font-heading text-lg font-semibold">Crisis Plan · {clientName || clientEmail}</h3>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-secondary transition" title="Close">
            <X size={18} className="text-muted-foreground" />
          </button>
        </div>

        {loading ? (
          <div className="flex justify-center py-8"><div className="w-7 h-7 border-4 border-secondary border-t-primary rounded-full animate-spin" /></div>
        ) : !plan ? (
          <div className="text-center py-8">
            <p className="text-sm text-muted-foreground">No crisis plan on file for this client.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {SECTIONS.map((section) => {
              const items = plan[section.key] || [];
              const Icon = section.icon;
              return (
                <div key={section.key}>
                  <p className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5 mb-1.5">
                    <Icon size={13} /> {section.label}
                  </p>
                  {items.length > 0 ? (
                    <ul className="space-y-1 ml-5">
                      {items.map((item, i) => (
                        <li key={i} className="text-sm text-foreground/80 list-disc">{item}</li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-xs text-muted-foreground/60 ml-5">Not specified</p>
                  )}
                </div>
              );
            })}
            {(plan.therapist_name || plan.therapist_phone) && (
              <div className="pt-3 border-t border-border/60">
                <p className="text-xs font-semibold text-muted-foreground mb-1">Therapist Contact</p>
                <p className="text-sm text-foreground/80">{plan.therapist_name || "—"}</p>
                {plan.therapist_phone && <p className="text-sm text-muted-foreground">{plan.therapist_phone}</p>}
              </div>
            )}
          </div>
        )}

        <p className="text-xs text-muted-foreground mt-5 pt-4 border-t border-border/60">
          Crisis support: call or text <span className="font-bold text-foreground">988</span> (Suicide &amp; Crisis Lifeline, 24/7).
        </p>
      </div>
    </div>
  );
}