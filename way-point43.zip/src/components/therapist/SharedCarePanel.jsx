import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Users, UserPlus, X, Loader2, ShieldCheck } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

// Shared care: lets the primary therapist add co-treating providers (at this
// practice or another) to a client's care team. Co-providers can then view
// the client's full clinical account and contribute (homework, goals), while
// each provider's clinical notes stay private to their author.
export default function SharedCarePanel({ clientEmail, user }) {
  const [client, setClient] = useState(null);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const { toast } = useToast();

  async function load() {
    const list = await base44.entities.Client.filter({ client_email: clientEmail }, "-created_date", 5);
    setClient((list || [])[0] || null);
  }

  useEffect(() => {
    load().catch(() => {}).finally(() => setLoading(false));
  }, [clientEmail]);

  const isPrimary =
    client &&
    String(client.therapist_email || "").toLowerCase() === String(user?.email || "").toLowerCase();
  const team = (client?.shared_therapist_emails || []).map((e) => String(e).toLowerCase());

  async function run(action, providerEmail) {
    if (action === "remove" && !window.confirm(`Revoke ${providerEmail}'s access to this client's clinical records? They'll immediately lose visibility of this client's shared records.`)) return;
    setBusy(true);
    try {
      const res = await base44.functions.invoke("manage-shared-provider", {
        client_email: clientEmail,
        provider_email: providerEmail,
        action,
      });
      await load();
      setEmail("");
      toast({
        title: action === "add" ? "Provider added to care team" : "Provider removed from care team",
        description:
          action === "add"
            ? "They can now view this client's account and contribute to their care."
            : "Their shared access has been revoked.",
      });
      if (res?.data?.already) {
        toast({ title: "No change needed", description: "That provider was already in that state." });
      }
    } catch (e) {
      toast({
        title: "Couldn't update the care team",
        description: e?.response?.data?.error || e?.message || "Please try again.",
        variant: "destructive",
      });
    }
    setBusy(false);
  }

  function handleAdd() {
    const value = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      toast({ title: "Invalid email", description: "Enter the co-treating provider's email address.", variant: "destructive" });
      return;
    }
    if (team.includes(value)) return;
    run("add", value);
  }

  return (
    <div className="pp-card p-6">
      <div className="flex items-start gap-3 mb-4">
        <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Users className="text-primary" size={18} />
        </div>
        <div>
          <h3 className="font-heading text-lg font-semibold">Shared Care Team</h3>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Co-treating providers — at this practice or another — can view this client&apos;s assessments, goals,
            homework, and progress, and contribute to their care. Each provider&apos;s clinical notes stay private to
            their author.
          </p>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-6">
          <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <>
          {team.length === 0 ? (
            <p className="text-sm text-muted-foreground mb-4">
              No co-treating providers yet.{" "}
              {isPrimary
                ? "Add one below if another clinician is also treating this client."
                : "Only the primary therapist manages this list."}
            </p>
          ) : (
            <div className="flex flex-wrap gap-2 mb-4">
              {team.map((e) => (
                <span
                  key={e}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-medium"
                >
                  {e}
                  {isPrimary && (
                    <button
                      onClick={() => run("remove", e)}
                      disabled={busy}
                      className="text-primary/60 hover:text-primary transition disabled:opacity-50"
                      title={`Remove ${e} from the care team`}
                    >
                      <X size={12} />
                    </button>
                  )}
                </span>
              ))}
            </div>
          )}

          {isPrimary ? (
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") handleAdd(); }}
                placeholder="Co-treating provider's email"
                className="pp-input flex-1"
                disabled={busy}
              />
              <button
                onClick={handleAdd}
                disabled={busy || !email.trim()}
                className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition disabled:opacity-50 shrink-0"
              >
                {busy ? <Loader2 size={15} className="animate-spin" /> : <UserPlus size={15} />}
                Grant access
              </button>
            </div>
          ) : (
            <p className="text-xs text-muted-foreground flex items-center gap-1.5">
              <ShieldCheck size={13} />
              {client?.therapist_email
                ? `Shared access is managed by the primary therapist (${client.therapist_email}).`
                : "Shared access is managed by the primary therapist."}
            </p>
          )}
        </>
      )}
    </div>
  );
}