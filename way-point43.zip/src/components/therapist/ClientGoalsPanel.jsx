import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Target, Check, TrendingUp, Plus } from "lucide-react";
import { useSubscribeRefresh } from "@/hooks/useSubscribeRefresh";
import { logGoalCheckin } from "@/lib/goalProgress";

export default function ClientGoalsPanel({ clientEmail, therapistEmail }) {
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", description: "" });
  const [saving, setSaving] = useState(false);

  async function loadGoals() {
    try {
      const data = await base44.entities.TherapyGoal.filter({ client_email: clientEmail }, "-created_date", 50);
      setGoals(data || []);
    } catch {}
    setLoading(false);
  }
  useEffect(() => { loadGoals(); }, [clientEmail]);
  useSubscribeRefresh("TherapyGoal", loadGoals);

  async function updateRating(goal, value) {
    try {
      await base44.entities.TherapyGoal.update(goal.id, { therapist_rating: value });
      await logGoalCheckin(goal, "therapist", { therapist_rating: value });
      setGoals(goals.map((g) => (g.id === goal.id ? { ...g, therapist_rating: value } : g)));
    } catch {}
  }

  async function toggleStatus(goal) {
    const newStatus = goal.status === "achieved" ? "active" : "achieved";
    try {
      await base44.entities.TherapyGoal.update(goal.id, { status: newStatus });
      setGoals(goals.map((g) => (g.id === goal.id ? { ...g, status: newStatus } : g)));
    } catch {}
  }

  async function createGoal() {
    if (!form.title.trim()) return;
    setSaving(true);
    try {
      const created = await base44.entities.TherapyGoal.create({
        title: form.title.trim(),
        description: form.description.trim() || undefined,
        client_email: clientEmail,
        therapist_email: therapistEmail || "",
        status: "active",
      });
      await logGoalCheckin(created, "therapist");
      const data = await base44.entities.TherapyGoal.filter({ client_email: clientEmail }, "-created_date", 50);
      setGoals(data || []);
      setForm({ title: "", description: "" });
      setShowForm(false);
    } catch {}
    setSaving(false);
  }

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 120 }}>
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const active = goals.filter((g) => g.status !== "achieved");
  const achieved = goals.filter((g) => g.status === "achieved");

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <Target size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Therapy Goals</h3>
        <button onClick={() => setShowForm(!showForm)} className="ml-auto px-3 py-1.5 rounded-lg bg-primary/10 text-primary text-xs font-medium hover:bg-primary/20 transition flex items-center gap-1">
          <Plus size={14} /> {showForm ? "Cancel" : "New Goal"}
        </button>
      </div>

      {showForm && (
        <div className="mb-4 p-4 rounded-xl bg-secondary/30 space-y-3">
          <input
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder="Goal title (e.g., Reduce panic attacks to 1x/week)"
            className="pp-input"
          />
          <textarea
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="What does success look like? (optional)"
            className="pp-input min-h-[60px] resize-none"
          />
          <button
            onClick={createGoal}
            disabled={saving || !form.title.trim()}
            className="w-full py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition disabled:opacity-50"
          >
            {saving ? "Saving…" : "Add Goal"}
          </button>
        </div>
      )}

      {goals.length === 0 ? (
        <p className="text-sm text-muted-foreground py-4 text-center">No goals set yet.</p>
      ) : (
        <div className="space-y-3">
          {[...active, ...achieved].map((goal) => (
            <div key={goal.id} className="p-3 rounded-xl bg-secondary/40">
              <div className="flex items-start justify-between gap-2 mb-2">
                <p className="text-sm font-medium">{goal.title}</p>
                <span className={`px-2 py-0.5 rounded-full text-xs font-medium shrink-0 ${goal.status === "achieved" ? "bg-primary/10 text-primary" : "bg-amber-500/10 text-amber-600"}`}>
                  {goal.status === "achieved" ? "Achieved" : "Active"}
                </span>
              </div>
              {goal.description && <p className="text-xs text-muted-foreground mb-3">{goal.description}</p>}
              <div className="space-y-2">
                <div>
                  <div className="flex justify-between text-xs mb-0.5">
                    <span className="text-muted-foreground">Client Rating</span>
                    <span className="font-semibold" style={{ color: "#1995A1" }}>{goal.client_rating || 0}/10</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${(goal.client_rating || 0) * 10}%`, backgroundColor: "#1995A1" }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-0.5">
                    <span className="text-muted-foreground">Your Rating</span>
                    <span className="font-semibold" style={{ color: "#D4A055" }}>{goal.therapist_rating || 0}/10</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="10"
                    value={goal.therapist_rating || 0}
                    onChange={(e) => updateRating(goal, parseInt(e.target.value))}
                    className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
                    style={{ accentColor: "#D4A055" }}
                  />
                </div>
              </div>
              <button onClick={() => toggleStatus(goal)} className="mt-2 text-xs text-primary hover:underline flex items-center gap-1">
                {goal.status === "achieved" ? <><TrendingUp size={11} /> Reopen</> : <><Check size={11} /> Mark Achieved</>}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}