import React, { useMemo, useState } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { Activity, TrendingUp, TrendingDown, Minus } from "lucide-react";

const DAY = 86400000;

// Composite emotional wellbeing (0-100) for a single check-in.
// Higher = better: energy & social engagement lift it, distress (anxiety,
// depression, stress) lowers it. This is the therapist-visible proxy for the
// client's emotional state, derived from the nervous-system check-ins they
// share with their therapist (private mood logs stay private to the client).
function wellbeingOf(n) {
  const distress = ((n.anxiety_level ?? 0) + (n.depression_level ?? 0) + (n.stress_level ?? 0)) / 3;
  const vitality = ((n.energy_level ?? 0) + (n.social_interaction ?? 0)) / 2;
  return Math.round((((vitality + (10 - distress)) / 2) * 10));
}

function dayKey(d) {
  const dt = new Date(d);
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
}

function fmtDate(k) {
  const [y, m, d] = k.split("-");
  return new Date(+y, +m - 1, +d).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export default function ClientEmotionTrendChart({ nervousMetrics, clients }) {
  const [scope, setScope] = useState("all");

  const { points, latest, first, delta, count } = useMemo(() => {
    const metrics = (nervousMetrics || []).filter(
      (n) => n.created_date && (scope === "all" || n.client_email === scope)
    );
    if (!metrics.length) return { points: [], latest: null, first: null, delta: null, count: 0 };

    const byDay = {};
    metrics.forEach((n) => {
      const k = dayKey(n.created_date);
      (byDay[k] = byDay[k] || []).push(wellbeingOf(n));
    });

    const days = Object.keys(byDay).sort();
    const firstMs = new Date(days[0]).getTime();
    const lastMs = new Date(days[days.length - 1]).getTime();

    const pts = [];
    for (let t = firstMs; t <= lastMs; t += DAY) {
      const k = dayKey(t);
      if (byDay[k]) {
        const avg = byDay[k].reduce((a, b) => a + b, 0) / byDay[k].length;
        pts.push({ date: k, day: Math.round(avg) });
      }
    }
    // 7-day rolling average of the daily wellbeing
    pts.forEach((p, i) => {
      const win = pts.slice(Math.max(0, i - 6), i + 1);
      p.trend = Math.round(win.reduce((a, b) => a + b.day, 0) / win.length);
    });

    const latestVal = pts[pts.length - 1]?.trend ?? null;
    const firstVal = pts[0]?.trend ?? null;
    const d = latestVal !== null && firstVal !== null ? latestVal - firstVal : null;
    return { points: pts, latest: latestVal, first: firstVal, delta: d, count: metrics.length };
  }, [nervousMetrics, scope]);

  const trendState =
    delta === null ? "none"
    : delta >= 3 ? "up"
    : delta <= -3 ? "down"
    : "flat";

  return (
    <div className="pp-card p-5 mb-6">
      <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
        <div className="flex items-start gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
            <Activity className="text-primary" size={18} />
          </div>
          <div>
            <h2 className="font-heading text-lg font-semibold">Client Emotion Trends</h2>
            <p className="text-xs text-muted-foreground">
              Average emotional wellbeing over time, from client nervous-system check-ins.
            </p>
          </div>
        </div>
        <select value={scope} onChange={(e) => setScope(e.target.value)} className="pp-input !w-auto !py-1.5 text-sm">
          <option value="all">All clients</option>
          {clients.map((c) => (
            <option key={c.email} value={c.email}>{c.name}</option>
          ))}
        </select>
      </div>

      {count === 0 ? (
        <div className="py-10 text-center">
          <Activity className="mx-auto mb-3 text-muted-foreground/30" size={36} />
          <p className="text-sm text-muted-foreground">
            No check-in data yet{scope !== "all" ? " for this client" : ""}. Trends appear once clients start logging nervous-system check-ins.
          </p>
        </div>
      ) : (
        <>
          <div className="flex flex-wrap items-center gap-5 mb-4">
            <div>
              <p className="text-xs text-muted-foreground">Current wellbeing</p>
              <p className="font-heading text-3xl font-semibold" style={{ color: latest >= 60 ? "#1995A1" : latest >= 40 ? "#D4A055" : "#D9534F" }}>
                {latest ?? "—"}<span className="text-base text-muted-foreground">/100</span>
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Change vs. baseline</p>
              <p className="font-heading text-xl font-semibold flex items-center gap-1.5">
                {trendState === "up" && <><TrendingUp size={18} className="text-accent" /><span className="text-accent">+{delta}</span></>}
                {trendState === "down" && <><TrendingDown size={18} className="text-destructive" /><span className="text-destructive">{delta}</span></>}
                {trendState === "flat" && <><Minus size={18} className="text-muted-foreground" /><span className="text-muted-foreground">{delta > 0 ? `+${delta}` : delta}</span></>}
                {trendState === "none" && <span className="text-muted-foreground">—</span>}
              </p>
            </div>
            <div className="ml-auto text-xs text-muted-foreground text-right">
              <p>{count} check-in{count === 1 ? "" : "s"}</p>
              <p>{points.length} active day{points.length === 1 ? "" : "s"}</p>
            </div>
          </div>

          <div className="h-64 -ml-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={points} margin={{ top: 5, right: 10, bottom: 0, left: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
                <XAxis
                  dataKey="date"
                  tickFormatter={fmtDate}
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                  tickLine={false}
                  axisLine={{ stroke: "hsl(var(--border))" }}
                  minTickGap={28}
                />
                <YAxis
                  domain={[0, 100]}
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                  tickLine={false}
                  axisLine={false}
                  width={34}
                />
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "12px",
                    fontSize: "12px",
                  }}
                  labelFormatter={fmtDate}
                  formatter={(value, name) => [
                    name === "trend" ? `${value}/100` : `${value}/100`,
                    name === "trend" ? "7-day avg" : "Daily avg",
                  ]}
                />
                <Line
                  type="monotone"
                  dataKey="day"
                  stroke="hsl(var(--primary))"
                  strokeOpacity={0.25}
                  strokeWidth={1.5}
                  dot={{ r: 2, fill: "hsl(var(--primary))", fillOpacity: 0.4 }}
                  activeDot={false}
                  isAnimationActive={false}
                />
                <Line
                  type="monotone"
                  dataKey="trend"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2.5}
                  dot={false}
                  activeDot={{ r: 4 }}
                  isAnimationActive={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <span className="inline-block w-4 h-0.5 rounded bg-primary" /> 7-day rolling average
            </span>
            <span className="flex items-center gap-1.5">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-primary/40" /> Daily check-in
            </span>
          </div>
        </>
      )}
    </div>
  );
}