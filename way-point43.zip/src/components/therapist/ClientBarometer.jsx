import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { ASSESSMENTS } from "@/lib/assessments";
import { TrendingUp, ClipboardCheck, Gauge } from "lucide-react";

function polarToCartesian(cx, cy, r, angleDeg) {
  const angleRad = (angleDeg * Math.PI) / 180;
  return { x: cx + r * Math.cos(angleRad), y: cy - r * Math.sin(angleRad) };
}

function describeArc(cx, cy, r, startAngle, endAngle) {
  const start = polarToCartesian(cx, cy, r, startAngle);
  const end = polarToCartesian(cx, cy, r, endAngle);
  const largeArcFlag = Math.abs(endAngle - startAngle) > 180 ? 1 : 0;
  const sweepFlag = startAngle > endAngle ? 1 : 0;
  return `M ${start.x} ${start.y} A ${r} ${r} 0 ${largeArcFlag} ${sweepFlag} ${end.x} ${end.y}`;
}

const SEGMENTS = [
  { from: 0, to: 30, color: "#D9534F", label: "Concerning" },
  { from: 30, to: 50, color: "#D4A055", label: "Needs Attention" },
  { from: 50, to: 75, color: "#1995A1", label: "Stable" },
  { from: 75, to: 100, color: "#7CB69D", label: "Thriving" },
];

export default function ClientBarometer({ clientEmail }) {
  const [assessments, setAssessments] = useState([]);
  const [homework, setHomework] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [a, h] = await Promise.all([
          base44.entities.AssessmentResult.filter({ client_email: clientEmail }, "-created_date", 50),
          base44.entities.HomeworkAssignment.filter({ client_email: clientEmail }, "-created_date", 50),
        ]);
        setAssessments(a || []);
        setHomework(h || []);
      } catch {}
      setLoading(false);
    })();
  }, [clientEmail]);

  const data = useMemo(() => {
    const latest = {};
    (assessments || []).forEach((a) => {
      if (!latest[a.test_type] || new Date(a.created_date) > new Date(latest[a.test_type].created_date)) {
        latest[a.test_type] = a;
      }
    });
    const latestList = Object.values(latest);
    let aScore = null;
    if (latestList.length > 0) {
      const scores = latestList
        .map((a) => {
          const test = ASSESSMENTS[a.test_type];
          if (!test) return null;
          const maxScore = test.items.length * (test.scale.length - 1);
          const ratio = a.score / maxScore;
          return a.test_type === "WHO5" ? ratio * 100 : (1 - ratio) * 100;
        })
        .filter((s) => s !== null);
      if (scores.length > 0) aScore = scores.reduce((a, b) => a + b, 0) / scores.length;
    }
    const totalHW = (homework || []).length;
    const completedHW = (homework || []).filter((h) => h.status === "completed").length;
    const hScore = totalHW > 0 ? (completedHW / totalHW) * 100 : null;
    let overall = null;
    if (aScore !== null && hScore !== null) overall = aScore * 0.7 + hScore * 0.3;
    else if (aScore !== null) overall = aScore;
    else if (hScore !== null) overall = hScore;
    return { overall, assessmentScore: aScore, homeworkScore: hScore, hasData: overall !== null, latestList, totalHW, completedHW };
  }, [assessments, homework]);

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 160 }}>
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!data.hasData) {
    return (
      <div className="pp-card p-6 text-center">
        <Gauge className="mx-auto mb-3 text-muted-foreground/40" size={36} />
        <h3 className="font-heading text-lg font-semibold mb-1">Mental Health Barometer</h3>
        <p className="text-sm text-muted-foreground">No assessment or homework data yet for this client.</p>
      </div>
    );
  }

  const score = Math.round(data.overall);
  const segment = SEGMENTS.find((s) => score >= s.from && score < s.to) || SEGMENTS[SEGMENTS.length - 1];
  const needleAngle = 180 * (1 - score / 100);
  const needleEnd = polarToCartesian(150, 150, 95, needleAngle);

  return (
    <div className="pp-card p-6">
      <h3 className="font-heading text-lg font-semibold mb-4">Mental Health Barometer</h3>
      <div className="flex flex-col sm:flex-row items-center gap-6">
        <div className="shrink-0">
          <svg viewBox="0 0 300 180" className="w-56 sm:w-64">
            {SEGMENTS.map((seg) => (
              <path key={seg.label} d={describeArc(150, 150, 120, 180 * (1 - seg.to / 100), 180 * (1 - seg.from / 100))} fill="none" stroke={seg.color} strokeWidth="22" opacity="0.25" />
            ))}
            <path d={describeArc(150, 150, 120, 180, needleAngle)} fill="none" stroke={segment.color} strokeWidth="22" strokeLinecap="round" />
            <line x1="150" y1="150" x2={needleEnd.x} y2={needleEnd.y} stroke="hsl(var(--foreground))" strokeWidth="3" strokeLinecap="round" />
            <circle cx="150" cy="150" r="8" fill="hsl(var(--foreground))" />
            <text x="150" y="135" textAnchor="middle" fontSize="38" fontWeight="700" fill="hsl(var(--foreground))" fontFamily="var(--font-heading)">{score}</text>
            <text x="150" y="160" textAnchor="middle" fontSize="13" fill={segment.color} fontWeight="600">{segment.label}</text>
          </svg>
        </div>
        <div className="flex-1 w-full space-y-3">
          {data.assessmentScore !== null && (
            <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary/50">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <TrendingUp className="text-primary" size={20} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">Assessment Score</p>
                <p className="text-xs text-muted-foreground">{data.latestList.length} recent {data.latestList.length === 1 ? "assessment" : "assessments"}</p>
              </div>
              <span className="font-heading text-2xl font-semibold">{Math.round(data.assessmentScore)}</span>
            </div>
          )}
          {data.homeworkScore !== null && (
            <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary/50">
              <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center shrink-0">
                <ClipboardCheck className="text-accent" size={20} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">Homework Completion</p>
                <p className="text-xs text-muted-foreground">{data.completedHW} of {data.totalHW} done</p>
              </div>
              <span className="font-heading text-2xl font-semibold">{Math.round(data.homeworkScore)}%</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}