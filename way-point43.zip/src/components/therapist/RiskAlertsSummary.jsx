import React from "react";
import { ShieldAlert, AlertTriangle, ChevronRight } from "lucide-react";

// Highlights clients whose recent nervous-system check-ins flagged high-risk
// symptoms or a concerning trend. Receives the precomputed `risk` object per
// client from TherapistPortal's metricsByClient.
export default function RiskAlertsSummary({ clients, metricsByClient, onSelectClient }) {
  const flagged = clients
    .map((c) => ({ client: c, risk: metricsByClient?.[c.email]?.risk }))
    .filter((x) => x.risk)
    .sort((a, b) => {
      // high before concern
      const order = (l) => (l === "high" ? 0 : 1);
      if (order(a.risk.level) !== order(b.risk.level)) return order(a.risk.level) - order(b.risk.level);
      return new Date(b.risk.date) - new Date(a.risk.date);
    });

  if (!flagged.length) return null;

  const high = flagged.filter((f) => f.risk.level === "high");

  return (
    <div className="mb-6 pp-card overflow-hidden">
      <div className="flex items-center gap-2 px-5 py-3 border-b border-border/60 bg-red-500/5">
        <ShieldAlert size={18} className="text-red-500" />
        <h2 className="font-heading text-base font-semibold">Risk Alerts</h2>
        <span className="text-xs text-muted-foreground">
          {flagged.length} client{flagged.length === 1 ? "" : "s"} flagged in recent check-ins
        </span>
        {high.length > 0 && (
          <span className="ml-auto px-2.5 py-1 rounded-full text-xs font-semibold bg-red-500/15 text-red-600">
            {high.length} high-risk
          </span>
        )}
      </div>

      <div className="divide-y divide-border/50">
        {flagged.map(({ client, risk }) => {
          const isHigh = risk.level === "high";
          const color = isHigh ? "#D9534F" : "#D4A055";
          return (
            <button
              key={client.email}
              onClick={() => onSelectClient(client.email)}
              className="w-full flex items-center gap-3 px-5 py-3 text-left hover:bg-secondary/40 transition"
            >
              <span className="w-2 h-2 rounded-full shrink-0" style={{ background: color }} />
              {isHigh ? <AlertTriangle size={15} className="shrink-0" style={{ color }} /> : null}
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium truncate">{client.name}</p>
                <p className="text-[11px] truncate" style={{ color }}>
                  {risk.reason}
                  {risk.date && (
                    <span className="text-muted-foreground">
                      {" · "}
                      {new Date(risk.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                    </span>
                  )}
                </p>
              </div>
              <ChevronRight size={16} className="text-muted-foreground/40 shrink-0" />
            </button>
          );
        })}
      </div>
    </div>
  );
}