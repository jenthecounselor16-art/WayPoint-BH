import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { CLIENT_FEATURES, FUNCTIONING_LEVELS, levelPreset } from "@/lib/clientFeatures";
import { SlidersHorizontal, Save } from "lucide-react";

export default function ClientAccessPanel({ clientEmail, therapistEmail }) {
  const [record, setRecord] = useState(null);
  const [level, setLevel] = useState("high");
  const [enabled, setEnabled] = useState(() => CLIENT_FEATURES.map((f) => f.key));
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState(null);

  useEffect(() => {
    if (!clientEmail) return;
    (async () => {
      try {
        const data = await base44.entities.ClientFeatureAccess.filter({ client_email: clientEmail }, "-created_date", 1);
        const rec = data?.[0] || null;
        setRecord(rec);
        setLevel(rec?.functioning_level || "high");
        setEnabled(rec?.enabled_features?.length ? rec.enabled_features : levelPreset(rec?.functioning_level || "high"));
      } catch {}
      setLoading(false);
    })();
  }, [clientEmail]);

  function applyLevel(newLevel) {
    setLevel(newLevel);
    setEnabled(levelPreset(newLevel));
  }

  function toggleFeature(key) {
    setEnabled((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  }

  async function save() {
    setSaving(true);
    try {
      const payload = {
        client_email: clientEmail,
        therapist_email: therapistEmail || "",
        functioning_level: level,
        enabled_features: enabled,
      };
      if (record) {
        await base44.entities.ClientFeatureAccess.update(record.id, payload);
      } else {
        const created = await base44.entities.ClientFeatureAccess.create(payload);
        setRecord(created);
      }
      setSavedAt(new Date().toLocaleTimeString());
    } catch {}
    setSaving(false);
  }

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 120 }}>
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <SlidersHorizontal size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Functioning & Feature Access</h3>
      </div>
      <p className="text-sm text-muted-foreground mb-4">
        Set the client's level of functioning to grant access to the app components appropriate for them. Higher-functioning clients get the full toolkit; lower-functioning clients see a focused set.
      </p>

      {/* Functioning level */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-2 mb-5">
        {FUNCTIONING_LEVELS.map((l) => (
          <button
            key={l.key}
            onClick={() => applyLevel(l.key)}
            className={`p-3 rounded-xl border text-left transition ${
              level === l.key ? "border-primary bg-primary/10" : "border-border/60 hover:border-primary/40"
            }`}
          >
            <p className="text-sm font-semibold">{l.label}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{l.description}</p>
          </button>
        ))}
      </div>

      {/* Feature toggles */}
      <p className="text-xs font-medium text-muted-foreground mb-2">Allowed features ({enabled.length} of {CLIENT_FEATURES.length})</p>
      <div className="grid sm:grid-cols-2 gap-2 mb-5">
        {CLIENT_FEATURES.map((f) => {
          const on = enabled.includes(f.key);
          return (
            <button
              key={f.key}
              onClick={() => toggleFeature(f.key)}
              className={`flex items-center gap-2.5 p-2.5 rounded-lg border text-sm text-left transition ${
                on ? "border-primary/40 bg-primary/5" : "border-border/60 bg-secondary/20"
              }`}
            >
              <span className={`w-5 h-5 rounded-md flex items-center justify-center shrink-0 ${on ? "bg-primary text-primary-foreground" : "border-2 border-border"}`}>
                {on && <span className="text-[10px]">✓</span>}
              </span>
              <span className={on ? "font-medium" : "text-muted-foreground"}>{f.label}</span>
            </button>
          );
        })}
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={save}
          disabled={saving}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:opacity-90 transition disabled:opacity-50"
        >
          {saving ? "Saving…" : <><Save size={16} /> Save Access</>}
        </button>
        {savedAt && !saving && <span className="text-xs text-muted-foreground">Saved at {savedAt}</span>}
      </div>
    </div>
  );
}