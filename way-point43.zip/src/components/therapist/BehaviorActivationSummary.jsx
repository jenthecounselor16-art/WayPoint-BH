import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Sparkles, Heart, Target, Repeat, Check, ChevronDown, CircleDashed } from "lucide-react";

const CATEGORIES = [
  { key: "enjoyable", label: "Enjoyable", icon: Heart, colorClass: "text-accent" },
  { key: "valuable", label: "Valuable", icon: Target, colorClass: "text-primary" },
  { key: "routine", label: "Routine", icon: Repeat, colorClass: "text-subtleAccent" },
];

const FREQ_LABEL = { daily: "Daily", weekly: "Weekly", as_needed: "As needed" };
const STATUS_LABEL = { planned: "Planned", active: "In progress", done: "Done" };

const FILTERS = [
  { key: "all", label: "All" },
  { key: "done", label: "Completed" },
  { key: "pending", label: "Pending" },
];

function catOf(key) {
  return CATEGORIES.find((c) => c.key === key) || CATEGORIES[0];
}

export default function BehaviorActivationSummary({ therapistEmail, clients }) {
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openClient, setOpenClient] = useState(null);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    if (!therapistEmail) return;
    (async () => {
      try {
        const data = await base44.entities.BehaviorActivationActivity.filter(
          { therapist_email: therapistEmail },
          "-created_date",
          300
        );
        setActivities(data || []);
      } catch {}
      setLoading(false);
    })();
  }, [therapistEmail]);

  const nameFor = (email) => {
    const c = (clients || []).find((x) => x.email === email);
    return c?.name || email;
  };

  const clientRows = useMemo(() => {
    const byClient = {};
    (activities || []).forEach((a) => {
      const e = a.client_email || "unknown";
      if (!byClient[e]) byClient[e] = [];
      byClient[e].push(a);
    });
    return Object.entries(byClient).map(([email, list]) => {
      const done = list.filter((a) => a.status === "done");
      const pending = list.filter((a) => a.status !== "done");
      return {
        email,
        list,
        done,
        pending,
        doneCount: done.length,
        pendingCount: pending.length,
        total: list.length,
      };
    });
  }, [activities]);

  const totals = useMemo(() => {
    const done = (activities || []).filter((a) => a.status === "done").length;
    const total = (activities || []).length;
    const pending = total - done;
    return { done, pending, total, pct: total ? Math.round((done / total) * 100) : 0 };
  }, [activities]);

  if (loading) {
    return (
      <div className="flex justify-center py-6">
        <div className="w-6 h-6 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (activities.length === 0) return null;

  const visibleRows = filter === "all"
    ? clientRows
    : clientRows.filter((r) => (filter === "done" ? r.doneCount : r.pendingCount) > 0);

  function ActivityRow({ a }) {
    const isDone = a.status === "done";
    const cat = catOf(a.category);
    const Icon = cat.icon;
    return (
      <div className="flex items-center gap-2.5 p-2 rounded-lg bg-secondary/30">
        <span className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${isDone ? "bg-primary text-primary-foreground" : "border-2 border-border"}`}>
          {isDone ? <Check size={11} /> : <CircleDashed size={10} className="text-muted-foreground" />}
        </span>
        <Icon size={13} className={cat.colorClass} />
        <p className={`text-sm flex-1 min-w-0 truncate ${isDone ? "line-through text-muted-foreground" : "font-medium"}`}>{a.name}</p>
        {a.linked_value && <span className="text-xs px-1.5 py-0.5 rounded bg-accent/10 text-accent shrink-0 hidden sm:inline">{a.linked_value}</span>}
        <span className="text-xs text-muted-foreground shrink-0 hidden md:inline">{FREQ_LABEL[a.frequency] || "—"}</span>
        <span className={`text-xs font-medium shrink-0 w-16 text-right ${isDone ? "text-primary" : "text-muted-foreground"}`}>
          {isDone
            ? (a.last_done_at ? new Date(a.last_done_at).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "Done")
            : STATUS_LABEL[a.status] || "Pending"}
        </span>
      </div>
    );
  }

  function ClientGroup({ title, items, emptyNote, accent }) {
    if (items.length === 0) {
      return (
        <div className="pt-1">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-1.5">{title}</p>
          <p className="text-xs text-muted-foreground/70 italic pl-1">{emptyNote}</p>
        </div>
      );
    }
    return (
      <div>
        <div className="flex items-center gap-2 mb-1.5">
          <span className={`w-2 h-2 rounded-full ${accent}`} />
          <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{title}</span>
          <span className="text-xs text-muted-foreground/70">({items.length})</span>
        </div>
        <div className="space-y-1.5">
          {items.map((a) => <ActivityRow key={a.id} a={a} />)}
        </div>
      </div>
    );
  }

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <Sparkles size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Behavior Activation Progress</h3>
        <span className="ml-auto text-xs text-muted-foreground">{totals.done}/{totals.total} completed</span>
      </div>

      {/* Overall progress bar */}
      <div className="mb-5">
        <div className="h-2.5 rounded-full bg-secondary overflow-hidden flex">
          <div className="h-full bg-primary transition-all duration-500" style={{ width: `${totals.pct}%` }} />
        </div>
        <div className="flex items-center justify-between mt-2 text-xs">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-primary" /> Completed {totals.done}
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-secondary border border-border" /> Pending {totals.pending}
          </span>
        </div>
      </div>

      {/* Filter toggle */}
      <div className="flex gap-1 p-1 rounded-lg bg-secondary/60 mb-4 w-fit">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`px-3 py-1 rounded-md text-xs font-medium transition ${filter === f.key ? "bg-card text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
          >
            {f.label}{f.key !== "all" && ` (${f.key === "done" ? totals.done : totals.pending})`}
          </button>
        ))}
      </div>

      {/* Per-client breakdown */}
      {visibleRows.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-4">No {filter === "done" ? "completed" : "pending"} activities.</p>
      ) : (
        <div className="space-y-2">
          {visibleRows.map((row) => {
            const open = openClient === row.email;
            const cPct = row.total ? Math.round((row.doneCount / row.total) * 100) : 0;
            const showDone = filter !== "pending";
            const showPending = filter !== "done";
            return (
              <div key={row.email} className="rounded-xl border border-border/60 overflow-hidden">
                <button
                  onClick={() => setOpenClient(open ? null : row.email)}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-secondary/40 transition text-left"
                >
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{nameFor(row.email)}</p>
                    <p className="text-xs text-muted-foreground">
                      <span className="text-primary font-medium">{row.doneCount} done</span> · {row.pendingCount} pending
                    </p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="w-20 h-2 rounded-full bg-secondary overflow-hidden">
                      <div className="h-full bg-primary transition-all duration-500" style={{ width: `${cPct}%` }} />
                    </div>
                    <span className="text-xs font-semibold w-9 text-right text-primary">{cPct}%</span>
                    <ChevronDown className={`text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} size={16} />
                  </div>
                </button>

                {open && (
                  <div className="px-4 pb-4 pt-2 border-t border-border/60 space-y-4">
                    {showDone && (
                      <ClientGroup
                        title="Completed"
                        items={row.done}
                        emptyNote="Nothing completed yet."
                        accent="bg-primary"
                      />
                    )}
                    {showPending && (
                      <ClientGroup
                        title="Pending"
                        items={row.pending}
                        emptyNote="All activities complete — great progress!"
                        accent="bg-muted-foreground/40"
                      />
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}