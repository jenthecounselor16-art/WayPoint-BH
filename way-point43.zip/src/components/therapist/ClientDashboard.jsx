import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Printer, Download, LineChart as LineChartIcon, Pencil, Trash2, Check, X, ClipboardCheck, Cloud, UserPlus } from "lucide-react";
import { exportElementToPDF, exportElementToPDFBase64 } from "@/lib/exportPdf";
import { useToast } from "@/components/ui/use-toast";
import ClientReportBody from "./ClientReportBody";
import MedicalNecessityPacket from "./MedicalNecessityPacket";
import ClientBarometer from "./ClientBarometer";
import ClientNervousSystemPanel from "./ClientNervousSystemPanel";
import ClientHomeworkPanel from "./ClientHomeworkPanel";
import ClientGoalsPanel from "./ClientGoalsPanel";
import ClientAssessmentPanel from "./ClientAssessmentPanel";
import ClientSafetyPlan from "./ClientSafetyPlan";
import ClientValuesPanel from "./ClientValuesPanel";
import ClinicalNotes from "./ClinicalNotes";
import ClientFunctionalImpairmentPanel from "./ClientFunctionalImpairmentPanel";
import ClientBarometerTrend from "./ClientBarometerTrend";
import ClientInitialVsRecent from "./ClientInitialVsRecent";
import ClientSymptomTrends from "./ClientSymptomTrends";
import ClientScoreProgress from "./ClientScoreProgress";
import ClientBehaviorActivationPanel from "./ClientBehaviorActivationPanel";
import ClientJournalPanel from "./ClientJournalPanel";
import ClientCopingPanel from "./ClientCopingPanel";
import ClientAccessPanel from "./ClientAccessPanel";
import ClientClinicalSummary from "./ClientClinicalSummary";
import InviteParentModal from "./InviteParentModal";
import SharedCarePanel from "./SharedCarePanel";

export default function ClientDashboard({ clientEmail, clientName, clientId, user, onBack, onClientRemoved }) {
  const [editName, setEditName] = useState(false);
  const [nameValue, setNameValue] = useState(clientName || clientEmail);
  const [removing, setRemoving] = useState(false);
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const [reportData, setReportData] = useState(null);
  const [showParentModal, setShowParentModal] = useState(false);
  const [packetMode, setPacketMode] = useState(false);
  const [saveToDrive, setSaveToDrive] = useState(false);
  const reportRef = useRef(null);
  const { toast } = useToast();

  useEffect(() => {
    (async () => {
      try {
        await base44.entities.AuditLog.create({
          action: "view_client_dashboard",
          client_email: clientEmail,
          therapist_email: user?.email || "",
          details: `Viewed dashboard for ${clientName || clientEmail}`,
        });
      } catch (e) {
        console.error("Audit log error:", e);
      }
    })();
  }, [clientEmail]);

  // When report data is fetched for an in-place download, wait for the
  // off-screen report to render, then capture it to a PDF.
  useEffect(() => {
    if (!reportData || !generatingPdf) return;
    const id = setTimeout(async () => {
      try {
        const base = packetMode ? "WayPoint_MedicalNecessity" : "WayPoint_Report";
        const fileName = `${base}_${(clientName || clientEmail).replace(/\s+/g, "_")}.pdf`;
        if (saveToDrive) {
          const fileBase64 = await exportElementToPDFBase64(reportRef.current);
          const res = await base44.functions.invoke("save-report-to-drive", { fileBase64, fileName });
          toast({
            title: "Saved to Google Drive",
            description: `${fileName} uploaded to your WayPoint Reports folder.`,
          });
        } else {
          await exportElementToPDF(reportRef.current, fileName);
        }
      } catch (e) {
        console.error("PDF export failed:", e);
        if (saveToDrive) {
          toast({
            title: "Save to Drive failed",
            description: e?.message || "Please try again.",
            variant: "destructive",
          });
        }
      }
      setGeneratingPdf(false);
      setPacketMode(false);
      setSaveToDrive(false);
      setReportData(null);
    }, 120);
    return () => clearTimeout(id);
  }, [reportData, generatingPdf]);

  async function fetchReportData() {
    const [a, g, f, n] = await Promise.all([
      base44.entities.AssessmentResult.filter({ client_email: clientEmail }, "-created_date", 50),
      base44.entities.TherapyGoal.filter({ client_email: clientEmail }, "-created_date", 50),
      base44.entities.FunctionalImpairment.filter({ client_email: clientEmail }, "-created_date", 20),
      base44.entities.NervousSystemMetric.filter({ client_email: clientEmail }, "-created_date", 20),
    ]);
    return { assessments: a || [], goals: g || [], impairments: f || [], nervous: n || [] };
  }

  async function handleDownloadReport() {
    setSaveToDrive(false);
    setPacketMode(false);
    setGeneratingPdf(true);
    try {
      setReportData(await fetchReportData());
    } catch (e) {
      console.error("Report data fetch failed:", e);
      setGeneratingPdf(false);
    }
  }

  async function handleSaveToDrive() {
    setSaveToDrive(true);
    setPacketMode(false);
    setGeneratingPdf(true);
    try {
      setReportData(await fetchReportData());
    } catch (e) {
      console.error("Report data fetch failed:", e);
      setGeneratingPdf(false);
      setSaveToDrive(false);
    }
  }

  async function handleDownloadPacket() {
    setSaveToDrive(false);
    setGeneratingPdf(true);
    setPacketMode(true);
    try {
      let therapist = user;
      try { const me = await base44.auth.me(); if (me) therapist = me; } catch {}
      const [a, g, f, n, hw, cp, inv] = await Promise.all([
        base44.entities.AssessmentResult.filter({ client_email: clientEmail }, "-created_date", 100),
        base44.entities.TherapyGoal.filter({ client_email: clientEmail }, "-created_date", 50),
        base44.entities.FunctionalImpairment.filter({ client_email: clientEmail }, "-created_date", 20),
        base44.entities.NervousSystemMetric.filter({ client_email: clientEmail }, "-created_date", 50),
        base44.entities.HomeworkAssignment.filter({ client_email: clientEmail }, "-created_date", 50),
        base44.entities.CrisisPlan.filter({ client_email: clientEmail }, "-created_date", 5),
        base44.entities.ClientInvitation.filter({ client_email: clientEmail }, "-created_date", 1),
      ]);
      let dateOfBirth = inv?.[0]?.date_of_birth || null;
      if (!dateOfBirth) {
        try {
          const users = await base44.entities.User.filter({ email: clientEmail }, "-created_date", 1);
          dateOfBirth = users?.[0]?.date_of_birth || null;
        } catch {}
      }
      setReportData({
        assessments: a || [],
        goals: g || [],
        impairments: f || [],
        nervous: n || [],
        homework: hw || [],
        crisisPlan: cp?.[0] || null,
        dateOfBirth,
        therapist,
      });
    } catch (e) {
      console.error("Packet data fetch failed:", e);
      setGeneratingPdf(false);
      setPacketMode(false);
    }
  }

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-4">
        <ArrowLeft size={16} /> Back to Clients
      </button>

      <div className="mb-6 pb-6 border-b border-border/60">
        <div className="mb-4">
          {editName ? (
            <div className="flex items-center gap-2">
              <input value={nameValue} onChange={(e) => setNameValue(e.target.value)} className="pp-input" />
              <button
                onClick={async () => {
                  try {
                    await base44.entities.Client.update(clientId, { client_name: nameValue.trim() || clientEmail });
                    setEditName(false);
                  } catch {}
                }}
                className="p-2 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition shrink-0"
                title="Save name"
              >
                <Check size={16} />
              </button>
              <button onClick={() => { setNameValue(clientName || clientEmail); setEditName(false); }} className="p-2 rounded-lg bg-secondary text-secondary-foreground hover:opacity-80 transition shrink-0" title="Cancel">
                <X size={16} />
              </button>
            </div>
          ) : (
            <>
              <h1 className="font-heading text-2xl md:text-3xl font-semibold">{clientName || clientEmail}</h1>
              <p className="text-sm text-muted-foreground">{clientEmail}</p>
            </>
          )}
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Link
            to={`/client-trends/${encodeURIComponent(clientEmail)}?name=${encodeURIComponent(clientName || "")}`}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-accent/10 text-accent text-sm font-medium hover:bg-accent/20 transition"
          >
            <LineChartIcon size={16} /> 90-day trends
          </Link>
          <button
            onClick={handleDownloadReport}
            disabled={generatingPdf}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition disabled:opacity-50"
          >
            {generatingPdf && !saveToDrive ? (
              <span className="block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
            ) : (
              <Download size={16} />
            )}
            {generatingPdf && !saveToDrive ? "Generating…" : "Download PDF"}
          </button>
          <button
            onClick={handleSaveToDrive}
            disabled={generatingPdf}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-accent/10 text-accent text-sm font-medium hover:bg-accent/20 transition disabled:opacity-50"
            title="Save PDF to your Google Drive"
          >
            {generatingPdf && saveToDrive ? (
              <span className="block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
            ) : (
              <Cloud size={16} />
            )}
            {generatingPdf && saveToDrive ? "Saving…" : "Save to Drive"}
          </button>
          <Link
            to={`/report/${encodeURIComponent(clientEmail)}?name=${encodeURIComponent(clientName || "")}`}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-primary/10 text-primary text-sm font-medium hover:bg-primary/20 transition"
          >
            <Printer size={16} /> Print Report
          </Link>
          <button
            onClick={handleDownloadPacket}
            disabled={generatingPdf}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-accent/10 text-accent text-sm font-medium hover:bg-accent/20 transition disabled:opacity-50"
            title="Download documentation supporting a medical necessity letter"
          >
            <ClipboardCheck size={16} /> Medical Necessity
          </button>
          <button
            onClick={() => setShowParentModal(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-accent/10 text-accent text-sm font-medium hover:bg-accent/20 transition"
            title="Invite a parent or guardian to view this client's progress"
          >
            <UserPlus size={16} /> Invite Parent
          </button>
          {clientId && (
            <>
              <button
                onClick={() => setEditName(true)}
                className="inline-flex items-center justify-center px-3 py-2 rounded-xl bg-secondary text-secondary-foreground text-sm font-medium hover:opacity-80 transition"
                title="Edit client name"
              >
                <Pencil size={16} />
              </button>
              <button
                onClick={async () => {
                  if (!window.confirm(`Remove ${clientName || clientEmail} from your client list? This won't delete their existing homework or goals.`)) return;
                  setRemoving(true);
                  try {
                    await base44.entities.Client.delete(clientId);
                    onClientRemoved?.();
                  } catch {}
                  setRemoving(false);
                }}
                disabled={removing}
                className="inline-flex items-center justify-center px-3 py-2 rounded-xl bg-destructive/10 text-destructive text-sm font-medium hover:bg-destructive/20 transition disabled:opacity-50"
                title="Remove client"
              >
                <Trash2 size={16} />
              </button>
            </>
          )}
        </div>
      </div>

      <ClientClinicalSummary clientEmail={clientEmail} />

      <SharedCarePanel clientEmail={clientEmail} user={user} />

      <div className="flex items-center gap-3 mt-10 mb-4">
        <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Clinical Details</span>
        <span className="h-px flex-1 bg-border/60" />
      </div>

      <div className="grid gap-6">
        <ClientBarometerTrend clientEmail={clientEmail} />

        <ClientInitialVsRecent clientEmail={clientEmail} />

        <ClientSymptomTrends clientEmail={clientEmail} />

        <ClientScoreProgress clientEmail={clientEmail} />

        <div className="grid lg:grid-cols-2 gap-6">
          <ClientBarometer clientEmail={clientEmail} />
          <ClientNervousSystemPanel clientEmail={clientEmail} />
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <ClientHomeworkPanel clientEmail={clientEmail} therapistEmail={user?.email} />
          <ClientGoalsPanel clientEmail={clientEmail} therapistEmail={user?.email} />
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <ClientAssessmentPanel clientEmail={clientEmail} therapistEmail={user?.email} />
          <ClientSafetyPlan clientEmail={clientEmail} />
        </div>

        <ClientFunctionalImpairmentPanel clientEmail={clientEmail} therapistEmail={user?.email} />

        <ClientAccessPanel clientEmail={clientEmail} therapistEmail={user?.email} />

        <div className="grid lg:grid-cols-2 gap-6">
          <ClientValuesPanel clientEmail={clientEmail} />
          <ClientBehaviorActivationPanel clientEmail={clientEmail} therapistEmail={user?.email} />
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <ClientJournalPanel clientEmail={clientEmail} />
          <ClientCopingPanel clientEmail={clientEmail} />
        </div>

        <ClinicalNotes clientEmail={clientEmail} therapistEmail={user?.email} />
      </div>

      {showParentModal && (
        <InviteParentModal
          clientEmail={clientEmail}
          clientName={clientName || clientEmail}
          therapistEmail={user?.email}
          onClose={() => setShowParentModal(false)}
        />
      )}

      {/* Off-screen report rendered only for one-click PDF capture */}
      {reportData && (
        <div style={{ position: "fixed", left: "-10000px", top: 0, width: "794px", background: "#fff" }}>
          <div ref={reportRef}>
            {packetMode ? (
              <MedicalNecessityPacket
                clientName={clientName || clientEmail}
                email={clientEmail}
                dateOfBirth={reportData.dateOfBirth}
                therapist={reportData.therapist || user}
                assessments={reportData.assessments}
                goals={reportData.goals}
                impairments={reportData.impairments}
                nervous={reportData.nervous}
                homework={reportData.homework}
                crisisPlan={reportData.crisisPlan}
              />
            ) : (
              <ClientReportBody
                clientName={clientName || clientEmail}
                email={clientEmail}
                therapist={user}
                assessments={reportData.assessments}
                goals={reportData.goals}
                impairments={reportData.impairments}
                nervous={reportData.nervous}
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
}