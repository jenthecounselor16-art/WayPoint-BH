import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Heart } from "lucide-react";

export default function ClientValuesPanel({ clientEmail }) {
  const [values, setValues] = useState(null);
  const [loading, setLoading] = useState(true);
  const topValues = values?.top_values?.length ? values.top_values : (values?.values || []).slice(0, 3);

  useEffect(() => {
    if (!clientEmail) return;
    (async () => {
      try {
        const data = await base44.entities.ValuesChecklist.filter({ client_email: clientEmail }, "-created_date", 1);
        setValues(data[0] || null);
      } catch {}
      setLoading(false);
    })();
  }, [clientEmail]);

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <Heart size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Client's Top 3 Values</h3>
      </div>
      {loading ? (
        <div className="flex justify-center py-4">
          <div className="w-6 h-6 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : topValues.length > 0 ? (
        <div className="space-y-2">
          {topValues.map((value, i) => (
            <div key={i} className="flex items-center gap-2.5 p-2 rounded-lg bg-primary/5">
              <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center shrink-0">{i + 1}</span>
              <span className="text-sm font-medium">{value}</span>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">The client hasn't completed their values inventory yet.</p>
      )}
    </div>
  );
}