import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { X, Send, MessageSquare } from "lucide-react";

export default function ClientMessageModal({ clientEmail, clientName, onClose }) {
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [status, setStatus] = useState(null); // { state: 'sent' | 'error', msg }

  async function send(e) {
    e.preventDefault();
    if (!subject.trim() || !body.trim()) return;
    setSending(true);
    setStatus(null);
    try {
      await base44.integrations.Core.SendEmail({
        to: clientEmail,
        subject: subject.trim(),
        body: body.trim(),
      });
      setStatus({ state: "sent" });
    } catch (err) {
      setStatus({ state: "error", msg: err?.message || "Could not send. The client may not be a registered WayPoint user." });
    }
    setSending(false);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4" onClick={onClose}>
      <div className="bg-card rounded-2xl shadow-xl w-full max-w-lg p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <MessageSquare size={18} className="text-primary" />
            <h3 className="font-heading text-lg font-semibold">Message {clientName || clientEmail}</h3>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-secondary transition" title="Close">
            <X size={18} className="text-muted-foreground" />
          </button>
        </div>

        {status?.state === "sent" ? (
          <div className="text-center py-6">
            <div className="w-12 h-12 rounded-full bg-accent/10 mx-auto mb-3 flex items-center justify-center">
              <Send size={22} className="text-accent" />
            </div>
            <p className="font-medium mb-1">Message sent</p>
            <p className="text-sm text-muted-foreground">Your message is on its way to {clientEmail}.</p>
            <button onClick={onClose} className="mt-5 px-5 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition">
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={send} className="space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">To</label>
              <p className="text-sm px-3 py-2 rounded-lg bg-secondary/40">{clientEmail}</p>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Subject</label>
              <input
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Checking in"
                className="pp-input"
                autoFocus
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Message</label>
              <textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Write your message…"
                className="pp-input min-h-[120px] resize-none"
              />
            </div>
            {status?.state === "error" && (
              <p className="text-sm text-destructive">{status.msg}</p>
            )}
            <p className="text-xs text-muted-foreground">
              Sends via WayPoint email. The client must be a registered WayPoint user to receive it.
            </p>
            <div className="flex gap-2 pt-1">
              <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl bg-secondary text-secondary-foreground text-sm font-medium hover:opacity-80 transition">
                Cancel
              </button>
              <button
                type="submit"
                disabled={sending || !subject.trim() || !body.trim()}
                className="flex-1 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {sending ? <span className="block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> : <Send size={15} />}
                {sending ? "Sending…" : "Send message"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}