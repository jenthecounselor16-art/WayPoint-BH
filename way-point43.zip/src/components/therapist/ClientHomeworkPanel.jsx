import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ClipboardCheck, Calendar, Check, Plus, Trash2 } from "lucide-react";
import { useSubscribeRefresh } from "@/hooks/useSubscribeRefresh";

export default function ClientHomeworkPanel({ clientEmail, therapistEmail }) {
  const [homework, setHomework] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", description: "", due_date: "", tasks: [] });
  const [newTask, setNewTask] = useState("");
  const [saving, setSaving] = useState(false);

  async function loadHomework() {
    try {
      const data = await base44.entities.HomeworkAssignment.filter({ client_email: clientEmail }, "-created_date", 50);
      setHomework(data || []);
    } catch {}
    setLoading(false);
  }
  useEffect(() => { loadHomework(); }, [clientEmail]);
  useSubscribeRefresh("HomeworkAssignment", loadHomework);

  async function updateCompletion(hw, percentage) {
    const status = percentage >= 100 ? "completed" : "assigned";
    try {
      await base44.entities.HomeworkAssignment.update(hw.id, { completion_percentage: percentage, status });
      setHomework(homework.map((h) => (h.id === hw.id ? { ...h, completion_percentage: percentage, status } : h)));
    } catch {}
  }

  function addTask() {
    if (!newTask.trim()) return;
    setForm({ ...form, tasks: [...form.tasks, newTask.trim()] });
    setNewTask("");
  }

  async function createHomework() {
    if (!form.title.trim()) return;
    setSaving(true);
    try {
      await base44.entities.HomeworkAssignment.create({
        title: form.title.trim(),
        description: form.description.trim() || undefined,
        due_date: form.due_date || undefined,
        tasks: form.tasks,
        client_email: clientEmail,
        therapist_email: therapistEmail || "",
        status: "assigned",
        completion_percentage: 0,
      });
      if (form.due_date) {
        try {
          await base44.functions.invoke("sync-calendar-event", {
            title: form.title,
            description: form.description,
            dueDate: form.due_date,
            clientName: clientEmail,
          });
        } catch (e) {
          console.error("Calendar sync failed:", e);
        }
      }
      const data = await base44.entities.HomeworkAssignment.filter({ client_email: clientEmail }, "-created_date", 50);
      setHomework(data || []);
      setForm({ title: "", description: "", due_date: "", tasks: [] });
      setShowForm(false);
    } catch {}
    setSaving(false);
  }

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 120 }}>
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const total = homework.length;
  const avgCompletion = total > 0
    ? Math.round(homework.reduce((sum, h) => sum + (h.completion_percentage || (h.status === "completed" ? 100 : 0)), 0) / total)
    : 0;

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <ClipboardCheck size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Homework</h3>
        {total > 0 && (
          <span className="text-sm text-muted-foreground">{avgCompletion}% avg</span>
        )}
        <button onClick={() => setShowForm(!showForm)} className="ml-auto px-3 py-1.5 rounded-lg bg-primary/10 text-primary text-xs font-medium hover:bg-primary/20 transition flex items-center gap-1">
          <Plus size={14} /> {showForm ? "Cancel" : "Assign"}
        </button>
      </div>

      {showForm && (
        <div className="mb-4 p-4 rounded-xl bg-secondary/30 space-y-3">
          <input
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder="Assignment title (e.g., Practice STOP skill daily)"
            className="pp-input"
          />
          <textarea
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="Instructions for the client (optional)"
            className="pp-input min-h-[60px] resize-none"
          />
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">Due date (next session)</label>
            <input type="date" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} className="pp-input" />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">Tasks</label>
            {form.tasks.length > 0 && (
              <div className="space-y-1.5 mb-2">
                {form.tasks.map((task, i) => (
                  <div key={i} className="flex items-center justify-between gap-2 px-3 py-1.5 rounded-lg bg-secondary/50 group">
                    <span className="text-sm">{task}</span>
                    <button onClick={() => setForm({ ...form, tasks: form.tasks.filter((_, idx) => idx !== i) })} className="text-muted-foreground/40 hover:text-destructive transition">
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}
            <div className="flex gap-2">
              <input
                value={newTask}
                onChange={(e) => setNewTask(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addTask(); } }}
                placeholder="Add a task…"
                className="pp-input flex-1"
              />
              <button onClick={addTask} className="px-3 rounded-xl bg-secondary text-secondary-foreground hover:opacity-80 transition flex items-center justify-center">
                <Plus size={18} />
              </button>
            </div>
          </div>
          <button
            onClick={createHomework}
            disabled={saving || !form.title.trim()}
            className="w-full py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition disabled:opacity-50"
          >
            {saving ? "Assigning…" : "Assign Homework"}
          </button>
        </div>
      )}

      {total === 0 ? (
        <p className="text-sm text-muted-foreground py-4 text-center">No homework assigned yet.</p>
      ) : (
        <div className="space-y-3">
          {homework.map((hw) => {
            const pct = hw.completion_percentage || (hw.status === "completed" ? 100 : 0);
            return (
              <div key={hw.id} className="p-3 rounded-xl bg-secondary/40">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{hw.title}</p>
                    {hw.due_date && (
                      <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                        <Calendar size={11} /> Due {new Date(hw.due_date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                      </p>
                    )}
                  </div>
                  <span className={`text-xs font-medium shrink-0 ${pct >= 100 ? "text-primary" : "text-muted-foreground"}`}>
                    {pct >= 100 ? <span className="flex items-center gap-0.5"><Check size={11} /> Done</span> : `${pct}%`}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="10"
                  value={pct}
                  onChange={(e) => updateCompletion(hw, parseInt(e.target.value))}
                  className="w-full h-2 rounded-full appearance-none cursor-pointer accent-primary"
                />
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}