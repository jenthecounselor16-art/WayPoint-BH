import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { ASSESSMENTS } from "@/lib/assessments";
import { TrendingUp, TrendingDown, Minus, GitCompareArrows } from "lucide-react";

const DAY = 86400000;

// Wellbeing % — higher is always better. WHO-5 counts up; all symptom
// scales are inverted so that a falling score means improvement.
function wellbeing(testType, score) {
  const test = ASSESSMENTS[testType];
  if (!test) return null;
  const maxScore = test.items.length * (test.scale.length - 1);
  if (!maxScore) return null;
  const ratio = score / maxScore;
  return testType === "WHO5" ? ratio * 100 : (1 - ratio) * 100;
}

function fmtDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

function DeltaBadge({ value }) {
  if (value === null || Number.isNaN(value)) return null;
  const rounded = Math.round(value);
  if (Math.abs(rounded) < 1) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-secondary text-xs font-medium text-muted-foreground">
        <Minus size={12} /> No change
      </span>
    );
  }
  const positive = rounded > 0;
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
      style={{
        backgroundColor: `${positive ? "#1995A1" : "#D9534F"}15`,
        color: positive ? "#1995A1" : "#D9534F",
      }}
    >
      {positive ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
      {positive ? "+" : ""}{rounded} pts
    </span>
  );
}

export default function ClientInitialVsRecent({ clientEmail }) {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.AssessmentResult.filter({ client_email: clientEmail }, "created_date", 200);
        setResults(data || []);
      } catch (e) {
        console.error("Initial vs recent fetch failed:", e);
        setError(true);
      }
      setLoading(false);
    })();
  }, [clientEmail]);

  const { rows, overallInitial, overallRecent, overallDelta } = useMemo(() => {
    const byType = {};
    (results || []).forEach((r) => {
      if (!byType[r.test_type]) byType[r.test_type] = [];
      byType[r.test_type].push(r);
    });
    Object.values(byType).forEach((list) => list.sort((a, b) => new Date(a.created_date) - new Date(b.created_date)));

    const rows = [];
    const initials = [];
    const recents = [];
    Object.keys(byType).forEach((testType) => {
      const list = byType[testType];
      const first = list[0];
      const last = list[list.length - 1];
      const wbFirst = wellbeing(testType, first.score);
      const wbLast = wellbeing(testType, last.score);
      const sameRecord = first.id === last.id;
      if (wbFirst !== null) initials.push(wbFirst);
      if (wbLast !== null) recents.push(wbLast);
      rows.push({
        testType,
        first,
        last,
        wbFirst,
        wbLast,
        delta: wbFirst !== null && wbLast !== null ? wbLast - wbFirst : null,
        sameRecord,
        hasMultiple: list.length > 1,
      });
    });
    rows.sort((a, b) => (ASSESSMENTS[a.testType]?.name || a.testType).localeCompare(ASSESSMENTS[b.testType]?.name || b.testType));

    const overallInitial = initials.length ? initials.reduce((x, y) => x + y, 0) / initials.length : null;
    const overallRecent = recents.length ? recents.reduce((x, y) => x + y, 0) / recents.length : null;
    const overallDelta = overallInitial !== null && overallRecent !== null ? overallRecent - overallInitial : null;
    return { rows, overallInitial, overallRecent, overallDelta };
  }, [results]);

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 140 }}>
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="pp-card p-6 text-center">
        <h3 className="font-heading text-lg font-semibold mb-1">Initial vs. Recent</h3>
        <p className="text-sm text-muted-foreground">Couldn't load assessment history.</p>
      </div>
    );
  }

  if (rows.length === 0) {
    return (
      <div className="pp-card p-6 text-center">
        <GitCompareArrows className="mx-auto mb-3 text-muted-foreground/40" size={32} />
        <h3 className="font-heading text-lg font-semibold mb-1">Initial vs. Recent</h3>
        <p className="text-sm text-muted-foreground">No assessment data yet for this client.</p>
      </div>
    );
  }

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <GitCompareArrows size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Initial vs. Most Recent</h3>
        <span className="ml-auto text-xs text-muted-foreground">Wellbeing % (higher = better)</span>
      </div>

      {/* Overall summary */}
      {overallInitial !== null && overallRecent !== null && (
        <div className="mb-4 p-4 rounded-xl bg-primary/5 border border-primary/15 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            <p className="text-sm font-medium">Overall Wellbeing</p>
            <p className="text-xs text-muted-foreground">Average across all administered screens</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-center">
              <p className="text-xs text-muted-foreground">Initial</p>
              <p className="font-heading text-2xl font-semibold">{Math.round(overallInitial)}</p>
            </div>
            <span className="text-muted-foreground/40 text-xl">→</span>
            <div className="text-center">
              <p className="text-xs text-muted-foreground">Most Recent</p>
              <p className="font-heading text-2xl font-semibold text-primary">{Math.round(overallRecent)}</p>
            </div>
            <div className="ml-1">
              <DeltaBadge value={overallDelta} />
            </div>
          </div>
        </div>
      )}

      {/* Per-assessment side-by-side */}
      <div className="overflow-x-auto pp-scroll-hide">
        <table className="w-full text-sm min-w-[560px]">
          <thead>
            <tr className="text-xs text-muted-foreground border-b border-border/60">
              <th className="text-left font-medium pb-2 pr-3">Assessment</th>
              <th className="text-center font-medium pb-2 px-2">Initial</th>
              <th className="text-center font-medium pb-2 px-2">Most Recent</th>
              <th className="text-right font-medium pb-2 pl-3">Change</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => {
              const test = ASSESSMENTS[row.testType];
              const firstScored = test?.score(row.first.score);
              const lastScored = test?.score(row.last.score);
              return (
                <tr key={row.testType} className="border-b border-border/40 last:border-0">
                  <td className="py-3 pr-3">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-md bg-primary/10 text-primary text-xs font-bold">{test?.abbr || row.testType}</span>
                      <span className="text-xs text-muted-foreground hidden sm:inline">{test?.name || row.testType}</span>
                    </div>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <p className="font-heading text-lg font-semibold">{row.first.score}</p>
                    <p className="text-xs text-muted-foreground">{fmtDate(row.first.created_date)}</p>
                    {row.wbFirst !== null && (
                      <p className="text-[11px] text-muted-foreground/80">{Math.round(row.wbFirst)}% wellbeing</p>
                    )}
                    {firstScored && (
                      <span className="mt-0.5 inline-block px-1.5 py-0.5 rounded text-[10px] font-medium" style={{ backgroundColor: `${firstScored.color}15`, color: firstScored.color }}>
                        {firstScored.severity}
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-2 text-center">
                    <p className="font-heading text-lg font-semibold text-primary">{row.last.score}</p>
                    <p className="text-xs text-muted-foreground">{fmtDate(row.last.created_date)}</p>
                    {row.wbLast !== null && (
                      <p className="text-[11px] text-muted-foreground/80">{Math.round(row.wbLast)}% wellbeing</p>
                    )}
                    {lastScored && (
                      <span className="mt-0.5 inline-block px-1.5 py-0.5 rounded text-[10px] font-medium" style={{ backgroundColor: `${lastScored.color}15`, color: lastScored.color }}>
                        {lastScored.severity}
                      </span>
                    )}
                  </td>
                  <td className="py-3 pl-3 text-right">
                    {row.sameRecord ? (
                      <span className="text-xs text-muted-foreground">First reading</span>
                    ) : (
                      <DeltaBadge value={row.delta} />
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <p className="text-xs text-muted-foreground mt-3">
        Wellbeing % inverts symptom scales (e.g. PHQ-9, GAD-7) so that higher always indicates improvement. WHO-5 is scored directly.
      </p>
    </div>
  );
}