import React from "react";
import { ASSESSMENTS } from "@/lib/assessments";
import { NEGATIVE_ITEMS, MAX_IMPAIRMENT } from "@/lib/functionalImpairment";

const NOT_SIGNIFICANT = ["Minimal", "Low", "Good Wellbeing", "No Insomnia"];
const DOMAIN = {
  PHQ9: "Major Depressive Disorder / depressive disorders",
  BDI: "Major Depressive Disorder / depressive disorders",
  GAD7: "Generalized Anxiety Disorder / anxiety disorders",
  BAI: "Generalized Anxiety Disorder / anxiety disorders",
  "PCL-5": "Posttraumatic Stress Disorder",
  ISI: "Insomnia Disorder",
  K6: "general psychological distress",
  WHO5: "diminished wellbeing",
  ASRS: "Attention-Deficit/Hyperactivity Disorder",
};

function latestPerType(assessments) {
  const map = {};
  assessments.forEach((a) => {
    if (!map[a.test_type] || new Date(a.created_date) > new Date(map[a.test_type].created_date)) map[a.test_type] = a;
  });
  return map;
}
function firstPerType(assessments) {
  const map = {};
  assessments.forEach((a) => {
    if (!map[a.test_type] || new Date(a.created_date) < new Date(map[a.test_type].created_date)) map[a.test_type] = a;
  });
  return map;
}
function severityOf(a) {
  const test = ASSESSMENTS[a.test_type];
  return test?.score?.(a.score)?.severity || a.severity;
}

export default function MedicalNecessityPacket({
  clientName, email, dateOfBirth, therapist,
  assessments = [], goals = [], impairments = [],
  nervous = [], homework = [], crisisPlan = null,
}) {
  const reportDate = new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  // Parse "YYYY-MM-DD" parts directly so timezone conversion doesn't shift the
  // displayed day (new Date("1992-04-06") is UTC midnight → wrong day in some tz).
  const dob = (() => {
    if (!dateOfBirth) return null;
    const m = dateOfBirth.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) {
      const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
      return d.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
    }
    const d = new Date(dateOfBirth);
    return d.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  })();

  const latest = latestPerType(assessments);
  const first  = firstPerType(assessments);

  const significant = Object.values(latest).filter((a) => {
    const sev = severityOf(a);
    return sev && !NOT_SIGNIFICANT.includes(sev);
  });
  const impressionDomains = [...new Set(significant.map((a) => DOMAIN[a.test_type]).filter(Boolean))];

  const latestImpairment = impairments[0];
  const impScore = latestImpairment
    ? NEGATIVE_ITEMS.reduce((s, i) => s + (latestImpairment[i.key] || 0), 0)
    : 0;
  const impPct     = Math.round((impScore / MAX_IMPAIRMENT) * 100);
  const flaggedAreas = latestImpairment
    ? NEGATIVE_ITEMS.filter((i) => (latestImpairment[i.key] || 0) >= 3).map((i) => i.label)
    : [];

  const allDates = [...assessments, ...nervous, ...homework]
    .map((x) => x.created_date && new Date(x.created_date).getTime())
    .filter(Boolean);
  const firstDate  = allDates.length ? Math.min(...allDates) : null;
  const daysInCare = firstDate ? Math.max(1, Math.round((Date.now() - firstDate) / 86400000)) : 0;
  const hwCompleted = homework.filter((h) => h.status === "completed").length;

  const phq    = latest.PHQ9;
  const siItem = phq?.answers?.[8];
  const siPresent = typeof siItem === "number" && siItem > 0;

  const clinicianName = therapist?.display_name || therapist?.full_name || "";

  return (
    <div style={{ fontFamily: "Inter, Arial, sans-serif", fontSize: "11pt", lineHeight: 1.45, color: "#1a1a1a", background: "#fff", padding: "0 0 24px 0" }}>

      {/* ── Repeating page header ──────────────────────────────── */}
      <div data-pdf-header style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", borderBottom: "1.5px solid #ccc", paddingBottom: "6px", marginBottom: "0" }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: "11pt" }}>Client: {clientName}</div>
          {dob && <div style={{ fontSize: "10pt", color: "#555" }}>DOB: {dob}</div>}
        </div>
        <div style={{ textAlign: "right", fontSize: "10pt", color: "#444" }}>
          {clinicianName && <div style={{ fontWeight: 700, color: "#1a1a1a" }}>{clinicianName}</div>}
          {therapist?.practice_name && <div>{therapist.practice_name}</div>}
          {therapist?.practice_address && <div>{therapist.practice_address}</div>}
          {therapist?.npi && <div>NPI: {therapist.npi}</div>}
        </div>
      </div>

      {/* ── Body ─────────────────────────────────────────────────── */}
      <div style={{ paddingTop: "10px" }}>

        {/* Title block */}
        <div style={{ marginBottom: "10px" }}>
          <div style={{ fontWeight: 700, fontSize: "14pt", color: "#0f766e", marginBottom: "2px" }}>WayPoint</div>
          <div style={{ fontWeight: 700, fontSize: "13pt" }}>Clinical Documentation in Support of Medical Necessity</div>
          <div style={{ fontSize: "10pt", color: "#666", marginTop: "2px" }}>{reportDate}</div>
        </div>

        {/* Purpose */}
        <p style={{ marginBottom: "10px", fontSize: "11pt" }}>
          This document summarizes objective clinical data gathered through WayPoint to support medical necessity
          for continued behavioral health treatment.{" "}
          {impressionDomains.length > 0 ? (
            <>Validated screening measures indicate clinically significant symptoms consistent with{" "}
              <strong>{impressionDomains.join("; ")}.</strong>{" "}
              Symptoms are associated with functional impairment and warrant continued therapeutic intervention.</>
          ) : (
            "No clinically significant elevations are documented on current validated measures."
          )}
        </p>

        {/* Validated Measures */}
        <div style={{ marginBottom: "12px" }}>
          <div style={{ fontWeight: 700, fontSize: "11pt", borderBottom: "1px solid #ddd", marginBottom: "6px", paddingBottom: "2px" }}>
            Symptom Severity — Validated Measures
          </div>
          {Object.keys(latest).length === 0 ? (
            <p style={{ color: "#888", fontStyle: "italic" }}>No assessments on record.</p>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "10.5pt" }}>
              <thead>
                <tr style={{ background: "#f3f4f6" }}>
                  <th style={thStyle}>Measure</th>
                  <th style={{ ...thStyle, textAlign: "center" }}>Initial</th>
                  <th style={{ ...thStyle, textAlign: "center" }}>Latest</th>
                  <th style={{ ...thStyle, textAlign: "center" }}>Change</th>
                  <th style={thStyle}>Severity</th>
                  <th style={thStyle}>Interpretation</th>
                </tr>
              </thead>
              <tbody>
                {Object.values(latest).map((a) => {
                  const test      = ASSESSMENTS[a.test_type];
                  const f         = first[a.test_type];
                  const change    = f ? a.score - f.score : 0;
                  const pos       = a.test_type === "WHO5";
                  const improved  = pos ? change > 0 : change < 0;
                  const computed  = test?.score?.(a.score);
                  const sevLabel  = computed?.severity || a.severity || "—";
                  const sevColor  = computed?.color || "#888";
                  const sig       = sevLabel && !NOT_SIGNIFICANT.includes(sevLabel);
                  const changeColor = improved ? "#0f766e" : change === 0 ? "#888" : "#c0392b";
                  return (
                    <tr key={a.id} style={{ borderBottom: "1px solid #e5e7eb" }}>
                      <td style={tdStyle}><strong>{a.test_type}</strong></td>
                      <td style={{ ...tdStyle, textAlign: "center" }}>{f ? f.score : "—"}</td>
                      <td style={{ ...tdStyle, textAlign: "center", fontWeight: 700 }}>{a.score}</td>
                      <td style={{ ...tdStyle, textAlign: "center", color: changeColor }}>
                        {change > 0 ? `+${change}` : change < 0 ? `${change}` : "—"}
                      </td>
                      <td style={tdStyle}>
                        <span style={{ background: `${sevColor}22`, color: sevColor, padding: "1px 6px", borderRadius: "10px", fontSize: "10pt", fontWeight: 600 }}>
                          {sevLabel}
                        </span>
                      </td>
                      <td style={{ ...tdStyle, fontSize: "10pt", color: "#444" }}>
                        {sig ? "Clinically significant; supports continued treatment." : "Within normal range."}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Functional Impairment & Engagement */}
        <div style={{ marginBottom: "12px" }}>
          <div style={{ fontWeight: 700, fontSize: "11pt", borderBottom: "1px solid #ddd", marginBottom: "6px", paddingBottom: "2px" }}>
            Functional Impairment &amp; Engagement
          </div>
          <div style={{ display: "flex", gap: "10px", marginBottom: "6px" }}>
            {[
              { label: "Functional Impairment", value: `${impPct}%` },
              { label: "Enjoyable Activity Rating", value: `${latestImpairment?.enjoyable_activities ?? "—"}/4` },
              { label: "Days in Care", value: daysInCare },
              { label: "Homework Completed", value: `${hwCompleted}/${homework.length}` },
            ].map((s) => (
              <div key={s.label} style={{ flex: 1, border: "1px solid #e5e7eb", borderRadius: "6px", padding: "6px 8px" }}>
                <div style={{ fontSize: "9.5pt", color: "#666" }}>{s.label}</div>
                <div style={{ fontWeight: 700, fontSize: "13pt" }}>{s.value}</div>
              </div>
            ))}
          </div>
          {flaggedAreas.length > 0 && (
            <p style={{ marginTop: "4px", fontSize: "10.5pt" }}>
              <strong>Significant impairment areas:</strong> {flaggedAreas.join(", ")}. These areas impair occupational, social, and self-care functioning, supporting medical necessity.
            </p>
          )}
        </div>

        {/* Treatment Goals */}
        <div style={{ marginBottom: "12px" }}>
          <div style={{ fontWeight: 700, fontSize: "11pt", borderBottom: "1px solid #ddd", marginBottom: "6px", paddingBottom: "2px" }}>
            Treatment Plan &amp; Goals
          </div>
          {goals.length === 0 ? (
            <p style={{ color: "#888", fontStyle: "italic" }}>No treatment goals on record.</p>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "10.5pt" }}>
              <thead>
                <tr style={{ background: "#f3f4f6" }}>
                  <th style={thStyle}>Goal</th>
                  <th style={{ ...thStyle, textAlign: "center", width: "80px" }}>Client</th>
                  <th style={{ ...thStyle, textAlign: "center", width: "80px" }}>Clinician</th>
                  <th style={{ ...thStyle, textAlign: "center", width: "70px" }}>Status</th>
                </tr>
              </thead>
              <tbody>
                {goals.slice(0, 6).map((g) => (
                  <tr key={g.id} style={{ borderBottom: "1px solid #e5e7eb" }}>
                    <td style={tdStyle}>{g.title}</td>
                    <td style={{ ...tdStyle, textAlign: "center" }}>{g.client_rating ?? "—"}/10</td>
                    <td style={{ ...tdStyle, textAlign: "center" }}>{g.therapist_rating ?? "—"}/10</td>
                    <td style={{ ...tdStyle, textAlign: "center", fontSize: "10pt", color: "#666" }}>{g.status || "active"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Risk & Safety */}
        <div style={{ marginBottom: "12px" }}>
          <div style={{ fontWeight: 700, fontSize: "11pt", borderBottom: "1px solid #ddd", marginBottom: "6px", paddingBottom: "2px" }}>
            Risk &amp; Safety Considerations
          </div>
          <div style={{ border: "1px solid #e5e7eb", borderRadius: "6px", padding: "8px 10px", fontSize: "10.5pt" }}>
            {siPresent && (
              <p style={{ marginBottom: "4px" }}>
                <strong style={{ color: "#c0392b" }}>Suicidal ideation endorsed</strong> on most recent PHQ-9 (item 9 score: {siItem}). Ongoing monitoring and safety planning are indicated.
              </p>
            )}
            {crisisPlan ? (
              <p style={{ margin: 0 }}>
                <strong>Safety plan on file</strong> including warning signs, coping strategies, and emergency contacts, supporting continuity of safety planning.
              </p>
            ) : !siPresent ? (
              <p style={{ margin: 0, color: "#666", fontStyle: "italic" }}>No acute risk indicators or formal safety plan documented at this time.</p>
            ) : null}
          </div>
        </div>

        {/* Medical Necessity Justification */}
        <div style={{ marginBottom: "12px" }}>
          <div style={{ fontWeight: 700, fontSize: "11pt", borderBottom: "1px solid #ddd", marginBottom: "6px", paddingBottom: "2px" }}>
            Medical Necessity Justification
          </div>
          <div style={{ border: "1px solid #e5e7eb", borderRadius: "6px", padding: "8px 10px", fontSize: "10.5pt" }}>
            <p style={{ marginBottom: "8px" }}>
              Based on the validated measures, functional impairment data, and treatment response above, the client demonstrates
              clinically significant symptoms impairing daily functioning that are responsive to psychotherapeutic intervention.
              Discontinuation would reasonably result in symptom recurrence or worsening, increased impairment, and elevated
              clinical risk. Continued treatment is medically necessary to reduce symptom severity, restore function, and
              maintain safety.
            </p>
            <div style={{ display: "flex", gap: "20px" }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: "9.5pt", color: "#666", marginBottom: "2px" }}>Recommended session frequency:</div>
                <div style={{ borderBottom: "1px solid #555", height: "18px" }} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: "9.5pt", color: "#666", marginBottom: "2px" }}>Estimated duration of continued care:</div>
                <div style={{ borderBottom: "1px solid #555", height: "18px" }} />
              </div>
            </div>
          </div>
        </div>

        {/* Additional Clinical Notes */}
        <div style={{ marginBottom: "12px" }}>
          <div style={{ fontWeight: 700, fontSize: "11pt", borderBottom: "1px solid #ddd", marginBottom: "6px", paddingBottom: "2px" }}>
            Additional Clinical Notes
          </div>
          <div style={{ border: "1px solid #e5e7eb", borderRadius: "6px", padding: "8px 10px" }}>
            <div style={{ borderBottom: "1px solid #aaa", height: "20px", marginBottom: "10px" }} />
            <div style={{ borderBottom: "1px solid #aaa", height: "20px", marginBottom: "10px" }} />
            <div style={{ borderBottom: "1px solid #aaa", height: "20px" }} />
          </div>
        </div>

        {/* Attestation — keep entire signature block on one page */}
        <div data-pdf-keep style={{ borderTop: "2px solid #e5e7eb", paddingTop: "10px", marginTop: "8px" }}>
          <div style={{ display: "flex", gap: "20px", marginBottom: "10px" }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: "9.5pt", color: "#666", marginBottom: "2px" }}>Clinician signature</div>
              <div style={{ borderBottom: "1px solid #555", height: "22px" }} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: "9.5pt", color: "#666", marginBottom: "2px" }}>Date</div>
              <div style={{ borderBottom: "1px solid #555", height: "22px" }} />
            </div>
          </div>
          <div style={{ display: "flex", gap: "20px", marginBottom: "8px" }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: "9.5pt", color: "#666", marginBottom: "2px" }}>License / credential #</div>
              <div style={{ borderBottom: "1px solid #555", height: "22px" }} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: "9.5pt", color: "#666", marginBottom: "2px" }}>NPI</div>
              {therapist?.npi
                ? <div style={{ paddingTop: "3px", fontWeight: 600 }}>{therapist.npi}</div>
                : <div style={{ borderBottom: "1px solid #555", height: "22px" }} />}
            </div>
          </div>
          <p style={{ fontSize: "9pt", color: "#888", marginTop: "4px" }}>
            Generated from WayPoint — contains PHI. Supports, not replaces, the treating clinician's clinical judgment.
            Crisis support: call or text <strong style={{ color: "#1a1a1a" }}>988</strong> (24/7).
          </p>
        </div>

      </div>{/* end body */}
    </div>
  );
}

// Inline style helpers
const thStyle = {
  textAlign: "left",
  padding: "5px 8px",
  fontWeight: 600,
  fontSize: "10.5pt",
  borderBottom: "1px solid #d1d5db",
};
const tdStyle = {
  padding: "5px 8px",
  verticalAlign: "top",
};