import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { copingTools } from "@/lib/copingTools";
import { Star } from "lucide-react";
import { useSubscribeRefresh } from "@/hooks/useSubscribeRefresh";

// Real-time view of a client's saved coping tools. Updates the moment the
// client stars or unstars a tool in their Coping Toolbox.
export default function ClientCopingPanel({ clientEmail }) {
  const [favorites, setFavorites] = useState([]);
  const [loading, setLoading] = useState(true);

  async function loadFavorites() {
    try {
      const data = await base44.entities.CopingFavorite.filter({ client_email: clientEmail }, "-created_date", 100);
      setFavorites(data || []);
    } catch {}
    setLoading(false);
  }

  useEffect(() => {
    setLoading(true);
    loadFavorites();
  }, [clientEmail]);

  useSubscribeRefresh("CopingFavorite", loadFavorites);

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <Star size={16} className="text-amber-500" fill="currentColor" />
        <h3 className="font-heading text-lg font-semibold">Saved Coping Tools</h3>
        <span className="ml-auto text-xs text-muted-foreground">
          {favorites.length} favorite{favorites.length === 1 ? "" : "s"}
        </span>
      </div>

      {loading ? (
        <div className="flex justify-center py-8">
          <div className="w-6 h-6 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : favorites.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          No saved tools yet. Tools the client stars in their Coping Toolbox appear here instantly.
        </p>
      ) : (
        <div className="space-y-1.5">
          {favorites.map((f) => {
            const tool = copingTools.find((t) => t.key === f.tool_key);
            return (
              <div key={f.id} className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-secondary/40">
                <Star size={13} className="text-amber-500 shrink-0" fill="currentColor" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium truncate">{tool?.name || f.tool_key}</p>
                  {tool && (
                    <p className="text-xs text-muted-foreground">
                      {tool.category} · {tool.duration}
                    </p>
                  )}
                </div>
                <span className="text-[11px] text-muted-foreground shrink-0">
                  {new Date(f.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}