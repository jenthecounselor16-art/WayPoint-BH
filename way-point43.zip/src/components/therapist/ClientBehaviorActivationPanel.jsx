import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Heart, Target, Repeat, Sparkles, Check } from "lucide-react";

const CATEGORIES = [
  { key: "enjoyable", label: "Enjoyable", icon: Heart, color: "accent" },
  { key: "valuable", label: "Valuable", icon: Target, color: "primary" },
  { key: "routine", label: "Routine", icon: Repeat, color: "subtleAccent" },
];

const FREQ_LABEL = { daily: "Daily", weekly: "Weekly", as_needed: "As needed" };

export default function ClientBehaviorActivationPanel({ clientEmail }) {
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!clientEmail) return;
    (async () => {
      try {
        const data = await base44.entities.BehaviorActivationActivity.filter({ client_email: clientEmail }, "-created_date", 100);
        setActivities(data || []);
      } catch {}
      setLoading(false);
    })();
  }, [clientEmail]);

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <Sparkles size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Behavior Activation</h3>
        <span className="ml-auto text-xs text-muted-foreground">{activities.length} activit{activities.length === 1 ? "y" : "ies"}</span>
      </div>

      {loading ? (
        <div className="flex justify-center py-4">
          <div className="w-6 h-6 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : activities.length === 0 ? (
        <p className="text-sm text-muted-foreground">No behavior activation activities yet. The client can build these from their Home page.</p>
      ) : (
        <div className="space-y-5">
          {CATEGORIES.map((cat) => {
            const items = activities.filter((a) => a.category === cat.key);
            if (items.length === 0) return null;
            const Icon = cat.icon;
            return (
              <div key={cat.key}>
                <div className="flex items-center gap-2 mb-2">
                  <Icon size={15} className={`text-${cat.color}`} />
                  <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{cat.label}</span>
                </div>
                <div className="space-y-2">
                  {items.map((a) => (
                    <div key={a.id} className="flex items-center gap-2.5 p-2.5 rounded-lg bg-secondary/30">
                      <span className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${a.status === "done" ? "bg-primary text-primary-foreground" : "border-2 border-border"}`}>
                        {a.status === "done" && <Check size={12} />}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className={`text-sm font-medium ${a.status === "done" ? "line-through text-muted-foreground" : ""}`}>{a.name}</p>
                        <div className="flex items-center gap-2 flex-wrap mt-0.5">
                          {a.linked_value && <span className="text-xs px-1.5 py-0.5 rounded bg-accent/10 text-accent">{a.linked_value}</span>}
                          <span className="text-xs text-muted-foreground">{FREQ_LABEL[a.frequency] || a.frequency}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}