import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { ASSESSMENTS } from "@/lib/assessments";
import { NEGATIVE_ITEMS, MAX_IMPAIRMENT } from "@/lib/functionalImpairment";
import {
  ClipboardList, TrendingUp, TrendingDown, Minus, Calendar,
  Activity, CheckCircle2, Target, AlertTriangle, ShieldCheck, FileText,
} from "lucide-react";
import { useSubscribeRefresh } from "@/hooks/useSubscribeRefresh";

const DAY = 86400000;

// Wellbeing % — higher is always better. Symptom scales inverted; WHO-5 direct.
function wellbeing(testType, score) {
  const test = ASSESSMENTS[testType];
  if (!test) return null;
  const maxScore = test.items.length * (test.scale.length - 1);
  if (!maxScore) return null;
  const ratio = score / maxScore;
  return testType === "WHO5" ? ratio * 100 : (1 - ratio) * 100;
}

// Composite wellbeing (0–100) from the most recent score of each assessment
// type on or before asOfMs. Mirrors the barometer used in the Therapist Portal.
function barometerAt(assessments, asOfMs) {
  const latest = {};
  assessments.forEach((a) => {
    if (new Date(a.created_date).getTime() > asOfMs) return;
    if (!latest[a.test_type] || new Date(a.created_date) > new Date(latest[a.test_type].created_date)) {
      latest[a.test_type] = a;
    }
  });
  const scores = Object.values(latest).map((a) => wellbeing(a.test_type, a.score)).filter((s) => s !== null);
  if (!scores.length) return null;
  return scores.reduce((x, y) => x + y, 0) / scores.length;
}

function timeAgo(ms) {
  if (!ms) return "No activity yet";
  const diff = Date.now() - ms;
  const days = Math.floor(diff / DAY);
  if (days <= 0) return "Today";
  if (days === 1) return "1 day ago";
  if (days < 30) return `${days} days ago`;
  return `${Math.floor(days / 30)} mo ago`;
}

// Severity ranking so the most clinically salient concern surfaces first.
const SEVERITY_RANK = {
  "Very High": 6, Severe: 5, "Moderate-Severe": 4.5, "Moderately Severe": 4.5,
  Moderate: 4, "Poor Wellbeing": 4, Subthreshold: 3, Mild: 3,
  "Moderate Wellbeing": 2, Minimal: 2, Low: 2, "No Insomnia": 1, "Good Wellbeing": 1,
};

// Symptom scales (negative valence) — used to flag "most prominent concern".
const SYMPTOM_SCALES = ["PHQ9", "BDI", "GAD7", "BAI", "PCL-5", "ISI", "K6", "ASRS"];

export default function ClientClinicalSummary({ clientEmail }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  async function loadSummary() {
    try {
      const [assessments, nervous, impairments, homework, goals, crisisPlans] = await Promise.all([
        base44.entities.AssessmentResult.filter({ client_email: clientEmail }, "-created_date", 200),
        base44.entities.NervousSystemMetric.filter({ client_email: clientEmail }, "-created_date", 200),
        base44.entities.FunctionalImpairment.filter({ client_email: clientEmail }, "-created_date", 20),
        base44.entities.HomeworkAssignment.filter({ client_email: clientEmail }, "-created_date", 100),
        base44.entities.TherapyGoal.filter({ client_email: clientEmail }, "-created_date", 50),
        base44.entities.CrisisPlan.filter({ client_email: clientEmail }, "-created_date", 5),
      ]);
      setData({
        assessments: assessments || [],
        nervous: nervous || [],
        impairments: impairments || [],
        homework: homework || [],
        goals: goals || [],
        crisisPlan: crisisPlans?.[0] || null,
      });
    } catch (e) {
      console.error("Clinical summary fetch failed:", e);
    }
    setLoading(false);
  }
  useEffect(() => { loadSummary(); }, [clientEmail]);
  useSubscribeRefresh("AssessmentResult", loadSummary);
  useSubscribeRefresh("NervousSystemMetric", loadSummary);
  useSubscribeRefresh("FunctionalImpairment", loadSummary);
  useSubscribeRefresh("HomeworkAssignment", loadSummary);
  useSubscribeRefresh("TherapyGoal", loadSummary);
  useSubscribeRefresh("CrisisPlan", loadSummary);

  const summary = useMemo(() => {
    if (!data) return null;
    const { assessments, nervous, impairments, homework, goals, crisisPlan } = data;
    const now = Date.now();
    const current = barometerAt(assessments, now);
    const previous = barometerAt(assessments, now - 30 * DAY);
    const trend = current !== null && previous !== null ? current - previous : null;

    const latestByType = {};
    const firstByType = {};
    assessments.forEach((a) => {
      if (!latestByType[a.test_type] || new Date(a.created_date) > new Date(latestByType[a.test_type].created_date)) {
        latestByType[a.test_type] = a;
      }
      if (!firstByType[a.test_type] || new Date(a.created_date) < new Date(firstByType[a.test_type].created_date)) {
        firstByType[a.test_type] = a;
      }
    });

    const profile = Object.entries(latestByType)
      .map(([type, a]) => {
        const test = ASSESSMENTS[type];
        const scored = test?.score?.(a.score);
        const sev = scored?.severity || a.severity;
        return {
          type,
          abbr: test?.abbr || type,
          name: test?.name || type,
          score: a.score,
          severity: sev,
          color: scored?.color,
          date: a.created_date,
          rank: SEVERITY_RANK[sev] || 0,
          isSymptom: SYMPTOM_SCALES.includes(type),
        };
      })
      .sort((a, b) => b.rank - a.rank);

    // Risk flags
    const risks = [];
    const phq = latestByType["PHQ9"];
    if (phq?.answers && phq.answers[8] >= 1) {
      risks.push({ level: "critical", label: "Suicidal ideation endorsed (PHQ-9 item 9)" });
    }
    const latestImp = impairments[0];
    if (latestImp && (latestImp.self_harm ?? 0) >= 1) {
      risks.push({ level: "critical", label: "Self-harm reported in functional check-in" });
    }
    profile.forEach((p) => {
      if (p.isSymptom && (p.severity === "Severe" || p.severity === "Very High")) {
        risks.push({ level: "high", label: `${p.abbr} in severe range` });
      }
    });
    const latestNs = nervous[0];
    if (latestNs) {
      const parts = [];
      if ((latestNs.anxiety_level ?? 0) >= 8) parts.push("anxiety");
      if ((latestNs.depression_level ?? 0) >= 8) parts.push("depression");
      if ((latestNs.stress_level ?? 0) >= 9) parts.push("stress");
      if (parts.length) risks.push({ level: "high", label: `Elevated ${parts.join(", ")} in latest check-in` });
    }

    // Engagement
    const checkins30 = nervous.filter((n) => now - new Date(n.created_date).getTime() <= 30 * DAY).length;
    const hwAssigned = homework.length;
    const hwCompleted = homework.filter((h) => h.status === "completed").length;
    const hwPct = hwAssigned ? Math.round((hwCompleted / hwAssigned) * 100) : null;
    const goalsActive = goals.filter((g) => g.status !== "achieved").length;
    const goalsAchieved = goals.filter((g) => g.status === "achieved").length;

    const allDates = [
      ...assessments.map((a) => a.created_date),
      ...nervous.map((n) => n.created_date),
      ...homework.map((h) => h.created_date),
      ...goals.map((g) => g.created_date),
      ...impairments.map((i) => i.created_date),
    ].filter(Boolean).map((d) => new Date(d).getTime());
    const lastActivity = allDates.length ? Math.max(...allDates) : 0;

    let impairmentPct = null;
    if (latestImp) {
      const score = NEGATIVE_ITEMS.reduce((s, i) => s + (latestImp[i.key] || 0), 0);
      impairmentPct = Math.round((score / MAX_IMPAIRMENT) * 100);
    }

    const topConcern = profile.find((p) => p.isSymptom) || null;

    const improvements = [];
    Object.keys(latestByType).forEach((type) => {
      const first = firstByType[type];
      const last = latestByType[type];
      if (!first || !last || first.id === last.id) return;
      const wf = wellbeing(type, first.score);
      const wl = wellbeing(type, last.score);
      if (wf !== null && wl !== null && wl - wf >= 10) {
        improvements.push({ abbr: ASSESSMENTS[type]?.abbr || type, delta: Math.round(wl - wf) });
      }
    });

    return {
      current, trend, profile, risks, checkins30, hwAssigned, hwCompleted, hwPct,
      goalsActive, goalsAchieved, lastActivity, impairmentPct, topConcern,
      improvements, crisisPlan,
      hasData: Boolean(assessments.length || nervous.length || impairments.length || homework.length || goals.length),
    };
  }, [data]);

  // Narrative paragraph synthesized from the structured data.
  const narrative = useMemo(() => {
    if (!summary) return "";
    if (!summary.hasData) {
      return "No clinical data has been recorded for this client yet. Engagement and symptom measures will populate here as the client begins using WayPoint tools.";
    }
    const parts = [];
    if (summary.checkins30 > 0) {
      parts.push(`logged ${summary.checkins30} nervous-system check-in${summary.checkins30 === 1 ? "" : "s"} in the past 30 days`);
    } else {
      parts.push("no nervous-system check-ins recorded in the past 30 days");
    }
    if (summary.current !== null) {
      const trendWord = summary.trend === null ? ""
        : summary.trend > 3 ? ", improving from last month"
        : summary.trend < -3 ? ", declining from last month"
        : ", stable versus last month";
      parts.push(`composite wellbeing sits at ${Math.round(summary.current)}/100${trendWord}`);
    }
    if (summary.topConcern) {
      parts.push(`the most prominent symptom concern is ${summary.topConcern.name} (${summary.topConcern.severity}, score ${summary.topConcern.score})`);
    }
    if (summary.impairmentPct !== null) {
      parts.push(`functional impairment rated at ${summary.impairmentPct}%`);
    }
    if (summary.improvements.length) {
      parts.push(`notable improvement on ${summary.improvements.map((i) => `${i.abbr} (+${i.delta})`).join(", ")}`);
    }
    if (summary.hwAssigned > 0) {
      parts.push(`homework completion at ${summary.hwPct}% (${summary.hwCompleted}/${summary.hwAssigned})`);
    }
    if (summary.goalsActive + summary.goalsAchieved > 0) {
      parts.push(`${summary.goalsAchieved} of ${summary.goalsActive + summary.goalsAchieved} treatment goals achieved`);
    }
    if (summary.risks.some((r) => r.level === "critical")) {
      parts.push("clinically significant risk indicators are present and warrant immediate safety review");
    } else if (summary.risks.length) {
      parts.push("elevated symptom levels merit close monitoring");
    }
    if (summary.crisisPlan) {
      parts.push("a crisis safety plan is on file");
    } else if (summary.risks.length) {
      parts.push("no crisis safety plan currently on file");
    }
    const text = parts.join("; ") + ".";
    return text.charAt(0).toUpperCase() + text.slice(1);
  }, [summary]);

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 120 }}>
        <div className="w-7 h-7 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!summary || !summary.hasData) {
    return (
      <div className="pp-card p-6">
        <div className="flex items-center gap-2 mb-3">
          <ClipboardList size={18} className="text-primary" />
          <h3 className="font-heading text-lg font-semibold">Clinical Summary</h3>
        </div>
        <p className="text-sm text-muted-foreground leading-relaxed">{narrative}</p>
      </div>
    );
  }

  const trendUp = summary.trend !== null && summary.trend > 3;
  const trendDown = summary.trend !== null && summary.trend < -3;
  const hasCritical = summary.risks.some((r) => r.level === "critical");

  return (
    <div className="pp-card p-6">
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <ClipboardList size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Clinical Summary</h3>
        <span className="ml-auto text-xs text-muted-foreground">{timeAgo(summary.lastActivity)}</span>
      </div>

      {/* Narrative */}
      <p className="text-sm text-foreground/90 leading-relaxed mb-5">{narrative}</p>

      {/* Risk flags */}
      {summary.risks.length > 0 && (
        <div className={`mb-5 rounded-xl border p-3 flex flex-wrap gap-2 ${
          hasCritical ? "bg-destructive/5 border-destructive/30" : "bg-amber-500/5 border-amber-500/30"
        }`}>
          <div className="flex items-center gap-1.5 text-xs font-semibold shrink-0"
               style={{ color: hasCritical ? "#D9534F" : "#D4A055" }}>
            <AlertTriangle size={14} /> Risk indicators
          </div>
          {summary.risks.map((r, i) => (
            <span
              key={i}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
              style={{
                backgroundColor: r.level === "critical" ? "#D9534F15" : "#D4A05515",
                color: r.level === "critical" ? "#D9534F" : "#D4A055",
              }}
            >
              {r.label}
            </span>
          ))}
        </div>
      )}

      {/* Quick stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
        <StatChip
          icon={summary.current !== null ? (trendUp ? TrendingUp : trendDown ? TrendingDown : Minus) : Activity}
          label="Wellbeing"
          value={summary.current !== null ? `${Math.round(summary.current)}/100` : "—"}
          tone={summary.current === null ? "neutral" : summary.current >= 50 ? "good" : summary.current >= 30 ? "warn" : "bad"}
          sub={summary.trend !== null ? (trendUp ? "improving" : trendDown ? "declining" : "stable") : undefined}
        />
        <StatChip
          icon={Calendar}
          label="Check-ins (30d)"
          value={String(summary.checkins30)}
          tone="neutral"
        />
        <StatChip
          icon={CheckCircle2}
          label="Homework"
          value={summary.hwAssigned ? `${summary.hwPct}%` : "—"}
          sub={summary.hwAssigned ? `${summary.hwCompleted}/${summary.hwAssigned} done` : undefined}
          tone="neutral"
        />
        <StatChip
          icon={Target}
          label="Goals"
          value={String(summary.goalsActive + summary.goalsAchieved)}
          sub={summary.goalsActive + summary.goalsAchieved ? `${summary.goalsAchieved} achieved` : undefined}
          tone="neutral"
        />
      </div>

      {/* Symptom profile */}
      {summary.profile.length > 0 && (
        <div className="mb-4">
          <div className="flex items-center gap-1.5 mb-2">
            <FileText size={14} className="text-muted-foreground" />
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Symptom Profile (latest)</p>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {summary.profile.map((p) => (
              <span
                key={p.type}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium"
                style={{
                  backgroundColor: p.color ? `${p.color}15` : "hsl(var(--secondary))",
                  color: p.color || "hsl(var(--muted-foreground))",
                }}
                title={`${p.name} — ${new Date(p.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}`}
              >
                <span className="font-bold">{p.abbr}</span>
                <span>{p.score}</span>
                {p.severity && <span className="opacity-80">· {p.severity}</span>}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Safety plan status */}
      <div className="flex items-center gap-2 pt-4 border-t border-border/60 text-xs text-muted-foreground">
        {summary.crisisPlan ? (
          <span className="inline-flex items-center gap-1.5 text-accent">
            <ShieldCheck size={14} /> Crisis safety plan on file
          </span>
        ) : (
          <span className="inline-flex items-center gap-1.5 text-muted-foreground">
            <ShieldCheck size={14} /> No crisis safety plan on file
          </span>
        )}
      </div>
    </div>
  );
}

function StatChip({ icon: Icon, label, value, sub, tone = "neutral" }) {
  const toneColor = tone === "good" ? "#1995A1" : tone === "warn" ? "#D4A055" : tone === "bad" ? "#D9534F" : "hsl(var(--foreground))";
  return (
    <div className="rounded-xl border border-border/60 bg-secondary/30 px-3 py-2.5">
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-0.5">
        <Icon size={12} /> {label}
      </div>
      <p className="font-heading text-lg font-semibold leading-none" style={{ color: toneColor }}>{value}</p>
      {sub && <p className="text-[11px] text-muted-foreground mt-1">{sub}</p>}
    </div>
  );
}