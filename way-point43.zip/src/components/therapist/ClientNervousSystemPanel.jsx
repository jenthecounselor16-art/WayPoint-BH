import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Activity } from "lucide-react";
import { useSubscribeRefresh } from "@/hooks/useSubscribeRefresh";

const METRICS = [
  { key: "sleep_hours", label: "Sleep", unit: "hrs", color: "#5B8FB9" },
  { key: "stress_level", label: "Stress", unit: "/10", color: "#E07856" },
  { key: "anxiety_level", label: "Anxiety", unit: "/10", color: "#8B7CB6" },
  { key: "depression_level", label: "Depression", unit: "/10", color: "#6B7280" },
  { key: "energy_level", label: "Energy", unit: "/10", color: "#D4906A" },
  { key: "movement_minutes", label: "Movement", unit: "min", color: "#7CB69D" },
  { key: "hydration_glasses", label: "Hydration", unit: "gl", color: "#3B82F6" },
  { key: "social_interaction", label: "Social", unit: "/10", color: "#D97757" },
];

export default function ClientNervousSystemPanel({ clientEmail }) {
  const [metrics, setMetrics] = useState([]);
  const [loading, setLoading] = useState(true);

  async function loadMetrics() {
    if (!clientEmail) return;
    try {
      const data = await base44.entities.NervousSystemMetric.filter({ client_email: clientEmail }, "-created_date", 30);
      setMetrics(data || []);
    } catch {}
    setLoading(false);
  }
  useEffect(() => { loadMetrics(); }, [clientEmail]);
  useSubscribeRefresh("NervousSystemMetric", loadMetrics);

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 120 }}>
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const latest = metrics[0];

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <Activity size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Nervous System Metrics</h3>
        {latest && (
          <span className="ml-auto text-xs text-muted-foreground">
            Last logged: {new Date(latest.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
          </span>
        )}
      </div>

      {metrics.length === 0 ? (
        <p className="text-sm text-muted-foreground py-4 text-center">No metrics logged yet.</p>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
            {METRICS.map((m) => (
              <div key={m.key} className="p-3 rounded-xl bg-secondary/40">
                <div className="flex items-center gap-1.5 mb-1">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: m.color }} />
                  <span className="text-xs text-muted-foreground">{m.label}</span>
                </div>
                <p className="font-heading text-xl font-semibold">
                  {latest[m.key] ?? "—"}
                  <span className="text-xs text-muted-foreground font-normal"> {m.unit}</span>
                </p>
              </div>
            ))}
          </div>
          {latest.note && (
            <div className="p-3 rounded-xl bg-secondary/30">
              <p className="text-xs text-muted-foreground mb-1">Client's note:</p>
              <p className="text-sm">{latest.note}</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}