import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { ClipboardList, Calendar, Pause, Play } from "lucide-react";
import { FUNCTIONAL_ITEMS, FREQUENCY_OPTIONS, NEGATIVE_ITEMS, MAX_IMPAIRMENT } from "@/lib/functionalImpairment";

export default function ClientFunctionalImpairmentPanel({ clientEmail, therapistEmail }) {
  const [entries, setEntries] = useState([]);
  const [assignment, setAssignment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showAssign, setShowAssign] = useState(false);
  const [frequency, setFrequency] = useState("weekly");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!clientEmail) return;
    (async () => {
      try {
        const data = await base44.entities.FunctionalImpairment.filter({ client_email: clientEmail }, "-created_date", 50);
        setEntries(data || []);
      } catch {}
      try {
        const assignments = await base44.entities.FunctionalImpairmentAssignment.filter(
          { client_email: clientEmail, status: "active" },
          "-created_date",
          1
        );
        setAssignment(assignments?.[0] || null);
        if (assignments?.[0]?.frequency) setFrequency(assignments[0].frequency);
      } catch {}
      setLoading(false);
    })();
  }, [clientEmail]);

  async function createAssignment() {
    setSaving(true);
    try {
      if (assignment) {
        await base44.entities.FunctionalImpairmentAssignment.update(assignment.id, { status: "paused" });
      }
      const nextDue = new Date();
      if (frequency === "weekly") nextDue.setDate(nextDue.getDate() + 7);
      else if (frequency === "biweekly") nextDue.setDate(nextDue.getDate() + 14);
      else nextDue.setMonth(nextDue.getMonth() + 1);

      const created = await base44.entities.FunctionalImpairmentAssignment.create({
        client_email: clientEmail,
        therapist_email: therapistEmail || "",
        frequency,
        status: "active",
        next_due_date: nextDue.toISOString().split("T")[0],
      });
      setAssignment(created);
      setShowAssign(false);
    } catch (err) {
      console.error("Assignment error:", err);
    }
    setSaving(false);
  }

  async function toggleAssignmentStatus() {
    if (!assignment) return;
    const newStatus = assignment.status === "active" ? "paused" : "active";
    try {
      await base44.entities.FunctionalImpairmentAssignment.update(assignment.id, { status: newStatus });
      setAssignment({ ...assignment, status: newStatus });
    } catch {}
  }

  const chartData = [...entries]
    .reverse()
    .map((e) => {
      const impairment = NEGATIVE_ITEMS.reduce((sum, i) => sum + (e[i.key] || 0), 0);
      return {
        date: new Date(e.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
        Impairment: Math.round((impairment / MAX_IMPAIRMENT) * 100),
        Engagement: Math.round(((e.enjoyable_activities || 0) / 4) * 100),
      };
    });

  const latest = entries[0];

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 120 }}>
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="pp-card p-5">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <ClipboardList size={18} className="text-primary" />
          <h3 className="font-heading text-lg font-semibold">Functional Impairments</h3>
        </div>
        {assignment && (
          <div className="flex items-center gap-2">
            <span
              className={`text-xs px-2 py-1 rounded-full font-medium ${
                assignment.status === "active" ? "bg-accent/10 text-accent" : "bg-muted text-muted-foreground"
              }`}
            >
              {assignment.frequency} · {assignment.status}
            </span>
            <button onClick={toggleAssignmentStatus} className="text-muted-foreground hover:text-foreground transition p-1">
              {assignment.status === "active" ? <Pause size={14} /> : <Play size={14} />}
            </button>
          </div>
        )}
      </div>

      {/* Assignment controls */}
      {assignment ? (
        <div className="flex items-center justify-between p-3 rounded-xl bg-secondary/30 mb-4">
          <div className="flex items-center gap-2 text-sm">
            <Calendar size={14} className="text-muted-foreground" />
            <span>
              Next due:{" "}
              {assignment.next_due_date
                ? new Date(assignment.next_due_date).toLocaleDateString("en-US", { month: "short", day: "numeric" })
                : "—"}
            </span>
          </div>
          <button onClick={() => setShowAssign(!showAssign)} className="text-sm text-primary hover:underline">
            Change frequency
          </button>
        </div>
      ) : (
        <button
          onClick={() => setShowAssign(!showAssign)}
          className="w-full py-2.5 rounded-xl bg-primary/10 text-primary text-sm font-medium hover:bg-primary/20 transition mb-4"
        >
          + Schedule recurring check-in
        </button>
      )}

      {showAssign && (
        <div className="p-4 rounded-xl bg-secondary/20 mb-4">
          <label className="text-sm font-medium mb-2 block">Frequency</label>
          <div className="flex gap-2 mb-3">
            {FREQUENCY_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                onClick={() => setFrequency(opt.value)}
                className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium transition border ${
                  frequency === opt.value
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card border-border hover:border-primary/40"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
          <button
            onClick={createAssignment}
            disabled={saving}
            className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition disabled:opacity-50"
          >
            {saving ? "Saving…" : "Save schedule"}
          </button>
        </div>
      )}

      {/* Trend chart */}
      {chartData.length > 0 ? (
        <>
          <p className="text-sm text-muted-foreground mb-2">Impairment vs. engagement over time (%)</p>
          <div className="w-full mb-4" style={{ height: 200 }}>
            <ResponsiveContainer width="100%" height="100%" debounce={100}>
              <LineChart data={chartData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                <XAxis dataKey="date" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" interval="preserveStartEnd" />
                <YAxis domain={[0, 100]} tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" width={32} />
                <Tooltip contentStyle={{ borderRadius: "12px", border: "1px solid hsl(var(--border))", fontSize: "11px" }} />
                <Line type="monotone" dataKey="Impairment" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 3 }} connectNulls />
                <Line type="monotone" dataKey="Engagement" stroke="hsl(var(--accent))" strokeWidth={2} dot={{ r: 3 }} connectNulls />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="flex gap-4 mb-4">
            <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <span className="w-3 h-3 rounded-full" style={{ backgroundColor: "hsl(var(--primary))" }} /> Impairment
            </span>
            <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <span className="w-3 h-3 rounded-full" style={{ backgroundColor: "hsl(var(--accent))" }} /> Engagement
            </span>
          </div>

          {/* Latest response breakdown */}
          {latest && (
            <div>
              <p className="text-sm font-medium mb-2">
                Latest: {new Date(latest.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {FUNCTIONAL_ITEMS.map((item) => {
                  const val = latest[item.key];
                  return (
                    <div key={item.key} className="p-2.5 rounded-lg bg-secondary/30">
                      <p className="text-[10px] text-muted-foreground truncate mb-0.5">{item.label}</p>
                      <p className={`font-heading text-lg font-semibold ${item.positive ? "text-accent" : val >= 3 ? "text-destructive" : ""}`}>
                        {val ?? "—"}<span className="text-xs text-muted-foreground font-normal">/4</span>
                      </p>
                    </div>
                  );
                })}
              </div>
              {latest.notes && (
                <div className="mt-3 p-3 rounded-lg bg-secondary/20">
                  <p className="text-[10px] text-muted-foreground mb-1">Client note:</p>
                  <p className="text-sm">{latest.notes}</p>
                </div>
              )}
            </div>
          )}
        </>
      ) : (
        <p className="text-sm text-muted-foreground py-4 text-center">No check-ins completed yet.</p>
      )}
    </div>
  );
}