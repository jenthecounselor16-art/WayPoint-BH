import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { BookOpen } from "lucide-react";
import { useSubscribeRefresh } from "@/hooks/useSubscribeRefresh";

// Real-time view of a client's CBT journal (thought records). Any entry the
// client saves appears here instantly — no refresh needed.
export default function ClientJournalPanel({ clientEmail }) {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState(null);

  async function loadRecords() {
    try {
      const data = await base44.entities.ThoughtRecord.filter({ client_email: clientEmail }, "-created_date", 50);
      setRecords(data || []);
    } catch {}
    setLoading(false);
  }

  useEffect(() => {
    setLoading(true);
    loadRecords();
  }, [clientEmail]);

  useSubscribeRefresh("ThoughtRecord", loadRecords);

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <BookOpen size={16} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">CBT Journal</h3>
        <span className="ml-auto text-xs text-muted-foreground">
          {records.length} thought record{records.length === 1 ? "" : "s"}
        </span>
      </div>

      {loading ? (
        <div className="flex justify-center py-8">
          <div className="w-6 h-6 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : records.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          No journal entries yet. Entries appear here the moment the client saves one.
        </p>
      ) : (
        <div className="space-y-2">
          {records.map((r) => {
            const expanded = expandedId === r.id;
            return (
              <div key={r.id} className="rounded-xl border border-border/60 overflow-hidden">
                <button onClick={() => setExpandedId(expanded ? null : r.id)} className="w-full text-left p-3.5">
                  <p className="text-sm font-medium line-clamp-2">{r.automatic_thought}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {new Date(r.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                    {r.emotion && ` · ${r.emotion}`}
                    {r.emotion_intensity != null && r.new_emotion_intensity != null && (
                      <span className="text-primary font-medium"> · {r.emotion_intensity} → {r.new_emotion_intensity}</span>
                    )}
                  </p>
                </button>
                {expanded && (
                  <div className="px-3.5 pb-3.5 pt-2 border-t border-border/60 space-y-2.5">
                    {r.situation && <Field label="Situation" value={r.situation} />}
                    {r.evidence_for && <Field label="Evidence For" value={r.evidence_for} />}
                    {r.evidence_against && <Field label="Evidence Against" value={r.evidence_against} />}
                    {r.balanced_thought && <Field label="Balanced Thought" value={r.balanced_thought} />}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Field({ label, value }) {
  return (
    <div>
      <p className="text-xs font-medium text-muted-foreground mb-0.5">{label}</p>
      <p className="text-sm whitespace-pre-wrap">{value}</p>
    </div>
  );
}