import React from "react";
import { AlertCircle, Clock, ArrowUpRight } from "lucide-react";

const DAY = 86400000;

function timeAgo(ms) {
  if (!ms) return "—";
  const diff = Date.now() - ms;
  const days = Math.floor(diff / DAY);
  if (days <= 0) return "today";
  if (days === 1) return "1 day ago";
  if (days < 30) return `${days} days ago`;
  return `${Math.floor(days / 30)} months ago`;
}

export default function InactiveClientsSummary({ clients, metricsByClient, onSelectClient }) {
  const now = Date.now();
  const inactive = clients
    .map((c) => {
      const m = metricsByClient[c.email] || {};
      const last = m.lastActivityMs || 0;
      const daysInactive = last ? Math.floor((now - last) / DAY) : Infinity;
      return { ...c, lastActivityMs: last, daysInactive };
    })
    .filter((c) => c.daysInactive > 7)
    .sort((a, b) => b.daysInactive - a.daysInactive);

  return (
    <div className="pp-card p-5 mb-6">
      <div className="flex items-center gap-2 mb-1">
        <AlertCircle size={18} className="text-amber-500" />
        <h2 className="font-heading text-lg font-semibold">Needs a Check-In</h2>
        <span className="ml-auto text-xs text-muted-foreground">
          {inactive.length} inactive {inactive.length === 1 ? "client" : "clients"}
        </span>
      </div>
      <p className="text-sm text-muted-foreground mb-4">
        Clients with no recorded activity in the last 7 days. A quick proactive check-in can help re-engage them.
      </p>

      {inactive.length === 0 ? (
        <div className="flex items-center gap-2 text-sm text-primary py-2">
          <Clock size={16} /> All clients have been active in the past week.
        </div>
      ) : (
        <div className="space-y-2">
          {inactive.map((c) => (
            <button
              key={c.email}
              onClick={() => onSelectClient(c.email)}
              className="w-full flex items-center justify-between gap-3 px-4 py-3 rounded-xl bg-amber-500/5 hover:bg-amber-500/10 border border-amber-500/15 transition text-left"
            >
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">{c.name}</p>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <Clock size={11} />
                  {c.daysInactive === Infinity
                    ? "No activity yet"
                    : `${c.daysInactive} days inactive · last ${timeAgo(c.lastActivityMs)}`}
                </p>
              </div>
              <span className="text-xs font-medium text-amber-600 flex items-center gap-1 shrink-0">
                Open <ArrowUpRight size={14} />
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}