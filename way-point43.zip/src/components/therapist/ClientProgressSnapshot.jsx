import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { ASSESSMENTS } from "@/lib/assessments";
import {
  LineChart, Line, ResponsiveContainer, YAxis,
} from "recharts";
import { Activity, ClipboardCheck, TrendingUp, TrendingDown, Minus, ChevronRight, MessageSquare, ShieldAlert } from "lucide-react";
import ClientMessageModal from "@/components/therapist/ClientMessageModal";
import CrisisPlanModal from "@/components/therapist/CrisisPlanModal";

const DAY = 86400000;
const WINDOW_DAYS = 30;

// Composite "balance" score (0–100) from a nervous-system check-in.
// Higher = more regulated: blends vitality (energy, social, sleep, movement,
// hydration) with low distress (stress, anxiety, depression).
function balanceScore(m) {
  if (!m) return null;
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const distress = (
    (clamp(m.stress_level ?? 0, 0, 10) +
     clamp(m.anxiety_level ?? 0, 0, 10) +
     clamp(m.depression_level ?? 0, 0, 10)) / 3
  ) / 10 * 100;
  const vitality = (
    (clamp(m.energy_level ?? 0, 0, 10) / 10) +
    (clamp(m.social_interaction ?? 0, 0, 10) / 10) +
    (clamp(Math.min(m.sleep_hours ?? 0, 8), 0, 8) / 8) +
    (clamp(Math.min(m.movement_minutes ?? 0, 30), 0, 30) / 30) +
    (clamp(Math.min(m.hydration_glasses ?? 0, 8), 0, 8) / 8)
  ) / 5 * 100;
  return Math.round(0.5 * vitality + 0.5 * (100 - distress));
}

export default function ClientProgressSnapshot({ clients, assessments, therapistEmail, metricsByClient, onSelectClient }) {
  const [nervous, setNervous] = useState([]);
  const [loading, setLoading] = useState(true);
  const [messageClient, setMessageClient] = useState(null);
  const [planClient, setPlanClient] = useState(null);

  useEffect(() => {
    if (!therapistEmail) { setLoading(false); return; }
    (async () => {
      try {
        const data = await base44.entities.NervousSystemMetric.filter(
          { therapist_email: therapistEmail }, "-created_date", 500
        );
        setNervous(data || []);
      } catch (e) {
        console.error("Progress snapshot nervous fetch failed:", e);
      }
      setLoading(false);
    })();
  }, [therapistEmail]);

  const cutoff = useMemo(() => Date.now() - WINDOW_DAYS * DAY, []);

  const snapshots = useMemo(() => {
    return clients.map((c) => {
      const ns = nervous
        .filter((n) => n.client_email === c.email && new Date(n.created_date).getTime() >= cutoff)
        .sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
      const aList = (assessments || [])
        .filter((a) => a.client_email === c.email && new Date(a.created_date).getTime() >= cutoff)
        .sort((a, b) => new Date(a.created_date) - new Date(b.created_date));

      // latest score per assessment type in window
      const latestByType = {};
      aList.forEach((a) => {
        if (!latestByType[a.test_type] || new Date(a.created_date) > new Date(latestByType[a.test_type].created_date)) {
          latestByType[a.test_type] = a;
        }
      });

      const points = ns.map((n) => ({
        t: new Date(n.created_date).getTime(),
        label: new Date(n.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
        value: balanceScore(n),
      }));
      const first = points[0]?.value;
      const last = points[points.length - 1]?.value;
      const delta = first != null && last != null ? last - first : null;

      return { client: c, checkins: ns.length, points, delta, lastScore: last, assessments: aList, latestByType };
    });
  }, [clients, nervous, assessments, cutoff]);

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 120 }}>
        <div className="w-7 h-7 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!clients.length) return null;

  return (
    <div className="mb-8">
      <div className="flex items-center gap-2 mb-3">
        <Activity size={18} className="text-primary" />
        <h2 className="font-heading text-lg font-semibold">Progress Snapshot</h2>
        <span className="text-xs text-muted-foreground">Last 30 days · check-ins + assessments</span>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {snapshots.map(({ client, checkins, points, delta, lastScore, assessments: aList, latestByType }) => {
          const m = metricsByClient?.[client.email];
          const baro = m?.current;
          const improving = delta != null && delta > 2;
          const declining = delta != null && delta < -2;
          return (
            <div
              key={client.email}
              onClick={() => onSelectClient(client.email)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => { if (e.key === "Enter") onSelectClient(client.email); }}
              className="pp-card p-4 text-left hover:border-primary/40 hover:shadow-md transition group flex flex-col cursor-pointer"
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="min-w-0">
                  <p className="font-heading text-sm font-semibold truncate group-hover:text-primary transition">{client.name}</p>
                  <p className="text-[11px] text-muted-foreground truncate">{client.email}</p>
                </div>
                <ChevronRight size={16} className="text-muted-foreground/40 group-hover:text-primary transition shrink-0 mt-1" />
              </div>

              {/* Barometer + check-in counts */}
              <div className="flex items-center gap-3 mb-3 text-xs">
                {baro != null && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium">
                    Barometer {Math.round(baro)}
                  </span>
                )}
                <span className="text-muted-foreground inline-flex items-center gap-1">
                  <ClipboardCheck size={12} /> {checkins} check-in{checkins === 1 ? "" : "s"}
                </span>
                <span className="text-muted-foreground">· {aList.length} assessment{aList.length === 1 ? "" : "s"}</span>
              </div>

              {/* Nervous-system balance sparkline */}
              <div className="rounded-xl bg-secondary/30 p-3 mb-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] text-muted-foreground">Regulation trend</span>
                  {delta != null ? (
                    <span
                      className="inline-flex items-center gap-1 text-[11px] font-medium"
                      style={{ color: improving ? "#1995A1" : declining ? "#D9534F" : "#6b7280" }}
                    >
                      {improving ? <TrendingUp size={11} /> : declining ? <TrendingDown size={11} /> : <Minus size={11} />}
                      {delta > 0 ? "+" : ""}{delta}
                    </span>
                  ) : (
                    <span className="text-[11px] text-muted-foreground">—</span>
                  )}
                </div>
                {points.length > 0 ? (
                  <div style={{ width: "100%", height: 56 }}>
                    <ResponsiveContainer>
                      <LineChart data={points} margin={{ top: 4, right: 4, left: 4, bottom: 0 }}>
                        <YAxis domain={[0, 100]} hide />
                        <Line
                          type="monotone"
                          dataKey="value"
                          stroke="hsl(var(--primary))"
                          strokeWidth={2}
                          dot={false}
                          activeDot={{ r: 3 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <p className="text-[11px] text-muted-foreground py-3 text-center">No check-ins in last 30 days</p>
                )}
              </div>

              {/* Completed assessment milestones */}
              {Object.keys(latestByType).length > 0 ? (
                <div className="flex flex-wrap gap-1.5">
                  {Object.entries(latestByType).map(([type, r]) => {
                    const test = ASSESSMENTS[type];
                    const scored = test?.score?.(r.score);
                    return (
                      <span
                        key={type}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium"
                        style={scored ? { backgroundColor: `${scored.color}15`, color: scored.color } : { backgroundColor: "hsl(var(--secondary))", color: "hsl(var(--muted-foreground))" }}
                        title={`${test?.name || type}: ${r.score} — ${r.severity || ""}`}
                      >
                        <span className="font-bold">{test?.abbr || type}</span> {r.score}
                      </span>
                    );
                  })}
                </div>
              ) : (
                <p className="text-[11px] text-muted-foreground">No assessments completed in last 30 days</p>
              )}

              <div className="flex gap-2 mt-3 pt-3 border-t border-border/60" onClick={(e) => e.stopPropagation()}>
                <button
                  onClick={() => setMessageClient(client)}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-2 py-1.5 rounded-lg bg-primary/10 text-primary text-xs font-medium hover:bg-primary/20 transition"
                >
                  <MessageSquare size={13} /> Message
                </button>
                <button
                  onClick={() => setPlanClient(client)}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-2 py-1.5 rounded-lg bg-accent/10 text-accent text-xs font-medium hover:bg-accent/20 transition"
                >
                  <ShieldAlert size={13} /> Crisis Plan
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {messageClient && (
        <ClientMessageModal
          clientEmail={messageClient.email}
          clientName={messageClient.name}
          onClose={() => setMessageClient(null)}
        />
      )}
      {planClient && (
        <CrisisPlanModal
          clientEmail={planClient.email}
          clientName={planClient.name}
          onClose={() => setPlanClient(null)}
        />
      )}
    </div>
  );
}