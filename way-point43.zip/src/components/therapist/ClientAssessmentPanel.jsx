import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ASSESSMENTS } from "@/lib/assessments";
import { ClipboardList, Plus, ArrowLeft, X, Check, UserPlus, Clock, Heart, Wind, ShieldAlert, Sparkles, Moon, Activity, Zap, Accessibility, RefreshCw, LifeBuoy, Baby, Users, Pill, Gauge, Utensils } from "lucide-react";
import { useSubscribeRefresh } from "@/hooks/useSubscribeRefresh";

const CATEGORIES = [
  { key: "mood", label: "Mood & Depression", tests: ["PHQ9", "BDI"], color: "#26A69A", icon: Heart },
  { key: "anxiety", label: "Anxiety", tests: ["GAD7", "BAI"], color: "#D4A055", icon: Wind },
  { key: "social_anxiety", label: "Social Anxiety", tests: ["SPIN"], color: "#EC407A", icon: Users },
  { key: "ocd", label: "Obsessive-Compulsive", tests: ["YBOCS", "CYBOCS"], color: "#5C6BC0", icon: RefreshCw },
  { key: "trauma", label: "Trauma", tests: ["PCL-5", "PCPTSD5"], color: "#E07856", icon: ShieldAlert },
  { key: "suicide", label: "Suicide Risk", tests: ["CSSRS"], color: "#D9534F", icon: LifeBuoy },
  { key: "bipolar", label: "Bipolar Screen", tests: ["MDQ"], color: "#FFB300", icon: Gauge },
  { key: "substance", label: "Substance Use", tests: ["CAGE", "DAST"], color: "#8D6E63", icon: Pill },
  { key: "eating", label: "Eating", tests: ["SCOFF"], color: "#AB47BC", icon: Utensils },
  { key: "child_anxiety", label: "Child & Adolescent Anxiety", tests: ["SCARED"], color: "#4DB6AC", icon: Baby },
  { key: "wellbeing", label: "Wellbeing", tests: ["WHO5"], color: "#1995A1", icon: Sparkles },
  { key: "sleep", label: "Sleep", tests: ["ISI"], color: "#5E7ED4", icon: Moon },
  { key: "distress", label: "General Distress", tests: ["K6"], color: "#E07856", icon: Activity },
  { key: "adhd", label: "ADHD", tests: ["ASRS"], color: "#9B7DD4", icon: Zap },
  { key: "functioning", label: "Functioning", tests: ["SENSORY"], color: "#3B82F6", icon: Accessibility },
];

export default function ClientAssessmentPanel({ clientEmail, therapistEmail }) {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [administering, setAdministering] = useState(false);
  const [assigning, setAssigning] = useState(false);
  const [assignSuccess, setAssignSuccess] = useState(null);
  const [assignments, setAssignments] = useState([]);
  const [selectedTest, setSelectedTest] = useState(null);
  const [answers, setAnswers] = useState({});
  const [saving, setSaving] = useState(false);

  async function loadAll() {
    try {
      const [data, assigned] = await Promise.all([
        base44.entities.AssessmentResult.filter({ client_email: clientEmail }, "-created_date", 50),
        base44.entities.AssessmentAssignment.filter({ client_email: clientEmail }, "-created_date", 50),
      ]);
      setResults(data || []);
      setAssignments(assigned || []);
    } catch (err) {
      console.error("Assessment panel fetch error:", err);
    }
    setLoading(false);
  }
  useEffect(() => { loadAll(); }, [clientEmail]);
  useSubscribeRefresh("AssessmentResult", loadAll);
  useSubscribeRefresh("AssessmentAssignment", loadAll);

  function setAnswer(index, value) {
    setAnswers({ ...answers, [index]: value });
  }

  async function assignTest(testType) {
    try {
      await base44.entities.AssessmentAssignment.create({
        test_type: testType,
        client_email: clientEmail,
        therapist_email: therapistEmail || "",
        status: "assigned",
      });
      const assigned = await base44.entities.AssessmentAssignment.filter({ client_email: clientEmail }, "-created_date", 50);
      setAssignments(assigned || []);
      setAssignSuccess(testType);
      setTimeout(() => { setAssignSuccess(null); }, 2000);
      // Notify the client by email to complete the assessment through their portal.
      try {
        await base44.functions.invoke("assessment-assignment-notify", {
          client_email: clientEmail,
          test_type: testType,
          therapist_email: therapistEmail || "",
        });
      } catch (e) {
        console.error("Assessment notify failed:", e);
      }
    } catch (err) {
      console.error("Assign error:", err);
    }
  }

  async function submitAssessment() {
    const test = ASSESSMENTS[selectedTest];
    const total = test.items.reduce((sum, _, i) => sum + (answers[i] || 0), 0);
    const scored = test.score(total);
    setSaving(true);
    try {
      await base44.entities.AssessmentResult.create({
        test_type: selectedTest,
        score: total,
        severity: scored.severity,
        answers: test.items.map((_, i) => answers[i] || 0),
        client_email: clientEmail,
        therapist_email: therapistEmail || "",
      });
      const data = await base44.entities.AssessmentResult.filter({ client_email: clientEmail }, "-created_date", 50);
      setResults(data || []);
      setAdministering(false);
      setSelectedTest(null);
      setAnswers({});
    } catch (err) {
      console.error("Assessment save error:", err);
    }
    setSaving(false);
  }

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 120 }}>
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (administering && selectedTest) {
    const test = ASSESSMENTS[selectedTest];
    const answeredCount = Object.keys(answers).length;
    const allAnswered = answeredCount === test.items.length;
    return (
      <div className="pp-card p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-lg bg-primary/10 text-primary text-xs font-bold">{test.abbr}</span>
            <h3 className="font-heading text-lg font-semibold">{test.name}</h3>
          </div>
          <button onClick={() => { setAdministering(false); setSelectedTest(null); setAnswers({}); }} className="text-muted-foreground hover:text-foreground">
            <X size={20} />
          </button>
        </div>
        <p className="text-sm text-muted-foreground mb-4">{test.instructions}</p>
        <div className="mb-4">
          <div className="flex justify-between text-xs text-muted-foreground mb-1.5">
            <span>Progress</span><span>{answeredCount} / {test.items.length}</span>
          </div>
          <div className="h-2 rounded-full bg-secondary overflow-hidden">
            <div className="h-full bg-primary transition-all duration-300" style={{ width: `${(answeredCount / test.items.length) * 100}%` }} />
          </div>
        </div>
        <div className="space-y-3 mb-4 max-h-96 overflow-y-auto pp-scroll-hide">
          {test.items.map((item, i) => (
            <div key={i} className="p-3 rounded-xl bg-secondary/30">
              <p className="text-sm font-medium mb-2">{i + 1}. {item}</p>
              <div className="flex flex-wrap gap-1.5">
                {test.scale.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => setAnswer(i, opt.value)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition border ${answers[i] === opt.value ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border text-muted-foreground hover:border-primary/40"}`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
        <button onClick={submitAssessment} disabled={!allAnswered || saving} className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:opacity-90 transition disabled:opacity-50">
          {saving ? "Saving…" : "Save Assessment Results"}
        </button>
      </div>
    );
  }

  if (administering || assigning) {
    const mode = administering ? "Administer" : "Assign";
    const onSelect = administering
      ? (key) => setSelectedTest(key)
      : (key) => assignTest(key);
    return (
      <div className="pp-card p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading text-lg font-semibold">{mode} Assessment</h3>
          <button onClick={() => { setAdministering(false); setAssigning(false); }} className="text-muted-foreground hover:text-foreground"><X size={20} /></button>
        </div>
        <p className="text-sm text-muted-foreground mb-4">
          {administering
            ? "Take the assessment on behalf of the client during session."
            : "Assign an assessment for the client to complete on their own."}
        </p>
        <div className="grid sm:grid-cols-2 gap-2">
          {Object.entries(ASSESSMENTS).map(([key, test]) => (
            <button
              key={key}
              onClick={() => onSelect(key)}
              className={`p-3 rounded-xl border text-left transition ${
                assignSuccess === key
                  ? "border-primary bg-primary/10"
                  : "border-border/60 hover:border-primary/40 hover:bg-secondary/40"
              }`}
            >
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 rounded-md bg-primary/10 text-primary text-xs font-bold">{test.abbr}</span>
                <span className="text-xs text-muted-foreground">{test.items.length} items</span>
                {assignSuccess === key && <Check size={14} className="text-primary ml-auto" />}
              </div>
              <p className="text-sm font-medium">{test.name}</p>
              {assignSuccess === key && (
                <p className="text-xs text-primary mt-1">Assigned! We've emailed the client a link to complete it in their portal.</p>
              )}
            </button>
          ))}
        </div>
      </div>
    );
  }

  const pendingAssignments = assignments.filter((a) => a.status === "assigned");

  const knownTests = new Set(CATEGORIES.flatMap((c) => c.tests));
  const grouped = CATEGORIES.map((cat) => {
    const pending = pendingAssignments.filter((a) => cat.tests.includes(a.test_type));
    const done = results.filter((r) => cat.tests.includes(r.test_type));
    return { cat, pending, done };
  }).filter((g) => g.pending.length || g.done.length);
  const otherPending = pendingAssignments.filter((a) => !knownTests.has(a.test_type));
  const otherResults = results.filter((r) => !knownTests.has(r.test_type));
  const hasOther = otherPending.length || otherResults.length;
  const isEmpty = grouped.length === 0 && !hasOther;

  const renderItem = (r) => {
    const test = ASSESSMENTS[r.test_type];
    const scored = test?.score(r.score);
    return (
      <div key={r.id} className="flex items-center justify-between gap-3 p-2 rounded-lg bg-secondary/30">
        <div className="flex items-center gap-2 min-w-0">
          <span className="px-2 py-0.5 rounded-md bg-secondary text-xs font-bold shrink-0">{r.test_type}</span>
          <span className="text-xs text-muted-foreground truncate">{new Date(r.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="font-heading text-lg font-semibold">{r.score}</span>
          {scored && <span className="px-2 py-0.5 rounded-full text-xs font-medium" style={{ backgroundColor: `${scored.color}15`, color: scored.color }}>{scored.severity}</span>}
        </div>
      </div>
    );
  };

  const renderPending = (a) => (
    <div key={a.id} className="flex items-center gap-2 text-sm">
      <span className="px-2 py-0.5 rounded-md bg-accent/10 text-accent text-xs font-bold shrink-0">{ASSESSMENTS[a.test_type]?.abbr || a.test_type}</span>
      <span className="text-muted-foreground truncate">{ASSESSMENTS[a.test_type]?.name || a.test_type}</span>
      <span className="ml-auto text-xs text-accent font-medium flex items-center gap-1 shrink-0"><Clock size={12} /> Pending</span>
    </div>
  );

  const renderGroup = (g) => {
    const Icon = g.cat.icon;
    const total = g.pending.length + g.done.length;
    return (
      <div key={g.cat.key} className="mb-4">
        <div className="flex items-center gap-2 mb-2">
          <span className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: `${g.cat.color}15`, color: g.cat.color }}>
            <Icon size={15} />
          </span>
          <h4 className="text-sm font-semibold">{g.cat.label}</h4>
          <span className="text-xs text-muted-foreground">{total} {total === 1 ? "entry" : "entries"}</span>
          {g.pending.length > 0 && <span className="text-xs text-accent font-medium ml-auto">{g.pending.length} pending</span>}
        </div>
        <div className="pl-9 space-y-1.5">
          {g.pending.map(renderPending)}
          {g.done.map(renderItem)}
        </div>
      </div>
    );
  };

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <ClipboardList size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Assessments</h3>
        <div className="ml-auto flex gap-2">
          <button onClick={() => setAssigning(true)} className="px-3 py-1.5 rounded-lg bg-accent/10 text-accent text-xs font-medium hover:bg-accent/20 transition flex items-center gap-1">
            <UserPlus size={14} /> Assign
          </button>
          <button onClick={() => setAdministering(true)} className="px-3 py-1.5 rounded-lg bg-primary/10 text-primary text-xs font-medium hover:bg-primary/20 transition flex items-center gap-1">
            <Plus size={14} /> Administer
          </button>
        </div>
      </div>

      {isEmpty ? (
        <p className="text-sm text-muted-foreground py-4 text-center">No assessments on record yet.</p>
      ) : (
        <>
          {grouped.map(renderGroup)}
          {hasOther && (
            <div className="mb-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="w-7 h-7 rounded-lg flex items-center justify-center bg-secondary text-muted-foreground shrink-0">
                  <ClipboardList size={15} />
                </span>
                <h4 className="text-sm font-semibold">Other</h4>
              </div>
              <div className="pl-9 space-y-1.5">
                {otherPending.map(renderPending)}
                {otherResults.map(renderItem)}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}