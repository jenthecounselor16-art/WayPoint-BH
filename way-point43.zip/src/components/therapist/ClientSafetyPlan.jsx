import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ShieldAlert, AlertTriangle, Check, Phone, Heart } from "lucide-react";

const SECTIONS = [
  { key: "warning_signs", label: "Warning Signs", icon: AlertTriangle },
  { key: "coping_skills", label: "Coping Skills", icon: Check },
  { key: "emergency_contacts", label: "Emergency Contacts", icon: Phone },
  { key: "reasons_to_live", label: "Reasons to Live", icon: Heart },
];

export default function ClientSafetyPlan({ clientEmail }) {
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.CrisisPlan.filter({ client_email: clientEmail }, "-created_date", 1);
        setPlan(data?.[0] || null);
      } catch {}
      setLoading(false);
    })();
  }, [clientEmail]);

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 120 }}>
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <ShieldAlert size={18} className="text-red-500" />
        <h3 className="font-heading text-lg font-semibold">Safety Plan</h3>
      </div>

      {!plan ? (
        <p className="text-sm text-muted-foreground py-4 text-center">No safety plan on file for this client.</p>
      ) : (
        <div className="space-y-4">
          {SECTIONS.map((section) => {
            const items = plan[section.key] || [];
            const Icon = section.icon;
            return (
              <div key={section.key}>
                <p className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5 mb-1.5">
                  <Icon size={13} /> {section.label}
                </p>
                {items.length > 0 ? (
                  <ul className="space-y-1 ml-5">
                    {items.map((item, i) => (
                      <li key={i} className="text-sm text-foreground/80 list-disc">{item}</li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-xs text-muted-foreground/60 ml-5">Not specified</p>
                )}
              </div>
            );
          })}
          {(plan.therapist_name || plan.therapist_phone) && (
            <div className="pt-3 border-t border-border/60">
              <p className="text-xs font-semibold text-muted-foreground mb-1">Therapist Contact</p>
              <p className="text-sm text-foreground/80">{plan.therapist_name || "—"}</p>
              {plan.therapist_phone && <p className="text-sm text-muted-foreground">{plan.therapist_phone}</p>}
            </div>
          )}
        </div>
      )}
    </div>
  );
}