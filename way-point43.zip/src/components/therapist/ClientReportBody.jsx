import React from "react";
import { ASSESSMENTS } from "@/lib/assessments";
import { NEGATIVE_ITEMS, MAX_IMPAIRMENT } from "@/lib/functionalImpairment";

const NOT_SIGNIFICANT = ["Minimal", "Low", "Good Wellbeing", "No Insomnia"];

export default function ClientReportBody({ clientName, email, therapist, assessments = [], goals = [], impairments = [], nervous = [] }) {
  const reportDate = new Date().toLocaleDateString("en-US", {
    weekday: "long", year: "numeric", month: "long", day: "numeric",
  });

  const latestByType = {};
  assessments.forEach((a) => {
    if (!latestByType[a.test_type] || new Date(a.created_date) > new Date(latestByType[a.test_type].created_date)) {
      latestByType[a.test_type] = a;
    }
  });
  const latestAssessments = Object.values(latestByType);

  const firstByType = {};
  assessments.forEach((a) => {
    if (!firstByType[a.test_type] || new Date(a.created_date) < new Date(firstByType[a.test_type].created_date)) {
      firstByType[a.test_type] = a;
    }
  });

  const recentImpairments = impairments.slice(0, 5);
  const latestImpairment = impairments[0];
  const latestImpairmentScore = latestImpairment
    ? NEGATIVE_ITEMS.reduce((sum, i) => sum + (latestImpairment[i.key] || 0), 0)
    : 0;
  const latestImpairmentPct = Math.round((latestImpairmentScore / MAX_IMPAIRMENT) * 100);

  const clinicianName = therapist?.display_name || therapist?.full_name || "";

  return (
    <div style={{ fontFamily: "Inter, Arial, sans-serif", fontSize: "11pt", lineHeight: 1.5, color: "#1a1a1a", background: "#fff", padding: "24px 32px 32px 32px" }}>

      {/* Header */}
      <div style={{ borderBottom: "2px solid #e5e7eb", paddingBottom: "20px", marginBottom: "24px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "12px" }}>
          <div>
            <div style={{ fontWeight: 700, fontSize: "14pt", color: "#0f766e", marginBottom: "4px" }}>WayPoint</div>
            <div style={{ fontWeight: 700, fontSize: "20pt" }}>Clinical Summary Report</div>
            <div style={{ color: "#666", marginTop: "2px" }}>{reportDate}</div>
          </div>
          <div style={{ textAlign: "right", fontSize: "10.5pt" }}>
            <div style={{ fontWeight: 700 }}>{clientName}</div>
            <div style={{ color: "#666" }}>{email}</div>
            {clinicianName && <div style={{ color: "#666", marginTop: "4px" }}>Prepared by: {clinicianName}</div>}
          </div>
        </div>
      </div>

      {/* Assessment Progress */}
      <div style={{ marginBottom: "24px" }}>
        <div style={{ fontWeight: 700, fontSize: "13pt", marginBottom: "10px", borderBottom: "1px solid #e5e7eb", paddingBottom: "4px" }}>
          Assessment Progress
        </div>
        {latestAssessments.length === 0 ? (
          <p style={{ color: "#888", fontStyle: "italic" }}>No assessments on record.</p>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "10.5pt" }}>
            <thead>
              <tr style={{ background: "#f3f4f6" }}>
                <th style={thStyle}>Assessment</th>
                <th style={{ ...thStyle, textAlign: "center" }}>Initial</th>
                <th style={{ ...thStyle, textAlign: "center" }}>Latest</th>
                <th style={{ ...thStyle, textAlign: "center" }}>Change</th>
                <th style={thStyle}>Severity (latest)</th>
              </tr>
            </thead>
            <tbody>
              {latestAssessments.map((a) => {
                const test = ASSESSMENTS[a.test_type];
                const scored = test?.score?.(a.score);
                const first = firstByType[a.test_type];
                const change = first ? a.score - first.score : 0;
                const positiveValence = a.test_type === "WHO5";
                const improved = positiveValence ? change > 0 : change < 0;
                const worsened = positiveValence ? change < 0 : change > 0;
                const sevColor = scored?.color || "#888";
                return (
                  <tr key={a.id} style={{ borderBottom: "1px solid #e5e7eb" }}>
                    <td style={{ ...tdStyle, fontWeight: 600 }}>{a.test_type}</td>
                    <td style={{ ...tdStyle, textAlign: "center" }}>
                      {first ? first.score : "—"}
                      {first && (
                        <div style={{ fontSize: "9pt", color: "#666" }}>
                          {new Date(first.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "2-digit" })}
                        </div>
                      )}
                    </td>
                    <td style={{ ...tdStyle, textAlign: "center", fontWeight: 700 }}>
                      {a.score}
                      <div style={{ fontSize: "9pt", color: "#666" }}>
                        {new Date(a.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "2-digit" })}
                      </div>
                    </td>
                    <td style={{ ...tdStyle, textAlign: "center", fontWeight: 600, color: improved ? "#0f766e" : worsened ? "#c0392b" : "#888" }}>
                      {change > 0 ? `+${change}` : change < 0 ? `${change}` : "—"}
                    </td>
                    <td style={tdStyle}>
                      {scored && (
                        <span style={{ background: `${sevColor}22`, color: sevColor, padding: "2px 8px", borderRadius: "10px", fontSize: "10pt", fontWeight: 600 }}>
                          {scored.severity}
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
        {assessments.length > latestAssessments.length && (
          <p style={{ fontSize: "9.5pt", color: "#888", marginTop: "6px" }}>
            {assessments.length} total results on record. Change compares the first recorded score to the most recent.
          </p>
        )}
      </div>

      {/* Mood & Nervous System Trends */}
      <div style={{ marginBottom: "24px" }}>
        <div style={{ fontWeight: 700, fontSize: "13pt", marginBottom: "10px", borderBottom: "1px solid #e5e7eb", paddingBottom: "4px" }}>
          Mood &amp; Nervous System Trends
        </div>
        {nervous.length === 0 ? (
          <p style={{ color: "#888", fontStyle: "italic" }}>No nervous-system check-ins on record.</p>
        ) : (
          <>
            <div style={{ display: "flex", gap: "10px", marginBottom: "12px" }}>
              {[
                { key: "anxiety_level", label: "Avg Anxiety" },
                { key: "depression_level", label: "Avg Depression" },
                { key: "energy_level", label: "Avg Energy" },
                { key: "stress_level", label: "Avg Stress" },
              ].map((m) => {
                const vals = nervous.map((n) => n[m.key]).filter((v) => Number.isFinite(v));
                const avg = vals.length ? (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1) : "—";
                return (
                  <div key={m.key} style={{ flex: 1, border: "1px solid #e5e7eb", borderRadius: "8px", padding: "8px", textAlign: "center" }}>
                    <div style={{ fontSize: "9.5pt", color: "#666" }}>{m.label}</div>
                    <div style={{ fontWeight: 700, fontSize: "14pt" }}>{avg}</div>
                    <div style={{ fontSize: "9pt", color: "#888" }}>/10</div>
                  </div>
                );
              })}
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "10.5pt" }}>
              <thead>
                <tr style={{ background: "#f3f4f6" }}>
                  <th style={thStyle}>Date</th>
                  <th style={{ ...thStyle, textAlign: "center" }}>Anxiety</th>
                  <th style={{ ...thStyle, textAlign: "center" }}>Depression</th>
                  <th style={{ ...thStyle, textAlign: "center" }}>Energy</th>
                  <th style={{ ...thStyle, textAlign: "center" }}>Stress</th>
                </tr>
              </thead>
              <tbody>
                {nervous.slice(0, 10).map((n) => (
                  <tr key={n.id} style={{ borderBottom: "1px solid #e5e7eb" }}>
                    <td style={{ ...tdStyle, color: "#666" }}>
                      {new Date(n.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                    </td>
                    <td style={{ ...tdStyle, textAlign: "center" }}>{n.anxiety_level ?? "—"}</td>
                    <td style={{ ...tdStyle, textAlign: "center" }}>{n.depression_level ?? "—"}</td>
                    <td style={{ ...tdStyle, textAlign: "center" }}>{n.energy_level ?? "—"}</td>
                    <td style={{ ...tdStyle, textAlign: "center" }}>{n.stress_level ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {nervous.length > 10 && (
              <p style={{ fontSize: "9.5pt", color: "#888", marginTop: "6px" }}>
                Showing 10 most recent of {nervous.length} check-ins.
              </p>
            )}
          </>
        )}
      </div>

      {/* Goal Progress */}
      <div style={{ marginBottom: "24px" }}>
        <div style={{ fontWeight: 700, fontSize: "13pt", marginBottom: "10px", borderBottom: "1px solid #e5e7eb", paddingBottom: "4px" }}>
          Goal Progress
        </div>
        {goals.length === 0 ? (
          <p style={{ color: "#888", fontStyle: "italic" }}>No goals on record.</p>
        ) : (
          <div>
            {goals.map((g) => {
              const clientPct = g.client_rating != null ? (g.client_rating / 10) * 100 : 0;
              const therapistPct = g.therapist_rating != null ? (g.therapist_rating / 10) * 100 : 0;
              const isAchieved = g.status === "achieved";
              return (
                <div key={g.id} style={{ border: "1px solid #e5e7eb", borderRadius: "8px", padding: "12px 14px", marginBottom: "10px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "10px", marginBottom: "8px" }}>
                    <div>
                      <div style={{ fontWeight: 600 }}>{g.title}</div>
                      {g.description && <div style={{ fontSize: "10pt", color: "#666", marginTop: "2px" }}>{g.description}</div>}
                    </div>
                    <span style={{ background: isAchieved ? "#d1fae522" : "#f3f4f6", color: isAchieved ? "#0f766e" : "#666", padding: "2px 10px", borderRadius: "10px", fontSize: "9.5pt", fontWeight: 600, whiteSpace: "nowrap", border: isAchieved ? "1px solid #6ee7b7" : "1px solid #e5e7eb" }}>
                      {g.status || "active"}
                    </span>
                  </div>
                  <div style={{ display: "flex", gap: "20px" }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: "9.5pt", color: "#666", marginBottom: "3px" }}>Client self-rating: {g.client_rating ?? "—"}/10</div>
                      <div style={{ height: "6px", background: "#e5e7eb", borderRadius: "4px", overflow: "hidden" }}>
                        <div style={{ height: "100%", width: `${clientPct}%`, background: "#0f766e", borderRadius: "4px" }} />
                      </div>
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: "9.5pt", color: "#666", marginBottom: "3px" }}>Therapist rating: {g.therapist_rating ?? "—"}/10</div>
                      <div style={{ height: "6px", background: "#e5e7eb", borderRadius: "4px", overflow: "hidden" }}>
                        <div style={{ height: "100%", width: `${therapistPct}%`, background: "#16a34a", borderRadius: "4px" }} />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Functional Impairment Trends */}
      <div style={{ marginBottom: "24px" }}>
        <div style={{ fontWeight: 700, fontSize: "13pt", marginBottom: "10px", borderBottom: "1px solid #e5e7eb", paddingBottom: "4px" }}>
          Functional Impairment Trends
        </div>
        {impairments.length === 0 ? (
          <p style={{ color: "#888", fontStyle: "italic" }}>No functional impairment check-ins on record.</p>
        ) : (
          <>
            {latestImpairment && (
              <div style={{ display: "flex", gap: "12px", marginBottom: "12px" }}>
                <div style={{ flex: 1, border: "1px solid #e5e7eb", borderRadius: "8px", padding: "10px 14px" }}>
                  <div style={{ fontSize: "9.5pt", color: "#666" }}>Current Impairment</div>
                  <div style={{ fontWeight: 700, fontSize: "18pt" }}>{latestImpairmentPct}%</div>
                  <div style={{ fontSize: "9.5pt", color: "#888" }}>{latestImpairmentScore}/{MAX_IMPAIRMENT} items flagged</div>
                </div>
                <div style={{ flex: 1, border: "1px solid #e5e7eb", borderRadius: "8px", padding: "10px 14px" }}>
                  <div style={{ fontSize: "9.5pt", color: "#666" }}>Engagement</div>
                  <div style={{ fontWeight: 700, fontSize: "18pt" }}>{latestImpairment.enjoyable_activities ?? "—"}/4</div>
                  <div style={{ fontSize: "9.5pt", color: "#888" }}>Enjoyable activities</div>
                </div>
              </div>
            )}
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "10.5pt" }}>
              <thead>
                <tr style={{ background: "#f3f4f6" }}>
                  <th style={thStyle}>Date</th>
                  <th style={{ ...thStyle, textAlign: "center" }}>Impairment</th>
                  <th style={{ ...thStyle, textAlign: "center" }}>Engagement</th>
                  <th style={thStyle}>Flagged areas</th>
                </tr>
              </thead>
              <tbody>
                {recentImpairments.map((e) => {
                  const score = NEGATIVE_ITEMS.reduce((sum, i) => sum + (e[i.key] || 0), 0);
                  const pct = Math.round((score / MAX_IMPAIRMENT) * 100);
                  const flagged = NEGATIVE_ITEMS.filter((i) => (e[i.key] || 0) >= 3).map((i) => i.label);
                  return (
                    <tr key={e.id} style={{ borderBottom: "1px solid #e5e7eb" }}>
                      <td style={{ ...tdStyle, color: "#666" }}>
                        {new Date(e.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                      </td>
                      <td style={{ ...tdStyle, textAlign: "center", fontWeight: 600 }}>{pct}%</td>
                      <td style={{ ...tdStyle, textAlign: "center" }}>{e.enjoyable_activities ?? "—"}/4</td>
                      <td style={{ ...tdStyle, fontSize: "9.5pt" }}>{flagged.length > 0 ? flagged.join(", ") : "—"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </>
        )}
      </div>

      {/* Footer */}
      <div style={{ borderTop: "2px solid #e5e7eb", paddingTop: "12px", marginTop: "8px" }}>
        <p style={{ fontSize: "9.5pt", color: "#666", margin: 0 }}>
          Crisis support: Call or text <strong style={{ color: "#1a1a1a" }}>988</strong> for the Suicide &amp; Crisis Lifeline (24/7).{" "}
          This report is generated from WayPoint and contains Protected Health Information (PHI).
        </p>
      </div>

    </div>
  );
}

const thStyle = {
  textAlign: "left",
  padding: "6px 10px",
  fontWeight: 600,
  fontSize: "10.5pt",
  borderBottom: "1px solid #d1d5db",
};
const tdStyle = {
  padding: "6px 10px",
  verticalAlign: "top",
};