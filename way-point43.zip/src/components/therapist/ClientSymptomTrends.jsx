import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { ASSESSMENTS } from "@/lib/assessments";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine,
} from "recharts";
import { TrendingUp, TrendingDown, Minus, Activity } from "lucide-react";

const DAY = 86400000;
const WINDOW_DAYS = 182; // ~6 months
const TYPES = ["GAD7", "PHQ9", "PCL-5"];
const COLORS = { GAD7: "hsl(172 68% 38%)", PHQ9: "hsl(200 55% 45%)", "PCL-5": "hsl(280 45% 55%)" };

function maxScore(testType) {
  const test = ASSESSMENTS[testType];
  return test ? test.items.length * (test.scale.length - 1) : 0;
}

export default function ClientSymptomTrends({ clientEmail }) {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.AssessmentResult.filter({ client_email: clientEmail }, "created_date", 200);
        setResults(data || []);
      } catch (e) {
        console.error("Symptom trends fetch failed:", e);
        setError(true);
      }
      setLoading(false);
    })();
  }, [clientEmail]);

  const series = useMemo(() => {
    const cutoff = Date.now() - WINDOW_DAYS * DAY;
    return TYPES.map((type) => {
      const points = (results || [])
        .filter((r) => r.test_type === type && new Date(r.created_date).getTime() >= cutoff)
        .map((r) => ({
          date: new Date(r.created_date).getTime(),
          label: new Date(r.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
          score: r.score,
          severity: ASSESSMENTS[type]?.score?.(r.score)?.severity || r.severity,
        }))
        .sort((a, b) => a.date - b.date);
      const first = points[0];
      const last = points[points.length - 1];
      const delta = first && last ? last.score - first.score : null;
      return { type, points, delta, first, last };
    });
  }, [results]);

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 140 }}>
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="pp-card p-6 text-center">
        <h3 className="font-heading text-lg font-semibold mb-1">Symptom Trends</h3>
        <p className="text-sm text-muted-foreground">Couldn't load assessment history.</p>
      </div>
    );
  }

  const hasAny = series.some((s) => s.points.length > 0);

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <Activity size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Symptom Trends</h3>
        <span className="ml-auto text-xs text-muted-foreground">Last 6 months · raw scores</span>
      </div>

      {!hasAny ? (
        <p className="text-sm text-muted-foreground py-6 text-center">
          No GAD-7, PHQ-9, or PCL-5 results recorded in the last 6 months.
        </p>
      ) : (
        <div className="grid lg:grid-cols-3 gap-4">
          {series.map(({ type, points, delta, first, last }) => {
            const test = ASSESSMENTS[type];
            const mx = maxScore(type);
            const color = COLORS[type];
            // For symptom scales, a falling score = improvement.
            const improving = delta !== null && delta < -1;
            const worsening = delta !== null && delta > 1;
            const badge = delta === null ? null : improving
              ? { label: "Improving", color: "#1995A1", icon: TrendingDown }
              : worsening
                ? { label: "Worsening", color: "#D9534F", icon: TrendingUp }
                : { label: "Stable", color: "#6b7280", icon: Minus };

            return (
              <div key={type} className="rounded-xl border border-border/60 p-4 bg-secondary/20">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-primary/10 text-primary text-xs font-bold">{test?.abbr || type}</span>
                    <span className="text-xs text-muted-foreground">{test?.name || type}</span>
                  </div>
                  {badge && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium" style={{ backgroundColor: `${badge.color}15`, color: badge.color }}>
                      <badge.icon size={11} /> {badge.label}
                    </span>
                  )}
                </div>

                {points.length === 0 ? (
                  <p className="text-xs text-muted-foreground py-8 text-center">No data in window</p>
                ) : (
                  <>
                    <div className="flex items-baseline justify-between text-xs text-muted-foreground mb-1">
                      <span>{first.label}</span>
                      <span className="font-heading font-semibold text-foreground">{last.score}<span className="text-muted-foreground/70 font-normal"> / {mx}</span></span>
                      <span>{last.label}</span>
                    </div>
                    <div style={{ width: "100%", height: 120 }}>
                      <ResponsiveContainer>
                        <LineChart data={points} margin={{ top: 5, right: 8, left: -22, bottom: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
                          <XAxis dataKey="label" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} interval="preserveStartEnd" minTickGap={20} />
                          <YAxis domain={[0, mx]} tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} allowDecimals={false} />
                          <Tooltip
                            contentStyle={{ fontSize: 12, borderRadius: 10, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }}
                            formatter={(value) => [`Score ${value}`, test?.abbr || type]}
                            labelFormatter={(l) => l}
                          />
                          <ReferenceLine y={0} stroke="transparent" />
                          <Line type="monotone" dataKey="score" stroke={color} strokeWidth={2.5} dot={{ r: 3, fill: color }} activeDot={{ r: 5 }} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                    {last.severity && (
                      <p className="text-xs text-muted-foreground mt-1 text-center">Most recent: <span className="font-medium text-foreground">{last.severity}</span></p>
                    )}
                  </>
                )}
              </div>
            );
          })}
        </div>
      )}

      <p className="text-xs text-muted-foreground mt-3">
        Falling lines indicate symptom improvement for these screens. Markers show each administered result over the last 6 months.
      </p>
    </div>
  );
}