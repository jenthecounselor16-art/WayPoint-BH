import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { ASSESSMENTS } from "@/lib/assessments";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Activity, TrendingUp } from "lucide-react";

const DAY = 86400000;

// Therapist-visible proxy of the barometer: assessment wellbeing (0.6) + nervous-system engagement (0.4).
function wellbeingOf(a) {
  const test = ASSESSMENTS[a.test_type];
  if (!test) return null;
  const maxScore = test.items.length * (test.scale.length - 1);
  if (!maxScore) return null;
  const ratio = a.score / maxScore;
  return a.test_type === "WHO5" ? ratio * 100 : (1 - ratio) * 100;
}

export default function ClientBarometerTrend({ clientEmail }) {
  const [assessments, setAssessments] = useState([]);
  const [nervous, setNervous] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      if (!clientEmail) { setLoading(false); return; }
      try {
        const [a, n] = await Promise.all([
          base44.entities.AssessmentResult.filter({ client_email: clientEmail }, "-created_date", 300),
          base44.entities.NervousSystemMetric.filter({ client_email: clientEmail }, "-created_date", 300),
        ]);
        setAssessments(a || []);
        setNervous(n || []);
      } catch (err) {
        console.error("Barometer trend fetch error:", err);
      }
      setLoading(false);
    })();
  }, [clientEmail]);

  const weeks = useMemo(() => {
    const now = Date.now();
    const buckets = [];
    for (let i = 12; i >= 0; i--) {
      const end = new Date(now - i * 7 * DAY);
      buckets.push({
        endMs: end.getTime(),
        label: end.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      });
    }
    return buckets;
  }, []);

  const chartData = useMemo(() => {
    return weeks.map((b) => {
      const D = b.endMs;
      const latest = {};
      assessments.forEach((a) => {
        if (new Date(a.created_date).getTime() <= D) {
          if (!latest[a.test_type] || new Date(a.created_date) > new Date(latest[a.test_type].created_date)) {
            latest[a.test_type] = a;
          }
        }
      });
      const latestList = Object.values(latest);
      let assessmentScore = null;
      if (latestList.length > 0) {
        const scores = latestList.map(wellbeingOf).filter((s) => s !== null);
        if (scores.length) assessmentScore = scores.reduce((x, y) => x + y, 0) / scores.length;
      }

      const nervousCount = nervous.filter((x) => {
        const t = new Date(x.created_date).getTime();
        return t <= D && t >= D - 30 * DAY;
      }).length;
      const nervousScore = Math.min(100, (nervousCount / 7) * 100);

      let barometer = null;
      let wsum = 0;
      let w = 0;
      [
        { v: assessmentScore, w: 0.6 },
        { v: nervousScore, w: 0.4 },
      ].forEach(({ v, w: ww }) => {
        if (v !== null && Number.isFinite(v)) { wsum += v * ww; w += ww; }
      });
      if (w > 0) barometer = wsum / w;

      const hasAny = assessmentScore !== null || nervousCount > 0;
      return {
        label: b.label,
        Barometer: hasAny && barometer !== null ? Math.round(barometer) : null,
        Assessment: assessmentScore !== null ? Math.round(assessmentScore) : null,
      };
    });
  }, [weeks, assessments, nervous]);

  const hasData = chartData.some((d) => d.Barometer !== null || d.Assessment !== null);

  return (
    <div className="pp-card p-5">
      <div className="flex items-start gap-3 mb-1">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Activity className="text-primary" size={20} />
        </div>
        <div className="flex-1">
          <h3 className="font-heading text-lg font-semibold">90-Day Progress Summary</h3>
          <p className="text-xs text-muted-foreground">
            Mental Health Barometer score tracked against assessment results over the last 90 days.
          </p>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="w-7 h-7 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : !hasData ? (
        <div className="py-10 text-center">
          <TrendingUp className="mx-auto mb-3 text-muted-foreground/40" size={36} />
          <p className="text-sm text-muted-foreground">
            No assessment or check-in data in the last 90 days for this client.
          </p>
        </div>
      ) : (
        <div className="mt-4 w-full" style={{ height: 280 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 8, right: 12, bottom: 4, left: -12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
              <XAxis dataKey="label" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} tickLine={false} axisLine={{ stroke: "hsl(var(--border))" }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} tickLine={false} axisLine={{ stroke: "hsl(var(--border))" }} />
              <Tooltip
                contentStyle={{
                  background: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: 12,
                  fontSize: 12,
                }}
                labelStyle={{ fontWeight: 600 }}
              />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Line
                type="monotone"
                dataKey="Barometer"
                name="Barometer Score"
                stroke="#1FA89D"
                strokeWidth={3}
                dot={{ r: 3, fill: "#1FA89D" }}
                connectNulls
              />
              <Line
                type="monotone"
                dataKey="Assessment"
                name="Assessment Score"
                stroke="#E8923A"
                strokeWidth={2.5}
                strokeDasharray="5 4"
                dot={{ r: 3, fill: "#E8923A" }}
                connectNulls
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
      <p className="text-[11px] text-muted-foreground mt-3 leading-relaxed">
        The Barometer combines assessment wellbeing and nervous-system engagement (visible to the therapist). Severe assessment ratings lower both lines; both rise as symptoms improve. Assessment scores reflect the latest result per test type as of each week.
      </p>
    </div>
  );
}