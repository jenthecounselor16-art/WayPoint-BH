import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { FileText, Save, Check } from "lucide-react";

export default function ClinicalNotes({ clientEmail, therapistEmail }) {
  const [note, setNote] = useState(null);
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.ClinicalNote.filter({ client_email: clientEmail }, "-created_date", 1);
        if (data?.[0]) {
          setNote(data[0]);
          setContent(data[0].content || "");
        }
      } catch {}
      setLoading(false);
    })();
  }, [clientEmail]);

  async function save() {
    setSaving(true);
    setSaved(false);
    try {
      if (note?.id) {
        await base44.entities.ClinicalNote.update(note.id, { content });
      } else {
        const created = await base44.entities.ClinicalNote.create({
          client_email: clientEmail,
          therapist_email: therapistEmail || "",
          content,
        });
        setNote(created);
      }
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch {}
    setSaving(false);
  }

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 120 }}>
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <FileText size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Goals & Interventions</h3>
        <div className="ml-auto flex items-center gap-2">
          {saved && <span className="text-xs text-primary flex items-center gap-1"><Check size={13} /> Saved</span>}
          <button onClick={save} disabled={saving} className="px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center gap-1">
            <Save size={13} /> {saving ? "Saving…" : "Save"}
          </button>
        </div>
      </div>
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Document treatment goals, planned interventions, clinical observations, and session notes here…"
        className="pp-input min-h-[200px] resize-y text-sm leading-relaxed"
      />
      <p className="text-xs text-muted-foreground/60 mt-2">
        This note is shared with the client and stored securely. Last updated: {note?.updated_date ? new Date(note.updated_date).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" }) : "never"}
      </p>
    </div>
  );
}