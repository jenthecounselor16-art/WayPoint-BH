import React from "react";
import { ClipboardCheck, Activity, BookOpen, Target, ShieldAlert } from "lucide-react";

function timeAgo(ms) {
  if (!ms) return "—";
  const diff = Date.now() - ms;
  const day = 86400000;
  const days = Math.floor(diff / day);
  if (days <= 0) return "today";
  if (days === 1) return "1d ago";
  if (days < 30) return `${days}d ago`;
  return `${Math.floor(days / 30)}mo ago`;
}

// Read-only summary of a single client's recent clinical activity, pulled from
// the therapist's shared records. Designed to sit inside an expanded row.
export default function ClientActivitySummary({ activity }) {
  if (!activity) {
    return <p className="text-xs text-muted-foreground">No activity on file — this client hasn't registered or shared data yet.</p>;
  }
  const { assessments = [], nervous = [], homework = [], goals = [], crisis = [] } = activity;

  const lastAssessment = assessments[0];
  const lastNervous = nervous[0];
  const pendingHw = homework.filter((h) => h.status !== "completed");
  const lastHw = homework[0];
  const activeGoals = goals.filter((g) => g.status !== "achieved");
  const lastCrisis = crisis[0];

  const items = [
    {
      icon: ClipboardCheck,
      label: "Assessments",
      color: "text-primary",
      value: assessments.length ? `${assessments.length} taken` : "None",
      detail: lastAssessment
        ? `${lastAssessment.test_type} · ${lastAssessment.score} (${lastAssessment.severity || "—"}) · ${timeAgo(new Date(lastAssessment.created_date).getTime())}`
        : "No assessments on record",
    },
    {
      icon: Activity,
      label: "Nervous system",
      color: "text-blue-500",
      value: nervous.length ? `${nervous.length} check-ins` : "None",
      detail: lastNervous
        ? `stress ${lastNervous.stress_level ?? "—"}/10 · anxiety ${lastNervous.anxiety_level ?? "—"}/10 · ${timeAgo(new Date(lastNervous.created_date).getTime())}`
        : "No check-ins logged",
    },
    {
      icon: BookOpen,
      label: "Homework",
      color: "text-amber-600",
      value: `${pendingHw.length} pending / ${homework.length} total`,
      detail: lastHw ? `${lastHw.title} · ${timeAgo(new Date(lastHw.created_date).getTime())}` : "No homework assigned",
    },
    {
      icon: Target,
      label: "Goals",
      color: "text-accent",
      value: `${activeGoals.length} active / ${goals.length} total`,
      detail: goals[0] ? `${goals[0].title} · ${timeAgo(new Date(goals[0].created_date).getTime())}` : "No goals set",
    },
    {
      icon: ShieldAlert,
      label: "Crisis plan",
      color: "text-red-500",
      value: crisis.length ? "On file" : "None",
      detail: lastCrisis
        ? `Last updated ${timeAgo(new Date(lastCrisis.updated_date || lastCrisis.created_date).getTime())}`
        : "No crisis plan saved",
    },
  ];

  return (
    <div className="mt-3 pt-3 border-t border-border/60 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
      {items.map((it) => {
        const Icon = it.icon;
        return (
          <div key={it.label} className="rounded-xl bg-secondary/30 p-3">
            <div className="flex items-center gap-1.5 mb-1">
              <Icon size={13} className={it.color} />
              <span className="text-xs font-medium text-muted-foreground">{it.label}</span>
            </div>
            <p className="text-sm font-medium">{it.value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{it.detail}</p>
          </div>
        );
      })}
    </div>
  );
}