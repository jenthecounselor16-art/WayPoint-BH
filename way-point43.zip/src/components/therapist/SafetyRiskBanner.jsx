import React, { useMemo } from "react";
import { ShieldAlert, AlertTriangle, Phone } from "lucide-react";
import { ASSESSMENTS } from "@/lib/assessments";

const SELF_HARM_ITEMS = {
  PHQ9: { index: 8, label: "Thoughts of being better off dead or of hurting yourself" },
  BDI: { index: 8, label: "Suicidal thoughts or wishes" },
};

const VALUE_LABELS = {
  PHQ9: ["Not at all", "Several days", "More than half the days", "Nearly every day"],
  BDI: ["Not at all", "Some of the time", "Much of the time", "Most or all of the time"],
};

export default function SafetyRiskBanner({ results }) {
  const risk = useMemo(() => {
    const candidates = (results || [])
      .filter((r) => Array.isArray(r.answers) && SELF_HARM_ITEMS[r.test_type])
      .map((r) => {
        const cfg = SELF_HARM_ITEMS[r.test_type];
        const val = Number(r.answers[cfg.index]);
        if (!Number.isFinite(val) || val < 1) return null;
        return {
          test_type: r.test_type,
          abbr: ASSESSMENTS[r.test_type]?.abbr || r.test_type,
          label: cfg.label,
          val,
          valLabel: (VALUE_LABELS[r.test_type] || [])[val] || `Level ${val}`,
          date: new Date(r.created_date),
          score: r.score,
        };
      })
      .filter(Boolean)
      .sort((a, b) => b.date - a.date);
    return candidates[0] || null;
  }, [results]);

  if (!risk) {
    return (
      <div className="pp-card p-4 mb-6 flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-accent/10 flex items-center justify-center shrink-0">
          <ShieldAlert className="text-accent" size={18} />
        </div>
        <div>
          <p className="text-sm font-medium">No acute safety risk flagged</p>
          <p className="text-xs text-muted-foreground">No self-harm or suicidal ideation disclosed on recent PHQ-9 / BDI assessments.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border-2 border-destructive/40 bg-destructive/5 p-5 mb-6">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-destructive/15 flex items-center justify-center shrink-0">
          <AlertTriangle className="text-destructive" size={22} />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-heading text-lg font-semibold text-destructive">High Safety Risk Identified</h3>
          <p className="text-sm text-foreground/80 mt-1">
            Client endorsed self-harm / suicidal ideation on the {risk.abbr} ({risk.label}).
          </p>
          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
            <span>Response: <span className="font-semibold text-destructive">{risk.valLabel}</span></span>
            <span>Assessment score: {risk.score}</span>
            <span>Disclosed: {risk.date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
          </div>
          <div className="mt-3 flex items-center gap-2 text-xs">
            <Phone size={13} className="text-destructive shrink-0" />
            <span className="font-medium text-destructive">Conduct a safety assessment &amp; review the client's crisis plan. Call or text 988 for the Suicide &amp; Crisis Lifeline.</span>
          </div>
        </div>
      </div>
    </div>
  );
}