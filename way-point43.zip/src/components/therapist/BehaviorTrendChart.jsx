import React, { useMemo } from "react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import { Activity } from "lucide-react";

const DAY = 86400000;

function weekStart(ms) {
  const d = new Date(ms);
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - d.getDay());
  return d.getTime();
}
function fmt(ms) {
  return new Date(ms).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

function Empty({ text }) {
  return (
    <div className="pp-card p-10 text-center">
      <Activity className="mx-auto mb-3 text-muted-foreground/30" size={36} />
      <p className="text-sm text-muted-foreground">{text}</p>
    </div>
  );
}

export default function BehaviorTrendChart({ activities, homework }) {
  const data = useMemo(() => {
    const now = Date.now();
    const weeks = [];
    for (let i = 7; i >= 0; i--) {
      const start = weekStart(now - i * 7 * DAY);
      weeks.push({ start, label: fmt(start), activities: 0, homework: 0 });
    }
    const idx = (ms) => {
      if (!ms) return -1;
      const ws = weekStart(new Date(ms).getTime());
      return weeks.findIndex((w) => w.start === ws);
    };
    (activities || []).forEach((a) => {
      if (a.status !== "done") return;
      const i = idx(a.last_done_at || a.created_date);
      if (i >= 0) weeks[i].activities++;
    });
    (homework || []).forEach((h) => {
      if (h.status !== "completed") return;
      const i = idx(h.updated_date || h.created_date);
      if (i >= 0) weeks[i].homework++;
    });
    return weeks;
  }, [activities, homework]);

  const totalAct = data.reduce((s, w) => s + w.activities, 0);
  const totalHw = data.reduce((s, w) => s + w.homework, 0);

  if (totalAct === 0 && totalHw === 0) {
    return <Empty text="No behavior-activation or homework completions logged yet for this client." />;
  }

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2.5 mb-1">
        <div className="w-9 h-9 rounded-lg bg-accent/10 flex items-center justify-center shrink-0">
          <Activity className="text-accent" size={18} />
        </div>
        <div>
          <h3 className="font-heading text-lg font-semibold">Behavior Trends</h3>
          <p className="text-xs text-muted-foreground">Behavior-activation activities &amp; homework completed per week (last 8 weeks)</p>
        </div>
      </div>
      <div className="h-72 mt-4 -ml-2">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 5, right: 10, bottom: 0, left: -10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
            <XAxis
              dataKey="label"
              tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
              tickLine={false}
              axisLine={{ stroke: "hsl(var(--border))" }}
              minTickGap={10}
            />
            <YAxis
              allowDecimals={false}
              tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
              tickLine={false}
              axisLine={false}
              width={30}
            />
            <Tooltip
              contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "12px", fontSize: "12px" }}
              cursor={{ fill: "hsl(var(--muted))", opacity: 0.4 }}
            />
            <Legend wrapperStyle={{ fontSize: "12px" }} />
            <Bar dataKey="activities" name="Activities done" fill="#1995A1" radius={[4, 4, 0, 0]} isAnimationActive={false} />
            <Bar dataKey="homework" name="Homework done" fill="#D4A055" radius={[4, 4, 0, 0]} isAnimationActive={false} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}