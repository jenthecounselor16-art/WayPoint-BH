import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { ASSESSMENTS } from "@/lib/assessments";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine,
} from "recharts";
import { TrendingUp, TrendingDown, Minus, Layers, Calendar } from "lucide-react";

// Wellbeing % — higher is always better. WHO-5 counts up; symptom scales inverted.
function wellbeing(testType, score) {
  const test = ASSESSMENTS[testType];
  if (!test) return null;
  const maxScore = test.items.length * (test.scale.length - 1);
  if (!maxScore) return null;
  const ratio = score / maxScore;
  return testType === "WHO5" ? ratio * 100 : (1 - ratio) * 100;
}

function maxScore(testType) {
  const test = ASSESSMENTS[testType];
  return test ? test.items.length * (test.scale.length - 1) : 0;
}

function fmtDate(iso) {
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "2-digit" });
}

function DeltaBadge({ value, invert }) {
  if (value === null || Number.isNaN(value)) return null;
  const rounded = Math.round(value);
  if (Math.abs(rounded) < 1) {
    return <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-secondary text-xs font-medium text-muted-foreground"><Minus size={11} /> 0</span>;
  }
  // invert = true for raw symptom scores where a fall is improvement
  const positive = invert ? rounded < 0 : rounded > 0;
  return (
    <span
      className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-xs font-medium"
      style={{ backgroundColor: `${positive ? "#1995A1" : "#D9534F"}15`, color: positive ? "#1995A1" : "#D9534F" }}
    >
      {positive ? <TrendingDown size={11} /> : <TrendingUp size={11} />}
      {rounded > 0 ? "+" : ""}{rounded}
    </span>
  );
}

export default function ClientScoreProgress({ clientEmail }) {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [metric, setMetric] = useState("wellbeing"); // "wellbeing" | "raw"

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.AssessmentResult.filter({ client_email: clientEmail }, "created_date", 300);
        setResults(data || []);
      } catch (e) {
        console.error("Score progress fetch failed:", e);
        setError(true);
      }
      setLoading(false);
    })();
  }, [clientEmail]);

  const groups = useMemo(() => {
    const byType = {};
    (results || []).forEach((r) => {
      if (!byType[r.test_type]) byType[r.test_type] = [];
      byType[r.test_type].push(r);
    });
    return Object.entries(byType)
      .map(([type, list]) => {
        list.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
        const first = list[0];
        const last = list[list.length - 1];
        const wbFirst = wellbeing(type, first.score);
        const wbLast = wellbeing(type, last.score);
        return { type, list, first, last, wbFirst, wbLast };
      })
      .filter((g) => g.list.length >= 1)
      .sort((a, b) => (ASSESSMENTS[a.type]?.name || a.type).localeCompare(ASSESSMENTS[b.type]?.name || b.type));
  }, [results]);

  if (loading) {
    return (
      <div className="pp-card p-6 flex items-center justify-center" style={{ minHeight: 140 }}>
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="pp-card p-6 text-center">
        <h3 className="font-heading text-lg font-semibold mb-1">Score Progress Overlays</h3>
        <p className="text-sm text-muted-foreground">Couldn't load assessment history.</p>
      </div>
    );
  }

  if (groups.length === 0) {
    return (
      <div className="pp-card p-6 text-center">
        <Layers className="mx-auto mb-3 text-muted-foreground/40" size={32} />
        <h3 className="font-heading text-lg font-semibold mb-1">Score Progress Overlays</h3>
        <p className="text-sm text-muted-foreground">No assessment data yet for this client.</p>
      </div>
    );
  }

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <Layers size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Score Progress Overlays</h3>
        <span className="text-xs text-muted-foreground hidden sm:inline">All historical readings overlaid on the current result</span>
        <div className="ml-auto flex gap-1 p-1 rounded-lg bg-secondary/60">
          <button
            onClick={() => setMetric("wellbeing")}
            className={`px-3 py-1 rounded-md text-xs font-medium transition ${metric === "wellbeing" ? "bg-card text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
          >
            Wellbeing %
          </button>
          <button
            onClick={() => setMetric("raw")}
            className={`px-3 py-1 rounded-md text-xs font-medium transition ${metric === "raw" ? "bg-card text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
          >
            Raw score
          </button>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        {groups.map((g) => {
          const test = ASSESSMENTS[g.type];
          const mx = maxScore(g.type);
          const isSymptom = g.type !== "WHO5";
          const multi = g.list.length > 1;

          // Build chart data
          const points = g.list.map((r) => {
            const wb = wellbeing(g.type, r.score);
            return {
              label: new Date(r.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
              value: metric === "wellbeing" ? (wb !== null ? Math.round(wb) : null) : r.score,
              raw: r.score,
              severity: ASSESSMENTS[g.type]?.score?.(r.score)?.severity || r.severity,
              date: r.created_date,
            };
          });

          // Reference line = initial reading (the baseline we're comparing progress against)
          const baseline = points[0]?.value;
          const totalDelta = multi && baseline !== undefined && points[points.length - 1]?.value !== null
            ? points[points.length - 1].value - baseline
            : null;
          const isImproving = metric === "wellbeing" ? totalDelta > 0 : totalDelta < 0;

          return (
            <div key={g.type} className="rounded-xl border border-border/60 p-4 bg-secondary/20">
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="px-2 py-0.5 rounded-md bg-primary/10 text-primary text-xs font-bold shrink-0">{test?.abbr || g.type}</span>
                  <span className="text-xs text-muted-foreground truncate">{test?.name || g.type}</span>
                </div>
                <span className="text-xs text-muted-foreground shrink-0">{g.list.length} {g.list.length === 1 ? "reading" : "readings"}</span>
              </div>

              {multi && (
                <div className="flex items-center justify-between mb-2 text-xs">
                  <span className="text-muted-foreground">
                    <Calendar size={11} className="inline mr-1" />Baseline {fmtDate(g.first.created_date)}
                  </span>
                  <DeltaBadge value={totalDelta} invert={metric === "raw" && isSymptom} />
                </div>
              )}

              <div style={{ width: "100%", height: 140 }}>
                <ResponsiveContainer>
                  <LineChart data={points} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
                    <XAxis dataKey="label" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} interval="preserveStartEnd" minTickGap={15} />
                    <YAxis
                      domain={metric === "wellbeing" ? [0, 100] : [0, mx]}
                      tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                      allowDecimals={false}
                    />
                    <Tooltip
                      contentStyle={{ fontSize: 12, borderRadius: 10, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }}
                      formatter={(value) => [metric === "wellbeing" ? `${value}%` : `Score ${value}`, test?.abbr || g.type]}
                      labelFormatter={(l, p) => p?.[0]?.payload?.date ? fmtDate(p[0].payload.date) : l}
                    />
                    {multi && baseline !== null && baseline !== undefined && (
                      <ReferenceLine
                        y={baseline}
                        stroke="hsl(var(--subtle-accent))"
                        strokeDasharray="4 4"
                        strokeWidth={1.5}
                        label={{ value: "baseline", fontSize: 9, fill: "hsl(var(--muted-foreground))", position: "insideTopLeft" }}
                      />
                    )}
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2.5}
                      activeDot={{ r: 5 }}
                      dot={(props) => {
                        const { cx, cy, index } = props;
                        const isLast = index === points.length - 1;
                        return (
                          <circle key={`dot-${index}`} cx={cx} cy={cy} r={isLast ? 5 : 3} fill="hsl(var(--primary))" stroke={isLast ? "hsl(var(--card))" : "none"} strokeWidth={isLast ? 2 : 0} />
                        );
                      }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Reading-by-reading list */}
              <div className="mt-3 space-y-1">
                {g.list.map((r, i) => {
                  const prev = g.list[i - 1];
                  const stepDelta = prev ? (metric === "wellbeing"
                    ? (wellbeing(g.type, r.score) ?? 0) - (wellbeing(g.type, prev.score) ?? 0)
                    : r.score - prev.score) : null;
                  const isLast = i === g.list.length - 1;
                  return (
                    <div key={r.id} className={`flex items-center gap-2 px-2 py-1.5 rounded-lg ${isLast ? "bg-primary/10" : "bg-card/60"}`}>
                      <span className="text-xs text-muted-foreground w-20 shrink-0">{fmtDate(r.created_date)}</span>
                      <span className={`font-heading text-sm font-semibold w-10 shrink-0 ${isLast ? "text-primary" : ""}`}>{r.score}</span>
                      {r.severity && <span className="text-[11px] text-muted-foreground truncate flex-1 min-w-0">{r.severity}</span>}
                      <div className="shrink-0 ml-auto">
                        {isLast ? (
                          <span className="text-[11px] font-medium text-primary">Current</span>
                        ) : stepDelta !== null ? (
                          <DeltaBadge value={stepDelta} invert={metric === "raw" && isSymptom} />
                        ) : <span className="text-[11px] text-muted-foreground">First</span>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      <p className="text-xs text-muted-foreground mt-4">
        Each card overlays every historical reading against a dashed <span className="text-subtleAccent">baseline</span> (first result). The highlighted <span className="text-primary">current</span> point and reading list show exactly how the score has moved over time.
        {metric === "wellbeing" ? " Wellbeing % inverts symptom scales so higher always means improvement." : " Raw symptom scores: a falling line indicates improvement."}
      </p>
    </div>
  );
}