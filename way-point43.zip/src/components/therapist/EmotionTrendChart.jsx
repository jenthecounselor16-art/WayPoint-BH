import React, { useMemo } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import { Brain } from "lucide-react";

const DAY = 86400000;

// Therapist-visible affect sub-scales from the client's nervous-system
// check-ins (private mood logs stay private to the client). Each is 0-10.
const SERIES = [
  { key: "anxiety", label: "Anxiety", color: "#D9534F" },
  { key: "depression", label: "Depression", color: "#5B7CC4" },
  { key: "stress", label: "Stress", color: "#D4A055" },
  { key: "energy", label: "Energy", color: "#1995A1" },
];

function dayKey(d) {
  const dt = new Date(d);
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
}
function fmt(k) {
  const [y, m, d] = k.split("-");
  return new Date(+y, +m - 1, +d).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

function Empty({ text }) {
  return (
    <div className="pp-card p-10 text-center">
      <Brain className="mx-auto mb-3 text-muted-foreground/30" size={36} />
      <p className="text-sm text-muted-foreground">{text}</p>
    </div>
  );
}

export default function EmotionTrendChart({ metrics }) {
  const data = useMemo(() => {
    const list = (metrics || []).filter((n) => n.created_date);
    if (!list.length) return [];
    const byDay = {};
    list.forEach((n) => {
      const k = dayKey(n.created_date);
      (byDay[k] = byDay[k] || []).push(n);
    });
    const days = Object.keys(byDay).sort();
    const first = new Date(days[0]).getTime();
    const last = new Date(days[days.length - 1]).getTime();
    const pts = [];
    for (let t = first; t <= last; t += DAY) {
      const k = dayKey(t);
      if (byDay[k]) {
        const arr = byDay[k];
        const avg = (f) => Math.round((arr.reduce((s, x) => s + (x[f] ?? 0), 0) / arr.length) * 10) / 10;
        pts.push({
          date: k,
          anxiety: avg("anxiety_level"),
          depression: avg("depression_level"),
          stress: avg("stress_level"),
          energy: avg("energy_level"),
        });
      }
    }
    // 7-day rolling average per sub-scale
    pts.forEach((p, i) => {
      const win = pts.slice(Math.max(0, i - 6), i + 1);
      SERIES.forEach((s) => {
        p[s.key] = Math.round((win.reduce((a, b) => a + b[s.key], 0) / win.length) * 10) / 10;
      });
    });
    return pts;
  }, [metrics]);

  if (!data.length) return <Empty text="No emotion check-ins yet for this client." />;

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2.5 mb-1">
        <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
          <Brain className="text-primary" size={18} />
        </div>
        <div>
          <h3 className="font-heading text-lg font-semibold">Emotion Trends</h3>
          <p className="text-xs text-muted-foreground">Anxiety, depression, stress &amp; energy over time (7-day rolling avg, 0–10)</p>
        </div>
      </div>
      <div className="h-72 mt-4 -ml-2">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 10, bottom: 0, left: -10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
            <XAxis
              dataKey="date"
              tickFormatter={fmt}
              tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
              tickLine={false}
              axisLine={{ stroke: "hsl(var(--border))" }}
              minTickGap={28}
            />
            <YAxis
              domain={[0, 10]}
              tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
              tickLine={false}
              axisLine={false}
              width={30}
            />
            <Tooltip
              contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "12px", fontSize: "12px" }}
              labelFormatter={fmt}
            />
            <Legend wrapperStyle={{ fontSize: "12px" }} />
            {SERIES.map((s) => (
              <Line
                key={s.key}
                type="monotone"
                dataKey={s.key}
                name={s.label}
                stroke={s.color}
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4 }}
                isAnimationActive={false}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}