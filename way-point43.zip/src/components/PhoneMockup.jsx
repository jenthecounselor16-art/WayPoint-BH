import React from "react";
import { motion } from "framer-motion";

export default function PhoneMockup({ children }) {
  return (
    <div className="relative mx-auto" style={{ width: 260, maxWidth: "100%" }}>
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="relative"
      >
        {/* Phone frame */}
        <div className="rounded-[2.5rem] bg-foreground p-2.5 shadow-2xl ring-1 ring-foreground/20">
          {/* Screen */}
          <div
            className="rounded-[2rem] bg-background overflow-hidden relative"
            style={{ aspectRatio: "9/19.5" }}
          >
            {/* Notch */}
            <div className="absolute top-2 left-1/2 -translate-x-1/2 w-16 h-5 bg-foreground rounded-full z-20" />
            {/* Content */}
            <div className="h-full overflow-hidden">{children}</div>
          </div>
        </div>
        {/* Side buttons */}
        <div className="absolute -left-1 top-24 w-1 h-8 bg-foreground/80 rounded-l-sm" />
        <div className="absolute -left-1 top-36 w-1 h-12 bg-foreground/80 rounded-l-sm" />
        <div className="absolute -right-1 top-28 w-1 h-16 bg-foreground/80 rounded-r-sm" />
      </motion.div>
    </div>
  );
}