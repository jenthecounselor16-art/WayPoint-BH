import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import {
  ChevronDown,
  ChevronRight,
  CheckCircle2,
  Loader2,
  XCircle,
} from "lucide-react";

export default function MessageBubble({ message }) {
  const isUser = message.role === "user";

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div className={`max-w-[85%] ${isUser ? "order-2" : "order-1"}`}>
        {message.content && (
          isUser ? (
            <div className="bg-primary text-primary-foreground px-4 py-2.5 rounded-2xl rounded-tr-md">
              <p className="text-sm whitespace-pre-wrap leading-relaxed">{message.content}</p>
            </div>
          ) : (
            <div className="bg-card border border-border/60 px-4 py-3 rounded-2xl rounded-tl-md">
              <ReactMarkdown
                components={{
                  p: ({ children }) => <p className="text-sm leading-relaxed mb-2 last:mb-0">{children}</p>,
                  ul: ({ children }) => <ul className="list-disc pl-4 mb-2 text-sm leading-relaxed">{children}</ul>,
                  ol: ({ children }) => <ol className="list-decimal pl-4 mb-2 text-sm leading-relaxed">{children}</ol>,
                  li: ({ children }) => <li className="mb-0.5 text-sm">{children}</li>,
                  strong: ({ children }) => <strong className="font-semibold">{children}</strong>,
                  blockquote: ({ children }) => <blockquote className="border-l-2 border-primary/40 pl-3 italic text-muted-foreground my-1">{children}</blockquote>,
                }}
              >
                {message.content}
              </ReactMarkdown>
            </div>
          )
        )}
        {message.tool_calls?.map((tc, i) => (
          <ToolCallDisplay key={i} toolCall={tc} />
        ))}
      </div>
    </div>
  );
}

function ToolCallDisplay({ toolCall }) {
  const [expanded, setExpanded] = useState(false);
  const status = toolCall.status;
  const isComplete = ["completed", "success"].includes(status);
  const isError = ["failed", "error"].includes(status);
  const isPending = ["pending", "running", "in_progress"].includes(status);

  const dp = toolCall.display_projection || {};
  const hideDetails = dp.hide_details && dp.details_redacted;

  let icon;
  let label;
  if (isPending) {
    icon = <Loader2 size={12} className="animate-spin text-muted-foreground" />;
    label = dp.active_label || "Working…";
  } else if (isError) {
    icon = <XCircle size={12} className="text-destructive" />;
    label = dp.error_label || "Failed";
  } else if (isComplete) {
    icon = <CheckCircle2 size={12} className="text-accent" />;
    label = dp.label || "Done";
  } else {
    icon = <Loader2 size={12} className="animate-spin text-muted-foreground" />;
    label = label || "Working…";
  }

  let parsedResults = toolCall.results;
  if (typeof parsedResults === "string") {
    try {
      parsedResults = JSON.parse(parsedResults);
    } catch {}
  }

  const isFailedResult =
    isError ||
    (parsedResults && typeof parsedResults === "object" && parsedResults.success === false) ||
    (typeof parsedResults === "string" && /error|failed/i.test(parsedResults));

  if (isFailedResult && !isError) {
    icon = <XCircle size={12} className="text-destructive" />;
    label = "Failed";
  }

  return (
    <div className="mt-1.5 text-xs">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition"
      >
        {expanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
        {icon}
        <span className="font-medium">{toolCall.name}</span>
        <span className="text-muted-foreground/60">· {label}</span>
      </button>
      {expanded && !hideDetails && (
        <div className="mt-1 ml-6 p-2 rounded-lg bg-secondary/50 space-y-1.5 max-w-md">
          {toolCall.arguments_string && (
            <div>
              <p className="text-muted-foreground/60 mb-0.5">Parameters:</p>
              <pre className="text-xs whitespace-pre-wrap break-words">
                {typeof toolCall.arguments_string === "string"
                  ? toolCall.arguments_string
                  : JSON.stringify(toolCall.arguments_string, null, 2)}
              </pre>
            </div>
          )}
          {toolCall.results && (
            <div>
              <p className="text-muted-foreground/60 mb-0.5">Result:</p>
              <pre className="text-xs whitespace-pre-wrap break-words">
                {typeof toolCall.results === "string"
                  ? toolCall.results
                  : JSON.stringify(toolCall.results, null, 2)}
              </pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
}