import React from "react";
import { Image } from "@/components/ui/image";

const MONOGRAM_URL = "https://media.base44.com/images/public/6a5d9b9fe72fabffdfd16c68/5b4d23001_IMG_5816.jpg";
const SPLASH_URL = "https://media.base44.com/images/public/6a5d9b9fe72fabffdfd16c68/08532b6f2_generated_image.png";

export default function AuthLayout({ title, subtitle, footer, banner, logo, theme, children }) {
  const bannerTheme = theme === "banner";
  const logoUrl = logo || MONOGRAM_URL;
  return (
    <div className={`min-h-screen flex items-center justify-center px-4 relative overflow-hidden ${bannerTheme ? "" : "bg-background"}`}>
      {bannerTheme && (
        <>
          <div
            className="absolute inset-0"
            style={{ backgroundImage: `url(${SPLASH_URL})`, backgroundSize: "cover", backgroundPosition: "center" }}
          />
          <div className="absolute inset-0 bg-gradient-to-br from-bannerTeal/80 to-bannerTealDark/90" />
        </>
      )}
      <div className="w-full max-w-md relative z-10 py-10">
        {banner && (
          <div className="mb-8 rounded-2xl overflow-hidden shadow-sm border border-border">
            <Image
              src={banner}
              alt="WayPoint"
              fittingType="fill"
              focalPointY={0.5}
              className="block w-full h-28 sm:h-32"
            />
          </div>
        )}
        <div className="text-center mb-10">
          <div className="flex flex-col items-center mb-5">
            <div className="w-28 h-28 rounded-3xl bg-white shadow-lg flex items-center justify-center overflow-hidden ring-4 ring-white/40 mb-3">
              <Image
                src={logoUrl}
                alt="WayPoint"
                fittingType="fill"
                className="block w-full h-full"
              />
            </div>
          </div>
          <h1
            className={`text-3xl font-bold tracking-tight font-display ${
              bannerTheme ? "text-white drop-shadow-sm" : "text-foreground"
            }`}
          >
            {title}
          </h1>
          {subtitle && (
            <p className={`mt-2 ${bannerTheme ? "text-white/85" : "text-muted-foreground"}`}>{subtitle}</p>
          )}
        </div>
        <div
          className={`rounded-2xl shadow-xl border p-8 ${
            bannerTheme ? "bg-white/95 backdrop-blur border-white/40" : "bg-card border-border"
          }`}
        >
          {children}
        </div>
        {footer && (
          <p className={`text-center text-sm mt-6 ${bannerTheme ? "text-white/85" : "text-muted-foreground"}`}>
            {footer}
          </p>
        )}
      </div>
    </div>
  );
}