import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { VALUES_LIST } from "@/lib/valuesData";
import { getMyTherapistEmail } from "@/lib/myTherapist";
import { Heart, Save, Trophy } from "lucide-react";

const SCALE = [1, 2, 3, 4, 5];

export default function ValuesChecklist() {
  const [existing, setExisting] = useState(null);
  const [ratings, setRatings] = useState({});
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.ValuesChecklist.list("-created_date", 1);
        if (data[0]) {
          setExisting(data[0]);
          setRatings(data[0].ratings || {});
        }
      } catch {}
      setLoading(false);
    })();
  }, []);

  const topThree = useMemo(() => {
    return Object.entries(ratings)
      .filter(([, v]) => Number.isFinite(v) && v > 0)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([k]) => k);
  }, [ratings]);

  function rate(value, n) {
    setRatings((prev) => ({ ...prev, [value]: prev[value] === n ? 0 : n }));
  }

  async function save() {
    if (topThree.length === 0) return;
    setSaving(true);
    try {
      const me = await base44.auth.me();
      let therapistEmail = existing?.therapist_email || "";
      if (!therapistEmail) {
        try {
          const hw = await base44.entities.HomeworkAssignment.list("-created_date", 1);
          if (hw[0]?.therapist_email) therapistEmail = hw[0].therapist_email;
        } catch {}
      }
      if (!therapistEmail) therapistEmail = await getMyTherapistEmail();
      const payload = {
        ratings,
        top_values: topThree,
        values: topThree,
        client_email: existing?.client_email || me?.email || "",
        therapist_email: therapistEmail,
      };
      if (existing) {
        await base44.entities.ValuesChecklist.update(existing.id, payload);
      } else {
        await base44.entities.ValuesChecklist.create(payload);
      }
      const data = await base44.entities.ValuesChecklist.list("-created_date", 1);
      if (data[0]) setExisting(data[0]);
      setEditing(false);
    } catch {}
    setSaving(false);
  }

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <div className="w-6 h-6 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (existing && !editing) {
    const top = existing.top_values?.length ? existing.top_values : existing.values || [];
    return (
      <div className="pp-card p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Trophy size={18} className="text-primary" />
            <h3 className="font-heading text-lg font-semibold">My Top 3 Values</h3>
          </div>
          <button onClick={() => setEditing(true)} className="text-sm text-primary hover:underline">
            Re-take inventory
          </button>
        </div>
        <div className="space-y-2">
          {top.map((value, i) => (
            <div key={i} className="flex items-center gap-3 p-2.5 rounded-xl bg-primary/5">
              <span className="w-7 h-7 rounded-full bg-primary text-primary-foreground text-sm font-bold flex items-center justify-center shrink-0">
                {i + 1}
              </span>
              <span className="font-medium">{value}</span>
            </div>
          ))}
        </div>
        <p className="text-xs text-muted-foreground mt-3">
          Your top values guide the activities you build in Behavior Activation.
        </p>
      </div>
    );
  }

  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-2 mb-2">
        <Heart size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Values Inventory</h3>
      </div>
      <p className="text-sm text-muted-foreground mb-4">
        Rate how important each value is to you (1 = a little, 5 = essential). Your top three will be identified automatically.
      </p>

      {topThree.length > 0 && (
        <div className="mb-4 p-3 rounded-xl bg-primary/5 border border-primary/15">
          <p className="text-xs font-medium text-primary mb-1.5">Current top 3</p>
          <div className="flex flex-wrap gap-2">
            {topThree.map((v, i) => (
              <span key={v} className="px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
                #{i + 1} {v}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-1.5 mb-5 max-h-80 overflow-y-auto pp-scroll-hide pr-1">
        {VALUES_LIST.map((value) => {
          const rating = ratings[value] || 0;
          return (
            <div key={value} className="flex items-center justify-between gap-3 py-1.5 border-b border-border/40 last:border-0">
              <span className="text-sm font-medium">{value}</span>
              <div className="flex items-center gap-1">
                {SCALE.map((n) => (
                  <button
                    key={n}
                    onClick={() => rate(value, n)}
                    className={`w-7 h-7 rounded-lg text-xs font-bold transition ${
                      rating >= n
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary/50 text-muted-foreground hover:bg-secondary"
                    }`}
                  >
                    {n}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <button
        onClick={save}
        disabled={topThree.length === 0 || saving}
        className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2"
      >
        {saving ? "Saving…" : <><Save size={16} /> Save My Top 3 Values</>}
      </button>
    </div>
  );
}