import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  SENSORY_QUADRANTS,
  SENSORY_SCALE,
  getQuadrantLevel,
  getAllItems,
} from "@/lib/sensoryProfile";
import { ChevronRight } from "lucide-react";

// Self-contained sensory profile quiz reused by the onboarding flow.
// Mirrors the scoring/saving logic of the standalone SensoryProfile page.
export default function SensoryQuiz({ onComplete }) {
  const [answers, setAnswers] = useState({});
  const [saving, setSaving] = useState(false);

  const allItems = getAllItems();
  const answeredCount = Object.keys(answers).length;
  const allAnswered = answeredCount === allItems.length;

  function setAnswer(index, value) {
    setAnswers((a) => ({ ...a, [index]: value }));
  }

  function quadrantScore(key) {
    let score = 0;
    allItems.forEach((item, i) => {
      if (item.quadrant === key) score += answers[i] || 0;
    });
    return score;
  }

  async function submit() {
    if (!allAnswered || saving) return;
    setSaving(true);
    try {
      const totalScore = Object.values(answers).reduce((a, b) => a + b, 0);
      const highest = SENSORY_QUADRANTS.map((q) => ({
        name: q.name,
        score: quadrantScore(q.key),
      })).reduce((max, q) => (q.score > max.score ? q : max));
      const level = getQuadrantLevel(highest.score);
      await base44.entities.AssessmentResult.create({
        test_type: "SENSORY",
        score: totalScore,
        severity: `${highest.name} — ${level.label}`,
      });
      onComplete();
    } catch (e) {
      console.error("Sensory quiz save failed:", e.message);
    }
    setSaving(false);
  }

  return (
    <div>
      <div className="mb-6">
        <div className="flex justify-between text-xs text-muted-foreground mb-2">
          <span>{answeredCount} of {allItems.length} answered</span>
          <span>{Math.round((answeredCount / allItems.length) * 100)}%</span>
        </div>
        <div className="h-2 rounded-full bg-secondary overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all duration-300"
            style={{ width: `${(answeredCount / allItems.length) * 100}%` }}
          />
        </div>
      </div>

      {SENSORY_QUADRANTS.map((q) => {
        const quadrantItems = allItems
          .map((item, i) => ({ ...item, index: i }))
          .filter((item) => item.quadrant === q.key);
        return (
          <div key={q.key} className="mb-8">
            <h2 className="font-heading text-lg font-semibold mb-3" style={{ color: q.color }}>
              {q.name}
            </h2>
            <div className="space-y-4">
              {quadrantItems.map((item) => (
                <div key={item.index} className="pp-card p-4">
                  <p className="text-sm mb-3">{item.text}</p>
                  <div className="flex flex-wrap gap-2">
                    {SENSORY_SCALE.map((opt) => {
                      const selected = answers[item.index] === opt.value;
                      return (
                        <button
                          key={opt.value}
                          onClick={() => setAnswer(item.index, opt.value)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition border ${
                            selected
                              ? "bg-primary text-primary-foreground border-primary"
                              : "bg-card border-border text-muted-foreground hover:border-primary/40"
                          }`}
                        >
                          {opt.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      <button
        onClick={submit}
        disabled={!allAnswered || saving}
        className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2"
      >
        {saving ? "Saving…" : <>Save & Continue <ChevronRight size={18} /></>}
      </button>
      {!allAnswered && (
        <p className="text-xs text-muted-foreground text-center mt-2">
          Answer all {allItems.length} statements to continue.
        </p>
      )}
    </div>
  );
}