import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Compass, ArrowRight, Sparkles } from "lucide-react";

/**
 * Surfaces the client's top three values on their Home dashboard as a
 * guide for behavior activation. Prompts them to take the inventory when
 * they haven't completed it yet.
 */
export default function TopValuesPanel() {
  const [values, setValues] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        const data = await base44.entities.ValuesChecklist.filter({ client_email: me?.email || "" }, "-created_date", 1);
        setValues(data?.[0] || null);
      } catch {}
      setLoading(false);
    })();
  }, []);

  const top = values?.top_values?.length ? values.top_values : values?.values || [];

  if (loading) {
    return (
      <div className="pp-card p-5 mb-6">
        <div className="h-20 rounded-xl bg-secondary/40 animate-pulse" />
      </div>
    );
  }

  // Not yet completed — prompt to take the inventory.
  if (top.length === 0) {
    return (
      <Link
        to="/values-inventory"
        className="pp-card p-5 mb-6 flex items-center gap-4 hover:shadow-md hover:-translate-y-0.5 transition-all group bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20"
      >
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Compass size={22} className="text-primary" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="font-heading text-lg font-semibold">Discover your top values</h3>
          <p className="text-sm text-muted-foreground">Take the Values Inventory to find what matters most — it will guide your behavior activation activities.</p>
        </div>
        <ArrowRight size={18} className="text-muted-foreground group-hover:text-primary transition shrink-0" />
      </Link>
    );
  }

  return (
    <div className="pp-card p-5 mb-6 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
      <div className="flex items-center gap-2 mb-3">
        <Compass size={18} className="text-primary" />
        <h3 className="font-heading text-lg font-semibold">Your Top Values</h3>
        <Link to="/values-inventory" className="ml-auto text-xs text-primary hover:underline">
          Re-rank
        </Link>
      </div>
      <div className="flex flex-col sm:flex-row sm:items-center gap-4">
        <div className="flex flex-wrap gap-2 flex-1">
          {top.slice(0, 3).map((v, i) => (
            <span key={v} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium">
              <span className="text-xs text-primary/60">#{i + 1}</span>
              {v}
            </span>
          ))}
        </div>
        <Link
          to="/behavior-activation"
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition shrink-0"
        >
          <Sparkles size={15} /> Build activities
        </Link>
      </div>
      <p className="text-xs text-muted-foreground mt-3">Let these values guide the activities you choose — they make behavior activation more meaningful.</p>
    </div>
  );
}