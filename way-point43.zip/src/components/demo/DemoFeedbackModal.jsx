import React from "react";
import { MessageSquareHeart, X } from "lucide-react";

export default function DemoFeedbackModal({ feedback, onClose }) {
  if (!feedback) return null;
  const date = feedback.submitted_at || feedback.created_date;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-card rounded-2xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-gradient-to-br from-primary/10 to-accent/10 px-6 pt-5 pb-4 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-lg text-muted-foreground hover:bg-secondary transition"
          >
            <X size={18} />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center shrink-0">
              <MessageSquareHeart className="text-primary" size={20} />
            </div>
            <div>
              <h2 className="font-heading text-lg font-semibold">Demo feedback</h2>
              <p className="text-xs text-muted-foreground">
                {feedback.participant_name || feedback.participant_email}
              </p>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto">
          <div className="flex flex-wrap gap-3">
            <Stat label="Overall" value={feedback.overall_rating ? `${feedback.overall_rating}/5` : "—"} />
            <Stat label="Ease" value={feedback.ease_rating ? `${feedback.ease_rating}/5` : "—"} />
            <Stat label="NPS" value={feedback.nps != null ? feedback.nps : "—"} />
          </div>

          {feedback.most_valuable_feature && (
            <Field label="Most valuable feature" value={feedback.most_valuable_feature} />
          )}
          {feedback.would_use && <Field label="Would use WayPoint?" value={feedback.would_use} />}
          {feedback.worked_well && <Field label="What worked well" value={feedback.worked_well} />}
          {feedback.improvements && <Field label="What to improve" value={feedback.improvements} />}
          {feedback.additional && <Field label="Anything else" value={feedback.additional} />}

          {date && (
            <p className="text-xs text-muted-foreground pt-2 border-t border-border">
              Submitted {new Date(date).toLocaleString("en-US")}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="pp-card p-3 flex-1 min-w-[80px]">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="font-heading text-lg font-semibold">{value}</p>
    </div>
  );
}

function Field({ label, value }) {
  return (
    <div>
      <p className="text-xs font-medium text-muted-foreground mb-1">{label}</p>
      <p className="text-sm text-foreground whitespace-pre-wrap">{value}</p>
    </div>
  );
}