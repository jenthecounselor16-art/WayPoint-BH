import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Check } from "lucide-react";

// Row-synchronized tier grid: every row (header, price, features, CTA) is one
// shared grid row across all four columns, so baselines can never drift apart.
export default function TierComparisonGrid({ plans, bestValueKey }) {
  const maxFeatures = Math.max(...plans.map((p) => p.features.length));

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="overflow-x-auto pp-scroll-hide"
    >
      <div className="min-w-[1020px]">
        {/* Header + description row */}
        <div className="grid grid-cols-4 gap-4 mb-5">
          {plans.map((plan) => {
            const Icon = plan.icon;
            return (
              <div key={plan.key} className="relative">
                {plan.key === bestValueKey && (
                  <span className="absolute -top-4 left-0 px-2.5 py-1 rounded-full bg-primary text-primary-foreground text-[11px] font-semibold whitespace-nowrap">
                    Best value
                  </span>
                )}
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <Icon className="text-primary" size={18} />
                  </div>
                  <h3 className="font-heading font-semibold text-lg">{plan.name}</h3>
                </div>
                <p className="text-xs text-muted-foreground mt-2.5 leading-relaxed min-h-[36px]">
                  {plan.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Price row */}
        <div className="grid grid-cols-4 gap-4 pb-5 border-b border-border/60">
          {plans.map((plan) => (
            <div key={plan.key}>
              <div className="flex items-baseline gap-1.5">
                <span className="font-heading font-semibold tracking-tight text-3xl">
                  ${plan.monthly.amount}
                </span>
                <span className="text-sm text-muted-foreground">/month</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{plan.clinicians}</p>
            </div>
          ))}
        </div>

        {/* Feature rows — aligned across all plans */}
        {Array.from({ length: maxFeatures }).map((_, i) => (
          <div key={i} className="grid grid-cols-4 gap-4 py-2.5 border-b border-border/40">
            {plans.map((plan) => {
              const f = plan.features[i];
              return (
                <div key={plan.key} className="text-[13px] leading-snug min-h-[18px]">
                  {!f ? null : f.startsWith("Everything in") ? (
                    <span className="text-muted-foreground">{f}</span>
                  ) : (
                    <span className="flex items-start gap-2">
                      <Check size={14} className="text-primary shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        ))}

        {/* CTA row */}
        <div className="grid grid-cols-4 gap-4 pt-6">
          {plans.map((plan) => (
            <Link
              key={plan.key}
              to="/billing"
              className={`w-full py-2.5 rounded-xl text-sm font-medium text-center transition ${
                plan.key === bestValueKey
                  ? "bg-primary text-primary-foreground hover:opacity-90"
                  : "bg-primary/10 text-primary hover:bg-primary/20"
              }`}
            >
              Subscribe — ${plan.monthly.amount}/mo
            </Link>
          ))}
        </div>
      </div>
    </motion.div>
  );
}