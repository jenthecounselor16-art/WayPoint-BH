import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { emotionTree, getEmotionColor } from "@/lib/emotionData";
import { copingTools, getToolsForEmotion } from "@/lib/copingTools";
import { ChevronRight, ChevronLeft, Check, ArrowRight } from "lucide-react";
import { checkAndAwardBadges } from "@/lib/badges";
import BadgeCelebration from "@/components/BadgeCelebration";
import MoodThoughtInvitation from "@/components/MoodThoughtInvitation";

export default function EmotionWheel() {
  const [path, setPath] = useState([]);
  const [selectedEmotion, setSelectedEmotion] = useState(null);
  const [intensity, setIntensity] = useState(3);
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [earnedBadges, setEarnedBadges] = useState([]);

  const currentEmotion = path.length > 0 ? path.reduce((node, key, i) => (i === 0 ? node[key] : node?.children?.[key]), emotionTree) : null;
  const breadcrumb = path.map((key, i) => {
    let node = emotionTree[path[0]];
    for (let j = 1; j <= i; j++) node = node?.children?.[path[j]];
    return node?.label || key;
  });

  const primaryKeys = Object.keys(emotionTree);

  function selectEmotion(key) {
    const newPath = [...path, key];
    setPath(newPath);
    let node = emotionTree[newPath[0]];
    for (let i = 1; i < newPath.length; i++) node = node?.children?.[newPath[i]];
    if (node && (!node.children || Object.keys(node.children).length === 0)) {
      setSelectedEmotion({ label: node.label, path: newPath.join("/"), color: node.color || getEmotionColor(newPath.join("/")) });
    }
  }

  function goBack() {
    setPath(path.slice(0, -1));
    setSelectedEmotion(null);
    setSaved(false);
  }

  async function saveMood() {
    setSaving(true);
    try {
      await base44.entities.MoodEntry.create({
        emotion: selectedEmotion.label,
        emotion_path: selectedEmotion.path,
        intensity,
        note: note || undefined,
      });
      setSaved(true);
      const newBadges = await checkAndAwardBadges();
      if (newBadges.length > 0) setEarnedBadges(newBadges);
    } catch (e) {
      // show error
    }
    setSaving(false);
  }

  if (saved) {
    return (
      <div className="p-6 md:p-10 max-w-2xl mx-auto min-h-screen flex flex-col items-center justify-center text-center">
        <motion.div
          initial={{ scale: 0, rotate: -20 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 200 }}
          className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-6"
        >
          <Check className="text-primary" size={36} />
        </motion.div>
        <h2 className="font-heading text-3xl font-semibold mb-3">Logged</h2>
        <p className="text-muted-foreground text-lg mb-4 max-w-md">
          You're feeling <span className="font-semibold text-foreground">{selectedEmotion.label.toLowerCase()}</span>. That takes courage to name.
        </p>
        <MoodThoughtInvitation
          emotion={selectedEmotion.label}
          emotionPath={selectedEmotion.path}
          intensity={intensity}
          note={note}
        />
        <div className="flex gap-3 flex-wrap justify-center mt-6">
          <Link to="/toolbox" className="px-5 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition flex items-center gap-2">
            Find a coping tool <ArrowRight size={16} />
          </Link>
          <Link to="/" className="px-5 py-2.5 rounded-xl bg-secondary text-secondary-foreground font-medium hover:opacity-80 transition">
            Back to home
          </Link>
        </div>
        <BadgeCelebration badges={earnedBadges} onClose={() => setEarnedBadges([])} />
      </div>
    );
  }

  if (selectedEmotion) {
    const suggestedTools = getToolsForEmotion(selectedEmotion.path.split("/").pop());
    return (
      <div className="p-6 md:p-10 max-w-2xl mx-auto">
        <button onClick={() => setSelectedEmotion(null)} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6 transition">
          <ChevronLeft size={16} /> Back to wheel
        </button>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center" style={{ backgroundColor: selectedEmotion.color + "20" }}>
            <span className="text-3xl">{path[0] && emotionTree[path[0]]?.emoji}</span>
          </div>
          <p className="text-sm text-muted-foreground mb-1">You're feeling</p>
          <h1 className="font-heading text-3xl font-semibold" style={{ color: selectedEmotion.color }}>{selectedEmotion.label}</h1>
        </motion.div>

        {/* Intensity */}
        <div className="pp-card p-5 mb-4">
          <label className="text-sm font-medium mb-3 block">How intense is this feeling?</label>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map((n) => (
              <button
                key={n}
                onClick={() => setIntensity(n)}
                className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all
                  ${intensity === n ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:opacity-80"}`}
              >
                {n}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-2">1 = mild · 5 = overwhelming</p>
        </div>

        {/* Note */}
        <div className="pp-card p-5 mb-4">
          <label className="text-sm font-medium mb-2 block">Want to write anything about it? <span className="text-muted-foreground">(optional)</span></label>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="What's going on for you right now?"
            className="pp-input min-h-[80px] resize-none"
          />
        </div>

        <button
          onClick={saveMood}
          disabled={saving}
          className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50 mb-8"
        >
          {saving ? "Saving…" : "Log this feeling"}
        </button>

        {/* Suggested tools */}
        {suggestedTools.length > 0 && (
          <div>
            <h3 className="font-heading text-lg font-semibold mb-3">Tools that might help</h3>
            <div className="space-y-2">
              {suggestedTools.slice(0, 3).map((tool) => (
                <Link key={tool.key} to="/toolbox" className="block pp-card p-4 hover:shadow-md transition group">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">{tool.name}</p>
                      <p className="text-xs text-muted-foreground">{tool.duration} · {tool.category}</p>
                    </div>
                    <ChevronRight className="text-muted-foreground group-hover:text-primary transition" size={18} />
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto">
      <div className="mb-8">
        <h1 className="font-heading text-3xl md:text-4xl font-semibold mb-2">Emotion Wheel</h1>
        <p className="text-muted-foreground text-lg">
          Start with a broad feeling, then narrow down to find the word that fits.
        </p>
      </div>

      {/* Breadcrumb */}
      {path.length > 0 && (
        <div className="flex items-center gap-1.5 mb-6 flex-wrap">
          <button onClick={goBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition">
            <ChevronLeft size={16} /> Back
          </button>
          <span className="text-muted-foreground">·</span>
          {breadcrumb.map((label, i) => (
            <span key={i} className="flex items-center gap-1.5">
              <span className={`text-sm ${i === breadcrumb.length - 1 ? "font-semibold text-foreground" : "text-muted-foreground"}`}>{label}</span>
              {i < breadcrumb.length - 1 && <ChevronRight size={14} className="text-muted-foreground/50" />}
            </span>
          ))}
        </div>
      )}

      {/* Emotion grid */}
      <motion.div
        key={path.join("/")}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.25 }}
        className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3"
      >
        {(path.length === 0 ? primaryKeys.map((k) => ({ key: k, ...emotionTree[k] })) : Object.entries(currentEmotion.children || {}).map(([k, v]) => ({ key: k, ...v }))).map((emotion) => {
          const color = emotion.color || getEmotionColor([...path, emotion.key].join("/"));
          return (
            <button
              key={emotion.key}
              onClick={() => selectEmotion(emotion.key)}
              className="relative pp-card p-5 hover:shadow-md hover:-translate-y-0.5 transition-all text-left group overflow-hidden"
            >
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity" style={{ background: `linear-gradient(135deg, ${color}15, transparent)` }} />
              <div className="relative">
                {emotion.emoji && <div className="text-2xl mb-2">{emotion.emoji}</div>}
                <p className="font-heading text-lg font-semibold" style={{ color }}>{emotion.label}</p>
                {emotion.children && <p className="text-xs text-muted-foreground mt-1">{Object.keys(emotion.children).length} more specific</p>}
              </div>
            </button>
          );
        })}
      </motion.div>

      {path.length === 0 && (
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-center text-sm text-muted-foreground mt-8"
        >
          Naming what you feel is the first step to knowing what to do next.
        </motion.p>
      )}
    </div>
  );
}