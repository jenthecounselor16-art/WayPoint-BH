import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { MessageSquareHeart, Star, Send, CheckCircle2, Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const FEATURES = [
  "Therapist Portal",
  "Clinical Insights",
  "Assessments",
  "Homework",
  "Coping Tools",
  "AI Coping Coach",
  "Behavior Activation",
  "Values Inventory",
  "Other",
];

function StarRating({ value, onChange, label }) {
  const [hover, setHover] = useState(0);
  return (
    <div>
      <label className="text-sm font-medium mb-2 block">{label}</label>
      <div className="flex items-center gap-1.5">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            type="button"
            onClick={() => onChange(n)}
            onMouseEnter={() => setHover(n)}
            onMouseLeave={() => setHover(0)}
            className="p-0.5 transition-transform hover:scale-110"
            aria-label={`${n} star${n > 1 ? "s" : ""}`}
          >
            <Star
              size={30}
              className={`transition-colors ${
                (hover || value) >= n ? "fill-amber-400 text-amber-400" : "text-muted-foreground/30"
              }`}
            />
          </button>
        ))}
        {value > 0 && (
          <span className="ml-2 text-sm font-medium text-muted-foreground">{value}/5</span>
        )}
      </div>
    </div>
  );
}

function NpsScale({ value, onChange }) {
  return (
    <div>
      <label className="text-sm font-medium mb-2 block">
        How likely are you to recommend WayPoint to a colleague?
      </label>
      <div className="flex items-end gap-1 flex-wrap">
        {Array.from({ length: 11 }, (_, n) => n).map((n) => {
          const active = value === n;
          const tone =
            n <= 6 ? "bg-rose-100 text-rose-700 border-rose-200"
            : n <= 8 ? "bg-amber-100 text-amber-700 border-amber-200"
            : "bg-emerald-100 text-emerald-700 border-emerald-200";
          return (
            <button
              key={n}
              type="button"
              onClick={() => onChange(n)}
              className={`w-9 h-10 rounded-lg border text-sm font-semibold transition ${
                active ? `${tone} ring-2 ring-primary/40` : "bg-card border-border text-muted-foreground hover:bg-secondary"
              }`}
            >
              {n}
            </button>
          );
        })}
      </div>
      <div className="flex justify-between text-xs text-muted-foreground mt-1.5">
        <span>Not at all likely</span>
        <span>Extremely likely</span>
      </div>
    </div>
  );
}

export default function DemoSurvey() {
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [loadingUser, setLoadingUser] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [existing, setExisting] = useState(null);
  const [form, setForm] = useState({
    overall_rating: 0,
    ease_rating: 0,
    nps: -1,
    most_valuable_feature: "",
    would_use: "",
    worked_well: "",
    improvements: "",
    additional: "",
  });

  useEffect(() => {
    (async () => {
      let me = null;
      try { me = await base44.auth.me(); setUser(me); } catch {}
      setLoadingUser(false);
      if (me?.email) {
        try {
          const prior = await base44.entities.DemoFeedback.filter({ participant_email: me.email }, "-created_date", 1);
          if (prior?.length) setExisting(prior[0]);
        } catch {}
      }
    })();
  }, []);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (submitting) return;
    if (form.overall_rating < 1) { toast({ title: "Please rate your overall experience", variant: "destructive" }); return; }
    if (form.nps < 0) { toast({ title: "Please pick a likelihood-to-recommend score", variant: "destructive" }); return; }
    setSubmitting(true);
    try {
      await base44.entities.DemoFeedback.create({
        participant_email: user?.email || "",
        participant_name: user?.full_name || user?.display_name || "",
        overall_rating: form.overall_rating,
        ease_rating: form.ease_rating || null,
        nps: form.nps,
        most_valuable_feature: form.most_valuable_feature || null,
        would_use: form.would_use || null,
        worked_well: form.worked_well.trim() || null,
        improvements: form.improvements.trim() || null,
        additional: form.additional.trim() || null,
        submitted_at: new Date().toISOString(),
      });
      setSubmitted(true);
    } catch (err) {
      toast({ title: "Couldn't submit feedback", description: err.message || "Please try again.", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  }

  if (loadingUser) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-7 h-7 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 max-w-2xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <MessageSquareHeart className="text-primary" size={24} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Demo Feedback</h1>
          <p className="text-muted-foreground">Your honest take helps us make WayPoint better for clinicians.</p>
        </div>
      </div>

      {existing && !submitted && (
        <div className="mb-5 p-4 rounded-xl bg-accent/10 border border-accent/20 flex items-start gap-3">
          <CheckCircle2 size={20} className="text-accent shrink-0 mt-0.5" />
          <p className="text-sm text-foreground">
            We already received feedback from <span className="font-medium">{existing.participant_email}</span> on{" "}
            {new Date(existing.submitted_at || existing.created_date).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}.
            You're welcome to share fresh thoughts below.
          </p>
        </div>
      )}

      {submitted ? (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-8 text-center">
          <CheckCircle2 className="mx-auto mb-4 text-accent" size={48} />
          <h2 className="font-heading text-2xl font-semibold mb-2">Thank you — truly.</h2>
          <p className="text-muted-foreground mb-6">
            Your feedback is in the right hands. We read every response, and yours will help shape what WayPoint becomes for clinicians like you.
          </p>
          <Link to="/" className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition">
            Back to home
          </Link>
        </motion.div>
      ) : (
        <motion.form
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleSubmit}
          className="pp-card p-6 md:p-8 space-y-7"
        >
          <StarRating label="Overall, how was your WayPoint demo experience? *" value={form.overall_rating} onChange={(n) => update("overall_rating", n)} />
          <StarRating label="How easy was it to get started and navigate?" value={form.ease_rating} onChange={(n) => update("ease_rating", n)} />

          <NpsScale value={form.nps} onChange={(n) => update("nps", n)} />

          <div>
            <label className="text-sm font-medium mb-2 block">Which feature did you find most valuable?</label>
            <div className="flex flex-wrap gap-2">
              {FEATURES.map((f) => (
                <button
                  key={f}
                  type="button"
                  onClick={() => update("most_valuable_feature", f)}
                  className={`px-3.5 py-2 rounded-xl text-sm font-medium border transition ${
                    form.most_valuable_feature === f
                      ? "bg-primary/10 border-primary text-primary"
                      : "bg-card border-border text-foreground hover:bg-secondary"
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Would you consider using WayPoint in your practice?</label>
            <div className="grid grid-cols-3 gap-2">
              {["Yes", "Maybe", "No"].map((opt) => (
                <button
                  key={opt}
                  type="button"
                  onClick={() => update("would_use", opt)}
                  className={`h-11 rounded-xl text-sm font-medium border transition ${
                    form.would_use === opt
                      ? "bg-primary/10 border-primary text-primary"
                      : "bg-card border-border text-foreground hover:bg-secondary"
                  }`}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">What worked well? <span className="text-muted-foreground font-normal">(optional)</span></label>
            <textarea
              value={form.worked_well}
              onChange={(e) => update("worked_well", e.target.value)}
              rows={3}
              maxLength={2000}
              className="pp-input resize-none"
              placeholder="Features, moments, or surprises you appreciated…"
            />
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">What could we improve? <span className="text-muted-foreground font-normal">(optional)</span></label>
            <textarea
              value={form.improvements}
              onChange={(e) => update("improvements", e.target.value)}
              rows={3}
              maxLength={2000}
              className="pp-input resize-none"
              placeholder="Anything that felt clunky, missing, or confusing…"
            />
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Anything else you'd like to share? <span className="text-muted-foreground font-normal">(optional)</span></label>
            <textarea
              value={form.additional}
              onChange={(e) => update("additional", e.target.value)}
              rows={3}
              maxLength={2000}
              className="pp-input resize-none"
              placeholder="The honest, unfiltered version — we're listening."
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3.5 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {submitting ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
            {submitting ? "Submitting…" : "Submit your feedback"}
          </button>
          <p className="text-xs text-muted-foreground text-center">
            Your responses are confidential and only reviewed by the WayPoint team.
          </p>
        </motion.form>
      )}
    </div>
  );
}