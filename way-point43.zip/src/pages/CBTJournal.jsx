import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Lightbulb, Plus, Trash2, ChevronDown, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import ThoughtRecordForm from "@/components/cbt/ThoughtRecordForm";
import { getMyTherapistEmail } from "@/lib/myTherapist";
import { checkAndAwardBadges } from "@/lib/badges";
import BadgeCelebration from "@/components/BadgeCelebration";

export default function CBTJournal() {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [expandedId, setExpandedId] = useState(null);
  const [earnedBadges, setEarnedBadges] = useState([]);

  useEffect(() => {
    fetchRecords();
  }, []);

  async function fetchRecords() {
    try {
      const data = await base44.entities.ThoughtRecord.list("-created_date", 50);
      setRecords(data || []);
    } catch {}
    setLoading(false);
  }

  async function handleSave(formData) {
    try {
      // Stamp ownership so the entry bridges to the therapist's clinical view.
      const me = await base44.auth.me();
      let therapistEmail = "";
      try { therapistEmail = await getMyTherapistEmail(); } catch {}
      await base44.entities.ThoughtRecord.create({
        ...formData,
        client_email: me?.email || "",
        therapist_email: therapistEmail,
      });
      setShowForm(false);
      await fetchRecords();
      const newBadges = await checkAndAwardBadges();
      if (newBadges.length > 0) setEarnedBadges(newBadges);
    } catch {}
  }

  async function handleDelete(id) {
    try {
      await base44.entities.ThoughtRecord.delete(id);
      setRecords(records.filter((r) => r.id !== id));
    } catch {}
  }

  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto">
      <div className="flex items-start gap-3 mb-8">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Lightbulb className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Thought Record</h1>
          <p className="text-muted-foreground text-lg">Challenge maladaptive thoughts step by step.</p>
        </div>
      </div>

      <button
        onClick={() => setShowForm(!showForm)}
        className="w-full mb-3 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition flex items-center justify-center gap-2"
      >
        <Plus size={18} /> {showForm ? "Cancel" : "New Thought Record"}
      </button>
      <Link
        to="/thought-coach"
        className="w-full mb-6 py-3 rounded-xl bg-accent/10 text-accent font-medium hover:bg-accent/20 transition flex items-center justify-center gap-2"
      >
        <Sparkles size={18} /> Talk to the Thought Coach
      </Link>

      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden mb-8"
          >
            <ThoughtRecordForm onSave={handleSave} onCancel={() => setShowForm(false)} />
          </motion.div>
        )}
      </AnimatePresence>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : records.length === 0 ? (
        <div className="pp-card p-10 text-center">
          <Lightbulb className="mx-auto mb-4 text-muted-foreground/40" size={48} />
          <h3 className="font-heading text-xl font-semibold mb-2">No thought records yet</h3>
          <p className="text-muted-foreground">Start above to challenge your first maladaptive thought.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {records.map((r) => (
            <ThoughtRecordCard
              key={r.id}
              record={r}
              expanded={expandedId === r.id}
              onToggle={() => setExpandedId(expandedId === r.id ? null : r.id)}
              onDelete={() => handleDelete(r.id)}
            />
          ))}
        </div>
      )}
      <BadgeCelebration badges={earnedBadges} onClose={() => setEarnedBadges([])} />
    </div>
  );
}

function ThoughtRecordCard({ record, expanded, onToggle, onDelete }) {
  const intensityChange =
    record.emotion_intensity !== undefined && record.new_emotion_intensity !== undefined
      ? `${record.emotion_intensity} → ${record.new_emotion_intensity}`
      : null;

  return (
    <div className="pp-card overflow-hidden">
      <button onClick={onToggle} className="w-full text-left p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium line-clamp-2">{record.automatic_thought}</p>
            <p className="text-xs text-muted-foreground mt-1">
              {new Date(record.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
              {record.emotion && ` · ${record.emotion}`}
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {intensityChange && (
              <span className="text-xs text-primary font-medium whitespace-nowrap">{intensityChange}</span>
            )}
            <ChevronDown
              className={`text-muted-foreground transition-transform ${expanded ? "rotate-180" : ""}`}
              size={18}
            />
          </div>
        </div>
      </button>
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 pt-2 border-t border-border/60 space-y-3">
              {record.situation && <Field label="Situation" value={record.situation} />}
              {record.automatic_thought && <Field label="Automatic Thought" value={record.automatic_thought} />}
              {record.evidence_for && <Field label="Evidence For" value={record.evidence_for} />}
              {record.evidence_against && <Field label="Evidence Against" value={record.evidence_against} />}
              {record.balanced_thought && <Field label="Balanced Thought" value={record.balanced_thought} highlight />}
              <button
                onClick={onDelete}
                className="flex items-center gap-1.5 text-xs text-destructive/60 hover:text-destructive transition mt-2"
              >
                <Trash2 size={12} /> Delete
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Field({ label, value, highlight }) {
  return (
    <div>
      <p className="text-xs font-medium text-muted-foreground mb-0.5">{label}</p>
      <p className={`text-sm whitespace-pre-wrap ${highlight ? "text-primary font-medium" : ""}`}>{value}</p>
    </div>
  );
}