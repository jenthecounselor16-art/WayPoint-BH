import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { BADGES, BADGE_CATEGORIES, TIER_COLORS, TIER_GLOW, checkAndAwardBadges } from "@/lib/badges";
import { Lock, Trophy } from "lucide-react";

export default function Badges() {
  const [earnedKeys, setEarnedKeys] = useState(new Set());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        await checkAndAwardBadges();
        const data = await base44.entities.UserBadge.list("-created_date", 100);
        setEarnedKeys(new Set((data || []).map((b) => b.badge_key)));
      } catch {}
      setLoading(false);
    })();
  }, []);

  const earnedCount = earnedKeys.size;
  const totalCount = BADGES.length;
  const progressPct = Math.round((earnedCount / totalCount) * 100);

  return (
    <div className="p-6 md:p-10 max-w-4xl mx-auto">
      <div className="flex items-start gap-3 mb-8">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Trophy className="text-primary" size={22} />
        </div>
        <div className="flex-1">
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Badges</h1>
          <p className="text-muted-foreground text-lg">Your milestones in healing, one step at a time.</p>
        </div>
      </div>

      {/* Progress overview */}
      <div className="pp-card p-5 mb-8">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Progress</span>
          <span className="text-sm text-muted-foreground">{earnedCount} / {totalCount} earned</span>
        </div>
        <div className="h-3 rounded-full bg-secondary overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progressPct}%` }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="h-full rounded-full bg-gradient-to-r from-primary to-accent"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : (
        <div className="space-y-10">
          {BADGE_CATEGORIES.map((category) => {
            const categoryBadges = BADGES.filter((b) => b.category === category);
            return (
              <div key={category}>
                <h2 className="font-heading text-xl font-semibold mb-4">{category}</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {categoryBadges.map((badge, i) => {
                    const earned = earnedKeys.has(badge.key);
                    const Icon = badge.icon;
                    const color = TIER_COLORS[badge.tier];
                    const glow = TIER_GLOW[badge.tier];
                    return (
                      <motion.div
                        key={badge.key}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.05 }}
                        className={`pp-card p-4 text-center transition-all ${earned ? "" : "opacity-50"}`}
                      >
                        <div className="flex justify-center mb-3">
                          {earned ? (
                            <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ background: `radial-gradient(circle, ${glow}, transparent)` }}>
                              <div className="w-14 h-14 rounded-full flex items-center justify-center border-2" style={{ borderColor: color, backgroundColor: `${color}15` }}>
                                <Icon size={28} style={{ color }} />
                              </div>
                            </div>
                          ) : (
                            <div className="w-16 h-16 rounded-full flex items-center justify-center border-2 border-border bg-secondary/30">
                              <Lock className="text-muted-foreground/40" size={24} />
                            </div>
                          )}
                        </div>
                        <h3 className="font-medium text-sm mb-1">{badge.title}</h3>
                        <p className="text-xs text-muted-foreground leading-snug">{badge.description}</p>
                        <span className="inline-block mt-2 text-[10px] font-semibold uppercase tracking-wider" style={{ color: earned ? color : undefined }}>
                          {badge.tier}
                        </span>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}