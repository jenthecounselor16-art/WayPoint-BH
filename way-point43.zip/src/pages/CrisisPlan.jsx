import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Plus, Trash2, Phone, Mail, ShieldAlert, Heart, Check, AlertTriangle, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import BadgeCelebration from "@/components/BadgeCelebration";
import { checkAndAwardBadges } from "@/lib/badges";
import { getMyTherapistEmail } from "@/lib/myTherapist";

const SECTIONS = [
  { key: "warning_signs", label: "Warning Signs", placeholder: "e.g. I stop replying to texts, I can't get out of bed", icon: AlertTriangle },
  { key: "coping_skills", label: "Coping Skills", placeholder: "e.g. Box breathing, call my sister, go for a walk", icon: Check },
  { key: "emergency_contacts", label: "Emergency Contacts", placeholder: "e.g. Sarah (sister) — 555-0100", icon: Phone },
  { key: "reasons_to_live", label: "Reasons to Live", placeholder: "e.g. My dog needs me, I want to see my niece grow up", icon: Heart },
];

export default function CrisisPlan() {
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [user, setUser] = useState(null);
  const [newBadges, setNewBadges] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
      } catch {}
      try {
        const existing = await base44.entities.CrisisPlan.list("-created_date", 1);
        if (existing[0]) {
          setPlan(existing[0]);
        } else {
          setPlan({
            warning_signs: [],
            coping_skills: [],
            emergency_contacts: [],
            reasons_to_live: [],
            therapist_name: "",
            therapist_phone: "",
            therapist_email: "",
          });
        }
      } catch {
        setPlan({
          warning_signs: [],
          coping_skills: [],
          emergency_contacts: [],
          reasons_to_live: [],
          therapist_name: "",
          therapist_phone: "",
          therapist_email: "",
        });
      }
      setLoading(false);
    })();
  }, []);

  function addItem(section, value) {
    if (!value.trim()) return;
    setPlan({ ...plan, [section]: [...plan[section], value] });
  }

  function removeItem(section, index) {
    setPlan({ ...plan, [section]: plan[section].filter((_, i) => i !== index) });
  }

  async function save() {
    setSaving(true);
    setSaved(false);
    try {
      let therapistEmail = plan.therapist_email || "";
      if (!therapistEmail) {
        try { therapistEmail = await getMyTherapistEmail(); } catch {}
      }
      const payload = { ...plan, client_email: user?.email, therapist_email: therapistEmail };
      if (plan.id) {
        await base44.entities.CrisisPlan.update(plan.id, payload);
      } else {
        const created = await base44.entities.CrisisPlan.create(payload);
        setPlan(created);
      }
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
      try {
        const earned = await checkAndAwardBadges();
        if (earned && earned.length) setNewBadges(earned);
      } catch {}
    } catch {
      // ignore
    }
    setSaving(false);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto">
      <div className="flex items-start gap-3 mb-2">
        <div className="w-11 h-11 rounded-xl bg-red-500/10 flex items-center justify-center shrink-0">
          <ShieldAlert className="text-red-500" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Crisis Plan</h1>
          <p className="text-muted-foreground text-lg">Your safety plan — built when you're calm, used when you need it.</p>
        </div>
      </div>

      {/* Coach link */}
      <Link
        to="/crisis-coach"
        className="mt-6 mb-6 w-full py-3 rounded-xl bg-accent/10 text-accent font-medium hover:bg-accent/20 transition flex items-center justify-center gap-2"
      >
        <Sparkles size={18} /> Work with the Crisis Plan Coach
      </Link>

      {/* Crisis banner */}
      <div className="mb-8 p-4 rounded-xl bg-red-500/5 border border-red-500/20 flex items-start gap-3">
        <Phone className="text-red-500 shrink-0 mt-0.5" size={18} />
        <div>
          <p className="text-sm font-medium text-foreground">If you're in crisis right now</p>
          <p className="text-sm text-muted-foreground mt-0.5">
            Call or text <span className="font-bold text-foreground">988</span> (Suicide &amp; Crisis Lifeline) or call <span className="font-bold text-foreground">911</span>. You don't have to figure this out alone.
          </p>
        </div>
      </div>

      {/* Sections */}
      <div className="space-y-6">
        {SECTIONS.map((section, sIdx) => {
          const Icon = section.icon;
          return (
            <motion.div
              key={section.key}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: sIdx * 0.05 }}
              className="pp-card p-5"
            >
              <div className="flex items-center gap-2 mb-4">
                <Icon size={18} className="text-primary" />
                <h3 className="font-heading text-lg font-semibold">{section.label}</h3>
              </div>

              {plan[section.key].length > 0 && (
                <div className="space-y-2 mb-3">
                  {plan[section.key].map((item, i) => (
                    <div key={i} className="flex items-center justify-between gap-2 px-3 py-2.5 rounded-lg bg-secondary/50 group">
                      <span className="text-sm">{item}</span>
                      <button onClick={() => removeItem(section.key, i)} className="text-muted-foreground/40 hover:text-destructive transition opacity-0 group-hover:opacity-100">
                        <Trash2 size={15} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <AddItemInput placeholder={section.placeholder} onAdd={(val) => addItem(section.key, val)} />
            </motion.div>
          );
        })}

        {/* Therapist info */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="pp-card p-5">
          <div className="flex items-center gap-2 mb-4">
            <Phone size={18} className="text-primary" />
            <h3 className="font-heading text-lg font-semibold">Therapist / Support</h3>
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <input
              value={plan.therapist_name}
              onChange={(e) => setPlan({ ...plan, therapist_name: e.target.value })}
              placeholder="Therapist name"
              className="pp-input"
            />
            <input
              value={plan.therapist_phone}
              onChange={(e) => setPlan({ ...plan, therapist_phone: e.target.value })}
              placeholder="Phone number"
              className="pp-input"
            />
            <input
              value={plan.therapist_email}
              onChange={(e) => setPlan({ ...plan, therapist_email: e.target.value })}
              placeholder="Email"
              className="pp-input sm:col-span-2"
            />
          </div>
        </motion.div>
      </div>

      {/* Save */}
      <div className="mt-8 flex items-center gap-3">
        <button
          onClick={save}
          disabled={saving}
          className="px-6 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50"
        >
          {saving ? "Saving…" : plan.id ? "Update plan" : "Save plan"}
        </button>
        {saved && (
          <motion.span initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="text-sm text-primary flex items-center gap-1.5">
            <Check size={16} /> Saved
          </motion.span>
        )}
      </div>

      <BadgeCelebration badges={newBadges} onClose={() => setNewBadges([])} />
    </div>
  );
}

function AddItemInput({ placeholder, onAdd }) {
  const [value, setValue] = useState("");
  return (
    <div className="flex gap-2">
      <input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            onAdd(value);
            setValue("");
          }
        }}
        placeholder={placeholder}
        className="pp-input flex-1"
      />
      <button
        onClick={() => {
          onAdd(value);
          setValue("");
        }}
        className="px-3 rounded-xl bg-secondary text-secondary-foreground hover:opacity-80 transition flex items-center justify-center"
      >
        <Plus size={18} />
      </button>
    </div>
  );
}