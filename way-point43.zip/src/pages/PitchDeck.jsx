import React, { useState, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import InteractiveMonitoringSlide from "@/components/pitch/InteractiveMonitoringSlide";
import { Image } from "@/components/ui/image";
import {
  ChevronLeft, ChevronRight, Activity, EyeOff, ShieldCheck, TrendingUp, Brain,
  Building2, LineChart, Lock, Users, Sparkles, Stethoscope, ArrowRight, Heart, Hospital,
  LayoutDashboard, Microscope, Gauge, ClipboardList, MessageSquare, Target,
  CalendarClock, FileText, Download,
} from "lucide-react";
const ACCENT = "hsl(172 68% 34%)";
const ACCENT2 = "hsl(152 52% 38%)";

const SLIDES = [
  {
    kind: "cover",
    title: "WayPoint",
    subtitle: "The clinician-built mental health platform for the modern workforce.",
    tag: "WayPoint Enterprise Pitch Deck · 2026",
  },
  {
    kind: "problem",
    icon: EyeOff,
    eyebrow: "The Problem",
    title: "Therapy today is a black box.",
    body: "Care is confined to a 53-minute session each week. Between sessions, clinicians are flying blind, clients can't see whether they're actually improving, and outcomes are guessed at rather than measured — so deterioration goes unnoticed and progress goes unproven.",
    stats: [
      { value: "167 hrs", label: "Each week a client spends unobserved between sessions" },
      { value: "<20%", label: "Therapists who routinely measure treatment outcomes" },
      { value: "1 in 10", label: "Clients who get worse in care — often unnoticed" },
    ],
  },
  {
    kind: "solution",
    icon: Brain,
    eyebrow: "The Solution",
    title: "Evidence-based care, between sessions and at scale.",
    body: "WayPoint bridges self-care and clinical intervention. Clients get a full CBT/DBT toolkit in their pocket; clinicians get a single portal with real-time symptom trends and outcome data — all in one HIPAA-aligned platform.",
    points: [
      "A therapist portal, clinical tools, and progress tracking in one place",
      "Standardized measurement built into every intervention",
      "AI coping coach available 24/7, clinician-gated by functioning level",
    ],
  },
  {
    kind: "portal",
    icon: LayoutDashboard,
    eyebrow: "The Therapist Portal",
    title: "Every client. One pane of glass.",
    body: "A single dashboard per client consolidates assessments, goals, homework, nervous-system data, and clinical notes — so therapists spend less time chasing charts and more time in session.",
    points: [
      "Per-client dashboard: homework, goals, notes & full symptom history",
      { icon: ClipboardList, text: "Assign CBT/DBT homework with checklists, due dates & calendar sync" },
      "Automated alerts when clients complete homework or assessments",
      "Clinician-gated feature access by functioning level (crisis → high)",
      { icon: FileText, text: "One-click clinical PDF reports for charts and payers" },
      "Audit log of every PHI view for compliance and trust",
    ],
  },
  {
    kind: "clinical",
    icon: Microscope,
    eyebrow: "Clinical Tools",
    title: "A full evidence-based toolkit, in the client's pocket.",
    body: "WayPoint operationalizes CBT, DBT, and ACT between sessions — with standardized measurement built in, so every tool feeds the outcome record.",
    points: [
      "9+ validated screens: GAD-7, PHQ-9, PCL-5, WHO-5, BAI, BDI, ISI, K6, ASRS",
      "CBT thought records, DBT coping toolbox & guided crisis planning",
      { icon: Target, text: "Values inventory driving personalized behavior activation" },
      "Sensory profile & activities quiz for tailored self-regulation",
      { icon: MessageSquare, text: "24/7 AI coping coach, gated by the clinician to match client readiness" },
      "All interventions cited to APA 7th edition references",
    ],
  },
  {
    kind: "progress",
    icon: Gauge,
    eyebrow: "Progress Tracking",
    title: "Measure what matters. Show the change.",
    body: "WayPoint turns every check-in and assessment into longitudinal outcome data — so clinicians and leaders can see real improvement and prove ROI to stakeholders and payers.",
    points: [
      "Mental Health Barometer fusing mood, sleep, stress & clinical scores",
      "Initial vs. most-recent comparison per client, per instrument",
      { icon: TrendingUp, text: "6-month symptom trend lines (GAD-7, PHQ-9, PCL-5)" },
      "Score overlays plotting every reading against a baseline",
      "Behavior-activation completion tracking across the whole caseload",
      "De-identified population outcomes for leadership & payers",
    ],
    stats: [
      { value: "9+", label: "Validated assessment instruments" },
      { value: "6 mo", label: "Symptom trend window per client" },
      { value: "100%", label: "Outcomes traceable to a cited intervention" },
    ],
  },
  {
    kind: "interactive",
    icon: Activity,
    eyebrow: "Live Monitoring",
    title: "See every signal, the moment it happens.",
    body: "Switch clients and tabs to explore the real-time view your therapists use every day — barometer, symptom trends, automated safety alerts, and assessment outcomes.",
  },
  {
    kind: "enterprise",
    icon: Building2,
    eyebrow: "Built for Large Practices",
    title: "From one site to a whole health system.",
    body: "Multi-site oversight, role-based access, and aggregated de-identified analytics give organizational leaders a population-level view — without ever exposing individual PHI.",
    points: [
      "Organization dashboard: caseload, utilization & outcome metrics",
      "Role tiers: Admin, Supervisor, Therapist, Client",
      { icon: CalendarClock, text: "Supervisor insights across therapists and sites" },
      "Clinician-gated feature access by client functioning level",
      "Custom onboarding, SSO readiness & volume pricing",
    ],
  },
  {
    kind: "security",
    icon: Lock,
    eyebrow: "Security & Trust",
    title: "Built for sensitive data, from day one.",
    body: "Row-level security isolates every client-therapist relationship. Audit logging tracks every PHI access. The platform is architected for HIPAA-aligned deployment.",
    points: [
      "Per-record row-level security across all clinical entities",
      "Full audit logging of PHI access and admin actions",
      "Role-based access control at every layer",
    ],
  },
  {
    kind: "tiers",
    icon: Building2,
    eyebrow: "Plans & Partners",
    title: "From solo clinicians to hospital systems — one platform that scales with you.",
    body: "WayPoint grows with your organization: solo and small group practices get the full clinical toolkit today, with a clear path to multi-site oversight, de-identified population outcomes, SSO, and enterprise pricing as you scale.",
    cards: [
      { name: "Solo & Small Practices", desc: "Single therapist or small team — full clinical toolkit & shared oversight", icon: Stethoscope },
      { name: "Group Practices", desc: "6–20 clinicians with supervision, analytics & caseload rollups", icon: Users },
      { name: "Hospital Systems", desc: "Integrated behavioral health across inpatient & outpatient programs", icon: Hospital },
      { name: "Enterprise Partners", desc: "Health systems, employers & plans — SSO, audit & population outcomes", icon: ShieldCheck },
    ],
  },
  {
    kind: "cta",
    title: "Let's bring measurable mental health care to your organization.",
    body: "Request a custom demo, onboarding plan, and enterprise pricing.",
    cta: { label: "Request a Demo", path: "/contact-sales" },
    secondary: { label: "Contact our team", path: "/contact" },
    contact: "jenthecounselor16@gmail.com · way-point43.base44.app",
  },
];



function ProgressBar({ current, total }) {
  return (
    <div className="absolute bottom-0 left-0 right-0 h-1 bg-border/40">
      <motion.div
        className="h-full"
        style={{ background: `linear-gradient(90deg, ${ACCENT}, ${ACCENT2})` }}
        animate={{ width: `${(current / total) * 100}%` }}
        transition={{ duration: 0.4, ease: "easeOut" }}
      />
    </div>
  );
}

function CoverSlide({ slide }) {
  return (
    <div className="flex flex-col items-center justify-center text-center h-full px-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6 }}
        className="w-20 h-20 md:w-24 md:h-24 rounded-3xl overflow-hidden mb-6 md:mb-8 shadow-lg ring-1 ring-border/40"
      >
        <Image
          src="https://media.base44.com/images/public/6a5d9b9fe72fabffdfd16c68/5b4d23001_IMG_5816.jpg"
          alt="WayPoint"
          fittingType="fill"
          className="block w-full h-full"
        />
      </motion.div>
      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="text-sm font-medium tracking-widest uppercase mb-4"
        style={{ color: ACCENT }}
      >
        {slide.tag}
      </motion.p>
      <motion.h1
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="font-display text-5xl sm:text-6xl md:text-8xl font-bold mb-5 md:mb-6"
      >
        {slide.title}
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="text-lg md:text-2xl text-muted-foreground max-w-2xl leading-relaxed"
      >
        {slide.subtitle}
      </motion.p>
    </div>
  );
}

function StatBlock({ stat, i }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 + i * 0.12 }}
      className="pp-card p-6 flex-1 text-center"
    >
      <p className="font-heading text-4xl md:text-5xl font-bold mb-2" style={{ color: ACCENT }}>{stat.value}</p>
      <p className="text-sm text-muted-foreground leading-snug">{stat.label}</p>
    </motion.div>
  );
}

function ContentSlide({ slide }) {
  const Icon = slide.icon;
  return (
    <div className="flex flex-col justify-center min-h-full max-w-4xl mx-auto px-4 md:px-2">
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.4 }}
        className="flex items-center gap-3 mb-6"
      >
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ background: `${ACCENT}1a` }}>
          <Icon size={24} style={{ color: ACCENT }} />
        </div>
        <span className="text-sm font-semibold tracking-widest uppercase" style={{ color: ACCENT }}>{slide.eyebrow}</span>
      </motion.div>

      <motion.h2
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="font-heading text-3xl md:text-5xl font-bold mb-5 leading-[1.1]"
      >
        {slide.title}
      </motion.h2>

      <motion.p
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="text-base md:text-lg text-muted-foreground mb-8 leading-relaxed max-w-3xl"
      >
        {slide.body}
      </motion.p>

      {slide.stats && (
        <div className="flex flex-col sm:flex-row gap-4">
          {slide.stats.map((s, i) => <StatBlock key={i} stat={s} i={i} />)}
        </div>
      )}

      {slide.points && (
        <div className="grid sm:grid-cols-2 gap-3">
          {slide.points.map((p, i) => {
            const text = typeof p === "string" ? p : p.text;
            const PointIcon = typeof p === "object" ? p.icon : null;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.35 + i * 0.08 }}
                className="flex items-start gap-3"
              >
                <div className="w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-0.5" style={{ background: `${ACCENT}1a` }}>
                  {PointIcon ? <PointIcon size={13} style={{ color: ACCENT }} /> : <Sparkles size={13} style={{ color: ACCENT }} />}
                </div>
                <p className="text-sm md:text-base text-foreground/85">{text}</p>
              </motion.div>
            );
          })}
        </div>
      )}

      {slide.cards && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {slide.cards.map((c, i) => {
            const CardIcon = c.icon;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.35 + i * 0.1 }}
                className="pp-card p-6"
              >
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ background: `${ACCENT}1a` }}>
                  <CardIcon size={20} style={{ color: ACCENT }} />
                </div>
                <h3 className="font-heading text-lg font-semibold mb-1">{c.name}</h3>
                <p className="text-sm text-muted-foreground">{c.desc}</p>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function CtaSlide({ slide }) {
  return (
    <div className="flex flex-col items-center justify-center text-center h-full px-6">
      <motion.h2
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="font-heading text-3xl md:text-5xl font-bold mb-5 max-w-3xl leading-[1.1]"
      >
        {slide.title}
      </motion.h2>
      <motion.p
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="text-lg text-muted-foreground mb-10 max-w-xl"
      >
        {slide.body}
      </motion.p>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.3 }}
        className="flex flex-col items-center gap-4"
      >
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <Link
            to={slide.cta.path}
            className="inline-flex items-center gap-2 px-8 py-4 rounded-2xl text-base font-semibold text-white transition hover:opacity-90"
            style={{ background: `linear-gradient(135deg, ${ACCENT}, ${ACCENT2})` }}
          >
            {slide.cta.label} <ArrowRight size={18} />
          </Link>
          {slide.secondary && (
            <Link
              to={slide.secondary.path}
              className="inline-flex items-center gap-2 px-6 py-4 rounded-2xl text-base font-semibold border border-border bg-card text-foreground transition hover:border-primary/50"
            >
              {slide.secondary.label}
            </Link>
          )}
        </div>
        {slide.contact && (
          <p className="text-sm text-muted-foreground mt-1">{slide.contact}</p>
        )}
      </motion.div>
    </div>
  );
}

function PrintSlides() {
  return (
    <div className="pitch-print-only">
      {SLIDES.map((slide, i) => (
        <section key={i} className="pitch-page">
          {slide.kind === "cover" && <CoverSlide slide={slide} />}
          {slide.kind === "cta" && <CtaSlide slide={slide} />}
          {slide.kind === "interactive" && <InteractiveMonitoringSlide slide={slide} />}
          {slide.kind !== "cover" && slide.kind !== "cta" && slide.kind !== "interactive" && <ContentSlide slide={slide} />}
        </section>
      ))}
    </div>
  );
}

export default function PitchDeck() {
  const [index, setIndex] = useState(0);
  const [dir, setDir] = useState(1);
  const total = SLIDES.length;

  const go = useCallback((next) => {
    setDir(next > index ? 1 : -1);
    setIndex((n) => Math.max(0, Math.min(total - 1, next)));
  }, [index, total]);

  const next = useCallback(() => go(index + 1), [go, index]);
  const prev = useCallback(() => go(index - 1), [go, index]);

  useEffect(() => {
    function onKey(e) {
      if (e.key === "ArrowRight" || e.key === " ") next();
      if (e.key === "ArrowLeft") prev();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [next, prev]);

  const slide = SLIDES[index];

  return (
    <>
    <div className="pitch-screen fixed inset-0 bg-background overflow-hidden">
      {/* Brand header: logo + wordmark, slide counter (desktop), branded Download PDF */}
      <header className="pitch-no-print absolute top-0 left-0 right-0 z-30 flex items-center justify-between gap-3 px-4 md:px-8 py-3 md:py-4">
        <Link to="/demo" className="flex items-center gap-2.5 shrink-0">
          <div className="w-8 h-8 md:w-9 md:h-9 rounded-xl overflow-hidden ring-1 ring-border/40">
            <Image
              src="https://media.base44.com/images/public/6a5d9b9fe72fabffdfd16c68/5b4d23001_IMG_5816.jpg"
              alt="WayPoint"
              fittingType="fill"
              className="block w-full h-full"
            />
          </div>
          <span className="font-display text-lg md:text-2xl font-bold" style={{ color: ACCENT }}>WayPoint</span>
        </Link>
        <span className="hidden sm:block text-sm font-medium tabular-nums text-foreground/40">
          {String(index + 1).padStart(2, "0")} <span className="text-foreground/25">/ {String(total).padStart(2, "0")}</span>
        </span>
        <button
          onClick={() => window.print()}
          className="inline-flex items-center gap-1.5 px-3.5 md:px-4 py-2 rounded-full text-xs md:text-sm font-semibold text-white shadow-sm hover:opacity-90 transition shrink-0"
          style={{ background: `linear-gradient(135deg, ${ACCENT}, ${ACCENT2})` }}
        >
          <Download size={15} /> Download PDF
        </button>
      </header>

      <AnimatePresence mode="wait" custom={dir}>
        <motion.div
          key={index}
          custom={dir}
          initial={{ opacity: 0, x: dir * 60 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -dir * 60 }}
          transition={{ duration: 0.45, ease: "easeOut" }}
          className="absolute inset-0 flex items-start justify-center overflow-y-auto pt-16 md:pt-24 pb-20 md:pb-24"
        >
          {slide.kind === "cover" && <CoverSlide slide={slide} />}
          {slide.kind === "cta" && <CtaSlide slide={slide} />}
          {slide.kind === "interactive" && <InteractiveMonitoringSlide slide={slide} />}
          {slide.kind !== "cover" && slide.kind !== "cta" && slide.kind !== "interactive" && <ContentSlide slide={slide} />}
        </motion.div>
      </AnimatePresence>

      {/* Bottom nav controls — centered, no overlap with the top Download button */}
      <div className="pitch-no-print absolute bottom-4 md:bottom-6 left-0 right-0 z-20 flex items-center justify-center gap-3 px-4">
        <button
          onClick={prev}
          disabled={index === 0}
          className="w-10 h-10 md:w-11 md:h-11 rounded-full border border-border bg-card/90 backdrop-blur flex items-center justify-center transition hover:border-primary/50 disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <ChevronLeft size={20} />
        </button>
        <div className="hidden sm:flex gap-1.5">
          {SLIDES.map((_, i) => (
            <button
              key={i}
              onClick={() => go(i)}
              className={`h-2 rounded-full transition-all ${i === index ? "w-7" : "w-2 bg-border"}`}
              style={i === index ? { background: ACCENT } : {}}
              aria-label={`Go to slide ${i + 1}`}
            />
          ))}
        </div>
        <span className="sm:hidden text-xs font-medium tabular-nums text-muted-foreground">
          {index + 1} / {total}
        </span>
        <button
          onClick={next}
          disabled={index === total - 1}
          className="w-10 h-10 md:w-11 md:h-11 rounded-full border border-border bg-card/90 backdrop-blur flex items-center justify-center transition hover:border-primary/50 disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <ChevronRight size={20} />
        </button>
      </div>

      <ProgressBar current={index + 1} total={total} />
    </div>
    <PrintSlides />
    </>
  );
}