import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Compass, ArrowRight, Sparkles } from "lucide-react";
import ValuesChecklist from "@/components/ValuesChecklist";

export default function ValuesInventory() {
  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto">
      <Link to="/" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-4">
        <ArrowLeft size={16} /> Back to Home
      </Link>

      <div className="flex items-start gap-3 mb-6">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Compass className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Values Inventory</h1>
          <p className="text-muted-foreground text-lg">Rank what matters most to you. Your top three values guide the activities you build in Behavior Activation.</p>
        </div>
      </div>

      <ValuesChecklist />

      <Link
        to="/behavior-activation"
        className="pp-card p-4 mt-6 flex items-center gap-4 hover:shadow-md hover:-translate-y-0.5 transition-all group bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20"
      >
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Sparkles size={22} className="text-primary" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="font-heading text-lg font-semibold">Put your values into action</h3>
          <p className="text-sm text-muted-foreground">Use your top values to choose enjoyable, valuable, and routine activities — or take the Activities Quiz for ideas.</p>
        </div>
        <ArrowRight size={18} className="text-muted-foreground group-hover:text-primary transition shrink-0" />
      </Link>
    </div>
  );
}