import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Moon, Zap, Brain, Droplet, Activity, Users, Frown, TrendingUp } from "lucide-react";
import { getMyTherapistEmail } from "@/lib/myTherapist";

const METRICS = [
  { key: "sleep_hours", label: "Sleep", unit: "hrs", icon: Moon, color: "#5B8FB9", max: 12 },
  { key: "stress_level", label: "Stress", unit: "/10", icon: Activity, color: "#E07856", max: 10 },
  { key: "anxiety_level", label: "Anxiety", unit: "/10", icon: Brain, color: "#8B7CB6", max: 10 },
  { key: "depression_level", label: "Depression", unit: "/10", icon: Frown, color: "#6B7280", max: 10 },
  { key: "energy_level", label: "Energy", unit: "/10", icon: Zap, color: "#D4906A", max: 10 },
  { key: "movement_minutes", label: "Movement", unit: "min", icon: Activity, color: "#7CB69D", max: 120 },
  { key: "hydration_glasses", label: "Hydration", unit: "glasses", icon: Droplet, color: "#3B82F6", max: 12 },
  { key: "social_interaction", label: "Social", unit: "/10", icon: Users, color: "#D97757", max: 10 },
];

export default function Dashboard() {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    sleep_hours: 7,
    stress_level: 5,
    movement_minutes: 20,
    hydration_glasses: 6,
    anxiety_level: 5,
    depression_level: 5,
    energy_level: 5,
    social_interaction: 5,
    note: "",
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.NervousSystemMetric.list("-created_date", 30);
        setEntries(data.reverse());
      } catch (err) {
        console.error("Dashboard fetch error:", err);
      }
      setLoading(false);
    })();
  }, []);

  // Realtime: refetch when nervous system metrics change
  useEffect(() => {
    const unsub = base44.entities.NervousSystemMetric.subscribe(() => {
      (async () => {
        try {
          const data = await base44.entities.NervousSystemMetric.list("-created_date", 30);
          setEntries(data.reverse());
        } catch (err) {
          console.error("Dashboard refetch error:", err);
        }
      })();
    });
    return unsub;
  }, []);

  async function saveEntry() {
    setSaving(true);
    try {
      const me = await base44.auth.me();
      let therapistEmail = "";
      try {
        const hw = await base44.entities.HomeworkAssignment.list("-created_date", 1);
        if (hw[0]?.therapist_email) therapistEmail = hw[0].therapist_email;
      } catch {}
      if (!therapistEmail) therapistEmail = await getMyTherapistEmail();

      await base44.entities.NervousSystemMetric.create({
        ...form,
        client_email: me?.email || "",
        therapist_email: therapistEmail,
      });
      const data = await base44.entities.NervousSystemMetric.list("-created_date", 30);
      setEntries(data.reverse());
      setShowForm(false);
    } catch (err) {
      console.error("Dashboard save error:", err);
    }
    setSaving(false);
  }

  const chartData = entries.map((e) => ({
    date: new Date(e.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
    ...e,
  }));

  const latest = entries[entries.length - 1];

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <div className="flex items-start justify-between mb-8 flex-wrap gap-4">
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold mb-2">Nervous System</h1>
          <p className="text-muted-foreground text-lg">Track the signals your body sends you over time.</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="px-5 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition"
        >
          {showForm ? "Cancel" : "+ Log today"}
        </button>
      </div>

      <Link
        to="/nervous-system-coach"
        className="mb-8 w-full py-3 rounded-xl bg-accent/10 text-accent font-medium hover:bg-accent/20 transition flex items-center justify-center gap-2"
      >
        <Activity size={18} /> Ask the Nervous System Coach
      </Link>

      {/* Log form */}
      {showForm && (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="pp-card p-5 mb-8 overflow-hidden">
          <h3 className="font-heading text-lg font-semibold mb-4">How was today?</h3>
          <div className="grid sm:grid-cols-2 gap-5">
            {METRICS.map((m) => (
              <div key={m.key}>
                <label className="text-sm font-medium mb-2 block flex items-center gap-2">
                  <m.icon size={16} style={{ color: m.color }} /> {m.label}
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min={0}
                    max={m.max}
                    value={form[m.key]}
                    onChange={(e) => setForm({ ...form, [m.key]: Number(e.target.value) })}
                    className="flex-1 accent-primary"
                  />
                  <span className="text-sm font-semibold w-16 text-right">{form[m.key]} {m.unit}</span>
                </div>
              </div>
            ))}
          </div>
          <textarea
            value={form.note}
            onChange={(e) => setForm({ ...form, note: e.target.value })}
            placeholder="Anything notable about today? (optional)"
            className="pp-input mt-4 min-h-[60px] resize-none"
          />
          <button
            onClick={saveEntry}
            disabled={saving}
            className="mt-4 w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50"
          >
            {saving ? "Saving…" : "Save entry"}
          </button>
        </motion.div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : entries.length === 0 ? (
        <div className="pp-card p-10 text-center">
          <TrendingUp className="mx-auto mb-4 text-muted-foreground/40" size={48} />
          <h3 className="font-heading text-xl font-semibold mb-2">No entries yet</h3>
          <p className="text-muted-foreground mb-4">Log your first check-in to start seeing trends.</p>
          <button onClick={() => setShowForm(true)} className="px-5 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition">
            Log today
          </button>
        </div>
      ) : (
        <>
          {/* Latest snapshot */}
          {latest && (
            <div className="mb-8">
              <h2 className="font-heading text-lg font-semibold mb-3 text-muted-foreground">Latest check-in</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                {METRICS.map((m) => (
                  <div key={m.key} className="pp-card p-4 flex flex-col min-h-[90px]">
                    <div className="flex items-center gap-2 mb-1.5">
                      <m.icon size={16} style={{ color: m.color }} className="shrink-0" />
                      <span className="text-xs text-muted-foreground truncate">{m.label}</span>
                    </div>
                    <p className="font-heading text-xl md:text-2xl font-semibold leading-tight truncate">
                      {latest[m.key] ?? "—"}
                      <span className="text-sm text-muted-foreground font-normal"> {m.unit}</span>
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Trend chart */}
          <div className="pp-card p-5 overflow-hidden">
            <h2 className="font-heading text-lg font-semibold mb-4">Trends</h2>
            <div className="flex gap-x-4 gap-y-2 flex-wrap mb-4">
              {METRICS.slice(0, 5).map((m) => (
                <span key={m.key} className="flex items-center gap-1.5 text-xs text-muted-foreground whitespace-nowrap">
                  <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: m.color }} />
                  {m.label}
                </span>
              ))}
            </div>
            <div className="w-full" style={{ height: 320 }}>
              <ResponsiveContainer width="100%" height="100%" debounce={100}>
                <LineChart data={chartData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" interval="preserveStartEnd" />
                  <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" width={32} />
                  <Tooltip
                    contentStyle={{ borderRadius: "12px", border: "1px solid hsl(var(--border))", fontSize: "12px" }}
                  />
                  {METRICS.slice(0, 5).map((m) => (
                    <Line key={m.key} type="monotone" dataKey={m.key} stroke={m.color} strokeWidth={2} dot={false} />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      )}
    </div>
  );
}