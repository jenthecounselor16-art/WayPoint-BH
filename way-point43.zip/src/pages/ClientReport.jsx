import React, { useState, useEffect, useRef } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { exportElementToPDF } from "@/lib/exportPdf";
import ClientReportBody from "@/components/therapist/ClientReportBody";
import { Printer, ArrowLeft, Download } from "lucide-react";

export default function ClientReport() {
  const { clientEmail } = useParams();
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);
  const reportRef = useRef(null);
  const [assessments, setAssessments] = useState([]);
  const [goals, setGoals] = useState([]);
  const [impairments, setImpairments] = useState([]);
  const [therapist, setTherapist] = useState(null);

  const email = clientEmail ? decodeURIComponent(clientEmail) : "";
  const clientName = new URLSearchParams(window.location.search).get("name") || email;

  useEffect(() => {
    if (!email) return;
    (async () => {
      try {
        const me = await base44.auth.me();
        setTherapist(me);
      } catch {}
      try {
        const [a, g, f] = await Promise.all([
          base44.entities.AssessmentResult.filter({ client_email: email }, "-created_date", 50),
          base44.entities.TherapyGoal.filter({ client_email: email }, "-created_date", 50),
          base44.entities.FunctionalImpairment.filter({ client_email: email }, "-created_date", 20),
        ]);
        setAssessments(a || []);
        setGoals(g || []);
        setImpairments(f || []);
      } catch (err) {
        console.error("Report fetch error:", err);
      }
      setLoading(false);
    })();
  }, [email]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  async function handleDownloadPDF() {
    if (!reportRef.current) return;
    setDownloading(true);
    try {
      await exportElementToPDF(reportRef.current, `WayPoint_Report_${clientName.replace(/\s+/g, "_")}.pdf`);
    } catch (err) {
      console.error("PDF export failed:", err);
    }
    setDownloading(false);
  }

  return (
    <div className="p-6 md:p-10 max-w-4xl mx-auto bg-white">
      {/* Action bar */}
      <div className="flex items-center justify-between mb-6 print:hidden">
        <Link to="/therapist" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition">
          <ArrowLeft size={16} /> Back to Portal
        </Link>
        <div className="flex gap-2">
          <button
            onClick={handleDownloadPDF}
            disabled={downloading}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-border font-medium text-sm hover:bg-secondary/50 transition disabled:opacity-50"
          >
            <Download size={16} /> {downloading ? "Generating…" : "Download PDF"}
          </button>
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition"
          >
            <Printer size={16} /> Print
          </button>
        </div>
      </div>

      <div ref={reportRef}>
        <ClientReportBody
          clientName={clientName}
          email={email}
          therapist={therapist}
          assessments={assessments}
          goals={goals}
          impairments={impairments}
        />
      </div>
    </div>
  );
}