import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Target, Plus, Trash2, Check, TrendingUp, ClipboardCheck } from "lucide-react";
import { useSubscribeRefresh } from "@/hooks/useSubscribeRefresh";
import { Link } from "react-router-dom";
import { celebrateGoalProgress, celebrateHomework } from "@/lib/celebrate";
import { logGoalCheckin } from "@/lib/goalProgress";

function RatingRow({ label, value, onChange, readOnly, color }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-muted-foreground">{label}</span>
        <span className="text-xs font-semibold" style={{ color }}>{value || 0}/10</span>
      </div>
      <input
        type="range"
        min="0"
        max="10"
        value={value || 0}
        onChange={(e) => onChange(parseInt(e.target.value))}
        disabled={readOnly}
        className="w-full h-2 rounded-full appearance-none cursor-pointer disabled:cursor-default disabled:opacity-60"
        style={{ accentColor: color }}
      />
    </div>
  );
}

export default function TherapyGoals() {
  const [user, setUser] = useState(null);
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", description: "", client_email: "" });
  const [saving, setSaving] = useState(false);

  const isTherapist = user?.role === "therapist";

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
      } catch {}
      setLoading(false);
    })();
  }, []);

  async function loadGoals() {
    try {
      const data = await base44.entities.TherapyGoal.list("-created_date", 100);
      setGoals(data);
    } catch {}
  }
  useEffect(() => {
    if (!user) return;
    loadGoals();
  }, [user]);
  useSubscribeRefresh("TherapyGoal", loadGoals);

  async function createGoal() {
    setSaving(true);
    try {
      const created = await base44.entities.TherapyGoal.create({
        ...form,
        therapist_email: user?.email || "",
        client_rating: 0,
        therapist_rating: 0,
        status: "active",
      });
      await logGoalCheckin(created, "therapist");
      const data = await base44.entities.TherapyGoal.list("-created_date", 100);
      setGoals(data);
      setForm({ title: "", description: "", client_email: "" });
      setShowForm(false);
    } catch {}
    setSaving(false);
  }

  async function updateRating(goal, field, value) {
    try {
      await base44.entities.TherapyGoal.update(goal.id, { [field]: value });
      await logGoalCheckin(goal, isTherapist ? "therapist" : "client", { [field]: value });
      setGoals(goals.map((g) => (g.id === goal.id ? { ...g, [field]: value } : g)));
      if (value > (goal[field] || 0)) celebrateGoalProgress();
    } catch {}
  }

  async function toggleStatus(goal) {
    const newStatus = goal.status === "achieved" ? "active" : "achieved";
    try {
      await base44.entities.TherapyGoal.update(goal.id, { status: newStatus });
      setGoals(goals.map((g) => (g.id === goal.id ? { ...g, status: newStatus } : g)));
      if (newStatus === "achieved") celebrateHomework();
    } catch {}
  }

  async function deleteGoal(goal) {
    try {
      await base44.entities.TherapyGoal.delete(goal.id);
      setGoals(goals.filter((g) => g.id !== goal.id));
    } catch {}
  }

  const active = goals.filter((g) => g.status !== "achieved");
  const achieved = goals.filter((g) => g.status === "achieved");

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <div className="flex items-start gap-3 mb-8">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Target className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Therapy Goals</h1>
          <p className="text-muted-foreground text-lg">
            {isTherapist
              ? "Set goals for your clients and track progress together."
              : "Your therapy goals and progress, shared with your therapist."}
          </p>
        </div>
      </div>

      {isTherapist && (
        <Link
          to="/goal-checkin"
          className="mb-4 w-full py-3 rounded-xl bg-accent/10 text-accent font-medium hover:bg-accent/20 transition flex items-center justify-center gap-2"
        >
          <ClipboardCheck size={18} /> Run a goal check-in
        </Link>
      )}

      {!isTherapist && (
        <Link
          to="/goal-self-checkin"
          className="mb-4 w-full py-3 rounded-xl bg-accent/10 text-accent font-medium hover:bg-accent/20 transition flex items-center justify-center gap-2"
        >
          <Target size={18} /> Check in on a goal
        </Link>
      )}

      {isTherapist && (
        <button
          onClick={() => setShowForm(!showForm)}
          className="w-full mb-6 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition flex items-center justify-center gap-2"
        >
          <Plus size={18} /> {showForm ? "Cancel" : "Create New Goal"}
        </button>
      )}

      <AnimatePresence>
        {showForm && isTherapist && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden mb-8">
            <div className="pp-card p-5 space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Goal Title</label>
                <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g., Practice assertive communication weekly" className="pp-input" />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Description</label>
                <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="What does success look like? Any specific steps or context for the client?" className="pp-input min-h-[80px] resize-none" />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Client Email</label>
                <input value={form.client_email} onChange={(e) => setForm({ ...form, client_email: e.target.value })} placeholder="client@email.com" className="pp-input" />
              </div>
              <button onClick={createGoal} disabled={saving || !form.title || !form.client_email} className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50">
                {saving ? "Creating…" : "Create Goal"}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : goals.length === 0 ? (
        <div className="pp-card p-10 text-center">
          <Target className="mx-auto mb-4 text-muted-foreground/40" size={48} />
          <h3 className="font-heading text-xl font-semibold mb-2">No goals yet</h3>
          <p className="text-muted-foreground">
            {isTherapist ? "Create your first therapy goal above." : "Your therapist hasn't set any goals yet."}
          </p>
        </div>
      ) : (
        <>
          {active.length > 0 && (
            <div className="mb-8">
              <h2 className="font-heading text-lg font-semibold mb-3">Active Goals</h2>
              <div className="grid md:grid-cols-2 gap-4">
                {active.map((goal) => (
                  <motion.div key={goal.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-5">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div className="flex-1">
                        <h3 className="font-heading text-lg font-semibold">{goal.title}</h3>
                        {goal.description && <p className="text-sm text-muted-foreground mt-1">{goal.description}</p>}
                      </div>
                      <span className="px-3 py-1 rounded-full bg-amber-500/10 text-amber-600 text-xs font-medium flex items-center gap-1 shrink-0">
                        <TrendingUp size={12} /> Active
                      </span>
                    </div>

                    {isTherapist && goal.client_email && (
                      <p className="text-xs text-muted-foreground mb-3">Client: {goal.client_email}</p>
                    )}

                    <div className="space-y-3 mt-4 pt-4 border-t border-border/60">
                      <RatingRow
                        label="Client's Progress"
                        value={goal.client_rating}
                        onChange={(v) => updateRating(goal, "client_rating", v)}
                        readOnly={isTherapist}
                        color="#1995A1"
                      />
                      <RatingRow
                        label="Therapist's Progress"
                        value={goal.therapist_rating}
                        onChange={(v) => updateRating(goal, "therapist_rating", v)}
                        readOnly={!isTherapist}
                        color="#D4A055"
                      />
                    </div>

                    {isTherapist && (
                      <div className="flex gap-2 mt-4">
                        <button onClick={() => toggleStatus(goal)} className="flex-1 py-2 rounded-xl bg-primary/10 text-primary text-sm font-medium hover:bg-primary/20 transition flex items-center justify-center gap-1.5">
                          <Check size={15} /> Mark Achieved
                        </button>
                        <button onClick={() => deleteGoal(goal)} className="px-3 py-2 rounded-xl bg-destructive/10 text-destructive hover:bg-destructive/20 transition flex items-center justify-center">
                          <Trash2 size={15} />
                        </button>
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {achieved.length > 0 && (
            <div>
              <h2 className="font-heading text-lg font-semibold mb-3">Achieved</h2>
              <div className="grid md:grid-cols-2 gap-4">
                {achieved.map((goal) => (
                  <div key={goal.id} className="pp-card p-5">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <Check className="text-primary" size={18} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-heading text-base font-semibold truncate">{goal.title}</h3>
                        <p className="text-xs text-muted-foreground">
                          Client: {goal.client_rating || 0}/10 • Therapist: {goal.therapist_rating || 0}/10
                        </p>
                      </div>
                      {isTherapist && (
                        <button onClick={() => toggleStatus(goal)} className="text-xs text-muted-foreground hover:text-foreground transition">
                          Reopen
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}