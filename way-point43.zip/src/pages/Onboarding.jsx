import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Activity, Compass, Check, ArrowRight, Sparkles, X, ClipboardList, Heart } from "lucide-react";
import SensoryQuiz from "@/components/onboarding/SensoryQuiz";
import ValuesChecklist from "@/components/ValuesChecklist";

const SKIP_KEY = "wp_onboarding_skipped";

export default function Onboarding() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [hasSensory, setHasSensory] = useState(false);
  const [hasValues, setHasValues] = useState(false);
  const [step, setStep] = useState("welcome"); // welcome | sensory | values | assessments | done
  const [checkingValues, setCheckingValues] = useState(false);
  const [pendingAssignments, setPendingAssignments] = useState([]);

  useEffect(() => {
    (async () => {
      let me = null;
      try {
        me = await base44.auth.me();
        setUser(me);
      } catch {}
      try {
        const [sensory, values, assignments] = await Promise.all([
          base44.entities.AssessmentResult.filter({ test_type: "SENSORY" }, "-created_date", 1),
          base44.entities.ValuesChecklist.list("-created_date", 1),
          me?.email
            ? base44.entities.AssessmentAssignment.filter({ client_email: me.email, status: "assigned" })
            : Promise.resolve([]),
        ]);
        const s = (sensory?.length || 0) > 0;
        const v = (values?.length || 0) > 0;
        setHasSensory(s);
        setHasValues(v);
        setPendingAssignments(assignments || []);
        if (s && v) {
          setStep((assignments?.length || 0) > 0 ? "assessments" : "done");
        } else if (s && !v) {
          setStep("values");
        } else {
          setStep("welcome");
        }
      } catch {}
      setLoading(false);
    })();
  }, []);

  const firstName = (user?.display_name || user?.full_name || "").split(" ")[0] || "there";

  function skip() {
    sessionStorage.setItem(SKIP_KEY, "1");
    navigate("/", { replace: true });
  }

  function begin() {
    setStep(hasSensory ? "values" : "sensory");
  }

  async function refreshValues() {
    setCheckingValues(true);
    try {
      const values = await base44.entities.ValuesChecklist.list("-created_date", 1);
      if (values?.length > 0) {
        setHasValues(true);
        setStep(pendingAssignments.length > 0 ? "assessments" : "done");
      }
    } catch {}
    setCheckingValues(false);
  }

  function finish() {
    sessionStorage.removeItem(SKIP_KEY);
    navigate("/", { replace: true });
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const steps = [
    { key: "sensory", label: "Sensory Profile", done: hasSensory },
    { key: "values", label: "Values Inventory", done: hasValues },
    ...(pendingAssignments.length > 0
      ? [{ key: "assessments", label: "Assessment", done: false }]
      : []),
  ];

  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto">
      {/* Top bar */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-2">
          <span className="font-display text-2xl font-bold text-primary">WayPoint</span>
          <span className="text-sm text-muted-foreground ml-2">Getting started</span>
        </div>
        {step !== "done" && (
          <button onClick={skip} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition">
            <X size={15} /> Skip for now
          </button>
        )}
      </div>

      {/* Progress */}
      {step !== "done" && (
        <div className="flex items-center gap-3 mb-8">
          {steps.map((s, i) => (
            <div key={s.key} className="flex items-center gap-3">
              <div
                className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium transition ${
                  s.done
                    ? "bg-accent/10 text-accent"
                    : step === s.key
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-muted-foreground"
                }`}
              >
                {s.done ? <Check size={14} /> : <span className="w-4 text-center">{i + 1}</span>}
                {s.label}
              </div>
              {i < steps.length - 1 && <div className="w-6 h-px bg-border" />}
            </div>
          ))}
        </div>
      )}

      <AnimatePresence mode="wait">
        {step === "welcome" && (
          <motion.div
            key="welcome"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className="pp-card p-6 md:p-8"
          >
            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Sparkles className="text-primary" size={24} />
              </div>
              <div>
                <h1 className="font-heading text-2xl md:text-3xl font-semibold">
                  Welcome to WayPoint, {firstName}
                </h1>
                <p className="text-muted-foreground">Let's set up your personalized experience.</p>
              </div>
            </div>
            <p className="text-foreground/80 leading-relaxed mb-4">
              To tailor your tools and coping strategies, we'll guide you through two quick
              introspective activities. Together they take about 8 minutes and help your care team
              understand how you process the world and what matters most to you.
            </p>
            <div className="mb-6 p-3 rounded-xl bg-accent/10 border border-accent/20 flex items-center gap-2.5">
              <Heart size={18} className="text-accent shrink-0" />
              <p className="text-sm text-foreground/80">
                <span className="font-semibold text-foreground">WayPoint is always free for you</span> — you'll never be asked to pay for anything here.
              </p>
            </div>
            <div className="space-y-3 mb-7">
              <StepRow
                icon={Activity}
                title="Sensory Profile"
                desc="Understand how you process everyday sensory input across four patterns."
                done={hasSensory}
              />
              <StepRow
                icon={Compass}
                title="Values Inventory"
                desc="Rank what matters most to you — your top three values guide your activities."
                done={hasValues}
              />
            </div>
            <button
              onClick={begin}
              className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition flex items-center justify-center gap-2"
            >
              {hasSensory ? "Continue to Values" : "Begin"} <ArrowRight size={18} />
            </button>
          </motion.div>
        )}

        {step === "sensory" && (
          <motion.div
            key="sensory"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
          >
            <div className="flex items-start gap-3 mb-6">
              <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                <Activity className="text-primary" size={22} />
              </div>
              <div>
                <h1 className="font-heading text-2xl md:text-3xl font-semibold">Sensory Profile</h1>
                <p className="text-muted-foreground">Rate how often each statement applies to you.</p>
              </div>
            </div>
            <SensoryQuiz onComplete={() => { setHasSensory(true); setStep("values"); }} />
          </motion.div>
        )}

        {step === "values" && (
          <motion.div
            key="values"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
          >
            <div className="flex items-start gap-3 mb-6">
              <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                <Compass className="text-primary" size={22} />
              </div>
              <div>
                <h1 className="font-heading text-2xl md:text-3xl font-semibold">Values Inventory</h1>
                <p className="text-muted-foreground">Rate each value, then save your top three.</p>
              </div>
            </div>
            <ValuesChecklist />
            <div className="mt-5">
              <button
                onClick={refreshValues}
                disabled={checkingValues}
                className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {checkingValues ? "Checking…" : <>Continue <ArrowRight size={18} /></>}
              </button>
              <p className="text-xs text-muted-foreground text-center mt-2">
                Save your top 3 values above, then tap Continue.
              </p>
            </div>
          </motion.div>
        )}

        {step === "assessments" && (
          <motion.div
            key="assessments"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className="pp-card p-6 md:p-8"
          >
            <div className="flex items-start gap-3 mb-5">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                <ClipboardList className="text-primary" size={24} />
              </div>
              <div>
                <h1 className="font-heading text-2xl md:text-3xl font-semibold">Your first assessment</h1>
                <p className="text-muted-foreground">A quick check-in your therapist has requested.</p>
              </div>
            </div>
            <p className="text-foreground/80 leading-relaxed mb-6">
              These short questionnaires help your care team understand how you've been doing and
              tailor your support. There are no right or wrong answers — just answer honestly,
              and take your time. Most take only a few minutes.
            </p>
            <div className="space-y-3 mb-7">
              {pendingAssignments.map((a) => (
                <div key={a.id} className="flex items-center justify-between gap-4 p-4 rounded-xl bg-secondary/40">
                  <div className="min-w-0">
                    <p className="font-medium">{a.test_type}</p>
                    {a.due_date && (
                      <p className="text-xs text-muted-foreground mt-0.5">Due {a.due_date}</p>
                    )}
                    {a.description && (
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{a.description}</p>
                    )}
                  </div>
                  <Link
                    to="/assessments"
                    className="shrink-0 inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition"
                  >
                    Start <ArrowRight size={15} />
                  </Link>
                </div>
              ))}
            </div>
            <button
              onClick={finish}
              className="w-full py-3 rounded-xl border border-border bg-card text-foreground font-medium hover:border-primary/40 transition flex items-center justify-center gap-2"
            >
              I'll do it later — go to Home <ArrowRight size={18} />
            </button>
          </motion.div>
        )}

        {step === "done" && (
          <motion.div
            key="done"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="pp-card p-8 md:p-10 text-center"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 15 }}
              className="w-16 h-16 rounded-2xl bg-accent/10 flex items-center justify-center mx-auto mb-5"
            >
              <Check className="text-accent" size={32} />
            </motion.div>
            <h1 className="font-heading text-2xl md:text-3xl font-semibold mb-2">You're all set!</h1>
            <p className="text-muted-foreground max-w-md mx-auto mb-7">
              Your sensory profile and values are saved. WayPoint will use them to personalize your
              coping tools and behavior activation. You can retake either anytime.
            </p>
            <button
              onClick={finish}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition"
            >
              Go to Home <ArrowRight size={18} />
            </button>
            <div className="mt-4">
              <Link to="/behavior-activation" className="text-sm text-primary hover:underline">
                Or explore Behavior Activation →
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StepRow({ icon: Icon, title, desc, done }) {
  return (
    <div className="flex items-start gap-3 p-4 rounded-xl bg-secondary/40">
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${done ? "bg-accent/10" : "bg-primary/10"}`}>
        {done ? <Check size={18} className="text-accent" /> : <Icon size={18} className="text-primary" />}
      </div>
      <div>
        <p className="font-medium">{title}</p>
        <p className="text-sm text-muted-foreground">{desc}</p>
      </div>
    </div>
  );
}