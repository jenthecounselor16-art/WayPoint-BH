import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { BarChart3, TrendingUp, Users, MousePointerClick, ArrowLeft } from "lucide-react";

export default function DemoEngagement() {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [participants, setParticipants] = useState([]);
  const [interactions, setInteractions] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        if (me?.role !== "admin") { setLoading(false); return; }
        const [ps, its] = await Promise.all([
          base44.entities.DemoParticipant.list("-seat_number", 50),
          base44.entities.DemoFeatureInteraction.list("-created_date", 1000),
        ]);
        setParticipants(ps || []);
        setInteractions(its || []);
      } catch (e) {
        console.error("Demo engagement load error:", e);
      }
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (user?.role !== "admin") {
    return (
      <div className="p-10 max-w-2xl mx-auto text-center">
        <p className="text-muted-foreground">Admins only. This dashboard shows how demo clinicians are engaging with WayPoint features.</p>
      </div>
    );
  }

  const demoEmails = new Set(participants.map((p) => p.email).filter(Boolean));
  const demoInteractions = interactions.filter((i) => demoEmails.has(i.participant_email));

  // Aggregate by feature
  const featureCounts = {};
  demoInteractions.forEach((i) => {
    const label = i.feature_label || i.feature_key || "Unknown";
    featureCounts[label] = (featureCounts[label] || 0) + 1;
  });
  const topFeatures = Object.entries(featureCounts)
    .map(([label, count]) => ({ label, count }))
    .sort((a, b) => b.count - a.count);
  const maxCount = topFeatures.length ? topFeatures[0].count : 1;

  const activeDemoParticipants = participants.filter(
    (p) => !p.expires_at || new Date(p.expires_at).getTime() > Date.now()
  );

  const perParticipant = participants
    .map((p) => {
      const pInteractions = demoInteractions.filter((i) => i.participant_email === p.email);
      const featuresUsed = new Set(pInteractions.map((i) => i.feature_key)).size;
      const lastMs = pInteractions.length
        ? Math.max(...pInteractions.map((i) => new Date(i.created_date).getTime()))
        : 0;
      return { ...p, interactions: pInteractions.length, featuresUsed, lastMs };
    })
    .sort((a, b) => b.interactions - a.interactions);

  function timeAgo(ms) {
    if (!ms) return "—";
    const d = Math.floor((Date.now() - ms) / 86400000);
    if (d <= 0) return "today";
    if (d === 1) return "1d ago";
    return `${d}d ago`;
  }

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <Link to="/demo-admin" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-6">
        <ArrowLeft size={16} /> Back to Demo Program
      </Link>

      <div className="flex items-start gap-3 mb-8">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <BarChart3 className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Demo Engagement</h1>
          <p className="text-muted-foreground text-lg">Which WayPoint features your trial clinicians are using most.</p>
        </div>
      </div>

      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        <div className="pp-card p-4">
          <div className="flex items-center gap-2 mb-1">
            <MousePointerClick size={16} className="text-primary" />
            <p className="text-xs text-muted-foreground">Total interactions</p>
          </div>
          <p className="font-heading text-2xl font-semibold">{demoInteractions.length}</p>
        </div>
        <div className="pp-card p-4">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp size={16} className="text-primary" />
            <p className="text-xs text-muted-foreground">Features used</p>
          </div>
          <p className="font-heading text-2xl font-semibold">{topFeatures.length}</p>
        </div>
        <div className="pp-card p-4">
          <div className="flex items-center gap-2 mb-1">
            <Users size={16} className="text-primary" />
            <p className="text-xs text-muted-foreground">Active demo users</p>
          </div>
          <p className="font-heading text-2xl font-semibold">{activeDemoParticipants.length}</p>
        </div>
      </div>

      {topFeatures.length === 0 ? (
        <div className="pp-card p-8 text-center text-muted-foreground">
          No feature interactions logged yet. Interactions are recorded automatically as demo clinicians navigate the app.
        </div>
      ) : (
        <div className="pp-card p-5 mb-6">
          <h2 className="font-heading text-lg font-semibold mb-4">Most-used features</h2>
          <div className="space-y-3">
            {topFeatures.map((f, i) => (
              <div key={f.label}>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span className="font-medium flex items-center gap-2">
                    <span className="text-muted-foreground w-5">{i + 1}.</span> {f.label}
                  </span>
                  <span className="text-muted-foreground">{f.count}</span>
                </div>
                <div className="h-2.5 rounded-full bg-secondary overflow-hidden">
                  <div
                    className="h-full rounded-full bg-primary transition-all"
                    style={{ width: `${(f.count / maxCount) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {participants.length > 0 && (
        <div className="pp-card p-5 overflow-x-auto">
          <h2 className="font-heading text-lg font-semibold mb-4">Per-participant activity</h2>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-xs text-muted-foreground">
                <th className="p-3">Seat</th>
                <th className="p-3">Clinician</th>
                <th className="p-3 text-right">Interactions</th>
                <th className="p-3 text-right">Features used</th>
                <th className="p-3 text-right">Last active</th>
              </tr>
            </thead>
            <tbody>
              {perParticipant.map((p) => (
                <tr key={p.id} className="border-b border-border/50">
                  <td className="p-3 font-medium">#{p.seat_number}</td>
                  <td className="p-3">
                    {p.name}
                    <div className="text-xs text-muted-foreground">{p.email}</div>
                  </td>
                  <td className="p-3 text-right">{p.interactions}</td>
                  <td className="p-3 text-right">{p.featuresUsed}</td>
                  <td className="p-3 text-right text-muted-foreground">{timeAgo(p.lastMs)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}