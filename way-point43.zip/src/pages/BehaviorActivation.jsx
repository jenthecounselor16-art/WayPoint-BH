import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { getMyTherapistEmail } from "@/lib/myTherapist";
import { Heart, Target, Repeat, Plus, Trash2, Check, Sparkles, ArrowLeft, Wand2 } from "lucide-react";

const CATEGORIES = [
  { key: "enjoyable", label: "Enjoyable", desc: "Activities that bring pleasure or fun", icon: Heart, color: "accent" },
  { key: "valuable", label: "Valuable", desc: "Activities tied to what you care about", icon: Target, color: "primary" },
  { key: "routine", label: "Routine", desc: "Small daily actions that keep you steady", icon: Repeat, color: "subtleAccent" },
];

const FREQ_LABEL = { daily: "Daily", weekly: "Weekly", as_needed: "As needed" };

export default function BehaviorActivation() {
  const [activities, setActivities] = useState([]);
  const [topValues, setTopValues] = useState([]);
  const [userEmail, setUserEmail] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: "", category: "enjoyable", linked_value: "", frequency: "weekly" });

  async function load() {
    try {
      const me = await base44.auth.me();
      setUserEmail(me?.email || "");
      const [acts, vals] = await Promise.all([
        base44.entities.BehaviorActivationActivity.filter({ client_email: me?.email || "" }, "-created_date", 100),
        base44.entities.ValuesChecklist.filter({ client_email: me?.email || "" }, "-created_date", 1),
      ]);
      setActivities(acts || []);
      const v = vals?.[0];
      setTopValues(v?.top_values?.length ? v.top_values : v?.values || []);
    } catch {}
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function addActivity() {
    if (!form.name.trim()) return;
    setSaving(true);
    try {
      let therapistEmail = "";
      try {
        const hw = await base44.entities.HomeworkAssignment.list("-created_date", 1);
        if (hw[0]?.therapist_email) therapistEmail = hw[0].therapist_email;
      } catch {}
      if (!therapistEmail) therapistEmail = await getMyTherapistEmail();
      await base44.entities.BehaviorActivationActivity.create({
        name: form.name.trim(),
        category: form.category,
        linked_value: form.linked_value || "",
        frequency: form.frequency,
        status: "planned",
        client_email: userEmail,
        therapist_email: therapistEmail,
      });
      setForm({ name: "", category: "enjoyable", linked_value: "", frequency: "weekly" });
      await load();
    } catch {}
    setSaving(false);
  }

  async function markDone(id) {
    try {
      await base44.entities.BehaviorActivationActivity.update(id, { status: "done", last_done_at: new Date().toISOString() });
      setActivities((prev) => prev.map((a) => (a.id === id ? { ...a, status: "done", last_done_at: new Date().toISOString() } : a)));
    } catch {}
  }

  async function remove(id) {
    try {
      await base44.entities.BehaviorActivationActivity.delete(id);
      setActivities((prev) => prev.filter((a) => a.id !== id));
    } catch {}
  }

  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto">
      <Link to="/" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-4">
        <ArrowLeft size={16} /> Back to Home
      </Link>

      <div className="flex items-start gap-3 mb-6">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Sparkles className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Behavior Activation</h1>
          <p className="text-muted-foreground text-lg">Build enjoyable, valuable, and routine activities that move you toward what matters.</p>
        </div>
      </div>

      {topValues.length > 0 && (
        <div className="pp-card p-4 mb-6">
          <p className="text-xs font-medium text-primary mb-2">Your top values</p>
          <div className="flex flex-wrap gap-2">
            {topValues.map((v) => (
              <span key={v} className="px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">{v}</span>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-2">Link activities to these values to make them more meaningful.</p>
        </div>
      )}

      <Link
        to="/activities-quiz"
        className="pp-card p-4 mb-6 flex items-center gap-4 hover:shadow-md hover:-translate-y-0.5 transition-all group bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20"
      >
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Wand2 size={22} className="text-primary" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="font-heading text-lg font-semibold">Not sure where to start? Take the Activities Quiz</h3>
          <p className="text-sm text-muted-foreground">Answer a few fun questions and we'll suggest enjoyable, valuable, and routine activities for you.</p>
        </div>
        <ArrowLeft size={18} className="text-muted-foreground rotate-180 group-hover:text-primary transition shrink-0" />
      </Link>

      {/* Add activity */}
      <div className="pp-card p-5 mb-6">
        <h3 className="font-heading text-lg font-semibold mb-3">Add an activity</h3>
        <input
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          placeholder="e.g. Morning walk, call a friend, work on a creative project"
          className="pp-input mb-3"
        />
        <div className="grid sm:grid-cols-3 gap-3 mb-3">
          <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="pp-input">
            {CATEGORIES.map((c) => (
              <option key={c.key} value={c.key}>{c.label}</option>
            ))}
          </select>
          <select value={form.linked_value} onChange={(e) => setForm({ ...form, linked_value: e.target.value })} className="pp-input" disabled={topValues.length === 0}>
            <option value="">{topValues.length ? "Link to a value…" : "Take values inventory first"}</option>
            {topValues.map((v) => (
              <option key={v} value={v}>{v}</option>
            ))}
          </select>
          <select value={form.frequency} onChange={(e) => setForm({ ...form, frequency: e.target.value })} className="pp-input">
            {Object.entries(FREQ_LABEL).map(([k, label]) => (
              <option key={k} value={k}>{label}</option>
            ))}
          </select>
        </div>
        <button
          onClick={addActivity}
          disabled={!form.name.trim() || saving}
          className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {saving ? "Saving…" : <><Plus size={16} /> Add Activity</>}
        </button>
      </div>

      {/* Activity lists by category */}
      {loading ? (
        <div className="flex justify-center py-10">
          <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : (
        <div className="space-y-6">
          {CATEGORIES.map((cat) => {
            const items = activities.filter((a) => a.category === cat.key);
            const Icon = cat.icon;
            return (
              <div key={cat.key}>
                <div className="flex items-center gap-2 mb-3">
                  <Icon size={18} className={`text-${cat.color}`} />
                  <h3 className="font-heading text-lg font-semibold">{cat.label}</h3>
                  <span className="text-xs text-muted-foreground">{cat.desc}</span>
                </div>
                {items.length === 0 ? (
                  <p className="text-sm text-muted-foreground py-3 pl-1">No {cat.label.toLowerCase()} activities yet.</p>
                ) : (
                  <div className="space-y-2">
                    {items.map((a) => (
                      <div key={a.id} className="pp-card p-3.5 flex items-center gap-3">
                        <button
                          onClick={() => markDone(a.id)}
                          className={`w-8 h-8 rounded-full border-2 flex items-center justify-center shrink-0 transition ${
                            a.status === "done" ? "bg-primary border-primary text-primary-foreground" : "border-border hover:border-primary/50"
                          }`}
                          title="Mark done"
                        >
                          {a.status === "done" && <Check size={16} />}
                        </button>
                        <div className="min-w-0 flex-1">
                          <p className={`text-sm font-medium ${a.status === "done" ? "line-through text-muted-foreground" : ""}`}>{a.name}</p>
                          <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                            {a.linked_value && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-accent/10 text-accent">{a.linked_value}</span>
                            )}
                            <span className="text-xs text-muted-foreground">{FREQ_LABEL[a.frequency] || a.frequency}</span>
                            {a.last_done_at && (
                              <span className="text-xs text-muted-foreground">Last done {new Date(a.last_done_at).toLocaleDateString()}</span>
                            )}
                          </div>
                        </div>
                        <button onClick={() => remove(a.id)} className="p-2 rounded-lg text-muted-foreground hover:text-destructive transition shrink-0">
                          <Trash2 size={16} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}