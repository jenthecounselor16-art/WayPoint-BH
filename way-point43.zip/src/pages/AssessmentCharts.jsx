import React, { useState, useEffect, useMemo } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import ClinicianGate from "@/components/ClinicianGate";
import { ASSESSMENTS } from "@/lib/assessments";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { LineChart as LineChartIcon, Loader2, Users, Activity } from "lucide-react";

const PALETTE = ["#D9534F", "#5B8FB9", "#8B7CB6", "#1995A1", "#D4A055", "#E07856", "#5B9D6B", "#C77DFF"];
// Highlighted scales the therapist is most likely tracking by hand.
const HIGHLIGHT_TYPES = ["CSSRS", "YBOCS", "CYBOCS"];

function typeColor(type, idx) {
  const map = { CSSRS: "#D9534F", YBOCS: "#5B8FB9", CYBOCS: "#8B7CB6" };
  return map[type] || PALETTE[idx % PALETTE.length];
}

export default function AssessmentCharts() {
  return <ClinicianGate><AssessmentChartsContent /></ClinicianGate>;
}

function AssessmentChartsContent() {
  const [user, setUser] = useState(null);
  const [clients, setClients] = useState([]);
  const [selected, setSelected] = useState("");
  const [assessments, setAssessments] = useState([]);
  const [loadingClients, setLoadingClients] = useState(true);
  const [loadingData, setLoadingData] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        const list = await base44.entities.Client.filter(
          { therapist_email: me.email }, "client_name", 100
        );
        setClients(list || []);
        if (list?.length) setSelected(list[0].client_email);
      } catch {}
      setLoadingClients(false);
    })();
  }, []);

  useEffect(() => {
    if (!selected) return;
    setLoadingData(true);
    (async () => {
      try {
        const data = await base44.entities.AssessmentResult.filter(
          { client_email: selected }, "created_date", 300
        );
        setAssessments(data || []);
      } catch {}
      setLoadingData(false);
    })();
  }, [selected]);

  const availableTypes = useMemo(() => {
    const set = new Set(assessments.map((a) => a.test_type));
    return Array.from(set);
  }, [assessments]);

  const [selectedTypes, setSelectedTypes] = useState([]);

  useEffect(() => {
    // Default to C-SSRS / Y-BOCS / CY-BOCS when present, else every available type.
    const defaults = availableTypes.filter((t) => HIGHLIGHT_TYPES.includes(t));
    setSelectedTypes(defaults.length ? defaults : [...availableTypes]);
  }, [availableTypes]);

  const chartData = useMemo(() => {
    const points = {};
    assessments.forEach((a) => {
      const d = new Date(a.created_date);
      const key = d.toISOString().slice(0, 10);
      if (!points[key]) {
        points[key] = {
          date: a.created_date,
          dateLabel: d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "2-digit" }),
          _meta: {},
        };
      }
      // Keep the most recent reading per type per day.
      if (!points[key][a.test_type] || new Date(a.created_date) > new Date(points[key]._meta[a.test_type])) {
        points[key][a.test_type] = a.score;
        points[key]._meta[a.test_type] = a.created_date;
      }
    });
    return Object.values(points)
      .map((p) => {
        const { _meta, ...rest } = p;
        return rest;
      })
      .sort((a, b) => new Date(a.date) - new Date(b.date));
  }, [assessments]);

  function toggleType(t) {
    setSelectedTypes((prev) =>
      prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]
    );
  }

  const clientName = clients.find((c) => c.client_email === selected)?.client_name || selected;

  if (loadingClients) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (clients.length === 0) {
    return (
      <div className="p-6 md:p-10 max-w-4xl mx-auto">
        <div className="pp-card p-10 text-center">
          <Users className="mx-auto mb-4 text-muted-foreground/40" size={48} />
          <h3 className="font-heading text-xl font-semibold mb-2">No clients yet</h3>
          <p className="text-muted-foreground max-w-md mx-auto">
            Add clients from the Therapist Portal to visualize their assessment progress over time.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 max-w-4xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <LineChartIcon className="text-primary" size={24} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Assessment Progress</h1>
          <p className="text-muted-foreground">Track assigned measures like C-SSRS and Y-BOCS over time.</p>
        </div>
      </div>

      {/* Client selector */}
      <div className="pp-card p-4 mb-6">
        <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Client</label>
        <select
          value={selected}
          onChange={(e) => setSelected(e.target.value)}
          className="pp-input mt-1"
        >
          {clients.map((c) => (
            <option key={c.id} value={c.client_email}>
              {c.client_name || c.client_email}
            </option>
          ))}
        </select>
      </div>

      {loadingData ? (
        <div className="pp-card p-10 flex items-center justify-center">
          <Loader2 className="w-7 h-7 text-primary animate-spin" />
        </div>
      ) : assessments.length === 0 ? (
        <div className="pp-card p-10 text-center">
          <Activity className="mx-auto mb-3 text-muted-foreground/40" size={40} />
          <p className="text-muted-foreground">No assessment results recorded for {clientName} yet.</p>
        </div>
      ) : (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
          {/* Type chips */}
          <div className="flex flex-wrap gap-2 mb-4">
            {availableTypes.map((t, i) => {
              const active = selectedTypes.includes(t);
              const test = ASSESSMENTS[t];
              const color = typeColor(t, i);
              return (
                <button
                  key={t}
                  onClick={() => toggleType(t)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition flex items-center gap-1.5 ${
                    active ? "border-transparent text-white" : "bg-card text-muted-foreground hover:text-foreground"
                  }`}
                  style={active ? { backgroundColor: color } : undefined}
                >
                  <span className="font-bold">{test?.abbr || t}</span>
                  {HIGHLIGHT_TYPES.includes(t) && <span className="opacity-80">★</span>}
                </button>
              );
            })}
          </div>

          {/* Chart */}
          {selectedTypes.length === 0 ? (
            <div className="pp-card p-10 text-center text-muted-foreground text-sm">
              Select at least one assessment type to chart.
            </div>
          ) : (
            <div className="pp-card p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-heading text-lg font-semibold">{clientName}</h3>
                <span className="text-xs text-muted-foreground">Raw scores · {chartData.length} time points</span>
              </div>
              <div style={{ width: "100%", height: 320 }}>
                <ResponsiveContainer>
                  <LineChart data={chartData} margin={{ top: 8, right: 16, left: -8, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
                    <XAxis
                      dataKey="dateLabel"
                      tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                      tickMargin={8}
                    />
                    <YAxis
                      tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                      allowDecimals={false}
                      width={36}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    {selectedTypes.map((t, i) => (
                      <Line
                        key={t}
                        type="monotone"
                        dataKey={t}
                        name={ASSESSMENTS[t]?.abbr || t}
                        stroke={typeColor(t, i)}
                        strokeWidth={2.5}
                        dot={{ r: 4, strokeWidth: 0 }}
                        activeDot={{ r: 6 }}
                        connectNulls
                      />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <p className="text-[11px] text-muted-foreground mt-3 leading-relaxed">
                Scores reflect each scale's own range and are not directly comparable across measures (e.g. C-SSRS max 6 vs Y-BOCS max 40). Hover any point for severity.
              </p>
            </div>
          )}

          {/* Latest readings table */}
          <div className="pp-card p-5 mt-4">
            <h3 className="font-heading text-lg font-semibold mb-3">Latest Readings</h3>
            <div className="space-y-2">
              {availableTypes.map((t) => {
                const latest = assessments
                  .filter((a) => a.test_type === t)
                  .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
                if (!latest) return null;
                const test = ASSESSMENTS[t];
                const scored = test?.score?.(latest.score);
                const sev = latest.severity || scored?.severity;
                const color = scored?.color || "#6B7280";
                const count = assessments.filter((a) => a.test_type === t).length;
                return (
                  <div key={t} className="flex items-center justify-between gap-3 p-3 rounded-xl bg-secondary/40">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-md text-xs font-bold text-white" style={{ backgroundColor: typeColor(t, 0) }}>
                          {test?.abbr || t}
                        </span>
                        <span className="text-sm font-medium truncate">{test?.name || t}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {count} reading{count === 1 ? "" : "s"} · last {new Date(latest.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-heading text-lg font-semibold">{latest.score}</p>
                      {sev && <p className="text-xs font-medium" style={{ color }}>{sev}</p>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="pp-card p-3 shadow-lg" style={{ background: "hsl(var(--card))" }}>
      <p className="text-xs font-semibold text-muted-foreground mb-2">{label}</p>
      <div className="space-y-1">
        {payload.map((p) => {
          const test = ASSESSMENTS[p.dataKey];
          const scored = test?.score?.(p.value);
          return (
            <div key={p.dataKey} className="flex items-center gap-2 text-xs">
              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: p.color }} />
              <span className="font-medium">{test?.abbr || p.dataKey}</span>
              <span className="font-heading font-semibold">{p.value}</span>
              {scored?.severity && <span style={{ color: scored.color }}>· {scored.severity}</span>}
            </div>
          );
        })}
      </div>
    </div>
  );
}