import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Send, Building2, Users, CheckCircle2, AlertCircle } from "lucide-react";

const SIZE_OPTIONS = [
  "5–20 clinicians",
  "21–50 clinicians",
  "51–100 clinicians",
  "101–500 clinicians",
  "500–1,000 clinicians",
  "1,000+ clinicians",
];

const INTEREST_OPTIONS = [
  "Just exploring",
  "Comparing options",
  "Evaluating for a purchase this quarter",
  "Ready to buy — need a quote ASAP",
];

export default function ContactSales() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    organization: "",
    title: "",
    clinician_count: "",
    phone: "",
    interest_level: "",
    message: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [status, setStatus] = useState(null); // { type: "success" | "error", text }

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    setStatus(null);
    try {
      const res = await base44.functions.invoke("contact-sales", form);
      if (res?.data?.ok) {
        setStatus({ type: "success", text: "Thanks! Our team will reach out within 1–2 business days with custom pricing and onboarding details." });
        setForm({ name: "", email: "", organization: "", title: "", clinician_count: "", phone: "", interest_level: "", message: "" });
      } else {
        setStatus({ type: "error", text: res?.data?.error || "Something went wrong. Please try again." });
      }
    } catch (err) {
      setStatus({ type: "error", text: "Something went wrong. Please try again or email us directly." });
    }
    setSubmitting(false);
  }

  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto">
      <Link to="/" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-6">
        <ArrowLeft size={16} /> Back to Home
      </Link>

      <div className="flex items-center gap-3 mb-3">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Building2 className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Contact Sales</h1>
          <p className="text-muted-foreground">Enterprise &amp; health system plans, custom pricing.</p>
        </div>
      </div>

      <p className="text-muted-foreground text-lg mb-8">
        Tell us about your organization and we'll follow up with tailored pricing and onboarding for your team.
      </p>

      {status?.type === "success" && (
        <div className="mb-6 p-4 rounded-xl bg-accent/10 border border-accent/20 text-accent text-sm flex items-start gap-2">
          <CheckCircle2 size={18} className="shrink-0 mt-0.5" />
          <span>{status.text}</span>
        </div>
      )}
      {status?.type === "error" && (
        <div className="mb-6 p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm flex items-start gap-2">
          <AlertCircle size={18} className="shrink-0 mt-0.5" />
          <span>{status.text}</span>
        </div>
      )}

      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-5 md:p-7">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Full name *</label>
              <input
                type="text"
                required
                value={form.name}
                onChange={(e) => update("name", e.target.value)}
                className="pp-input"
                placeholder="Jane Doe"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Work email *</label>
              <input
                type="email"
                required
                value={form.email}
                onChange={(e) => update("email", e.target.value)}
                className="pp-input"
                placeholder="jane@healthsystem.org"
              />
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Organization *</label>
              <input
                type="text"
                required
                value={form.organization}
                onChange={(e) => update("organization", e.target.value)}
                className="pp-input"
                placeholder="Health System Name"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Title / role</label>
              <input
                type="text"
                value={form.title}
                onChange={(e) => update("title", e.target.value)}
                className="pp-input"
                placeholder="Director of Behavioral Health"
              />
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block flex items-center gap-1.5">
                <Users size={14} /> Number of clinicians
              </label>
              <select
                value={form.clinician_count}
                onChange={(e) => update("clinician_count", e.target.value)}
                className="pp-input"
              >
                <option value="">Select a range…</option>
                {SIZE_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>{opt}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Phone</label>
              <input
                type="tel"
                value={form.phone}
                onChange={(e) => update("phone", e.target.value)}
                className="pp-input"
                placeholder="(555) 555-5555"
              />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-1.5 block">Interest level</label>
            <select
              value={form.interest_level}
              onChange={(e) => update("interest_level", e.target.value)}
              className="pp-input"
            >
              <option value="">Select how far along you are…</option>
              {INTEREST_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-sm font-medium mb-1.5 block">What are you looking for?</label>
            <textarea
              value={form.message}
              onChange={(e) => update("message", e.target.value)}
              className="pp-input min-h-[110px] resize-none"
              placeholder="Tell us about your organization, timelines, and any specific needs (multi-site rollout, EHR integration, compliance, etc.)"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <Send size={16} /> {submitting ? "Sending…" : "Request a quote"}
          </button>
          <p className="text-xs text-muted-foreground text-center">
            We'll respond within 1–2 business days. Your details are kept confidential.
          </p>
        </form>
      </motion.div>
    </div>
  );
}