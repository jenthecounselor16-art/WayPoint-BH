import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import {
  Heart, Gauge, Wrench, Bot, ShieldAlert, ArrowRight, Sparkles, Lightbulb, Trophy, Compass,
  Stethoscope, TrendingUp, Building2, BookOpen, CreditCard,
} from "lucide-react";
import MentalHealthBarometer from "@/components/MentalHealthBarometer";
import ParentAccessRequests from "@/components/parent/ParentAccessRequests";
import PhoneMockup from "@/components/PhoneMockup";
import TopValuesPanel from "@/components/TopValuesPanel";
import { useClientAccess } from "@/hooks/useClientAccess";
import { isDemoParticipant } from "@/lib/demoTracking";
import { getDemoView, setDemoView, onDemoViewChange } from "@/lib/demoView";

const CLINICIAN_ROLES = ["admin", "therapist", "supervisor"];

export default function Home() {
  const [user, setUser] = useState(null);
  const [recentMood, setRecentMood] = useState(null);
  const [loading, setLoading] = useState(true);
  const { can } = useClientAccess();
  const navigate = useNavigate();
  const [isDemo, setIsDemo] = useState(false);
  const [demoView, setDemoViewState] = useState(() => getDemoView());

  useEffect(() => onDemoViewChange(setDemoViewState), []);

  useEffect(() => {
    (async () => {
      let me = null;
      try {
        me = await base44.auth.me();
        setUser(me);
      } catch {}
      const clinician =
        CLINICIAN_ROLES.includes(me?.role) || CLINICIAN_ROLES.includes(me?.account_type);
      // Demo participants whose therapist role hasn't applied yet (e.g., Google
      // sign-up, or "Patient/Client" selected at registration): grant it now and
      // reload so they land on the clinician experience — not the client flow.
      if (me && !clinician) {
        // Parents are a distinct, read-only role — send them straight to the
        // parent portal instead of the client onboarding/home flow.
        try {
          const parentLinks = await base44.entities.Parent.filter({ parent_email: me.email, status: "active" });
          if (parentLinks?.length) {
            navigate("/parent-portal", { replace: true });
            return;
          }
        } catch {}
        try {
          const demo = await isDemoParticipant(me.email);
          if (demo && !sessionStorage.getItem("wp_demo_role_attempted")) {
            sessionStorage.setItem("wp_demo_role_attempted", "1");
            try {
              await base44.functions.invoke("grant-demo-therapist-role", {
                user_id: me.id,
                email: me.email,
              });
            } catch (e) {
              console.error("Demo role grant failed:", e);
            }
            window.location.reload();
            return;
          }
        } catch {}
      } else if (clinician) {
        sessionStorage.removeItem("wp_demo_role_attempted");
        try {
          if (await isDemoParticipant(me.email)) setIsDemo(true);
        } catch {}
      }
      // New-client onboarding: prompt clients who haven't completed their initial
      // sensory profile + values inventory, unless they've skipped this session.
      if (me && !clinician) {
        try {
          const skipped = sessionStorage.getItem("wp_onboarding_skipped") === "1";
          if (!skipped) {
            const [sensory, values] = await Promise.all([
              base44.entities.AssessmentResult.filter({ test_type: "SENSORY" }, "-created_date", 1),
              base44.entities.ValuesChecklist.list("-created_date", 1),
            ]);
            const complete = (sensory?.length || 0) > 0 && (values?.length || 0) > 0;
            if (!complete) {
              navigate("/onboarding", { replace: true });
              return;
            }
          }
        } catch {}
      }
      try {
        const moods = await base44.entities.MoodEntry.list("-created_date", 1);
        setRecentMood(moods?.[0] || null);
      } catch {}
      setLoading(false);
    })();
  }, []);

  const firstName = (user?.display_name || user?.full_name || "").split(" ")[0] || "friend";
  const realIsClinician =
    CLINICIAN_ROLES.includes(user?.role) || CLINICIAN_ROLES.includes(user?.account_type);
  const isClinician = isDemo ? demoView === "therapist" : realIsClinician;

  const adminCards = [
    { title: "Therapist Portal", desc: "Manage clients, assign homework, review progress", path: "/therapist", icon: Stethoscope },
    { title: "Clinical Insights", desc: "Track client symptom trends and outcomes", path: "/insights", icon: TrendingUp },
    { title: "Organization", desc: "Practice-wide metrics and oversight", path: "/organization", icon: Building2 },
    { title: "References", desc: "APA 7th edition evidence base", path: "/references", icon: BookOpen },
    { title: "Billing", desc: "Manage your practice subscription", path: "/billing", icon: CreditCard },
  ];

  const clientCards = [
    { title: "Values Inventory", desc: "Rank your top values to guide your activities", path: "/values-inventory", icon: Compass, feature: "values" },
    { title: "Emotion Wheel", desc: "Find the right word for what you're feeling", path: "/emotions", icon: Heart, feature: "emotions" },
    { title: "Nervous System", desc: "Track sleep, stress, energy & trends", path: "/dashboard", icon: Gauge, feature: "nervous" },
    { title: "Coping Toolbox", desc: "Guided tools for when you're overwhelmed", path: "/toolbox", icon: Wrench, feature: "toolbox" },
    { title: "AI Coping Coach", desc: "Get guidance on your next step", path: "/coach", icon: Bot, feature: "coach" },
    { title: "Behavior Activation", desc: "Build enjoyable, valuable & routine activities", path: "/behavior-activation", icon: Sparkles, feature: "behavior-activation" },
    { title: "Crisis Plan", desc: "Your safety plan, ready when you need it", path: "/crisis-plan", icon: ShieldAlert, feature: "crisis" },
    { title: "Thought Record", desc: "Challenge maladaptive thoughts with CBT", path: "/cbt-journal", icon: Lightbulb, feature: "cbt" },
    { title: "Badges", desc: "Track your milestones and streaks", path: "/badges", icon: Trophy, feature: "badges" },
  ];

  const cards = isClinician ? adminCards : clientCards.filter((c) => can(c.feature));

  return (
    <div className="p-6 md:p-10 max-w-7xl mx-auto">
      {isDemo && realIsClinician && (
        <div className="mb-6 flex items-center justify-center">
          <div className="inline-flex items-center gap-1 p-1 rounded-xl bg-secondary/60 border border-border/60">
            <button
              onClick={() => setDemoView("therapist")}
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition flex items-center gap-1.5 ${demoView === "therapist" ? "bg-card text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
            >
              <Stethoscope size={15} /> Therapist view
            </button>
            <button
              onClick={() => setDemoView("client")}
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition flex items-center gap-1.5 ${demoView === "client" ? "bg-card text-accent shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
            >
              <Heart size={15} /> Client view
            </button>
          </div>
        </div>
      )}
      {isClinician ? (
        <>
          {/* Admin/clinician hero */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="mb-8"
          >
            <p className="text-sm text-muted-foreground mb-2">
              {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
            </p>
            <h1 className="font-heading text-3xl md:text-5xl font-bold text-foreground mb-3 leading-[1.1]">
              Hello, {firstName}
            </h1>
            <p className="text-muted-foreground text-lg md:text-xl">
              Manage your practice and client care.
            </p>
          </motion.div>

          {/* Admin feature cards */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {cards.map((card, i) => {
              const Icon = card.icon;
              return (
                <motion.div
                  key={card.path}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: 0.1 + i * 0.05 }}
                >
                  <Link
                    to={card.path}
                    className="block pp-card p-5 md:p-6 hover:shadow-md hover:-translate-y-0.5 transition-all group h-full"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                        <Icon size={22} className="text-primary" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-heading text-lg font-semibold mb-1">{card.title}</h3>
                        <p className="text-sm text-muted-foreground">{card.desc}</p>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>

          {/* Enterprise / Contact Sales CTA */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.3 }}
            className="mt-8"
          >
            <div className="pp-card p-6 md:p-8 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
              <div className="flex flex-col md:flex-row items-start md:items-center gap-4 justify-between">
                <div className="min-w-0">
                  <h3 className="font-heading text-xl font-semibold mb-1">Running a larger practice or health system?</h3>
                  <p className="text-sm text-muted-foreground">Custom pricing, onboarding, and multi-site analytics for 5 to thousands of clinicians.</p>
                </div>
                <Link to="/contact-sales" className="shrink-0 inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition">
                  Contact Sales <ArrowRight size={16} />
                </Link>
              </div>
            </div>
          </motion.div>
        </>
      ) : (
        <>
          {/* Client hero — split layout with device mockup */}
          <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center mb-10 md:mb-14">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              <p className="text-sm text-muted-foreground mb-2">
                {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
              </p>
              <h1 className="font-heading text-3xl md:text-5xl font-bold text-foreground mb-3 leading-[1.1]">
                Hello, {firstName}
              </h1>
              <p className="text-muted-foreground text-lg md:text-xl mb-6">
                What do you need right now?
              </p>
              <Link
                to="/emotions"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition group"
              >
                <Sparkles size={18} />
                {recentMood ? "Update your check-in" : "Check in with yourself"}
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </Link>
            </motion.div>

            {/* Phone mockup showcasing the app */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.15 }}
              className="hidden md:block"
            >
              <PhoneMockup>
                <div className="h-full flex flex-col">
                  <div className="flex items-center justify-between px-5 pt-3 pb-1 text-[10px] font-semibold text-foreground">
                    <span>9:41</span>
                    <div className="flex items-center gap-1">
                      <div className="w-3 h-2 rounded-[2px] bg-foreground/50" />
                      <div className="w-4 h-2 rounded-[2px] bg-foreground/50" />
                    </div>
                  </div>
                  <div className="px-5 pt-4">
                    <span className="font-display text-xl font-bold text-primary">WayPoint</span>
                  </div>
                  <div className="px-5 pt-3">
                    <p className="text-[10px] text-muted-foreground">Today</p>
                    <h2 className="font-heading text-lg font-bold text-foreground">Hello, {firstName}</h2>
                  </div>
                  <div className="px-5 pt-3 flex flex-col items-center">
                    <div className="relative w-28 h-28">
                      <svg viewBox="0 0 120 120" className="w-full h-full -rotate-90">
                        <circle cx="60" cy="60" r="48" fill="none" stroke="hsl(var(--secondary))" strokeWidth="8" />
                        <circle
                          cx="60"
                          cy="60"
                          r="48"
                          fill="none"
                          stroke="hsl(var(--primary))"
                          strokeWidth="8"
                          strokeLinecap="round"
                          strokeDasharray="301"
                          strokeDashoffset="84"
                        />
                      </svg>
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="font-heading text-2xl font-bold text-foreground">72</span>
                        <span className="text-[9px] text-muted-foreground">Wellbeing</span>
                      </div>
                    </div>
                  </div>
                  <div className="mx-4 mt-3 p-3 rounded-xl bg-primary/10 flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-subtleAccent/20 flex items-center justify-center shrink-0">
                      <Sparkles size={12} className="text-subtleAccent" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-[11px] font-semibold truncate text-foreground">How are you feeling?</p>
                      <p className="text-[9px] text-muted-foreground truncate">Tap to check in</p>
                    </div>
                  </div>
                  <div className="mx-4 mt-3 grid grid-cols-2 gap-2">
                    <div className="p-2.5 rounded-xl bg-card border border-border/50">
                      <Heart size={14} className="text-accent mb-1" />
                      <p className="text-[10px] font-semibold text-foreground">Emotions</p>
                    </div>
                    <div className="p-2.5 rounded-xl bg-card border border-border/50">
                      <Wrench size={14} className="text-accent mb-1" />
                      <p className="text-[10px] font-semibold text-foreground">Coping</p>
                    </div>
                  </div>
                </div>
              </PhoneMockup>
            </motion.div>
          </div>

          {/* Always-free reassurance for clients */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.2 }}
            className="mb-6 p-4 rounded-2xl bg-accent/10 border border-accent/20 flex items-center gap-3"
          >
            <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center shrink-0">
              <Heart className="text-accent" size={20} />
            </div>
            <div>
              <p className="font-heading font-semibold text-foreground">WayPoint is always free for you.</p>
              <p className="text-sm text-muted-foreground">You'll never be asked to pay for anything here — this care is fully covered.</p>
            </div>
          </motion.div>

          <ParentAccessRequests />

          {/* Mental Health Barometer */}
          <MentalHealthBarometer />

          {/* Top values — guides behavior activation */}
          <TopValuesPanel />

          {/* Feature cards */}
          <div className="grid sm:grid-cols-2 gap-4">
            {cards.map((card, i) => {
              const Icon = card.icon;
              return (
                <motion.div
                  key={card.path}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: 0.15 + i * 0.05 }}
                >
                  <Link
                    to={card.path}
                    className="block pp-card p-5 md:p-6 hover:shadow-md hover:-translate-y-0.5 transition-all group h-full"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-11 h-11 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
                        <Icon size={22} className="text-accent" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-heading text-lg font-semibold mb-1">{card.title}</h3>
                        <p className="text-sm text-muted-foreground">{card.desc}</p>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}