import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Users, CheckCircle2, Clock, Star, Heart } from "lucide-react";
import DemoFeedbackModal from "@/components/demo/DemoFeedbackModal";

export default function ClientDemoAdmin() {
  const [user, setUser] = useState(null);
  const [participants, setParticipants] = useState([]);
  const [feedbackList, setFeedbackList] = useState([]);
  const [selectedFeedback, setSelectedFeedback] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        if (me?.role !== "admin") { setLoading(false); return; }
        const [list, fb] = await Promise.all([
          base44.entities.ClientDemoParticipant.list("-created_date", 200),
          base44.entities.ClientDemoFeedback.list("-created_date", 200),
        ]);
        setParticipants(list || []);
        setFeedbackList(fb || []);
      } catch (e) {
        console.error("Client demo admin load error:", e);
      }
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (user?.role !== "admin") {
    return (
      <div className="p-10 max-w-2xl mx-auto text-center">
        <p className="text-muted-foreground">Admins only. This page tracks the client demo program.</p>
      </div>
    );
  }

  const now = Date.now();
  const feedbackByEmail = new Map(feedbackList.map((f) => [String(f.participant_email || "").toLowerCase(), f]));
  const submittedCount = participants.filter((p) => feedbackByEmail.has(String(p.email || "").toLowerCase())).length;
  const activeCount = participants.filter((p) => p.expires_at && new Date(p.expires_at).getTime() > now).length;

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Heart className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl font-semibold">Client Demo Program</h1>
          <p className="text-muted-foreground">7-day free client trials · in-app feedback survey (no gift card)</p>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-3 mb-8">
        <div className="pp-card p-4">
          <p className="text-xs text-muted-foreground">Signups</p>
          <p className="font-heading text-2xl font-semibold">{participants.length}</p>
        </div>
        <div className="pp-card p-4">
          <p className="text-xs text-muted-foreground">Feedback submitted</p>
          <p className="font-heading text-2xl font-semibold">{submittedCount} / {participants.length}</p>
        </div>
        <div className="pp-card p-4">
          <p className="text-xs text-muted-foreground">Active trials</p>
          <p className="font-heading text-2xl font-semibold">{activeCount}</p>
        </div>
        <div className="pp-card p-4">
          <p className="text-xs text-muted-foreground">Expired</p>
          <p className="font-heading text-2xl font-semibold">{participants.length - activeCount}</p>
        </div>
      </div>

      {participants.length === 0 ? (
        <div className="pp-card p-8 text-center text-muted-foreground">
          No client demo signups yet. Share your link: <span className="font-medium text-foreground">/client-demo</span>
        </div>
      ) : (
        <div className="pp-card overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-xs text-muted-foreground">
                <th className="p-3">Client</th>
                <th className="p-3">Email</th>
                <th className="p-3">Started</th>
                <th className="p-3">Expires</th>
                <th className="p-3">Status</th>
                <th className="p-3">Feedback</th>
              </tr>
            </thead>
            <tbody>
              {participants.map((p) => {
                const expired = p.expires_at && new Date(p.expires_at).getTime() <= now;
                const fb = feedbackByEmail.get(String(p.email || "").toLowerCase());
                return (
                  <tr key={p.id} className="border-b border-border/50">
                    <td className="p-3 font-medium">{p.name}</td>
                    <td className="p-3 text-muted-foreground">{p.email}</td>
                    <td className="p-3 text-muted-foreground">
                      {p.started_at ? new Date(p.started_at).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "—"}
                    </td>
                    <td className="p-3 text-muted-foreground">
                      {p.expires_at ? new Date(p.expires_at).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "—"}
                    </td>
                    <td className="p-3">
                      {expired ? (
                        <span className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-700 text-xs font-medium">Expired</span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full bg-accent/15 text-accent text-xs font-medium">Active</span>
                      )}
                    </td>
                    <td className="p-3">
                      {fb ? (
                        <button
                          onClick={() => setSelectedFeedback(fb)}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-primary/10 text-primary text-xs font-medium hover:bg-primary/20 transition"
                        >
                          <Star size={12} className="fill-amber-400 text-amber-400" /> {fb.overall_rating}/5 · View
                        </button>
                      ) : p.feedback_received ? (
                        <span className="inline-flex items-center gap-1 text-xs text-accent">
                          <CheckCircle2 size={13} /> Received
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                          <Clock size={13} /> Pending
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <DemoFeedbackModal feedback={selectedFeedback} onClose={() => setSelectedFeedback(null)} />
    </div>
  );
}