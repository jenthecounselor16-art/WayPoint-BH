import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ageFromDob } from "@/lib/childAge";
import ClientActivitySummary from "@/components/therapist/ClientActivitySummary";
import { UserCheck, Clock, Search, CalendarDays, MapPin, Mail, ClipboardList, ChevronDown, Check } from "lucide-react";

// Lists the therapist's client invitations — the records that gate a new
// client's registration. Each row shows the name, DOB, and state the client
// must match to register, plus whether the invitation is still pending or has
// been claimed by a matching client.
export default function ClientRegistrations() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all"); // all | pending | claimed
  const [activity, setActivity] = useState({}); // client_email -> { assessments, nervous, homework, goals, crisis }
  const [expandedId, setExpandedId] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        const therapistEmail = me?.email || "";
        const [data, assessments, nervous, homework, goals, crisis] = await Promise.all([
          base44.entities.ClientInvitation.filter({ therapist_email: therapistEmail }, "-created_date", 200),
          base44.entities.AssessmentResult.filter({ therapist_email: therapistEmail }, "-created_date", 500),
          base44.entities.NervousSystemMetric.filter({ therapist_email: therapistEmail }, "-created_date", 500),
          base44.entities.HomeworkAssignment.list("-created_date", 500),
          base44.entities.TherapyGoal.filter({ therapist_email: therapistEmail }, "-created_date", 500),
          base44.entities.CrisisPlan.filter({ therapist_email: therapistEmail }, "-created_date", 100),
        ]);
        setRows(data || []);

        // Aggregate the therapist's shared records per client so each row can
        // show a recent-activity summary without an extra request per client.
        const map = {};
        const add = (email, key, rec) => {
          if (!email) return;
          if (!map[email]) map[email] = { assessments: [], nervous: [], homework: [], goals: [], crisis: [] };
          map[email][key].push(rec);
        };
        (assessments || []).forEach((a) => add(a.client_email, "assessments", a));
        (nervous || []).forEach((n) => add(n.client_email, "nervous", n));
        (homework || []).forEach((h) => add(h.client_email, "homework", h));
        (goals || []).forEach((g) => add(g.client_email, "goals", g));
        (crisis || []).forEach((c) => add(c.client_email, "crisis", c));
        setActivity(map);
      } catch {}
      setLoading(false);
    })();
  }, []);

  const pending = rows.filter((r) => r.status === "pending");
  const claimed = rows.filter((r) => r.status === "claimed");
  const approved = rows.filter((r) => r.status === "approved");

  const [approving, setApproving] = useState(null);

  async function approveMatch(r) {
    setApproving(r.id);
    try {
      await base44.entities.ClientInvitation.update(r.id, { status: "approved" });
      setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, status: "approved" } : x)));
    } catch {}
    setApproving(null);
  }

  const q = search.trim().toLowerCase();
  const visible = rows
    .filter((r) => filter === "all" || r.status === filter)
    .filter((r) => !q ||
      (r.client_name || "").toLowerCase().includes(q) ||
      (r.client_email || "").toLowerCase().includes(q) ||
      (r.state || "").toLowerCase().includes(q));

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <div className="flex items-start gap-3 mb-8">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <ClipboardList className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Client Registrations</h1>
          <p className="text-muted-foreground text-lg">Review incoming client registrations and the details they must match to join your practice.</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <div className="pp-card p-4">
          <p className="text-sm text-muted-foreground">Total</p>
          <p className="font-heading text-2xl font-semibold">{rows.length}</p>
        </div>
        <div className="pp-card p-4">
          <p className="text-sm text-muted-foreground flex items-center gap-1.5"><Clock size={13} /> Pending</p>
          <p className="font-heading text-2xl font-semibold text-amber-600">{pending.length}</p>
        </div>
        <div className="pp-card p-4">
          <p className="text-sm text-muted-foreground flex items-center gap-1.5"><UserCheck size={13} /> Needs review</p>
          <p className="font-heading text-2xl font-semibold text-primary">{claimed.length}</p>
        </div>
        <div className="pp-card p-4">
          <p className="text-sm text-muted-foreground flex items-center gap-1.5"><Check size={13} /> Approved</p>
          <p className="font-heading text-2xl font-semibold text-accent">{approved.length}</p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-5">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name, email, or state…"
            className="pp-input pl-9"
          />
        </div>
        <div className="flex p-1 rounded-xl bg-secondary/60">
          {[["all", "All"], ["pending", "Pending"], ["claimed", "Needs review"], ["approved", "Approved"]].map(([key, label]) => (
            <button
              key={key}
              onClick={() => setFilter(key)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${filter === key ? "bg-card text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {visible.length === 0 ? (
        <div className="pp-card p-10 text-center">
          <ClipboardList className="mx-auto mb-4 text-muted-foreground/40" size={44} />
          <h3 className="font-heading text-xl font-semibold mb-1">No registrations found</h3>
          <p className="text-muted-foreground text-sm">Invite a client from your Therapist Portal to start tracking their registration here.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {visible.map((r) => {
            const age = ageFromDob(r.date_of_birth);
            return (
              <div key={r.id} className="pp-card p-4">
                <div className="flex items-center gap-4 flex-wrap">
                  <button
                    onClick={() => setExpandedId(expandedId === r.id ? null : r.id)}
                    className="min-w-0 flex-1 text-left"
                  >
                    <p className="font-medium truncate">{r.client_name || "—"}</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 truncate">
                      <Mail size={12} /> {r.client_email}
                    </p>
                  </button>
                  <div className="text-sm">
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <CalendarDays size={12} /> Date of birth
                    </p>
                    <p className="font-medium">
                      {r.date_of_birth ? new Date(r.date_of_birth).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "—"}
                      {age !== null && <span className="text-muted-foreground text-xs ml-1.5">({age} yrs)</span>}
                    </p>
                  </div>
                  <div className="text-sm">
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <MapPin size={12} /> State
                    </p>
                    <p className="font-medium">{r.state || "—"}</p>
                  </div>
                  {r.status === "approved" ? (
                    <span className="px-2.5 py-1 rounded-full text-xs font-medium shrink-0 bg-accent/10 text-accent flex items-center gap-1">
                      <Check size={12} /> Approved
                    </span>
                  ) : r.status === "claimed" ? (
                    <button
                      onClick={() => approveMatch(r)}
                      disabled={approving === r.id}
                      className="px-3 py-1.5 rounded-full text-xs font-medium shrink-0 bg-primary text-primary-foreground hover:opacity-90 transition disabled:opacity-50 flex items-center gap-1"
                    >
                      {approving === r.id
                        ? <span className="block w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin" />
                        : <Check size={12} />}
                      {approving === r.id ? "Approving…" : "Approve match"}
                    </button>
                  ) : (
                    <span className="px-2.5 py-1 rounded-full text-xs font-medium shrink-0 bg-amber-500/10 text-amber-600">
                      Pending
                    </span>
                  )}
                  <button
                    onClick={() => setExpandedId(expandedId === r.id ? null : r.id)}
                    className="p-1.5 rounded-lg text-muted-foreground hover:bg-secondary transition shrink-0"
                    title="Toggle recent activity"
                  >
                    <ChevronDown size={18} className={`transition-transform ${expandedId === r.id ? "rotate-180" : ""}`} />
                  </button>
                </div>
                {expandedId === r.id && (
                  <ClientActivitySummary activity={activity[r.client_email]} />
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}