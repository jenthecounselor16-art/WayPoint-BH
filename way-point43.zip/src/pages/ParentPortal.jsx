import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { ASSESSMENTS } from "@/lib/assessments";
import { Heart, Target, ClipboardList, Loader2, Users, Info, CheckCircle2, Wrench } from "lucide-react";
import { copingTools } from "@/lib/copingTools";
import ParentClinicalSummary from "@/components/parent/ParentClinicalSummary";

const TOOL_MAP = Object.fromEntries(copingTools.map((t) => [t.key, t]));

export default function ParentPortal() {
  const [loading, setLoading] = useState(true);
  const [children, setChildren] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const res = await base44.functions.invoke("parent-child-data", {});
        if (res?.data?.children) setChildren(res.data.children);
        else if (res?.data?.error) setError(res.data.error);
      } catch (e) {
        setError(e?.message || "Couldn't load your child's progress.");
      }
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 max-w-4xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Users className="text-primary" size={24} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Parent Portal</h1>
          <p className="text-muted-foreground">A read-only view of your child's progress, assessments, and shared clinical summaries.</p>
        </div>
      </div>

      {error && (
        <div className="pp-card p-4 mb-6 border-destructive/30 bg-destructive/5 text-destructive text-sm">
          {error}
        </div>
      )}

      {!loading && children.length === 0 && !error && (
        <div className="pp-card p-10 text-center">
          <Info className="mx-auto mb-4 text-muted-foreground/40" size={48} />
          <h3 className="font-heading text-xl font-semibold mb-2">No children linked yet</h3>
          <p className="text-muted-foreground max-w-md mx-auto leading-relaxed">
            Your child's therapist can invite you from their WayPoint portal. Once linked, log in with
            the email your therapist used and you'll see your child's progress here.
          </p>
        </div>
      )}

      <div className="space-y-8">
        {children.map(({ link, assessments, goals, copingFavorites, nervous }) => (
          <motion.div
            key={link.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="flex items-center gap-2 mb-4">
              <Heart size={18} className="text-primary" />
              <h2 className="font-heading text-2xl font-semibold">{link.child_name || link.child_email}</h2>
            </div>

            {/* Shared clinical summary */}
            <ParentClinicalSummary assessments={assessments} goals={goals} nervous={nervous} />

            {/* Assessment scores */}
            <div className="pp-card p-5 mb-4">
              <div className="flex items-center gap-2 mb-4">
                <ClipboardList size={18} className="text-primary" />
                <h3 className="font-heading text-lg font-semibold">Assessment Scores</h3>
              </div>
              {assessments.length === 0 ? (
                <p className="text-sm text-muted-foreground py-3 text-center">No assessments recorded yet.</p>
              ) : (
                <div className="space-y-2">
                  {assessments.map((a) => {
                    const test = ASSESSMENTS[a.test_type];
                    return (
                      <div key={a.id} className="flex items-center justify-between gap-3 p-3 rounded-xl bg-secondary/40">
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className="px-2 py-0.5 rounded-md bg-primary/10 text-primary text-xs font-bold">
                              {test?.abbr || a.test_type}
                            </span>
                            <span className="text-sm font-medium truncate">{test?.name || a.test_type}</span>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {new Date(a.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                          </p>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="font-heading text-lg font-semibold">{a.score}</p>
                          {a.severity && (
                            <p className="text-xs text-muted-foreground">{a.severity}</p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Treatment goals */}
            <div className="pp-card p-5">
              <div className="flex items-center gap-2 mb-4">
                <Target size={18} className="text-primary" />
                <h3 className="font-heading text-lg font-semibold">Treatment Goals</h3>
              </div>
              {goals.length === 0 ? (
                <p className="text-sm text-muted-foreground py-3 text-center">No treatment goals set yet.</p>
              ) : (
                <div className="space-y-3">
                  {goals.map((g) => {
                    const achieved = g.status === "achieved";
                    return (
                      <div key={g.id} className="p-3 rounded-xl bg-secondary/40">
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <p className="text-sm font-medium">{g.title}</p>
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium shrink-0 flex items-center gap-1 ${achieved ? "bg-primary/10 text-primary" : "bg-amber-500/10 text-amber-600"}`}>
                            {achieved ? <><CheckCircle2 size={11} /> Achieved</> : "Active"}
                          </span>
                        </div>
                        {g.description && <p className="text-xs text-muted-foreground mb-2">{g.description}</p>}
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <div className="flex justify-between text-xs mb-0.5">
                              <span className="text-muted-foreground">Client Progress</span>
                              <span className="font-semibold" style={{ color: "#1995A1" }}>{g.client_rating || 0}/10</span>
                            </div>
                            <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
                              <div className="h-full rounded-full" style={{ width: `${(g.client_rating || 0) * 10}%`, backgroundColor: "#1995A1" }} />
                            </div>
                          </div>
                          <div>
                            <div className="flex justify-between text-xs mb-0.5">
                              <span className="text-muted-foreground">Therapist Progress</span>
                              <span className="font-semibold" style={{ color: "#D4A055" }}>{g.therapist_rating || 0}/10</span>
                            </div>
                            <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
                              <div className="h-full rounded-full" style={{ width: `${(g.therapist_rating || 0) * 10}%`, backgroundColor: "#D4A055" }} />
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Coping tools */}
            <div className="pp-card p-5 mt-4">
              <div className="flex items-center gap-2 mb-4">
                <Wrench size={18} className="text-primary" />
                <h3 className="font-heading text-lg font-semibold">Coping Tools</h3>
              </div>
              {copingFavorites.length === 0 ? (
                <p className="text-sm text-muted-foreground py-3 text-center">No coping tools saved yet.</p>
              ) : (
                <div className="space-y-2">
                  {copingFavorites.map((f, i) => {
                    const tool = TOOL_MAP[f.tool_key];
                    return (
                      <div key={i} className="p-3 rounded-xl bg-secondary/40">
                        <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                          <span className="text-sm font-medium">{tool?.name || f.tool_key}</span>
                          {tool?.category && <span className="px-2 py-0.5 rounded-md bg-primary/10 text-primary text-xs font-medium">{tool.category}</span>}
                        </div>
                        {tool?.description && <p className="text-xs text-muted-foreground">{tool.description}</p>}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1.5">
              <Info size={12} /> This is a read-only summary shared by {link.child_name || "your child"}'s care team.
            </p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}