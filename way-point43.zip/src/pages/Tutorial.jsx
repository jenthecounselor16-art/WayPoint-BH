import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Compass, Stethoscope, LineChart, ClipboardCheck, BookCheck, Wrench, Bot,
  Heart, Lightbulb, Sparkles, Target, Users, Building2, ShieldCheck, Lock,
  Activity, BookOpen, ArrowRight, Check, BarChart3, Calendar, UserCheck, FileText,
} from "lucide-react";

const CHAPTERS = [
  { id: "overview", label: "Overview", icon: Compass },
  { id: "clinician", label: "Clinician Side", icon: Stethoscope },
  { id: "client", label: "Client Side", icon: Heart },
  { id: "workflow", label: "How It Works", icon: Activity },
  { id: "security", label: "Security & Compliance", icon: ShieldCheck },
  { id: "get-started", label: "Get Started", icon: ArrowRight },
];

const CLINICIAN_FEATURES = [
  { icon: Stethoscope, title: "Therapist Portal", desc: "A single dashboard for every client — risk alerts, wellbeing trends, homework, goals, and clinical notes, all in one place." },
  { icon: LineChart, title: "Clinical Insights", desc: "Measurement-based care with GAD-7, PHQ-9, PCL-5, BDI, BAI and more. See initial-vs-recent change, symptom trends, and a Mental Health Barometer per client." },
  { icon: ClipboardCheck, title: "Assessments", desc: "Assign validated screeners; results score automatically and flow back to you with severity bands and risk flags." },
  { icon: BookCheck, title: "Homework & Reminders", desc: "Assign between-session homework with task checklists and due dates. Automated reminders keep clients on track." },
  { icon: BookOpen, title: "Care Library", desc: "A curated, evidence-based library of CBT/DBT tools, psychoeducation, and coping strategies you can prescribe in a click." },
  { icon: FileText, title: "Medical Necessity Docs", desc: "One-click, paginated PDF packets with validated measures, functional impairment, goals, and risk — formatted for payers." },
];

const CLIENT_FEATURES = [
  { icon: Heart, title: "Emotion Wheel", desc: "A guided, evidence-based emotion inventory that helps clients name what they feel and surface patterns." },
  { icon: Wrench, title: "Coping Toolbox", desc: "A personalized set of coping skills — grounding, breathing, sensory regulation — available whenever they need them." },
  { icon: Bot, title: "AI Coping Coach", desc: "A supportive, clinician-scoped coach that walks clients through CBT thought records, crisis planning, and nervous-system regulation." },
  { icon: Lightbulb, title: "Thought Records", desc: "Structured CBT worksheets: situation, automatic thought, evidence for/against, balanced thought, and re-rated emotion." },
  { icon: Sparkles, title: "Behavior Activation", desc: "Plan enjoyable, values-aligned, and routine activities; track completion and rebuild momentum." },
  { icon: Target, title: "Therapy Goals", desc: "Collaborative goals with client and clinician progress ratings, plus guided self check-ins." },
];

const WORKFLOW = [
  { icon: UserCheck, title: "Invite & Match", desc: "You invite a client by name, DOB, and state. The client registers and must match the invitation — no mismatches, no open sign-ups." },
  { icon: Heart, title: "Client Engages", desc: "Clients use the mobile-style app to log moods, complete assessments, practice coping tools, and submit homework — between sessions." },
  { icon: LineChart, title: "Data Flows to You", desc: "Every entry is securely linked to you and appears on the client's dashboard in real time, with risk alerts surfaced first." },
  { icon: FileText, title: "Document & Decide", desc: "Generate progress reports and medical necessity packets, review trends, and adjust the treatment plan with confidence." },
];

function Section({ id, children, className = "" }) {
  return (
    <section id={id} className={`scroll-mt-24 ${className}`}>
      {children}
    </section>
  );
}

function FeatureCard({ icon: Icon, title, desc }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="pp-card p-6 hover:shadow-md transition-shadow"
    >
      <div className="w-11 h-11 rounded-xl bg-primary/10 text-primary flex items-center justify-center mb-4 shrink-0">
        <Icon size={22} />
      </div>
      <h3 className="font-heading text-lg font-semibold mb-1.5">{title}</h3>
      <p className="text-[13px] text-muted-foreground leading-relaxed">{desc}</p>
    </motion.div>
  );
}

function Step({ icon: Icon, title, desc, index }) {
  return (
    <div className="relative pl-16">
      <div className="absolute left-0 top-0 w-11 h-11 rounded-xl bg-primary text-primary-foreground flex items-center justify-center font-heading font-bold text-lg shadow-sm">
        {index}
      </div>
      <h3 className="font-heading text-lg font-semibold mb-1.5 flex items-center gap-2">
        <Icon size={18} className="text-primary" /> {title}
      </h3>
      <p className="text-[13px] text-muted-foreground leading-relaxed">{desc}</p>
    </div>
  );
}

export default function Tutorial() {
  const [active, setActive] = useState("overview");

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(e.target.id);
        });
      },
      { rootMargin: "-30% 0px -60% 0px", threshold: 0 }
    );
    CHAPTERS.forEach((c) => {
      const el = document.getElementById(c.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen pp-gradient-bg">
      {/* Top bar */}
      <header className="sticky top-0 z-30 bg-card/90 backdrop-blur border-b border-border/60">
        <div className="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Compass className="text-primary" size={22} />
            <span className="font-display text-2xl font-bold text-primary">WayPoint</span>
          </Link>
          <div className="flex items-center gap-2">
            <Link to="/contact-sales" className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-primary/10 text-primary text-sm font-medium hover:bg-primary/20 transition">
              Talk to us
            </Link>
            <Link to="/demo" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition">
              Start a demo <ArrowRight size={15} />
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-5 lg:flex lg:gap-10 lg:py-10">
        {/* Side nav (desktop) */}
        <aside className="hidden lg:block w-52 shrink-0">
          <div className="sticky top-24">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-3 px-3">Tutorial</p>
            <nav className="space-y-0.5">
              {CHAPTERS.map((c) => {
                const Icon = c.icon;
                const isActive = active === c.id;
                return (
                  <a
                    key={c.id}
                    href={`#${c.id}`}
                    className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition ${
                      isActive ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-secondary/60"
                    }`}
                  >
                    <Icon size={16} className="shrink-0" />
                    {c.label}
                  </a>
                );
              })}
            </nav>
          </div>
        </aside>

        {/* Content */}
        <main className="flex-1 min-w-0 py-8 lg:py-0 space-y-16">
          {/* Overview */}
          <Section id="overview">
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold mb-4">
                <Compass size={13} /> Product Tutorial
              </span>
              <h1 className="font-display text-3xl md:text-4xl font-bold leading-tight mb-3">
                WayPoint — a therapist-built mental health platform
              </h1>
              <p className="text-muted-foreground text-base leading-relaxed max-w-2xl">
                WayPoint brings measurement-based care, guided CBT/DBT tools, and clinical progress tracking into one
                secure platform — built by a practicing therapist for real clinical workflows. This walkthrough shows
                how your team and your clients would use it day to day.
              </p>
              <div className="flex flex-wrap gap-3 mt-6">
                <a href="#clinician" className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition">
                  Start the tour <ArrowRight size={15} />
                </a>
                <Link to="/contact-sales" className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-secondary text-secondary-foreground text-sm font-medium hover:opacity-80 transition">
                  Schedule a live demo
                </Link>
              </div>
            </motion.div>

            <div className="grid sm:grid-cols-3 gap-4 mt-8">
              {[
                { icon: Stethoscope, label: "For clinicians", desc: "Measurement-based care in one dashboard" },
                { icon: Heart, label: "For clients", desc: "Guided CBT/DBT tools between sessions" },
                { icon: ShieldCheck, label: "For enterprises", desc: "HIPAA-minded security & oversight" },
              ].map((c) => (
                <div key={c.label} className="pp-card p-5">
                  <c.icon className="text-primary mb-2" size={20} />
                  <p className="font-heading font-semibold text-sm">{c.label}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{c.desc}</p>
                </div>
              ))}
            </div>
          </Section>

          {/* Clinician side */}
          <Section id="clinician">
            <div className="flex items-center gap-2 mb-2">
              <Stethoscope className="text-primary" size={20} />
              <h2 className="font-heading text-2xl font-semibold">The clinician side</h2>
            </div>
            <p className="text-muted-foreground text-[13px] mb-6 max-w-2xl">
              Everything a provider needs to run measurement-based care: a live client roster, risk alerts, validated
              assessments, homework, goals, and one-click documentation.
            </p>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {CLINICIAN_FEATURES.map((f) => (
                <FeatureCard key={f.title} {...f} />
              ))}
            </div>
          </Section>

          {/* Client side */}
          <Section id="client">
            <div className="flex items-center gap-2 mb-2">
              <Heart className="text-primary" size={20} />
              <h2 className="font-heading text-2xl font-semibold">The client side</h2>
            </div>
            <p className="text-muted-foreground text-[13px] mb-6 max-w-2xl">
              A calm, mobile-app experience clients use between sessions — turning therapy homework into engaging,
              evidence-based skill practice.
            </p>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {CLIENT_FEATURES.map((f) => (
                <FeatureCard key={f.title} {...f} />
              ))}
            </div>
          </Section>

          {/* Workflow */}
          <Section id="workflow">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="text-primary" size={20} />
              <h2 className="font-heading text-2xl font-semibold">How it works</h2>
            </div>
            <p className="text-muted-foreground text-[13px] mb-8 max-w-2xl">
              From invitation to documented outcomes — a secure, closed-loop workflow that keeps the clinician in
              control at every step.
            </p>
            <div className="space-y-8">
              {WORKFLOW.map((s, i) => (
                <Step key={s.title} {...s} index={i + 1} />
              ))}
            </div>
          </Section>

          {/* Security */}
          <Section id="security">
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="text-primary" size={20} />
              <h2 className="font-heading text-2xl font-semibold">Security & compliance</h2>
            </div>
            <div className="grid sm:grid-cols-2 gap-4 mt-6">
              {[
                { icon: Lock, title: "Row-level data isolation", desc: "Each client's records are isolated to their clinician via row-level security — one client cannot see another's data, and clinicians only see their own roster." },
                { icon: ShieldCheck, title: "HIPAA-minded by design", desc: "PHI handling, audit logging of client-dashboard access, and consent-gated parent portal access for clients 12+." },
                { icon: UserCheck, title: "Invitation-only clients", desc: "Clients register only by matching a clinician-generated invitation (name, DOB, state) — no open sign-ups, no mismatches." },
                { icon: Building2, title: "Enterprise oversight", desc: "Organization dashboards, supervisor views, and aggregated engagement metrics for leaders — without exposing individual PHI." },
              ].map((c) => (
                <div key={c.title} className="pp-card p-5 flex gap-4">
                  <c.icon className="text-primary shrink-0 mt-0.5" size={20} />
                  <div>
                    <p className="font-heading font-semibold text-sm mb-1">{c.title}</p>
                    <p className="text-[13px] text-muted-foreground leading-relaxed">{c.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </Section>

          {/* Get started */}
          <Section id="get-started">
            <div className="pp-card p-8 md:p-10 text-center bg-gradient-to-br from-primary/10 to-accent/10 border-primary/20">
              <h2 className="font-display text-2xl md:text-3xl font-bold mb-3">Ready to see it live?</h2>
              <p className="text-muted-foreground text-[13px] max-w-xl mx-auto mb-6">
                Schedule a personalized walkthrough for your team, or start a guided demo trial to explore WayPoint
                with your own clients.
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <Link to="/contact-sales" className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition">
                  Schedule a live demo <ArrowRight size={15} />
                </Link>
                <Link to="/demo" className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-card border border-border text-sm font-medium hover:bg-secondary/60 transition">
                  Start a demo trial
                </Link>
                <Link to="/website" className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-card border border-border text-sm font-medium hover:bg-secondary/60 transition">
                  See pricing
                </Link>
              </div>
              <p className="text-[11px] text-muted-foreground mt-6">
                Share this page directly during your presentation — no login required.
              </p>
            </div>
          </Section>
        </main>
      </div>
    </div>
  );
}