import React, { useState, useEffect, useMemo } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import ClinicianGate from "@/components/ClinicianGate";
import { ASSESSMENTS } from "@/lib/assessments";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { TrendingUp, TrendingDown, Minus, BarChart3 } from "lucide-react";
import ClientBarometer from "@/components/therapist/ClientBarometer";
import ClientGoalsPanel from "@/components/therapist/ClientGoalsPanel";
import ClientHomeworkPanel from "@/components/therapist/ClientHomeworkPanel";
import ClientFunctionalImpairmentPanel from "@/components/therapist/ClientFunctionalImpairmentPanel";
import SafetyRiskBanner from "@/components/therapist/SafetyRiskBanner";

const CHART_COLORS = {
  BAI: "#E07856",
  BDI: "#6B7280",
  "PCL-5": "#8B5CF6",
  PHQ9: "#3B82F6",
  GAD7: "#EF4444",
  ISI: "#6366F1",
  K6: "#F59E0B",
  WHO5: "#10B981",
  SENSORY: "#14B8A6",
  ASRS: "#EC4899",
  YBOCS: "#5C6BC0",
  CYBOCS: "#7986CB",
  CSSRS: "#D9534F",
  SCARED: "#4DB6AC",
  SPIN: "#EC407A",
  CAGE: "#8D6E63",
  DAST: "#A1887F",
  MDQ: "#FFB300",
  PCPTSD5: "#9575CD",
  SCOFF: "#AB47BC",
};

export default function TherapistInsights() {
  return <ClinicianGate><TherapistInsightsContent /></ClinicianGate>;
}

function TherapistInsightsContent() {
  const [user, setUser] = useState(null);
  const [assessments, setAssessments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedClient, setSelectedClient] = useState(null);
  const [hiddenTests, setHiddenTests] = useState(new Set());

  useEffect(() => {
    (async () => {
      let me = null;
      try { me = await base44.auth.me(); } catch {}
      setUser(me);
      if (me?.email) {
        try {
          const data = await base44.entities.AssessmentResult.filter({ therapist_email: me.email }, "-created_date", 500);
          setAssessments(data || []);
          const firstClient = data?.find((a) => a.client_email)?.client_email;
          if (firstClient) setSelectedClient(firstClient);
        } catch {}
      }
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    setHiddenTests(new Set());
  }, [selectedClient]);

  const clients = useMemo(() => {
    const map = {};
    assessments.forEach((a) => {
      if (a.client_email && !map[a.client_email]) map[a.client_email] = true;
    });
    return Object.keys(map).sort();
  }, [assessments]);

  const clientResults = useMemo(
    () => assessments.filter((a) => a.client_email === selectedClient),
    [assessments, selectedClient]
  );

  const testTypes = useMemo(
    () => [...new Set(clientResults.map((a) => a.test_type))],
    [clientResults]
  );

  const chartData = useMemo(() => {
    const grouped = {};
    clientResults.forEach((a) => {
      const d = new Date(a.created_date);
      const dateKey = d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
      if (!grouped[dateKey]) grouped[dateKey] = { date: dateKey, _sort: d.getTime() };
      grouped[dateKey][a.test_type] = a.score;
    });
    return Object.values(grouped).sort((a, b) => a._sort - b._sort);
  }, [clientResults]);

  const summaries = useMemo(() => {
    return testTypes
      .map((type) => {
        const typeResults = clientResults
          .filter((a) => a.test_type === type)
          .sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
        const first = typeResults[0];
        const latest = typeResults[typeResults.length - 1];
        const test = ASSESSMENTS[type];
        const maxScore = test ? test.items.length * (test.scale.length - 1) : 0;
        const firstScored = test?.score(first.score);
        const latestScored = test?.score(latest.score);
        const delta = latest.score - first.score;
        const isWellbeing = type === "WHO5";
        const improving = isWellbeing ? delta > 0 : delta < 0;
        const worsening = isWellbeing ? delta < 0 : delta > 0;
        return {
          type,
          name: test?.name || type,
          abbr: test?.abbr || type,
          first,
          latest,
          delta,
          maxScore,
          firstScored,
          latestScored,
          improving,
          worsening,
          count: typeResults.length,
          color: CHART_COLORS[type] || "#999",
        };
      })
      .sort((a, b) => a.abbr.localeCompare(b.abbr));
  }, [clientResults, testTypes]);

  function toggleTest(type) {
    const next = new Set(hiddenTests);
    if (next.has(type)) next.delete(type);
    else next.add(type);
    setHiddenTests(next);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 max-w-7xl mx-auto">
      <div className="flex items-start gap-3 mb-8">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <BarChart3 className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Therapy Insights</h1>
          <p className="text-muted-foreground text-lg">Visualize symptom progression to track treatment effectiveness over time.</p>
        </div>
      </div>

      {assessments.length === 0 ? (
        <div className="pp-card p-10 text-center">
          <BarChart3 className="mx-auto mb-4 text-muted-foreground/40" size={48} />
          <h3 className="font-heading text-xl font-semibold mb-2">No assessment data yet</h3>
          <p className="text-muted-foreground">Once your clients complete assessments, their symptom trends will appear here.</p>
        </div>
      ) : (
        <>
          {/* Client selector */}
          <div className="mb-6">
            <label className="text-sm font-medium mb-2 block">Select Client</label>
            <select
              value={selectedClient || ""}
              onChange={(e) => setSelectedClient(e.target.value)}
              className="pp-input"
            >
              {clients.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <SafetyRiskBanner results={clientResults} />

          <ClientBarometer clientEmail={selectedClient} />

          {clientResults.length === 0 ? (
            <div className="pp-card p-8 text-center">
              <p className="text-muted-foreground">No assessments on record for this client yet.</p>
            </div>
          ) : (
            <>
              {/* Chart */}
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-5 mb-6 overflow-hidden">
                <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                  <h2 className="font-heading text-lg font-semibold">Symptom Progression</h2>
                  <span className="text-xs text-muted-foreground">{clientResults.length} assessments · {testTypes.length} measures</span>
                </div>

                {/* Toggleable legend */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {testTypes.map((type) => {
                    const hidden = hiddenTests.has(type);
                    const test = ASSESSMENTS[type];
                    return (
                      <button
                        key={type}
                        onClick={() => toggleTest(type)}
                        className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium transition whitespace-nowrap
                          ${hidden ? "bg-secondary/40 text-muted-foreground/50" : "bg-secondary text-foreground"}`}
                      >
                        <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: hidden ? "#ccc" : CHART_COLORS[type] }} />
                        {test?.abbr || type}
                      </button>
                    );
                  })}
                </div>

                <div className="w-full" style={{ height: 350, minWidth: 0 }}>
                  <ResponsiveContainer width="100%" height="100%" debounce={100}>
                    <LineChart data={chartData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                      <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" interval="preserveStartEnd" />
                      <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" width={32} />
                      <Tooltip contentStyle={{ borderRadius: "12px", border: "1px solid hsl(var(--border))", fontSize: "12px" }} />
                      {testTypes
                        .filter((type) => !hiddenTests.has(type))
                        .map((type) => (
                          <Line
                            key={type}
                            type="monotone"
                            dataKey={type}
                            stroke={CHART_COLORS[type]}
                            strokeWidth={2}
                            dot={{ r: 4 }}
                            connectNulls
                          />
                        ))}
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </motion.div>

              {/* Summary cards */}
              <div>
                <h2 className="font-heading text-lg font-semibold mb-3">Assessment Breakdown</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {summaries.map((s) => {
                    const deltaColor = s.delta === 0 ? "text-muted-foreground" : s.improving ? "text-green-600" : "text-red-600";
                    return (
                      <motion.div
                        key={s.type}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="pp-card p-5"
                      >
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-0.5 rounded-md text-xs font-bold" style={{ backgroundColor: `${s.color}15`, color: s.color }}>
                              {s.abbr}
                            </span>
                            <span className="text-sm font-medium">{s.name}</span>
                          </div>
                          <span className="text-xs text-muted-foreground">{s.count} {s.count === 1 ? "assessment" : "assessments"}</span>
                        </div>

                        <div className="flex items-end justify-between gap-3">
                          <div>
                            <p className="text-xs text-muted-foreground mb-1">Latest Score</p>
                            <div className="flex items-center gap-2">
                              <span className="font-heading text-2xl font-semibold">{s.latest.score}</span>
                              {s.maxScore > 0 && <span className="text-xs text-muted-foreground">/ {s.maxScore}</span>}
                              {s.latestScored && (
                                <span className="px-2 py-0.5 rounded-full text-xs font-medium" style={{ backgroundColor: `${s.latestScored.color}15`, color: s.latestScored.color }}>
                                  {s.latestScored.severity}
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground mb-1">Change from first</p>
                            <div className={`flex items-center gap-1 font-semibold text-sm ${deltaColor}`}>
                              {s.delta === 0 ? <Minus size={14} /> : s.delta > 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                              {s.delta > 0 ? `+${s.delta}` : s.delta}
                            </div>
                          </div>
                        </div>

                        <div className="mt-3 pt-3 border-t border-border/60 flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">First score: {s.first.score}</span>
                          <span className={`font-medium ${deltaColor}`}>
                            {s.delta === 0 ? "No change" : s.improving ? "Improving" : "Worsening"}
                          </span>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            </>
          )}

          <div className="grid lg:grid-cols-2 gap-6 mt-6">
            <ClientGoalsPanel clientEmail={selectedClient} therapistEmail={user?.email} />
            <ClientHomeworkPanel clientEmail={selectedClient} therapistEmail={user?.email} />
          </div>
          <div className="mt-6">
            <ClientFunctionalImpairmentPanel clientEmail={selectedClient} therapistEmail={user?.email} />
          </div>
        </>
      )}
    </div>
  );
}