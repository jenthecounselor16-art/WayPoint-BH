import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Check, Heart } from "lucide-react";
import { PLANS } from "@/lib/plans";
import EnterpriseTiers from "@/components/billing/EnterpriseTiers";
import TierComparisonGrid from "@/components/pricing/TierComparisonGrid";

// Public pricing page — viewable without signing in. Subscribing takes the
// visitor to /billing (which handles login) so this page stays read-only.
const BEST_VALUE_KEY = "starter";

export default function Pricing() {
  const freePlan = PLANS.find((p) => p.isFree);
  const clinicianPlans = PLANS.filter((p) => !p.isFree);

  return (
    <div className="max-w-7xl mx-auto px-6 md:px-10 py-14 md:py-20">
      {/* Hero */}
      <div className="text-center max-w-2xl mx-auto">
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-xs font-semibold uppercase tracking-[0.2em] text-primary mb-5"
        >
          WayPoint Pricing
        </motion.p>
        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="font-heading font-semibold tracking-tight text-4xl md:text-5xl mb-5"
        >
          Plans that scale with your practice
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-muted-foreground text-lg leading-relaxed"
        >
          Clinicians pay for the tools they use — clients are always free.
          Every plan includes a 14-day free trial. No credit card required to start.
        </motion.p>
      </div>

      {/* Free-client assurance */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="mt-10 flex items-center justify-center gap-2.5 text-sm"
      >
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-accent/10 text-accent font-medium">
          <Heart size={13} />
          Client accounts are always free — no subscription, no charge, ever.
        </span>
      </motion.div>

      {/* Clinician tiers */}
      <div className="mt-16 pt-10 border-t border-border/60">
        <h2 className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground mb-8">
          For Clinicians
        </h2>
        <TierComparisonGrid plans={clinicianPlans} bestValueKey={BEST_VALUE_KEY} />
      </div>

      {/* Enterprise */}
      <div className="mt-16 pt-10 border-t border-border/60">
        <EnterpriseTiers />
      </div>

      {/* Free client tier */}
      <div className="mt-16 pt-10 border-t border-border/60">
        <h2 className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground mb-8">
          For Individuals
        </h2>
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.55 }}
          className="p-6 md:p-8 rounded-2xl border border-border/60 bg-accent/[0.04] max-w-3xl"
        >
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
              <Heart className="text-accent" size={19} />
            </div>
            <div>
              <div className="flex items-baseline gap-2 mb-1">
                <h3 className="font-heading font-semibold text-lg">{freePlan.name}</h3>
                <span className="text-sm text-muted-foreground">$0 / forever</span>
              </div>
              <p className="text-xs text-muted-foreground mb-4">{freePlan.description}</p>
              <ul className="grid sm:grid-cols-2 gap-x-6 gap-y-2 mb-6">
                {freePlan.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-[13px] leading-snug">
                    <Check size={14} className="text-accent shrink-0 mt-0.5" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <Link
                to="/register"
                className="inline-block px-4 py-2.5 rounded-xl bg-accent text-accent-foreground text-sm font-medium hover:opacity-90 transition"
              >
                Create a free account
              </Link>
            </div>
          </div>
        </motion.div>
      </div>

      <p className="mt-14 pt-8 border-t border-border/60 text-center text-xs text-muted-foreground/60">
        Payments processed securely by Base44 Payments. Cancel anytime.
      </p>
    </div>
  );
}