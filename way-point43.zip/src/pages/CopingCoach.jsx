import React, { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Send, Sparkles, AlertCircle } from "lucide-react";

const SYSTEM_PROMPT = `You are WayPoint's AI Coping Coach. You are NOT a therapist and you do not provide therapy or diagnose conditions.

Your role:
- Explain coping skills in clear, compassionate, practical language
- Help users identify and name their emotions using emotional vocabulary
- Suggest evidence-based coping exercises appropriate to what the user is feeling
- Guide users through simple worksheets or reflection prompts when asked
- When the user asks to role-play a conversation (e.g., boundary setting, saying no, asking for what they need), play the other person in the scenario. Keep it realistic and after the role-play, offer gentle feedback on their communication style
- Keep responses warm, concise, and actionable — suggest ONE specific next step when possible
- Always prioritize safety: if the user mentions self-harm, suicide, or being in danger, urge them to call or text 988 (Suicide & Crisis Lifeline) or 911 immediately

Tone: calm, grounding, non-judgmental. Never clinical or robotic. You're like a knowledgeable friend who happens to understand coping science.

Remember: you are a complement to therapy, not a replacement. Encourage users to bring up what they learn here with their therapist or support system.`;

const STARTERS = [
  "Help me figure out what I'm feeling",
  "I'm overwhelmed and don't know what to do",
  "Suggest a grounding exercise",
  "Explain what box breathing does",
  "Role-play: I need to say no to a request",
  "Role-play: Setting a boundary with family",
  "Role-play: Asking for what I need",
];

export default function CopingCoach() {
  const [messages, setMessages] = useState([
    { role: "coach", text: "Hi, I'm your coping coach. I'm here to help you figure out your next step when things feel heavy. What's going on for you right now?" },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  async function send(text) {
    const userMsg = text || input;
    if (!userMsg.trim() || loading) return;
    setInput("");

    const newMessages = [...messages, { role: "user", text: userMsg }];
    setMessages(newMessages);
    setLoading(true);

    try {
      const conversation = newMessages
        .map((m) => (m.role === "user" ? `User: ${m.text}` : `Coach: ${m.text}`))
        .join("\n\n");

      const prompt = `${SYSTEM_PROMPT}\n\n--- Conversation so far ---\n${conversation}\n\n---\nRespond as the Coach to the user's latest message. Keep it concise (3-5 sentences unless they ask for a detailed exercise or worksheet).`;

      const result = await base44.integrations.Core.InvokeLLM({ prompt });
      setMessages([...newMessages, { role: "coach", text: result }]);
    } catch (e) {
      setMessages([...newMessages, { role: "coach", text: "I'm having trouble connecting right now. Please try again in a moment." }]);
    }
    setLoading(false);
  }

  return (
    <div className="flex flex-col h-screen md:h-screen">
      {/* Header */}
      <div className="px-6 md:px-10 py-4 border-b border-border/60 bg-card/50 backdrop-blur-sm">
        <div className="max-w-3xl mx-auto flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Sparkles className="text-primary" size={20} />
          </div>
          <div>
            <h1 className="font-heading text-lg font-semibold">AI Coping Coach</h1>
            <p className="text-xs text-muted-foreground">Not therapy — a guide for your next step</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto pp-scroll-hide px-4 md:px-10 py-6">
        <div className="max-w-3xl mx-auto space-y-4">
          {messages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed
                  ${msg.role === "user"
                    ? "bg-primary text-primary-foreground rounded-br-md"
                    : "bg-card border border-border/60 rounded-bl-md"}`}
              >
                {msg.text}
              </div>
            </motion.div>
          ))}

          {loading && (
            <div className="flex justify-start">
              <div className="bg-card border border-border/60 rounded-2xl rounded-bl-md px-4 py-3 flex gap-1.5">
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    className="w-2 h-2 rounded-full bg-muted-foreground/40"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.2 }}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Starters */}
          {messages.length === 1 && !loading && (
            <div className="pt-4 space-y-2">
              <p className="text-xs text-muted-foreground px-1">Try asking:</p>
              {STARTERS.map((s) => (
                <button
                  key={s}
                  onClick={() => send(s)}
                  className="block w-full text-left px-4 py-2.5 rounded-xl bg-secondary/60 hover:bg-secondary text-sm text-foreground/80 hover:text-foreground transition"
                >
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Input */}
      <div className="px-4 md:px-10 py-4 border-t border-border/60 bg-card/50 backdrop-blur-sm pb-20 md:pb-4">
        <div className="max-w-3xl mx-auto flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Share what's on your mind…"
            disabled={loading}
            className="pp-input flex-1"
          />
          <button
            onClick={() => send()}
            disabled={loading || !input.trim()}
            className="px-4 rounded-xl bg-primary text-primary-foreground hover:opacity-90 transition disabled:opacity-40 flex items-center justify-center"
          >
            <Send size={18} />
          </button>
        </div>
        <p className="text-xs text-muted-foreground/60 text-center mt-2">
          If you're in crisis, call or text <span className="font-semibold">988</span> — available 24/7.
        </p>
      </div>
    </div>
  );
}