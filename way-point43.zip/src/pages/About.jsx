import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Compass, TrendingUp, HeartHandshake } from "lucide-react";

export default function About() {
  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto">
      <Link to="/" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-6">
        <ArrowLeft size={16} /> Back to Home
      </Link>

      <h1 className="font-heading text-3xl md:text-4xl font-semibold mb-6">About WayPoint</h1>

      <div className="space-y-5 text-foreground/80 leading-relaxed text-base md:text-lg">
        <p>
          WayPoint is a therapist-built mental health companion that brings evidence-based cognitive behavioral therapy (CBT)
          and dialectical behavior therapy (DBT) tools, guided journaling, and clinical progress tracking into a single,
          secure application. Our mission is to bridge the gap between therapy sessions by giving clients practical tools to
          navigate difficult emotions, track their nervous system signals, and build personalized crisis plans — while
          keeping their care team informed every step of the way.
        </p>

        <p>
          WayPoint serves two audiences. For clients, it offers an emotion wheel to name what you feel, a coping toolbox with
          guided DBT and CBT skills, an AI coping coach for in-the-moment support, standardized assessments including the
          PHQ-9 and GAD-7, and functional impairment tracking that monitors sleep, self-care, and daily habits over time.
          For therapists and counseling practices, it provides a HIPAA-conscious portal to assign homework, review
          assessment trends, monitor client progress through clinical insights dashboards, and communicate securely
          through built-in messaging.
        </p>

        <p>
          WayPoint was built by a licensed therapist who understood that healing happens between sessions, not just during
          them. Every feature is grounded in established clinical practice, with references organized according to APA 7th
          edition standards, ensuring the guidance clients receive is both compassionate and scientifically sound.
        </p>
      </div>

      <div className="grid sm:grid-cols-3 gap-4 mt-8">
        <div className="pp-card p-5">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
            <Compass className="text-primary" size={20} />
          </div>
          <h2 className="font-heading text-base font-semibold mb-1">Guidance</h2>
          <p className="text-sm text-muted-foreground">Expert-built CBT &amp; DBT tools that guide your next step.</p>
        </div>
        <div className="pp-card p-5">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
            <TrendingUp className="text-primary" size={20} />
          </div>
          <h2 className="font-heading text-base font-semibold mb-1">Progress</h2>
          <p className="text-sm text-muted-foreground">Clinical-grade tracking reveals your growth over time.</p>
        </div>
        <div className="pp-card p-5">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
            <HeartHandshake className="text-primary" size={20} />
          </div>
          <h2 className="font-heading text-base font-semibold mb-1">Connected Care</h2>
          <p className="text-sm text-muted-foreground">Your therapist walks alongside you in real time.</p>
        </div>
      </div>
    </div>
  );
}