import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Stethoscope, Check, ArrowLeft, HeartPulse, TrendingUp, Sparkles } from "lucide-react";

// Copenhagen Burnout Inventory (Kristensen et al., 2005) — free to use.
const SCALE = [
  { label: "Always", value: 100 },
  { label: "Often", value: 75 },
  { label: "Sometimes", value: 50 },
  { label: "Seldom", value: 25 },
  { label: "Never", value: 0 },
];

const PERSONAL_ITEMS = [
  "How often do you feel tired?",
  "How often are you physically exhausted?",
  "How often are you emotionally exhausted?",
  "How often do you think, \u201cI can\u2019t take it anymore\u201d?",
  "How often do you feel worn out?",
  "How often do you feel weak and susceptible to illness?",
];

const WORK_ITEMS = [
  "Is your work physically exhausting?",
  "Does your work frustrate you?",
  "Do you feel burned out by your work?",
  "Do you feel worn out after a day at work?",
  "Are you exhausted in the morning at the thought of another day at work?",
  "Do you feel that every working hour is tiring for you?",
  "Do you have enough energy for family and friends during leisure time?",
];

const REVERSE_INDEXES = new Set([WORK_ITEMS.length - 1]); // last work item is reverse-scored

const ALL = [...PERSONAL_ITEMS, ...WORK_ITEMS];

function bandFor(score) {
  if (score < 25) return { label: "Low", color: "#7CB69D", blurb: "You\u2019re holding steady. Keep protecting the basics \u2014 sleep, connection, and a real end to your workday." };
  if (score < 50) return { label: "Moderate", color: "#D4A055", blurb: "Some signs of strain are showing. This is a good moment to lean on peer consultation, protect a client-free lunch, and notice what you\u2019re carrying." };
  if (score < 75) return { label: "High", color: "#E07856", blurb: "Burnout is present. Talk with a supervisor about your caseload, consider your own therapy, and treat replenishment as a clinical obligation." };
  return { label: "Very High", color: "#D9534F", blurb: "Please take this seriously \u2014 your wellbeing matters as much as your clients\u2019. Reach out to peers, a supervisor, or your own clinician this week." };
}

export default function BurnoutCheckin() {
  const [answers, setAnswers] = useState({}); // index -> SCALE value (0/25/50/75/100)
  const [submitted, setSubmitted] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        const h = await base44.entities.TherapistBurnoutCheckin.list("-created_date", 12);
        setHistory(h || []);
      } catch {}
      setLoading(false);
    })();
  }, []);

  const answeredCount = Object.keys(answers).length;
  const complete = answeredCount === ALL.length;

  function score() {
    const personalVals = PERSONAL_ITEMS.map((_, i) => answers[i]).filter((v) => v != null);
    const workVals = WORK_ITEMS.map((_, j) => answers[PERSONAL_ITEMS.length + j]).filter((v) => v != null);
    // reverse-score the leisure-energy item
    const workAdj = WORK_ITEMS.map((_, j) => {
      const raw = answers[PERSONAL_ITEMS.length + j];
      if (raw == null) return null;
      return REVERSE_INDEXES.has(j) ? 100 - raw : raw;
    }).filter((v) => v != null);
    const avg = (vals) => (vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0);
    const p = avg(personalVals);
    const w = avg(workAdj);
    const overall = personalVals.length && workAdj.length ? (p + w) / 2 : 0;
    return { personal: Math.round(p), work: Math.round(w), overall: Math.round(overall) };
  }

  async function submit() {
    if (!complete) return;
    const s = score();
    const band = bandFor(s.overall);
    const rawAnswers = ALL.map((_, i) => (answers[i] != null ? answers[i] / 25 : 0));
    setSaving(true);
    try {
      await base44.entities.TherapistBurnoutCheckin.create({
        personal_score: s.personal,
        work_score: s.work,
        overall_score: s.overall,
        severity: band.label,
        answers: rawAnswers,
        therapist_email: user?.email || "",
      });
      const h = await base44.entities.TherapistBurnoutCheckin.list("-created_date", 12);
      setHistory(h || []);
    } catch {}
    setSaving(false);
    setSubmitted({ ...s, band });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function reset() {
    setAnswers({});
    setSubmitted(null);
  }

  if (submitted) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-10">
        <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-6">
          <ArrowLeft size={16} /> Back to WayPoint
        </Link>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-8 text-center">
          <div className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ background: `${submitted.band.color}15` }}>
            <HeartPulse size={30} style={{ color: submitted.band.color }} />
          </div>
          <p className="text-sm text-muted-foreground uppercase tracking-wide font-semibold mb-1">Your burnout score</p>
          <p className="font-heading text-5xl font-bold mb-2" style={{ color: submitted.band.color }}>{submitted.overall}<span className="text-2xl text-muted-foreground">/100</span></p>
          <span className="inline-block px-4 py-1 rounded-full text-sm font-semibold mb-4" style={{ backgroundColor: `${submitted.band.color}15`, color: submitted.band.color }}>
            {submitted.band.label}
          </span>
          <p className="text-muted-foreground leading-relaxed mb-6 max-w-md mx-auto">{submitted.band.blurb}</p>

          <div className="grid grid-cols-2 gap-4 mb-6 text-left">
            <div className="rounded-xl bg-secondary/40 p-4">
              <p className="text-xs text-muted-foreground">Personal burnout</p>
              <p className="font-heading text-2xl font-semibold">{submitted.personal}<span className="text-base text-muted-foreground">/100</span></p>
            </div>
            <div className="rounded-xl bg-secondary/40 p-4">
              <p className="text-xs text-muted-foreground">Work burnout</p>
              <p className="font-heading text-2xl font-semibold">{submitted.work}<span className="text-base text-muted-foreground">/100</span></p>
            </div>
          </div>

          <div className="rounded-xl bg-accent/5 border border-accent/20 p-4 mb-6 text-left">
            <p className="text-sm flex items-start gap-2">
              <Sparkles size={16} className="text-accent shrink-0 mt-0.5" />
              <span className="text-muted-foreground">Your score has been saved so you can watch your trend over time. Check in again next week.</span>
            </p>
          </div>

          {history.length > 1 && (
            <div className="text-left mb-6">
              <p className="text-sm font-medium mb-2 flex items-center gap-1.5"><TrendingUp size={15} className="text-primary" /> Recent trend</p>
              <div className="flex items-end gap-2 h-24">
                {[...history].reverse().map((h, i) => {
                  const b = bandFor(h.overall_score);
                  return (
                    <div key={h.id} className="flex-1 flex flex-col items-center justify-end" title={`${new Date(h.created_date).toLocaleDateString()} — ${h.overall_score} (${b.label})`}>
                      <span className="text-[10px] text-muted-foreground mb-0.5">{Math.round(h.overall_score)}</span>
                      <div className="w-full rounded-t-md" style={{ height: `${h.overall_score}%`, background: b.color }} />
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <button onClick={reset} className="px-6 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition">
            Take it again
          </button>
        </motion.div>
      </div>
    );
  }

  const sections = [
    { title: "Personal burnout", subtitle: "Thinking about the past few months, how often has each been true?", items: PERSONAL_ITEMS, offset: 0 },
    { title: "Work burnout", subtitle: "Now thinking about your work specifically:", items: WORK_ITEMS, offset: PERSONAL_ITEMS.length },
  ];

  return (
    <div className="max-w-2xl mx-auto px-4 py-10">
      <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-6">
        <ArrowLeft size={16} /> Back to WayPoint
      </Link>

      <div className="flex items-center gap-3 mb-2">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Stethoscope className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-2xl md:text-3xl font-semibold">Weekly Burnout Check-in</h1>
          <p className="text-muted-foreground">Copenhagen Burnout Inventory</p>
        </div>
      </div>
      <p className="text-sm text-muted-foreground mb-8">
        A brief, validated self-rating (Kristensen et al., 2005). Be honest &mdash; this is for <em>you</em>. Your answers stay private to your account.
      </p>

      <div className="mb-6">
        <div className="h-2 rounded-full bg-secondary overflow-hidden">
          <div className="h-full bg-primary rounded-full transition-all duration-300" style={{ width: `${(answeredCount / ALL.length) * 100}%` }} />
        </div>
        <p className="text-xs text-muted-foreground mt-1.5">{answeredCount} of {ALL.length} answered</p>
      </div>

      {loading ? (
        <div className="flex justify-center py-10"><div className="w-7 h-7 border-4 border-secondary border-t-primary rounded-full animate-spin" /></div>
      ) : (
        <div className="space-y-8">
          {sections.map((sec) => (
            <div key={sec.title}>
              <h2 className="font-heading text-lg font-semibold mb-1">{sec.title}</h2>
              <p className="text-sm text-muted-foreground mb-4">{sec.subtitle}</p>
              <div className="space-y-3">
                {sec.items.map((q, i) => {
                  const absIdx = sec.offset + i;
                  const isReverse = REVERSE_INDEXES.has(i) && sec.title === "Work burnout";
                  return (
                    <div key={absIdx} className="pp-card p-4">
                      <p className="text-sm font-medium mb-3">
                        {q}
                        {isReverse && <span className="ml-1 text-xs text-muted-foreground">(reverse-scored)</span>}
                      </p>
                      <div className="grid grid-cols-5 gap-2">
                        {SCALE.map((opt) => {
                          const selected = answers[absIdx] === opt.value;
                          return (
                            <button
                              key={opt.value}
                              onClick={() => setAnswers({ ...answers, [absIdx]: opt.value })}
                              className={`px-2 py-2 rounded-lg text-xs font-medium border transition ${
                                selected
                                  ? "bg-primary text-primary-foreground border-primary"
                                  : "bg-white border-border text-muted-foreground hover:border-primary/40 hover:text-foreground"
                              }`}
                            >
                              {opt.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}

          <button
            onClick={submit}
            disabled={!complete || saving}
            className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {saving ? <span className="block w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" /> : <Check size={18} />}
            {saving ? "Saving…" : complete ? "Score my burnout" : `Answer all ${ALL.length} questions to continue`}
          </button>
        </div>
      )}

      <p className="text-xs text-muted-foreground text-center mt-6">
        This self-check is for your own awareness and is not a clinical diagnosis. If you're struggling, please reach out to a trusted colleague, supervisor, or your own clinician.
      </p>
    </div>
  );
}