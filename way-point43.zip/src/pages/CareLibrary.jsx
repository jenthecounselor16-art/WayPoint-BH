import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import ClinicianGate from "@/components/ClinicianGate";
import { CARE_TEMPLATES } from "@/lib/careTemplates";
import { copingTools } from "@/lib/copingTools";
import { useToast } from "@/components/ui/use-toast";
import { logGoalCheckin } from "@/lib/goalProgress";
import { LayoutTemplate, Target, ClipboardList, Wrench, Check, ChevronDown, ChevronUp, Loader2, Users } from "lucide-react";

function toolName(key) {
  const t = copingTools.find((c) => c.key === key);
  return t?.name || key;
}

export default function CareLibrary() {
  return <ClinicianGate><CareLibraryContent /></ClinicianGate>;
}

function CareLibraryContent() {
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedEmail, setSelectedEmail] = useState("");
  const [expanded, setExpanded] = useState(null);
  const [applying, setApplying] = useState(null);
  const [applied, setApplied] = useState({});

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        const cl = await base44.entities.Client.filter(
          { therapist_email: me?.email || "" }, "-created_date", 200
        );
        setClients(cl || []);
      } catch {}
      setLoading(false);
    })();
  }, []);

  const selectedClient = clients.find((c) => c.client_email === selectedEmail);

  async function applyTemplate(tpl) {
    if (!selectedEmail) return;
    setApplying(tpl.key);
    try {
      const therapistEmail = user?.email || "";
      const clientName = selectedClient?.client_name || selectedEmail;

      const goals = tpl.goals.map((g) => ({
        title: g.title,
        description: g.description || "",
        client_email: selectedEmail,
        therapist_email: therapistEmail,
        client_rating: 0,
        therapist_rating: 0,
        status: "active",
      }));

      const homework = tpl.homework.map((h) => ({
        title: h.title,
        description: h.description || "",
        client_email: selectedEmail,
        client_name: clientName,
        therapist_email: therapistEmail,
        tasks: h.tasks || [],
        status: "assigned",
        completion_percentage: 0,
      }));

      if (tpl.copingTools?.length) {
        homework.push({
          title: "Recommended Coping Tools",
          description: "Practice these tools from your Coping Toolbox this week.",
          client_email: selectedEmail,
          client_name: clientName,
          therapist_email: therapistEmail,
          tasks: tpl.copingTools.map((k) => `Try: ${toolName(k)} (open in Coping Toolbox)`),
          status: "assigned",
          completion_percentage: 0,
        });
      }

      if (goals.length) {
        const createdGoals = await base44.entities.TherapyGoal.bulkCreate(goals);
        for (const g of createdGoals || []) await logGoalCheckin(g, "therapist");
      }
      if (homework.length) await base44.entities.HomeworkAssignment.bulkCreate(homework);

      setApplied((a) => ({ ...a, [tpl.key]: true }));
      toast({
        title: "Template applied",
        description: `${goals.length} goal${goals.length === 1 ? "" : "s"} and ${homework.length} homework item${homework.length === 1 ? "" : "s"} assigned to ${clientName}.`,
      });
    } catch (e) {
      toast({ title: "Couldn't apply template", description: e?.message || "Please try again.", variant: "destructive" });
    }
    setApplying(null);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <div className="flex items-start gap-3 mb-8">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <LayoutTemplate className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Care Template Library</h1>
          <p className="text-muted-foreground text-lg">Assign a pre-set bundle of goals, coping tools, and homework to a client in one click.</p>
        </div>
      </div>

      <div className="pp-card p-4 mb-8">
        <label className="text-sm font-medium mb-2 flex items-center gap-1.5">
          <Users size={15} className="text-muted-foreground" /> Assign to client
        </label>
        {clients.length === 0 ? (
          <p className="text-sm text-muted-foreground">You have no linked clients yet. Add a client from your Therapist Portal first.</p>
        ) : (
          <select
            value={selectedEmail}
            onChange={(e) => { setSelectedEmail(e.target.value); setApplied({}); }}
            className="pp-input"
          >
            <option value="" disabled>Select a client…</option>
            {clients.map((c) => (
              <option key={c.id} value={c.client_email}>{c.client_name || c.client_email} — {c.client_email}</option>
            ))}
          </select>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {CARE_TEMPLATES.map((tpl) => {
          const isOpen = expanded === tpl.key;
          const done = applied[tpl.key];
          return (
            <motion.div key={tpl.key} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-5 flex flex-col">
              <div className="flex items-start justify-between gap-3 mb-2">
                <div>
                  <span className="px-2.5 py-1 rounded-lg text-xs font-bold" style={{ backgroundColor: `${tpl.color}15`, color: tpl.color }}>
                    {tpl.category}
                  </span>
                  <h3 className="font-heading text-lg font-semibold mt-2">{tpl.name}</h3>
                </div>
              </div>
              <p className="text-sm text-muted-foreground mb-3">{tpl.description}</p>

              <div className="flex flex-wrap gap-3 text-xs text-muted-foreground mb-3">
                <span className="flex items-center gap-1"><Target size={13} /> {tpl.goals.length} goals</span>
                <span className="flex items-center gap-1"><ClipboardList size={13} /> {tpl.homework.length} homework</span>
                <span className="flex items-center gap-1"><Wrench size={13} /> {tpl.copingTools.length} coping tools</span>
              </div>

              <button
                onClick={() => setExpanded(isOpen ? null : tpl.key)}
                className="text-xs text-primary hover:underline text-left mb-3 flex items-center gap-1"
              >
                {isOpen ? <><ChevronUp size={13} /> Hide details</> : <><ChevronDown size={13} /> Preview contents</>}
              </button>

              {isOpen && (
                <div className="text-sm space-y-3 mb-4 pl-1">
                  <div>
                    <p className="text-xs font-semibold uppercase text-muted-foreground mb-1">Goals</p>
                    <ul className="space-y-1">
                      {tpl.goals.map((g, i) => (
                        <li key={i} className="text-sm text-foreground/80 flex items-start gap-1.5">
                          <Target size={13} className="shrink-0 mt-0.5 text-muted-foreground" /> {g.title}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <p className="text-xs font-semibold uppercase text-muted-foreground mb-1">Homework</p>
                    <ul className="space-y-1">
                      {tpl.homework.map((h, i) => (
                        <li key={i} className="text-sm text-foreground/80 flex items-start gap-1.5">
                          <ClipboardList size={13} className="shrink-0 mt-0.5 text-muted-foreground" /> {h.title}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <p className="text-xs font-semibold uppercase text-muted-foreground mb-1">Coping tools</p>
                    <div className="flex flex-wrap gap-1.5">
                      {tpl.copingTools.map((k) => (
                        <span key={k} className="px-2 py-0.5 rounded-md bg-secondary text-xs">{toolName(k)}</span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-auto">
                <button
                  onClick={() => applyTemplate(tpl)}
                  disabled={!selectedEmail || applying === tpl.key}
                  className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {applying === tpl.key ? (
                    <><Loader2 size={15} className="animate-spin" /> Assigning…</>
                  ) : done ? (
                    <><Check size={15} /> Applied — assign again</>
                  ) : (
                    <><LayoutTemplate size={15} /> Apply to client</>
                  )}
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}