import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from "recharts";
import {
  Building2,
  TrendingUp,
  CheckCircle2,
  ClipboardCheck,
  Users,
  Stethoscope,
  Target,
} from "lucide-react";
import OrgMetricCard from "@/components/OrgMetricCard";
import InviteTherapists from "@/components/therapist/InviteTherapists";

export default function OrganizationDashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const response = await base44.functions.invoke("organization-metrics", {});
        setData(response.data);
      } catch (err) {
        const status = err?.response?.status;
        const msg = err?.response?.data?.error || err?.message || "Unable to load organization metrics";
        setError({ message: msg, forbidden: status === 403 });
      }
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 md:p-10 max-w-5xl mx-auto">
        <div className="pp-card p-8 text-center">
          <Building2 className="mx-auto mb-4 text-muted-foreground/40" size={48} />
          <h3 className="font-heading text-xl font-semibold mb-2">{error.forbidden ? "Access Restricted" : "Couldn't Load Organization Data"}</h3>
          <p className="text-muted-foreground">{error.message}</p>
        </div>
      </div>
    );
  }

  if (!data) return null;

  const therapistChartData = (data.therapistUtilization.breakdown || []).map((t) => ({
    name: t.label,
    Clients: t.clients,
    Homework: t.homework,
    Assessments: t.assessments,
  }));

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-start gap-3 mb-8">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Building2 className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Organization Dashboard</h1>
          <p className="text-muted-foreground text-lg">
            Aggregated, de-identified metrics across all clinicians and clients.
          </p>
        </div>
      </div>

      <InviteTherapists />

      {/* Metric cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        <OrgMetricCard
          icon={TrendingUp}
          label="Avg. Symptom Improvement"
          value={`${data.symptomImprovement.avgChange} pts`}
          subtitle={`${data.symptomImprovement.improvementRate}% of clients improving`}
          detail={`${data.symptomImprovement.clientsImproved}/${data.symptomImprovement.clientsTotal} clients · ${data.symptomImprovement.comparisons} data points`}
          color="#10B981"
          delay={0}
        />
        <OrgMetricCard
          icon={CheckCircle2}
          label="Homework Completion"
          value={`${data.homework.completionRate}%`}
          subtitle={`${data.homework.completed} of ${data.homework.total} assignments`}
          color="#5B8FB9"
          delay={0.05}
        />
        <OrgMetricCard
          icon={ClipboardCheck}
          label="Assessment Completion"
          value={`${data.assessments.completionRate}%`}
          subtitle={`${data.assessments.completed} of ${data.assessments.total} assigned`}
          color="#8B7CB6"
          delay={0.1}
        />
        <OrgMetricCard
          icon={Users}
          label="Client Engagement"
          value={`${data.engagement.activeClients} active`}
          subtitle={`${data.engagement.avgEngagementPerClient} avg interactions/client`}
          detail={`${data.engagement.metricEntries} metrics · ${data.engagement.journalEntries} journals`}
          color="#D4906A"
          delay={0.15}
        />
        <OrgMetricCard
          icon={Stethoscope}
          label="Therapist Utilization"
          value={`${data.therapistUtilization.therapistCount} active`}
          subtitle={`${data.therapistUtilization.avgClientsPerTherapist} avg clients/therapist`}
          detail={`${data.therapistUtilization.totalAssignments} total assignments · ${data.therapistUtilization.avgAssignmentsPerTherapist} avg/therapist`}
          color="#E07856"
          delay={0.2}
        />
        <OrgMetricCard
          icon={Target}
          label="Program Outcomes"
          value={`${data.programOutcomes.goalAchievementRate}%`}
          subtitle={`${data.programOutcomes.goalsAchieved} of ${data.programOutcomes.goalsTotal} goals achieved`}
          color="#7CB69D"
          delay={0.25}
        />
      </div>

      {/* Therapist utilization chart */}
      {therapistChartData.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="pp-card p-5 mb-6 overflow-hidden"
        >
          <h2 className="font-heading text-lg font-semibold mb-4">Therapist Utilization Breakdown</h2>
          <div className="flex gap-x-4 gap-y-2 flex-wrap mb-4">
            {[
              { key: "Clients", color: "#5B8FB9" },
              { key: "Homework", color: "#E07856" },
              { key: "Assessments", color: "#8B7CB6" },
            ].map((s) => (
              <span key={s.key} className="flex items-center gap-1.5 text-xs text-muted-foreground whitespace-nowrap">
                <span className="w-3 h-3 rounded-sm shrink-0" style={{ backgroundColor: s.color }} />
                {s.key}
              </span>
            ))}
          </div>
          <div className="w-full" style={{ height: 300 }}>
            <ResponsiveContainer width="100%" height="100%" debounce={100}>
              <BarChart data={therapistChartData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" width={32} />
                <Tooltip
                  contentStyle={{ borderRadius: "12px", border: "1px solid hsl(var(--border))", fontSize: "12px" }}
                />
                <Bar dataKey="Clients" fill="#5B8FB9" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Homework" fill="#E07856" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Assessments" fill="#8B7CB6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      )}

      {/* Caseload table */}
      {data.therapistUtilization.breakdown.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          className="pp-card p-5 overflow-hidden mb-6"
        >
          <h2 className="font-heading text-lg font-semibold mb-4">Caseload Summary</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left border-b border-border/60">
                  <th className="pb-3 font-medium text-muted-foreground">Therapist</th>
                  <th className="pb-3 font-medium text-muted-foreground text-right">Clients</th>
                  <th className="pb-3 font-medium text-muted-foreground text-right">Homework</th>
                  <th className="pb-3 font-medium text-muted-foreground text-right">Assessments</th>
                  <th className="pb-3 font-medium text-muted-foreground text-right">Total</th>
                </tr>
              </thead>
              <tbody>
                {data.therapistUtilization.breakdown.map((t) => (
                  <tr key={t.label} className="border-b border-border/40 last:border-0">
                    <td className="py-3 font-medium">{t.label}</td>
                    <td className="py-3 text-right">{t.clients}</td>
                    <td className="py-3 text-right">{t.homework}</td>
                    <td className="py-3 text-right">{t.assessments}</td>
                    <td className="py-3 text-right font-semibold">{t.totalAssignments}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      )}

      {/* De-identification notice */}
      <div className="p-4 rounded-xl bg-secondary/30 text-center">
        <p className="text-xs text-muted-foreground">
          All metrics are de-identified and aggregated. Individual client and therapist identities are not displayed.
        </p>
      </div>
    </div>
  );
}