import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { ClipboardCheck, Send, RefreshCw, Loader2 } from "lucide-react";
import MessageBubble from "@/components/chat/MessageBubble";

export default function GoalCheckin() {
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(true);
  const [agentBusy, setAgentBusy] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    startConversation();
  }, []);

  async function startConversation() {
    setLoading(true);
    setMessages([]);
    setAgentBusy(false);
    try {
      const conv = await base44.agents.createConversation({
        agent_name: "goal_checkin",
        metadata: { name: "Goal Check-in Session" },
      });
      setConversation(conv);
      setMessages(conv.messages || []);
    } catch (e) {
      console.error("Failed to create conversation:", e);
    }
    setLoading(false);
  }

  useEffect(() => {
    if (!conversation?.id) return;
    const unsubscribe = base44.agents.subscribeToConversation(conversation.id, (data) => {
      const msgs = data.messages || [];
      setMessages(msgs);
      const last = msgs[msgs.length - 1];
      const busy =
        !last ||
        last.role === "user" ||
        (last.role === "assistant" &&
          last.tool_calls?.some((tc) =>
            ["pending", "running", "in_progress"].includes(tc.status)
          ));
      setAgentBusy(busy);
    });
    return () => unsubscribe();
  }, [conversation?.id]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function sendMessage(text) {
    const content = (text ?? input).trim();
    if (!content || !conversation || agentBusy) return;
    setInput("");
    setAgentBusy(true);
    setMessages((prev) => [...prev, { role: "user", content }]);
    try {
      await base44.agents.addMessage(conversation, { role: "user", content });
    } catch (e) {
      console.error("Failed to send message:", e);
      setAgentBusy(false);
    }
  }

  function handleKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="animate-spin text-primary" size={32} />
          <p className="text-sm text-muted-foreground">Starting your check-in…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto flex flex-col" style={{ minHeight: "calc(100vh - 220px)" }}>
      {/* Header */}
      <div className="flex items-start gap-3 mb-4">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <ClipboardCheck className="text-primary" size={22} />
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="font-heading text-2xl md:text-3xl font-semibold">Goal Check-in</h1>
          <p className="text-sm text-muted-foreground">Reviews every active therapy goal against the latest assessment insights for your clients.</p>
        </div>
        <button
          onClick={startConversation}
          className="px-3 py-2 rounded-xl text-sm text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition flex items-center gap-1.5 shrink-0"
          title="Start a new session"
        >
          <RefreshCw size={16} /> New
        </button>
      </div>

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 pp-scroll-hide min-h-[300px]">
        {messages.length === 0 ? (
          <div className="pp-card p-8 text-center">
            <ClipboardCheck className="mx-auto mb-3 text-primary/40" size={36} />
            <p className="text-sm text-muted-foreground mb-4">Run a caseload check-in to see how each client's latest assessments relate to their goals.</p>
            <button
              onClick={() => sendMessage("Run a check-in on all my active therapy goals using the latest assessment results.")}
              className="px-4 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition"
            >
              Run check-in
            </button>
          </div>
        ) : (
          messages.map((msg, i) => <MessageBubble key={i} message={msg} />)
        )}
        {agentBusy && messages.length > 0 && (
          <div className="flex justify-start">
            <div className="bg-card border border-border/60 px-4 py-3 rounded-2xl rounded-tl-md flex items-center gap-2">
              <Loader2 size={14} className="animate-spin text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Reviewing goals…</span>
            </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      {/* Input */}
      <div className="pp-card p-3 flex items-end gap-2">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask about a specific client or request updates…"
          rows={1}
          className="flex-1 bg-transparent resize-none outline-none text-sm px-2 py-2 max-h-32 leading-relaxed"
          disabled={agentBusy}
        />
        <button
          onClick={() => sendMessage()}
          disabled={!input.trim() || agentBusy}
          className="w-10 h-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center hover:opacity-90 transition disabled:opacity-40 shrink-0"
        >
          <Send size={18} />
        </button>
      </div>
      <p className="text-xs text-muted-foreground/50 text-center mt-2">
        Clinical aid only — the agent won't change a goal without your confirmation.
      </p>
    </div>
  );
}