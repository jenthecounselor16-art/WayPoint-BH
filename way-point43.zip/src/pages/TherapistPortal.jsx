import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { ASSESSMENTS } from "@/lib/assessments";
import {
  Stethoscope, Plus, Trash2, Check, Clock, ChevronDown, Calendar, CalendarPlus, Mail, Send, Shield, Users, TrendingUp, TrendingDown, Search
} from "lucide-react";
import { downloadHomeworkICS } from "@/lib/ics";
import ClientDashboard from "@/components/therapist/ClientDashboard";
import ClientEmotionTrendChart from "@/components/therapist/ClientEmotionTrendChart";
import BehaviorActivationSummary from "@/components/therapist/BehaviorActivationSummary";
import InactiveClientsSummary from "@/components/therapist/InactiveClientsSummary";
import ClientProgressSnapshot from "@/components/therapist/ClientProgressSnapshot";
import RiskAlertsSummary from "@/components/therapist/RiskAlertsSummary";
import { isDemoParticipant } from "@/lib/demoTracking";
import { useSubscribeRefresh } from "@/hooks/useSubscribeRefresh";

const DAY = 86400000;

const US_STATES = ["AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"];

function wellbeingOf(a) {
  const test = ASSESSMENTS[a.test_type];
  if (!test) return null;
  const maxScore = test.items.length * (test.scale.length - 1);
  if (!maxScore) return null;
  const ratio = a.score / maxScore;
  return a.test_type === "WHO5" ? ratio * 100 : (1 - ratio) * 100;
}

function barometerAt(assessments, asOfMs) {
  const latest = {};
  assessments.forEach((a) => {
    if (new Date(a.created_date).getTime() > asOfMs) return;
    if (!latest[a.test_type] || new Date(a.created_date) > new Date(latest[a.test_type].created_date)) {
      latest[a.test_type] = a;
    }
  });
  const scores = Object.values(latest).map(wellbeingOf).filter((s) => s !== null);
  if (!scores.length) return null;
  return scores.reduce((x, y) => x + y, 0) / scores.length;
}

function timeAgo(ms) {
  if (!ms) return "—";
  const diff = Date.now() - ms;
  const days = Math.floor(diff / DAY);
  if (days <= 0) return "today";
  if (days === 1) return "1d ago";
  if (days < 30) return `${days}d ago`;
  return `${Math.floor(days / 30)}mo ago`;
}

const RISK_WINDOW = 14 * DAY;

// Examines a client's recent (last 14-day) nervous-system check-ins, sorted
// newest-first, and returns a risk flag with a reason when elevated symptoms
// or a worsening trend are present. Returns null when nothing is flagged.
function assessRisk(nsSorted) {
  if (!nsSorted || !nsSorted.length) return null;
  const recent = nsSorted.filter((n) => Date.now() - new Date(n.created_date).getTime() <= RISK_WINDOW);
  if (!recent.length) return null;
  const latest = recent[0];
  const distress = (n) =>
    n == null ? null : ((n.anxiety_level ?? 0) + (n.depression_level ?? 0) + (n.stress_level ?? 0)) / 3;

  // High-risk: single elevated symptom in the latest check-in
  const parts = [];
  if ((latest.anxiety_level ?? 0) >= 8) parts.push(`anxiety ${latest.anxiety_level}/10`);
  if ((latest.depression_level ?? 0) >= 8) parts.push(`depression ${latest.depression_level}/10`);
  if ((latest.stress_level ?? 0) >= 9) parts.push(`stress ${latest.stress_level}/10`);
  if (parts.length) return { level: "high", reason: `Elevated: ${parts.join(", ")}`, date: latest.created_date };

  // Trend concern: distress rising across recent check-ins (need >= 4)
  if (recent.length >= 4) {
    const mid = Math.floor(recent.length / 2);
    const newer = recent.slice(0, mid);
    const older = recent.slice(mid);
    const avg = (arr) => {
      const ds = arr.map(distress).filter((v) => v != null);
      return ds.length ? ds.reduce((a, b) => a + b, 0) / ds.length : null;
    };
    const a = avg(older);
    const b = avg(newer);
    if (a != null && b != null && b - a >= 2) {
      return {
        level: "concern",
        reason: `Distress rising (${a.toFixed(1)} → ${b.toFixed(1)})`,
        date: latest.created_date,
      };
    }
  }

  // Sustained elevated distress in the latest reading
  const d = distress(latest);
  if (d != null && d >= 7) {
    return { level: "concern", reason: `Elevated distress (${d.toFixed(1)}/10)`, date: latest.created_date };
  }

  return null;
}

export default function TherapistPortal() {
  const [user, setUser] = useState(null);
  const [assignments, setAssignments] = useState([]);
  const [goals, setGoals] = useState([]);
  const [clientAssessments, setClientAssessments] = useState([]);
  const [nervousMetrics, setNervousMetrics] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [expandedId, setExpandedId] = useState(null);
  const [selectedClient, setSelectedClient] = useState(null);
  const [form, setForm] = useState({ title: "", description: "", client_email: "", client_name: "", due_date: "", tasks: [] });
  const [newTask, setNewTask] = useState("");
  const [saving, setSaving] = useState(false);
  const [explicitClients, setExplicitClients] = useState([]);
  const [showClientForm, setShowClientForm] = useState(false);
  const [clientForm, setClientForm] = useState({ email: "", name: "", date_of_birth: "", state: "" });
  const [savingClient, setSavingClient] = useState(false);
  const [inviteStatus, setInviteStatus] = useState({});
  const [sortBy, setSortBy] = useState("name");
  const [search, setSearch] = useState("");

  const loadPortalData = useCallback(async (initial = false) => {
    let me = null;
    try { me = await base44.auth.me(); setUser(me); } catch {}
    try {
      const [hw, gl, cl] = await Promise.all([
        base44.entities.HomeworkAssignment.list("-created_date", 100),
        base44.entities.TherapyGoal.list("-created_date", 100),
        base44.entities.Client.list("-created_date", 200),
      ]);
      setAssignments(hw || []);
      setGoals(gl || []);
      setExplicitClients(cl || []);
      // Seed sample clients so demo clinicians land on a populated portal.
      if (initial && me?.email && (cl || []).length === 0) {
        try {
          const demo = await isDemoParticipant(me.email);
          if (demo) {
            await base44.functions.invoke("seed-demo-clients", { therapist_email: me.email });
            const reseed = await base44.entities.Client.list("-created_date", 200);
            setExplicitClients(reseed || []);
          }
        } catch (e) {
          console.error("Demo seed failed:", e);
        }
      }
    } catch {}
    if (me?.email) {
      try {
        const [assessments, nervous] = await Promise.all([
          base44.entities.AssessmentResult.filter({ therapist_email: me.email }, "-created_date", 200),
          base44.entities.NervousSystemMetric.filter({ therapist_email: me.email }, "-created_date", 500),
        ]);
        setClientAssessments(assessments || []);
        setNervousMetrics(nervous || []);
      } catch {}
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadPortalData(true);
  }, [loadPortalData]);

  // Real-time: whenever a client logs a check-in, completes an assessment, or
  // updates homework or goals, the portal refreshes immediately — no reload needed.
  useSubscribeRefresh("AssessmentResult", () => loadPortalData(false));
  useSubscribeRefresh("NervousSystemMetric", () => loadPortalData(false));
  useSubscribeRefresh("HomeworkAssignment", () => loadPortalData(false));
  useSubscribeRefresh("TherapyGoal", () => loadPortalData(false));

  function addTask() {
    if (!newTask.trim()) return;
    setForm({ ...form, tasks: [...form.tasks, newTask.trim()] });
    setNewTask("");
  }

  async function createAssignment() {
    setSaving(true);
    try {
      await base44.entities.HomeworkAssignment.create({ ...form, therapist_email: user?.email || "", status: "assigned", completion_percentage: 0 });
      const data = await base44.entities.HomeworkAssignment.list("-created_date", 100);
      setAssignments(data);
      // Sync to Google Calendar if due date is set
      if (form.due_date) {
        try {
          await base44.functions.invoke("sync-calendar-event", {
            title: form.title,
            description: form.description,
            dueDate: form.due_date,
            clientName: form.client_name,
          });
        } catch (e) {
          console.error("Calendar sync failed:", e);
        }
      }
      setForm({ title: "", description: "", client_email: "", client_name: "", due_date: "", tasks: [] });
      setShowForm(false);
    } catch {}
    setSaving(false);
  }

  async function inviteClient(email) {
    setInviteStatus((s) => ({ ...s, [email]: { state: "sending" } }));
    try {
      await base44.users.inviteUser(email, "user");
      setInviteStatus((s) => ({ ...s, [email]: { state: "sent", msg: "Invitation sent" } }));
    } catch (e) {
      setInviteStatus((s) => ({ ...s, [email]: { state: "error", msg: e?.message || "Could not send invite" } }));
    }
  }

  async function addClient() {
    if (!clientForm.email.trim() || !clientForm.name.trim() || !clientForm.date_of_birth || !clientForm.state) return;
    setSavingClient(true);
    try {
      const email = clientForm.email.trim().toLowerCase();
      const name = clientForm.name.trim();
      const therapistEmail = user?.email || "";
      await base44.entities.Client.create({
        client_email: email,
        client_name: name,
        therapist_email: therapistEmail,
      });
      // Record the invitation that gates this client's registration — the client
      // must match this name, DOB, and state to sign up.
      await base44.entities.ClientInvitation.create({
        client_email: email,
        client_name: name,
        date_of_birth: clientForm.date_of_birth,
        state: clientForm.state,
        therapist_email: therapistEmail,
        therapist_name: user?.full_name || "",
        status: "pending",
      });
      // Relink the client's entire existing history to this therapist so the
      // portal shows every record at all times — not just task the therapist sent.
      try {
        await base44.functions.invoke("link-client-records", {
          client_email: email,
          therapist_email: therapistEmail,
        });
      } catch (e) {
        console.error("Link client records failed:", e);
      }
      inviteClient(email);
      const cl = await base44.entities.Client.list("-created_date", 200);
      setExplicitClients(cl || []);
      setClientForm({ email: "", name: "", date_of_birth: "", state: "" });
      setShowClientForm(false);
    } catch (e) {
      console.error("Add client error:", e);
    }
    setSavingClient(false);
  }

  const pending = assignments.filter((a) => a.status !== "completed");
  const completed = assignments.filter((a) => a.status === "completed");

  const clientMap = {};
  explicitClients.forEach((c) => { if (c.client_email) clientMap[c.client_email] = { email: c.client_email, name: c.client_name || c.client_email }; });
  assignments.forEach((a) => { if (a.client_email && !clientMap[a.client_email]) clientMap[a.client_email] = { email: a.client_email, name: a.client_name || a.client_email }; });
  goals.forEach((g) => { if (g.client_email && !clientMap[g.client_email]) clientMap[g.client_email] = { email: g.client_email, name: g.client_email }; });
  clientAssessments.forEach((a) => { if (a.client_email && !clientMap[a.client_email]) clientMap[a.client_email] = { email: a.client_email, name: a.client_email }; });
  const clients = Object.values(clientMap).sort((a, b) => (a.name || "").localeCompare(b.name || ""));

  const now = Date.now();
  const nervousByClient = {};
  (nervousMetrics || []).forEach((n) => {
    if (!n.client_email) return;
    if (!nervousByClient[n.client_email]) nervousByClient[n.client_email] = [];
    nervousByClient[n.client_email].push(n);
  });
  const metricsByClient = {};
  clients.forEach((c) => {
    const aList = (clientAssessments || []).filter((a) => a.client_email === c.email);
    const current = barometerAt(aList, now);
    const prev = barometerAt(aList, now - 30 * DAY);
    const trend = current !== null && prev !== null ? current - prev : null;
    const hw = (assignments || []).filter((a) => a.client_email === c.email);
    const gl = (goals || []).filter((g) => g.client_email === c.email);
    const ns = (nervousByClient[c.email] || [])
      .slice()
      .sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    const allDates = [...aList, ...hw, ...gl, ...ns]
      .map((x) => (x.created_date ? new Date(x.created_date).getTime() : 0))
      .filter(Boolean);
    const lastActivityMs = allDates.length ? Math.max(...allDates) : 0;
    metricsByClient[c.email] = { current, trend, lastActivityMs, risk: assessRisk(ns) };
  });

  const query = search.trim().toLowerCase();
  const filteredClients = query
    ? clients.filter((c) => (c.name || "").toLowerCase().includes(query) || (c.email || "").toLowerCase().includes(query))
    : clients;
  const sortedClients = [...filteredClients].sort((a, b) => {
    const ma = metricsByClient[a.email] || {};
    const mb = metricsByClient[b.email] || {};
    switch (sortBy) {
      case "barometer_low":
        return (ma.current ?? 999) - (mb.current ?? 999);
      case "barometer_high":
        return (mb.current ?? -1) - (ma.current ?? -1);
      case "trend_up":
        return (mb.trend ?? -999) - (ma.trend ?? -999);
      case "trend_down":
        return (ma.trend ?? 999) - (mb.trend ?? 999);
      case "activity":
        return (mb.lastActivityMs || 0) - (ma.lastActivityMs || 0);
      default:
        return (a.name || "").localeCompare(b.name || "");
    }
  });

  const assessmentsByClient = {};
  clientAssessments.forEach((a) => {
    const email = a.client_email;
    if (!email) return;
    if (!assessmentsByClient[email]) assessmentsByClient[email] = [];
    assessmentsByClient[email].push(a);
  });

  const selectedClientObj = clients.find((c) => c.email === selectedClient);
  const selectedClientRecord = explicitClients.find((c) => c.client_email === selectedClient);

  async function handleClientRemoved() {
    setSelectedClient(null);
    try {
      const cl = await base44.entities.Client.list("-created_date", 200);
      setExplicitClients(cl || []);
    } catch {}
  }

  return (
    <div>
      <div className="px-4 py-2 bg-primary/5 border-b border-primary/20">
        <p className="text-xs text-muted-foreground text-center max-w-5xl mx-auto flex items-center justify-center gap-1.5">
          <Shield size={12} className="text-primary" />
          HIPAA Notice: This portal contains Protected Health Information (PHI). Access is restricted to authorized providers and their assigned clients.
        </p>
      </div>

      <div className="flex max-w-7xl mx-auto">
        {/* Client sidebar */}
        <aside className={`w-full md:w-64 shrink-0 md:border-r border-border/60 p-4 ${selectedClient ? "hidden md:block" : "block"}`}>
          <div className="flex items-center gap-2 mb-4">
            <Users size={18} className="text-primary" />
            <h2 className="font-heading text-lg font-semibold">Clients</h2>
            <button onClick={() => setShowClientForm(!showClientForm)} className="ml-auto p-1.5 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition" title="Add client">
              <Plus size={16} />
            </button>
          </div>

          <div className="relative mb-3">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search clients…"
              className="pp-input pl-9 text-sm"
            />
          </div>

          <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="pp-input mb-4 text-sm">
            <option value="name">Sort: Name (A–Z)</option>
            <option value="barometer_low">Barometer: lowest first</option>
            <option value="barometer_high">Barometer: highest first</option>
            <option value="trend_up">Trend: improving</option>
            <option value="trend_down">Trend: declining</option>
            <option value="activity">Recent activity (newest)</option>
          </select>

          {showClientForm && (
            <div className="mb-4 p-3 rounded-xl bg-secondary/30 space-y-2">
              <input value={clientForm.name} onChange={(e) => setClientForm({ ...clientForm, name: e.target.value })} placeholder="Client full name *" className="pp-input" />
              <input type="email" value={clientForm.email} onChange={(e) => setClientForm({ ...clientForm, email: e.target.value })} placeholder="Client email *" className="pp-input" />
              <input type="date" value={clientForm.date_of_birth} onChange={(e) => setClientForm({ ...clientForm, date_of_birth: e.target.value })} className="pp-input" />
              <select value={clientForm.state} onChange={(e) => setClientForm({ ...clientForm, state: e.target.value })} className="pp-input">
                <option value="" disabled>State of residence *</option>
                {US_STATES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
              <button onClick={addClient} disabled={savingClient || !clientForm.email.trim() || !clientForm.name.trim() || !clientForm.date_of_birth || !clientForm.state} className="w-full py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition disabled:opacity-50">
                {savingClient ? "Adding…" : "Add & Invite"}
              </button>
              <p className="text-xs text-muted-foreground text-center">The client must match this name, DOB, and state to register.</p>
            </div>
          )}

          {loading ? (
            <div className="flex justify-center py-8"><div className="w-6 h-6 border-4 border-secondary border-t-primary rounded-full animate-spin" /></div>
          ) : clients.length === 0 ? (
            <p className="text-sm text-muted-foreground">No clients yet. Add a client or assign homework to get started.</p>
          ) : sortedClients.length === 0 ? (
            <p className="text-sm text-muted-foreground">No clients match "{search}".</p>
          ) : (
            <div className="space-y-1">
              {sortedClients.map((c) => {
                const st = inviteStatus[c.email];
                const m = metricsByClient[c.email];
                return (
                  <div
                    key={c.email}
                    className={`flex items-center gap-1 rounded-lg transition border-l-2 ${
                      m?.risk?.level === "high"
                        ? "border-l-red-500"
                        : m?.risk?.level === "concern"
                        ? "border-l-amber-500"
                        : "border-l-transparent"
                    } ${selectedClient === c.email ? "bg-primary/10" : "hover:bg-secondary/60"}`}
                  >
                    <button
                      onClick={() => setSelectedClient(c.email)}
                      className={`flex-1 min-w-0 text-left px-3 py-2.5 ${selectedClient === c.email ? "text-primary" : ""}`}
                    >
                      <p className="text-sm font-medium truncate flex items-center gap-1.5">
                        {c.name}
                        {m?.risk && (
                          <span
                            className="w-1.5 h-1.5 rounded-full shrink-0"
                            style={{ background: m.risk.level === "high" ? "#D9534F" : "#D4A055" }}
                            title={m.risk.reason}
                          />
                        )}
                      </p>
                      {c.name !== c.email && <p className="text-xs text-muted-foreground truncate">{c.email}</p>}
                      {m?.risk && (
                        <p
                          className="text-[11px] mt-0.5 truncate"
                          style={{ color: m.risk.level === "high" ? "#D9534F" : "#D4A055" }}
                        >
                          {m.risk.reason}
                        </p>
                      )}
                      {m && (m.current !== null || m.lastActivityMs) && (
                        <p className="text-[11px] mt-0.5 flex items-center gap-1.5">
                          {m.current !== null && (
                            <span className="font-semibold" style={{ color: m.current >= 50 ? "#1995A1" : m.current >= 30 ? "#D4A055" : "#D9534F" }}>
                              {Math.round(m.current)}
                            </span>
                          )}
                          {m.trend !== null && (m.trend > 1
                            ? <TrendingUp size={11} className="text-accent" />
                            : m.trend < -1 ? <TrendingDown size={11} className="text-destructive" /> : null)}
                          <span className="text-muted-foreground">· {timeAgo(m.lastActivityMs)}</span>
                        </p>
                      )}
                      {st?.state === "sent" && <p className="text-xs text-primary mt-0.5">Invitation sent</p>}
                      {st?.state === "error" && <p className="text-xs text-destructive mt-0.5 truncate">{st.msg}</p>}
                    </button>
                    <button
                      onClick={() => inviteClient(c.email)}
                      disabled={st?.state === "sending"}
                      title="Send registration invite"
                      className={`mr-1 p-1.5 rounded-md transition shrink-0 ${selectedClient === c.email ? "text-primary hover:bg-primary/15" : "text-muted-foreground hover:text-primary hover:bg-secondary"}`}
                    >
                      {st?.state === "sending"
                        ? <span className="block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                        : <Mail size={15} />}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </aside>

        {/* Content */}
        <main className={`flex-1 min-w-0 ${!selectedClient ? "hidden md:block" : "block"}`}>
          {selectedClient && selectedClientObj ? (
            <ClientDashboard
              clientEmail={selectedClient}
              clientName={selectedClientObj.name}
              clientId={selectedClientRecord?.id}
              user={user}
              onBack={() => setSelectedClient(null)}
              onClientRemoved={handleClientRemoved}
            />
          ) : (
            <div className="p-6 md:p-10">
              <div className="flex items-start gap-3 mb-8">
                <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  <Stethoscope className="text-primary" size={22} />
                </div>
                <div>
                  <h1 className="font-heading text-3xl md:text-4xl font-semibold">Therapist Portal</h1>
                  <p className="text-muted-foreground text-lg">Select a client to view their dashboard, or assign homework below.</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-6">
                <div className="pp-card p-4">
                  <p className="text-sm text-muted-foreground">Pending</p>
                  <p className="font-heading text-2xl font-semibold">{pending.length}</p>
                </div>
                <div className="pp-card p-4">
                  <p className="text-sm text-muted-foreground">Completed</p>
                  <p className="font-heading text-2xl font-semibold text-primary">{completed.length}</p>
                </div>
              </div>

              <ClientEmotionTrendChart nervousMetrics={nervousMetrics} clients={clients} />

              <RiskAlertsSummary
                clients={clients}
                metricsByClient={metricsByClient}
                onSelectClient={setSelectedClient}
              />

              <ClientProgressSnapshot
                clients={clients}
                assessments={clientAssessments}
                therapistEmail={user?.email}
                metricsByClient={metricsByClient}
                onSelectClient={setSelectedClient}
              />

              <InactiveClientsSummary
                clients={clients}
                metricsByClient={metricsByClient}
                onSelectClient={setSelectedClient}
              />

              <button onClick={() => setShowForm(!showForm)} className="w-full mb-6 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition flex items-center justify-center gap-2">
                <Plus size={18} /> {showForm ? "Cancel" : "Assign New Homework"}
              </button>

              <AnimatePresence>
                {showForm && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden mb-8">
                    <div className="pp-card p-5 space-y-4">
                      <div>
                        <label className="text-sm font-medium mb-2 block">Assignment Title</label>
                        <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g., Practice STOP skill daily" className="pp-input" />
                      </div>
                      <div>
                        <label className="text-sm font-medium mb-2 block">Instructions</label>
                        <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="What should the client do? Any context for them?" className="pp-input min-h-[80px] resize-none" />
                      </div>
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium mb-2 block">Client Email</label>
                          <input value={form.client_email} onChange={(e) => setForm({ ...form, client_email: e.target.value })} placeholder="client@email.com" className="pp-input" />
                        </div>
                        <div>
                          <label className="text-sm font-medium mb-2 block">Client Name</label>
                          <input value={form.client_name} onChange={(e) => setForm({ ...form, client_name: e.target.value })} placeholder="Jane Doe" className="pp-input" />
                        </div>
                      </div>
                      <div>
                        <label className="text-sm font-medium mb-2 block">Due Date (Next Session)</label>
                        <input type="date" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} className="pp-input" />
                      </div>
                      <div>
                        <label className="text-sm font-medium mb-2 block">Tasks</label>
                        {form.tasks.length > 0 && (
                          <div className="space-y-2 mb-2">
                            {form.tasks.map((task, i) => (
                              <div key={i} className="flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-secondary/50 group">
                                <span className="text-sm">{task}</span>
                                <button onClick={() => setForm({ ...form, tasks: form.tasks.filter((_, idx) => idx !== i) })} className="text-muted-foreground/40 hover:text-destructive transition opacity-0 group-hover:opacity-100">
                                  <Trash2 size={15} />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                        <div className="flex gap-2">
                          <input value={newTask} onChange={(e) => setNewTask(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addTask(); } }} placeholder="Add a task..." className="pp-input flex-1" />
                          <button onClick={addTask} className="px-3 rounded-xl bg-secondary text-secondary-foreground hover:opacity-80 transition flex items-center justify-center">
                            <Plus size={18} />
                          </button>
                        </div>
                      </div>
                      <button onClick={createAssignment} disabled={saving || !form.title || !form.client_email} className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50">
                        {saving ? "Assigning…" : "Assign Homework"}
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {loading ? (
                <div className="flex items-center justify-center py-20">
                  <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
                </div>
              ) : assignments.length === 0 ? (
                <div className="pp-card p-10 text-center">
                  <Stethoscope className="mx-auto mb-4 text-muted-foreground/40" size={48} />
                  <h3 className="font-heading text-xl font-semibold mb-2">No assignments yet</h3>
                  <p className="text-muted-foreground">Create your first homework assignment above.</p>
                </div>
              ) : (
                <>
                  {pending.length > 0 && (
                    <div className="mb-6">
                      <h2 className="font-heading text-lg font-semibold mb-3">Pending</h2>
                      <div className="space-y-3">
                        {pending.map((a) => (
                          <div key={a.id} className="pp-card p-5">
                            <div className="flex items-start justify-between gap-3 mb-2">
                              <div>
                                <h3 className="font-heading text-lg font-semibold">{a.title}</h3>
                                <p className="text-sm text-muted-foreground">{a.client_name || a.client_email}</p>
                              </div>
                              <span className="px-3 py-1 rounded-full bg-amber-500/10 text-amber-600 text-xs font-medium flex items-center gap-1 shrink-0">
                                <Clock size={12} /> Pending
                              </span>
                            </div>
                            {a.description && <p className="text-sm text-muted-foreground mb-2">{a.description}</p>}
                            {a.due_date && (
                              <div className="flex items-center gap-3">
                                <p className="text-xs text-muted-foreground flex items-center gap-1">
                                  <Calendar size={12} /> Due: {new Date(a.due_date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                                </p>
                                <button onClick={() => downloadHomeworkICS(a)} className="text-xs text-primary flex items-center gap-1 hover:underline">
                                  <CalendarPlus size={12} /> Add to Calendar
                                </button>
                              </div>
                            )}
                            {a.tasks?.length > 0 && (
                              <div className="mt-3 space-y-1">
                                {a.tasks.map((task, i) => (
                                  <div key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                                    <span className="w-4 h-4 rounded border border-border shrink-0" /> {task}
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {completed.length > 0 && (
                    <div>
                      <h2 className="font-heading text-lg font-semibold mb-3">Completed</h2>
                      <div className="space-y-3">
                        {completed.map((a) => (
                          <div key={a.id} className="pp-card p-5">
                            <button onClick={() => setExpandedId(expandedId === a.id ? null : a.id)} className="w-full text-left">
                              <div className="flex items-start justify-between gap-3">
                                <div>
                                  <h3 className="font-heading text-lg font-semibold">{a.title}</h3>
                                  <p className="text-sm text-muted-foreground">{a.client_name || a.client_email}</p>
                                </div>
                                <div className="flex items-center gap-2 shrink-0">
                                  <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium flex items-center gap-1">
                                    <Check size={12} /> Done
                                  </span>
                                  <ChevronDown className={`text-muted-foreground transition-transform ${expandedId === a.id ? "rotate-180" : ""}`} size={18} />
                                </div>
                              </div>
                            </button>
                            <AnimatePresence>
                              {expandedId === a.id && (
                                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                                  <div className="mt-4 pt-4 border-t border-border/60">
                                    <p className="text-sm font-medium mb-2">Client's Reflection:</p>
                                    <p className="text-sm text-muted-foreground whitespace-pre-wrap">{a.client_response || "No written response provided."}</p>
                                    {a.due_date && (
                                      <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1">
                                        <Calendar size={12} /> Was due: {new Date(a.due_date).toLocaleDateString("en-US", { month: "long", day: "numeric" })}
                                      </p>
                                    )}
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}

              {Object.keys(assessmentsByClient).length > 0 && (
                <div className="mt-10">
                  <h2 className="font-heading text-lg font-semibold mb-3">Client Symptom Progress</h2>
                  <div className="space-y-4">
                    {Object.entries(assessmentsByClient).map(([clientEmail, results]) => {
                      const clientName = clientMap[clientEmail]?.name || clientEmail;
                      return (
                        <div key={clientEmail} className="pp-card p-5">
                          <button onClick={() => setSelectedClient(clientEmail)} className="w-full text-left">
                            <h3 className="font-heading text-base font-semibold mb-3 hover:text-primary transition">{clientName} →</h3>
                          </button>
                          <div className="space-y-2">
                            {results.map((r) => {
                              const test = ASSESSMENTS[r.test_type];
                              const scored = test?.score(r.score);
                              return (
                                <div key={r.id} className="flex items-center justify-between gap-3">
                                  <div className="flex items-center gap-2">
                                    <span className="px-2 py-0.5 rounded-md bg-secondary text-xs font-bold">{r.test_type}</span>
                                    <span className="text-xs text-muted-foreground">
                                      {new Date(r.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-heading text-lg font-semibold">{r.score}</span>
                                    {scored && (
                                      <span className="px-2.5 py-1 rounded-full text-xs font-medium" style={{ backgroundColor: `${scored.color}15`, color: scored.color }}>
                                        {r.severity}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              <BehaviorActivationSummary therapistEmail={user?.email} clients={clients} />

              {assignments.length > 0 && (
                <p className="text-xs text-muted-foreground text-center mt-6 flex items-center justify-center gap-1.5">
                  <Mail size={12} /> You'll receive an email notification when a client completes their homework.
                </p>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}