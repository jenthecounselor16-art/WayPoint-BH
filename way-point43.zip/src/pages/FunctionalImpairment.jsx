import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { ClipboardList, AlertTriangle, Clock, CheckCircle2 } from "lucide-react";
import { FUNCTIONAL_ITEMS, FUNCTIONAL_SCALE, NEGATIVE_ITEMS, MAX_IMPAIRMENT } from "@/lib/functionalImpairment";
import { getMyTherapistEmail } from "@/lib/myTherapist";

export default function FunctionalImpairment() {
  const [user, setUser] = useState(null);
  const [assignment, setAssignment] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [responses, setResponses] = useState({});
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        if (me?.email) {
          try {
            const assignments = await base44.entities.FunctionalImpairmentAssignment.filter(
              { client_email: me.email, status: "active" },
              "-created_date",
              1
            );
            setAssignment(assignments?.[0] || null);
          } catch {}
          try {
            const data = await base44.entities.FunctionalImpairment.list("-created_date", 20);
            setHistory(data || []);
          } catch {}
        }
      } catch {}
      setLoading(false);
    })();
  }, []);

  function setRating(key, value) {
    setResponses((prev) => ({ ...prev, [key]: value }));
  }

  async function saveCheckIn() {
    setSaving(true);
    try {
      const me = user || (await base44.auth.me());
      let therapistEmail = assignment?.therapist_email || "";
      if (!therapistEmail) {
        try {
          const hw = await base44.entities.HomeworkAssignment.list("-created_date", 1);
          if (hw[0]?.therapist_email) therapistEmail = hw[0].therapist_email;
        } catch {}
      }
      if (!therapistEmail) therapistEmail = await getMyTherapistEmail();
      await base44.entities.FunctionalImpairment.create({
        ...responses,
        notes,
        client_email: me?.email || "",
        therapist_email: therapistEmail,
      });
      const data = await base44.entities.FunctionalImpairment.list("-created_date", 20);
      setHistory(data || []);
      setResponses({});
      setNotes("");
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      console.error("Save error:", err);
    }
    setSaving(false);
  }

  const allRated = FUNCTIONAL_ITEMS.every((item) => responses[item.key] !== undefined);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-start gap-3 mb-6">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <ClipboardList className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Function Check-in</h1>
          <p className="text-muted-foreground text-lg">How have daily habits and functioning been recently?</p>
        </div>
      </div>

      {/* Assignment info */}
      {assignment && (
        <div className="pp-card p-4 mb-6 flex items-center gap-3">
          <Clock size={18} className="text-primary shrink-0" />
          <div className="text-sm">
            <span className="font-medium">Your therapist scheduled this check-in {assignment.frequency}.</span>
            {assignment.next_due_date && (
              <span className="text-muted-foreground">
                {" "}Next due: {new Date(assignment.next_due_date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Crisis banner */}
      <div className="p-4 rounded-xl border-2 border-destructive/25 bg-destructive/5 mb-6 flex items-start gap-3">
        <AlertTriangle size={18} className="text-destructive shrink-0 mt-0.5" />
        <div className="text-sm">
          <p className="font-semibold text-destructive mb-0.5">If you're having thoughts of self-harm</p>
          <p className="text-muted-foreground">
            Call or text <span className="font-bold text-foreground">988</span> — the Suicide &amp; Crisis Lifeline is available 24/7.
          </p>
        </div>
      </div>

      {/* Check-in form */}
      <div className="pp-card p-5 md:p-6 mb-6">
        <div className="space-y-6">
          {FUNCTIONAL_ITEMS.map((item) => (
            <div key={item.key}>
              <div className="mb-2">
                <h3 className="font-medium mb-0.5 flex items-center gap-2 flex-wrap">
                  {item.label}
                  {item.crisis && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-destructive/10 text-destructive font-medium">Safety</span>
                  )}
                  {item.positive && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-accent/10 text-accent font-medium">Higher is better</span>
                  )}
                </h3>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </div>
              <div className="flex gap-1.5 flex-wrap">
                {FUNCTIONAL_SCALE.map((s) => {
                  const selected = responses[item.key] === s.value;
                  return (
                    <button
                      key={s.value}
                      onClick={() => setRating(item.key, s.value)}
                      className={`flex-1 min-w-[60px] px-2 py-2 rounded-lg text-center transition border ${
                        selected
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-card text-foreground/70 border-border hover:border-primary/40"
                      }`}
                    >
                      <span className="block font-heading font-bold text-base">{s.value}</span>
                      <span className="block text-[10px] font-normal opacity-80 leading-tight">{s.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Notes */}
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Anything else about your functioning this week? (optional)"
          className="pp-input mt-6 min-h-[70px] resize-none"
        />

        {/* Save */}
        <button
          onClick={saveCheckIn}
          disabled={!allRated || saving}
          className="mt-4 w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {saving ? "Saving…" : saved ? (
            <>
              <CheckCircle2 size={18} /> Saved
            </>
          ) : allRated ? (
            "Submit check-in"
          ) : (
            "Rate all items to submit"
          )}
        </button>
      </div>

      {/* History */}
      {history.length > 0 && (
        <div>
          <h2 className="font-heading text-lg font-semibold mb-3">Recent check-ins</h2>
          <div className="space-y-2">
            {history.slice(0, 5).map((entry) => {
              const impairment = NEGATIVE_ITEMS.reduce((sum, i) => sum + (entry[i.key] || 0), 0);
              const pct = Math.round((impairment / MAX_IMPAIRMENT) * 100);
              const engagement = entry.enjoyable_activities ?? 0;
              return (
                <div key={entry.id} className="pp-card p-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">
                      {new Date(entry.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                    </p>
                    <p className="text-xs text-muted-foreground">Engagement: {engagement}/4</p>
                  </div>
                  <div className="text-right">
                    <p className="font-heading text-xl font-semibold">{pct}%</p>
                    <p className="text-xs text-muted-foreground">impairment</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}