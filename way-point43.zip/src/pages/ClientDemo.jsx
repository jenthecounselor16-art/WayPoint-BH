import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Sparkles, CheckCircle2, AlertCircle, Send, CalendarDays, Heart } from "lucide-react";
import HIPAAAssurance from "@/components/HIPAAAssurance";

export default function ClientDemo() {
  const [form, setForm] = useState({ name: "", email: "" });
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);
  // Lightweight anti-bot guard: honeypot field, arithmetic verification, and
  // a minimum fill time. Real humans read the form; scripts post instantly.
  const [honeypot, setHoneypot] = useState("");
  const [verify, setVerify] = useState("");
  const [challenge] = useState(() => ({ a: 2 + Math.floor(Math.random() * 7), b: 2 + Math.floor(Math.random() * 7), t0: Date.now() }));

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    setResult(null);
    try {
      const res = await base44.functions.invoke("client-demo-signup", {
        ...form,
        website: honeypot,
        verify: Number(verify),
        a: challenge.a,
        b: challenge.b,
        t0: challenge.t0,
      });
      if (res?.data?.ok) {
        setResult({ type: "success", data: res.data });
        setForm({ name: "", email: "" });
        setHoneypot("");
        setVerify("");
      } else {
        setResult({ type: "error", text: res?.data?.error || "Something went wrong. Please try again." });
      }
    } catch (err) {
      setResult({ type: "error", text: "Something went wrong. Please try again." });
    }
    setSubmitting(false);
  }

  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Sparkles className="text-primary" size={24} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">7-Day Free Trial</h1>
          <p className="text-muted-foreground">WayPoint is always free for clients — explore everything for 7 days, no card required.</p>
        </div>
      </div>

      <div className="grid sm:grid-cols-3 gap-3 mb-8">
        <div className="pp-card p-4 text-center">
          <CalendarDays className="mx-auto text-primary mb-1" size={20} />
          <p className="font-heading text-lg font-semibold">7 days</p>
          <p className="text-xs text-muted-foreground">Full access</p>
        </div>
        <div className="pp-card p-4 text-center">
          <Heart className="mx-auto text-primary mb-1" size={20} />
          <p className="font-heading text-lg font-semibold">Always free</p>
          <p className="text-xs text-muted-foreground">Clients never pay</p>
        </div>
        <div className="pp-card p-4 text-center">
          <Sparkles className="mx-auto text-primary mb-1" size={20} />
          <p className="font-heading text-lg font-semibold">All tools</p>
          <p className="text-xs text-muted-foreground">Mood, coping, journaling &amp; more</p>
        </div>
      </div>

      <div className="mb-8">
        <HIPAAAssurance compact />
      </div>

      {result?.type === "success" ? (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-6 md:p-8 border-accent/30">
          <div className="flex items-start gap-3 mb-4">
            <CheckCircle2 className="text-accent shrink-0 mt-0.5" size={28} />
            <div>
              <h2 className="font-heading text-xl font-semibold mb-1">You're in — welcome!</h2>
              <p className="text-sm text-muted-foreground">
                {result.data.invited
                  ? <>We've sent an invitation to <span className="font-medium text-foreground">{form.email || "your inbox"}</span> — check your email to create your account and start exploring.</>
                  : <>Your 7-day trial is reserved. Create your account now to activate it and start exploring.</>}
              </p>
            </div>
          </div>
          <ul className="space-y-2 text-sm mb-5">
            <li className="flex items-start gap-2"><CheckCircle2 size={16} className="text-accent shrink-0 mt-0.5" /> Your trial runs through {new Date(result.data.expires_at).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}.</li>
            <li className="flex items-start gap-2"><CheckCircle2 size={16} className="text-accent shrink-0 mt-0.5" /> You'll have full access to mood tracking, coping tools, journaling, goals, and more.</li>
            <li className="flex items-start gap-2"><CheckCircle2 size={16} className="text-accent shrink-0 mt-0.5" /> WayPoint is always free for clients — you'll never be asked to pay.</li>
            <li className="flex items-start gap-2"><CheckCircle2 size={16} className="text-accent shrink-0 mt-0.5" /> After 7 days we'll send you a quick feedback survey — we'd love to hear what you think.</li>
          </ul>
          <Link to={result.data.invited ? "/login" : "/register"} className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition">
            {result.data.invited ? "Go to login" : "Create your account"} <Send size={16} />
          </Link>
        </motion.div>
      ) : (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-5 md:p-7">
          {result?.type === "error" && (
            <div className="mb-4 p-3 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm flex items-start gap-2">
              <AlertCircle size={18} className="shrink-0 mt-0.5" />
              <span>{result.text}</span>
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Full name *</label>
                <input type="text" required value={form.name} onChange={(e) => update("name", e.target.value)} className="pp-input" placeholder="Jane Doe" />
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Email *</label>
                <input type="email" required value={form.email} onChange={(e) => update("email", e.target.value)} className="pp-input" placeholder="jane@example.com" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Quick check — what is {challenge.a} + {challenge.b}? *</label>
              <input type="number" required value={verify} onChange={(e) => setVerify(e.target.value)} className="pp-input" placeholder="Your answer" inputMode="numeric" />
            </div>
            {/* Honeypot: hidden from humans, bots tend to fill it */}
            <input
              type="text"
              value={honeypot}
              onChange={(e) => setHoneypot(e.target.value)}
              tabIndex={-1}
              autoComplete="off"
              aria-hidden="true"
              name="website"
              className="absolute -left-[9999px] w-px h-px opacity-0"
            />
            <button type="submit" disabled={submitting} className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition flex items-center justify-center gap-2 disabled:opacity-50">
              <Send size={16} /> {submitting ? "Setting up your trial…" : "Start my free trial"}
            </button>
            <p className="text-xs text-muted-foreground text-center">
              We'll send an account invitation to your email. WayPoint is always free for clients — you'll never be asked to pay.
            </p>
          </form>
        </motion.div>
      )}

      <div className="mt-8 grid sm:grid-cols-3 gap-3 text-center">
        {["Mood tracking & emotion wheel", "CBT journaling & coping tools", "Goals, values & AI coping coach"].map((f, i) => (
          <div key={i} className="pp-card p-4">
            <p className="text-sm text-muted-foreground">{f}</p>
          </div>
        ))}
      </div>
    </div>
  );
}