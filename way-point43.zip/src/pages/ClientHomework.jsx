import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { ClipboardCheck, Clock, Check, Calendar, CalendarPlus, Send } from "lucide-react";
import { useSubscribeRefresh } from "@/hooks/useSubscribeRefresh";
import { downloadHomeworkICS } from "@/lib/ics";
import { checkAndAwardBadges } from "@/lib/badges";
import BadgeCelebration from "@/components/BadgeCelebration";
import { celebrateHomework } from "@/lib/celebrate";

export default function ClientHomework() {
  const [user, setUser] = useState(null);
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [responses, setResponses] = useState({});
  const [taskStates, setTaskStates] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [earnedBadges, setEarnedBadges] = useState([]);

  async function loadAssignments() {
    try {
      const data = await base44.entities.HomeworkAssignment.list("-created_date", 50);
      setAssignments(data);
    } catch {}
  }
  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
      } catch {}
      await loadAssignments();
      setLoading(false);
    })();
  }, []);
  useSubscribeRefresh("HomeworkAssignment", loadAssignments);

  function toggleTask(assignmentId, taskIndex) {
    const key = `${assignmentId}-${taskIndex}`;
    setTaskStates({ ...taskStates, [key]: !taskStates[key] });
  }

  async function submitHomework(assignment) {
    setSubmitting(true);
    try {
      const response = responses[assignment.id] || "";
      await base44.entities.HomeworkAssignment.update(assignment.id, {
        status: "completed",
        completion_percentage: 100,
        client_response: response,
      });
      // Notify the therapist
      if (assignment.therapist_email) {
        try {
          await base44.integrations.Core.SendEmail({
            to: assignment.therapist_email,
            subject: `Homework completed: ${assignment.title}`,
            body: `Hi,\n\nYour client ${user?.full_name || assignment.client_name || ""} has completed the homework assignment "${assignment.title}".\n\nTheir reflection:\n${response || "(no written response)"}\n\nDue date: ${assignment.due_date || "not set"}\n\nView details in your WayPoint therapist portal.`,
          });
        } catch {
          // Email failed, but homework is saved
        }
      }
      const data = await base44.entities.HomeworkAssignment.list("-created_date", 50);
      setAssignments(data);
      celebrateHomework();
      const newBadges = await checkAndAwardBadges();
      if (newBadges.length > 0) setEarnedBadges(newBadges);
    } catch {}
    setSubmitting(false);
  }

  const pending = assignments.filter((a) => a.status !== "completed");
  const completed = assignments.filter((a) => a.status === "completed");

  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto">
      <div className="flex items-start gap-3 mb-8">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <ClipboardCheck className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Homework</h1>
          <p className="text-muted-foreground text-lg">Complete your assignments before your next session.</p>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : assignments.length === 0 ? (
        <div className="pp-card p-10 text-center">
          <ClipboardCheck className="mx-auto mb-4 text-muted-foreground/40" size={48} />
          <h3 className="font-heading text-xl font-semibold mb-2">No homework assigned</h3>
          <p className="text-muted-foreground">Your therapist hasn't assigned any homework yet.</p>
        </div>
      ) : (
        <>
          {pending.length > 0 && (
            <div className="mb-8">
              <h2 className="font-heading text-lg font-semibold mb-3">To Do</h2>
              <div className="space-y-3">
                {pending.map((a) => (
                  <motion.div key={a.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-5">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div className="flex-1">
                        <h3 className="font-heading text-lg font-semibold">{a.title}</h3>
                        {a.due_date && (
                          <div className="flex items-center gap-3 mt-1">
                            <p className="text-xs text-muted-foreground flex items-center gap-1">
                              <Calendar size={12} /> Due: {new Date(a.due_date).toLocaleDateString("en-US", { month: "long", day: "numeric" })}
                            </p>
                            <button onClick={() => downloadHomeworkICS(a)} className="text-xs text-primary flex items-center gap-1 hover:underline">
                              <CalendarPlus size={12} /> Add to Calendar
                            </button>
                          </div>
                        )}
                      </div>
                      <span className="px-3 py-1 rounded-full bg-amber-500/10 text-amber-600 text-xs font-medium flex items-center gap-1 shrink-0">
                        <Clock size={12} /> Pending
                      </span>
                    </div>

                    {a.description && <p className="text-sm text-muted-foreground mb-4">{a.description}</p>}

                    {a.tasks?.length > 0 && (
                      <div className="mb-4 space-y-2">
                        {a.tasks.map((task, i) => {
                          const key = `${a.id}-${i}`;
                          const checked = taskStates[key];
                          return (
                            <button key={i} onClick={() => toggleTask(a.id, i)} className="flex items-center gap-2 text-sm text-left w-full group">
                              <span className={`w-5 h-5 rounded border flex items-center justify-center transition shrink-0 ${checked ? "bg-primary border-primary" : "border-border group-hover:border-primary/50"}`}>
                                {checked && <Check size={12} className="text-primary-foreground" />}
                              </span>
                              <span className={checked ? "line-through text-muted-foreground" : ""}>{task}</span>
                            </button>
                          );
                        })}
                      </div>
                    )}

                    <textarea
                      value={responses[a.id] || ""}
                      onChange={(e) => setResponses({ ...responses, [a.id]: e.target.value })}
                      placeholder="Write your reflection or response…"
                      className="pp-input min-h-[80px] resize-none mb-3"
                    />

                    <button
                      onClick={() => submitHomework(a)}
                      disabled={submitting}
                      className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {submitting ? "Submitting…" : <>Submit Homework <Send size={16} /></>}
                    </button>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {completed.length > 0 && (
            <div>
              <h2 className="font-heading text-lg font-semibold mb-3">Completed</h2>
              <div className="space-y-3">
                {completed.map((a) => (
                  <div key={a.id} className="pp-card p-5">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <Check className="text-primary" size={18} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-heading text-base font-semibold truncate">{a.title}</h3>
                        <p className="text-xs text-muted-foreground">Completed</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
      <BadgeCelebration badges={earnedBadges} onClose={() => setEarnedBadges([])} />
    </div>
  );
}