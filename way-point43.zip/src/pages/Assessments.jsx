import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ASSESSMENTS } from "@/lib/assessments";
import { getMyTherapistEmail } from "@/lib/myTherapist";
import { ClipboardList, ArrowLeft, AlertCircle, History, TrendingUp } from "lucide-react";
import { useSubscribeRefresh } from "@/hooks/useSubscribeRefresh";
import ValuesChecklist from "@/components/ValuesChecklist";
import SensoryProfile from "@/pages/SensoryProfile";
import ActivitiesQuiz from "@/pages/ActivitiesQuiz";

export default function Assessments() {
  const [activeTest, setActiveTest] = useState(null);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [user, setUser] = useState(null);
  const [tab, setTab] = useState("assessments");

  async function loadHistory() {
    try {
      const data = await base44.entities.AssessmentResult.list("-created_date", 50);
      setHistory(data);
    } catch {}
  }
  async function loadAssignments() {
    try {
      const assigned = await base44.entities.AssessmentAssignment.filter({ status: "assigned" }, "-created_date", 50);
      setAssignments(assigned || []);
    } catch {}
  }
  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
      } catch {}
      await Promise.all([loadHistory(), loadAssignments()]);
      setLoading(false);
    })();
  }, []);
  useSubscribeRefresh("AssessmentResult", loadHistory);
  useSubscribeRefresh("AssessmentAssignment", loadAssignments);

  function startTest(testKey) {
    setActiveTest(testKey);
    setAnswers({});
    setResult(null);
  }

  function setAnswer(index, value) {
    setAnswers({ ...answers, [index]: value });
  }

  async function submitTest() {
    const test = ASSESSMENTS[activeTest];
    const total = test.items.reduce((sum, _, i) => sum + (answers[i] || 0), 0);
    const scored = test.score(total);

    setSaving(true);
    try {
      let therapistEmail = "";
      try {
        const hw = await base44.entities.HomeworkAssignment.list("-created_date", 1);
        if (hw[0]?.therapist_email) therapistEmail = hw[0].therapist_email;
      } catch {}

      // Resolve therapist email from assignment if available
      try {
        const myAssignments = await base44.entities.AssessmentAssignment.filter({ test_type: activeTest, status: "assigned" }, "-created_date", 5);
        const matching = myAssignments.find((a) => a.client_email === user?.email);
        if (matching?.therapist_email) therapistEmail = matching.therapist_email;
      } catch {}
      if (!therapistEmail) therapistEmail = await getMyTherapistEmail();

      await base44.entities.AssessmentResult.create({
        test_type: activeTest,
        score: total,
        severity: scored.severity,
        answers: test.items.map((_, i) => answers[i] || 0),
        client_email: user?.email || "",
        therapist_email: therapistEmail,
      });

      // Notify the therapist immediately if this result triggers a high-risk safety flag
      try {
        await base44.functions.invoke("safety-risk-alert", {
          test_type: activeTest,
          score: total,
          answers: test.items.map((_, i) => answers[i] || 0),
          client_email: user?.email || "",
          therapist_email: therapistEmail,
        });
      } catch (e) {
        console.error("Safety alert failed:", e);
      }

      const data = await base44.entities.AssessmentResult.list("-created_date", 50);
        setHistory(data);
        // Mark matching assignment as completed
        try {
          const myAssignments = await base44.entities.AssessmentAssignment.filter({ test_type: activeTest, status: "assigned" }, "-created_date", 10);
          for (const a of myAssignments) {
            if (a.client_email === user?.email) {
              await base44.entities.AssessmentAssignment.update(a.id, { status: "completed" });
            }
          }
          const refreshed = await base44.entities.AssessmentAssignment.filter({ status: "assigned" }, "-created_date", 50);
          setAssignments(refreshed || []);
        } catch {}
      } catch {}
      setSaving(false);
    setResult({ score: total, ...scored });
  }

  function backToList() {
    setActiveTest(null);
    setResult(null);
    setAnswers({});
  }

  // Test selection screen
  if (!activeTest) {
    return (
      <div className="p-6 md:p-10 max-w-4xl mx-auto">
        <div className="flex gap-1 p-1 mb-6 rounded-xl bg-secondary/60 w-full max-w-xs">
          <button onClick={() => setTab("assessments")} className={`flex-1 px-4 py-2 rounded-lg text-sm font-medium transition ${tab === "assessments" ? "bg-card text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"}`}>Assessments</button>
          <button onClick={() => setTab("sensory")} className={`flex-1 px-4 py-2 rounded-lg text-sm font-medium transition ${tab === "sensory" ? "bg-card text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"}`}>Sensory Profile</button>
          <button onClick={() => setTab("quiz")} className={`flex-1 px-4 py-2 rounded-lg text-sm font-medium transition ${tab === "quiz" ? "bg-card text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"}`}>Activities Quiz</button>
        </div>
        {tab === "sensory" ? (
          <SensoryProfile />
        ) : tab === "quiz" ? (
          <ActivitiesQuiz />
        ) : (
        <>
        <div className="flex items-start gap-3 mb-8">
          <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
            <ClipboardList className="text-primary" size={22} />
          </div>
          <div>
            <h1 className="font-heading text-3xl md:text-4xl font-semibold">Assessments</h1>
            <p className="text-muted-foreground text-lg">Standardized screening tools to help you and your care team track symptoms over time.</p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-amber-500/5 border border-amber-500/20 flex items-start gap-3 mb-8">
          <AlertCircle className="text-amber-600 shrink-0 mt-0.5" size={18} />
          <p className="text-sm text-muted-foreground">
            These screening tools are for educational and tracking purposes only. They are not diagnostic and do not replace evaluation by a qualified healthcare professional. Always discuss results with your provider.
          </p>
        </div>

        {assignments.length > 0 && (
          <div className="mb-8">
            <h2 className="font-heading text-lg font-semibold mb-3 flex items-center gap-2">
              <ClipboardList size={18} className="text-primary" /> Assigned by Your Therapist
            </h2>
            <div className="space-y-2">
              {assignments.map((a) => {
                const test = ASSESSMENTS[a.test_type];
                return (
                  <div key={a.id} className="pp-card p-4 flex items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="px-2 py-0.5 rounded-md bg-primary/10 text-primary text-xs font-bold">{test?.abbr || a.test_type}</span>
                        <span className="text-sm font-medium">{test?.name || a.test_type}</span>
                      </div>
                      {a.due_date && (
                        <p className="text-xs text-muted-foreground">Due: {new Date(a.due_date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</p>
                      )}
                    </div>
                    <button onClick={() => startTest(a.test_type)} className="px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition shrink-0">
                      Start
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <div className="mb-8">
          <ValuesChecklist />
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
          {Object.entries(ASSESSMENTS)
            .sort(([, a], [, b]) => a.items.length - b.items.length)
            .map(([key, test]) => (
            <motion.div key={key} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-5 flex flex-col">
              <div className="flex items-center gap-2 mb-3">
                <span className="px-2.5 py-1 rounded-lg bg-primary/10 text-primary text-xs font-bold">{test.abbr}</span>
                <span className="text-xs text-muted-foreground">{test.items.length} items</span>
              </div>
              <h3 className="font-heading text-lg font-semibold mb-2">{test.name}</h3>
              <p className="text-sm text-muted-foreground mb-4 flex-1">{test.description}</p>
              <button onClick={() => startTest(key)} className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:opacity-90 transition">
                Start Assessment
              </button>
            </motion.div>
          ))}
        </div>

        <div>
          <h2 className="font-heading text-lg font-semibold mb-3 flex items-center gap-2">
            <History size={18} className="text-muted-foreground" /> Results History
          </h2>
          {loading ? (
            <div className="flex items-center justify-center py-10">
              <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
            </div>
          ) : history.length === 0 ? (
            <div className="pp-card p-8 text-center">
              <p className="text-muted-foreground">No assessments taken yet. Start one above to begin tracking.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {history.map((r) => {
                const test = ASSESSMENTS[r.test_type];
                const scored = test?.score(r.score);
                return (
                  <div key={r.id} className="pp-card p-4 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="px-2 py-0.5 rounded-md bg-secondary text-xs font-bold">{r.test_type}</span>
                      <div>
                        <p className="text-sm font-medium">{test?.name || r.test_type}</p>
                        <p className="text-xs text-muted-foreground">{new Date(r.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-heading text-xl font-semibold">{r.score}</span>
                      {scored && (
                        <span className="px-2.5 py-1 rounded-full text-xs font-medium" style={{ backgroundColor: `${scored.color}15`, color: scored.color }}>
                          {scored.severity}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="mt-8 text-center space-y-2">
          <div>
            <Link to="/reports" className="text-sm text-primary hover:underline inline-flex items-center gap-1">
              <TrendingUp size={14} /> View full progress reports
            </Link>
          </div>
          <div>
            <Link to="/billing" className="text-sm text-primary hover:underline">View plans & billing</Link>
          </div>
        </div>
        </>
        )}
      </div>
    );
  }

  const test = ASSESSMENTS[activeTest];

  // Results screen
  if (result) {
    return (
      <div className="p-6 md:p-10 max-w-2xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-8 text-center">
          <p className="text-sm text-muted-foreground mb-1">{test.name}</p>
          <div className="my-6">
            <span className="font-heading text-6xl font-semibold" style={{ color: result.color }}>{result.score}</span>
            <span className="text-xl text-muted-foreground ml-2">/ {test.items.length * (test.scale.length - 1)}</span>
          </div>
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium mb-6" style={{ backgroundColor: `${result.color}15`, color: result.color }}>
            {result.severity}
          </span>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">{result.description}</p>

          <div className="p-4 rounded-xl bg-secondary/50 text-left">
            <p className="text-xs text-muted-foreground">
              <strong>Important:</strong> This screening tool is for tracking purposes only and does not diagnose any condition. Please share these results with your healthcare provider for proper interpretation and care planning.
            </p>
          </div>

          <button onClick={backToList} className="mt-6 px-6 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition">
            Back to Assessments
          </button>
        </motion.div>
      </div>
    );
  }

  // Active test screen
  const answeredCount = Object.keys(answers).length;
  const allAnswered = answeredCount === test.items.length;

  return (
    <div className="p-6 md:p-10 max-w-2xl mx-auto">
      <button onClick={backToList} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-4">
        <ArrowLeft size={16} /> Back
      </button>

      <div className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <span className="px-2.5 py-1 rounded-lg bg-primary/10 text-primary text-xs font-bold">{test.abbr}</span>
          <h1 className="font-heading text-2xl font-semibold">{test.name}</h1>
        </div>
        <p className="text-sm text-muted-foreground mt-2">{test.instructions}</p>
      </div>

      <div className="mb-6">
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-1.5">
          <span>Progress</span>
          <span>{answeredCount} / {test.items.length}</span>
        </div>
        <div className="h-2 rounded-full bg-secondary overflow-hidden">
          <div className="h-full bg-primary transition-all duration-300" style={{ width: `${(answeredCount / test.items.length) * 100}%` }} />
        </div>
      </div>

      <div className="space-y-4 mb-6">
        {test.items.map((item, i) => (
          <div key={i} className="pp-card p-4">
            <p className="text-sm font-medium mb-3">{i + 1}. {item}</p>
            <div className="grid gap-2">
              {test.scale.map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => setAnswer(i, opt.value)}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-left transition
                    ${answers[i] === opt.value ? "bg-primary/10 border border-primary/30" : "border border-border/60 hover:bg-secondary/50"}`}
                >
                  <span className={`w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 ${answers[i] === opt.value ? "border-primary" : "border-border"}`}>
                    {answers[i] === opt.value && <span className="w-2 h-2 rounded-full bg-primary" />}
                  </span>
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={submitTest}
        disabled={!allAnswered || saving}
        className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50"
      >
        {saving ? "Saving…" : "Submit Assessment"}
      </button>
    </div>
  );
}