import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Shield, Brain, Heart, Activity, LineChart as LineChartIcon, MessageSquare,
  BookOpen, Check, Stethoscope, Sparkles, Phone, ArrowRight, Lock, Users,
  Target, ClipboardList, Wand2, LifeBuoy, Mail, Calendar, Star,
} from "lucide-react";

const CLIENT_FEATURES = [
  { icon: Brain, title: "CBT & DBT Tools", desc: "Thought records, coping toolbox, and an AI coach that guides clients through evidence-based skills in the moment.", color: "text-primary" },
  { icon: Activity, title: "Nervous System Check-ins", desc: "Daily sleep, stress, movement, and mood logs that feed a real-time wellbeing barometer.", color: "text-accent" },
  { icon: ClipboardList, title: "Standardized Assessments", desc: "GAD-7, PHQ-9, PCL-5, WHO-5, BDI, BAI, ISI, K6 and more — auto-scored with severity bands.", color: "text-chart-1" },
  { icon: Target, title: "Values & Behavior Activation", desc: "Clients discover their top values and link enjoyable, valuable, and routine activities to them.", color: "text-subtleAccent" },
  { icon: BookOpen, title: "Guided Journaling", desc: "Free journaling and structured CBT thought records that build insight between sessions.", color: "text-chart-3" },
  { icon: LifeBuoy, title: "Crisis Support", desc: "Personalized safety plans, warning-sign tracking, and 988 routing when risk escalates.", color: "text-destructive" },
];

const CLINICIAN_FEATURES = [
  { icon: Stethoscope, title: "Therapist Portal", desc: "One dashboard per client: assessments, goals, homework, nervous-system data, and clinical notes.", color: "text-primary" },
  { icon: LineChartIcon, title: "Progress Tracking", desc: "Initial-vs-recent comparisons, 6-month symptom trend lines, and score overlays showing exactly how far each client has come.", color: "text-accent" },
  { icon: MessageSquare, title: "Homework & Reminders", desc: "Assign CBT/DBT homework with checklists, due dates, calendar sync, and automated completion alerts.", color: "text-subtleAccent" },
  { icon: Users, title: "Organization Oversight", desc: "De-identified caseload, utilization, and outcome metrics for supervisors and group practices.", color: "text-chart-3" },
];

const STATS = [
  { value: "9+", label: "Standardized assessments" },
  { value: "CBT · DBT · ACT", label: "Evidence-based modalities" },
  { value: "HIPAA-aligned", label: "PHI & audit logging" },
  { value: "Therapist-built", label: "By clinicians, for clinicians" },
];

const TIERS = [
  { name: "Solo", price: "$59/mo", desc: "For an individual clinician.", points: ["Unlimited clients", "All assessment tools", "Progress tracking & reports", "AI coach for clients"] },
  { name: "Starter", price: "$129/mo", desc: "For small practices — 2–3 clinicians.", points: ["Everything in Solo", "Organization dashboard", "Supervisor insights", "Shared client visibility"] },
  { name: "Growth", price: "$249/mo", desc: "For group practices — 4–10 clinicians.", points: ["Everything in Starter", "Unlimited homework", "Practice-wide management", "Priority support"] },
  { name: "Professional", price: "$499/mo", desc: "For growing practices — 11–25 clinicians.", points: ["Everything in Growth", "Expanded org-wide analytics", "Dedicated account manager", "Priority support"] },
];

function Section({ children, className = "" }) {
  return <section className={`max-w-6xl mx-auto px-5 ${className}`}>{children}</section>;
}

export default function Website() {
  return (
    <div className="min-h-screen pp-gradient-bg">
      {/* Nav */}
      <header className="sticky top-0 z-40 bg-background/90 backdrop-blur-sm border-b border-border/60">
        <div className="max-w-6xl mx-auto px-5 py-3 flex items-center gap-4">
          <Link to="/" className="flex items-center gap-2">
            <span className="font-display text-2xl font-bold text-primary">WayPoint</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6 ml-6 text-sm text-muted-foreground">
            <a href="#features" className="hover:text-foreground transition">Features</a>
            <a href="#clinicians" className="hover:text-foreground transition">For Clinicians</a>
            <a href="#evidence" className="hover:text-foreground transition">Evidence</a>
            <a href="#security" className="hover:text-foreground transition">Security</a>
            <a href="#pricing" className="hover:text-foreground transition">Pricing</a>
          </nav>
          <div className="flex items-center gap-2 ml-auto">
            <Link to="/demo" className="px-4 py-2 rounded-xl text-sm font-medium text-foreground/70 hover:text-foreground transition">Demo</Link>
            <Link to="/contact-sales" className="px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition flex items-center gap-1.5">
              <Mail size={14} /> Contact Sales
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <Section className="py-16 md:py-24 text-center">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-5">
            <Sparkles size={13} /> Therapist-built mental health companion
          </span>
          <h1 className="font-display text-4xl md:text-6xl font-bold leading-tight mb-5">
            Evidence-based care<br className="hidden md:block" /> that travels <span className="text-primary">with your clients</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            WayPoint brings CBT/DBT tools, guided journaling, standardized assessments, and clinical progress tracking into one HIPAA-aligned platform — so progress continues between sessions.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link to="/contact-sales" className="px-6 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition flex items-center gap-2">
              Request enterprise pricing <ArrowRight size={16} />
            </Link>
            <Link to="/demo" className="px-6 py-3 rounded-xl bg-card border border-border/60 font-medium hover:shadow-sm transition">
              Start a 7-day demo
            </Link>
          </div>
        </motion.div>

        {/* Hero card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.15 }}
          className="mt-14 max-w-4xl mx-auto pp-card p-6 md:p-8 text-left"
        >
          <div className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center"><Activity className="text-primary" size={20} /></div>
            <div>
              <p className="font-heading font-semibold">Wellbeing Barometer</p>
              <p className="text-xs text-muted-foreground">Mood, sleep, stress & clinical scores in one number</p>
            </div>
            <div className="ml-auto text-right">
              <p className="font-heading text-3xl font-bold text-primary">68</p>
              <p className="text-xs text-muted-foreground">up 14 pts this month</p>
            </div>
          </div>
          <div className="h-2.5 rounded-full bg-secondary overflow-hidden mb-6">
            <div className="h-full rounded-full bg-gradient-to-r from-primary to-accent" style={{ width: "68%" }} />
          </div>
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-3 rounded-xl bg-secondary/40">
              <p className="font-heading text-xl font-semibold">GAD-7</p>
              <p className="text-xs text-muted-foreground">9 → 5</p>
            </div>
            <div className="p-3 rounded-xl bg-secondary/40">
              <p className="font-heading text-xl font-semibold">PHQ-9</p>
              <p className="text-xs text-muted-foreground">14 → 8</p>
            </div>
            <div className="p-3 rounded-xl bg-secondary/40">
              <p className="font-heading text-xl font-semibold">WHO-5</p>
              <p className="text-xs text-muted-foreground">36 → 52</p>
            </div>
          </div>
        </motion.div>
      </Section>

      {/* Stats bar */}
      <Section className="pb-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {STATS.map((s) => (
            <div key={s.label} className="pp-card p-5 text-center">
              <p className="font-heading text-xl md:text-2xl font-bold text-primary">{s.value}</p>
              <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Client features */}
      <Section id="features" className="py-16">
        <div className="text-center mb-10">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-3">Tools clients actually use</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">A companion that meets clients where they are — from daily check-ins to in-the-moment coping.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {CLIENT_FEATURES.map((f) => {
            const Icon = f.icon;
            return (
              <div key={f.title} className="pp-card p-5 hover:shadow-md hover:-translate-y-0.5 transition-all">
                <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                  <Icon className={f.color} size={22} />
                </div>
                <h3 className="font-heading text-lg font-semibold mb-1.5">{f.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
              </div>
            );
          })}
        </div>
      </Section>

      {/* Clinician features */}
      <Section id="clinicians" className="py-16 bg-secondary/20">
        <div className="text-center mb-10">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-3">Built for clinicians</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">Everything you need to track outcomes, assign work, and keep oversight — without the paperwork.</p>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          {CLINICIAN_FEATURES.map((f) => {
            const Icon = f.icon;
            return (
              <div key={f.title} className="pp-card p-5 flex gap-4">
                <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  <Icon className={f.color} size={22} />
                </div>
                <div>
                  <h3 className="font-heading text-lg font-semibold mb-1.5">{f.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </Section>

      {/* Evidence-based */}
      <Section id="evidence" className="py-16">
        <div className="pp-card p-8 md:p-10 text-center">
          <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mx-auto mb-4">
            <BookOpen className="text-accent" size={24} />
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-3">Grounded in evidence</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-6">
            Every assessment, tool, and intervention in WayPoint maps to peer-reviewed, APA-7th-edition-cited research — from CBT and DBT to behavior activation and trauma-informed care.
          </p>
          <Link to="/references" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-accent/10 text-accent font-medium hover:bg-accent/20 transition">
            View the reference library <ArrowRight size={16} />
          </Link>
        </div>
      </Section>

      {/* Security */}
      <Section id="security" className="py-16 bg-secondary/20">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
              <Shield className="text-primary" size={24} />
            </div>
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-3">Security &amp; compliance first</h2>
            <p className="text-muted-foreground mb-5 leading-relaxed">
              WayPoint is designed with clinical privacy at its core. Protected Health Information is restricted to authorized providers and their assigned clients, with every dashboard access logged.
            </p>
            <Link to="/pitch-deck" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition">
              See the enterprise pitch deck <ArrowRight size={16} />
            </Link>
          </div>
          <div className="space-y-3">
            {[
              { icon: Lock, text: "Row-level security isolates each client's data" },
              { icon: Users, text: "Role-based access for therapists, supervisors & admins" },
              { icon: ClipboardList, text: "Audit logging of every PHI view" },
              { icon: Check, text: "Functioning-level feature gating per client" },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <div key={item.text} className="pp-card p-4 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-accent/10 flex items-center justify-center shrink-0">
                    <Icon className="text-accent" size={18} />
                  </div>
                  <p className="text-sm font-medium">{item.text}</p>
                </div>
              );
            })}
          </div>
        </div>
      </Section>

      {/* Pricing */}
      <Section id="pricing" className="py-16">
        <div className="text-center mb-10">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-3">Plans that scale with your practice</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">Clinicians pay for the tools they use — clients are always free. Running 26+ clinicians? Ask about custom Enterprise pricing.</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {TIERS.map((t, i) => (
            <div key={t.name} className={`pp-card p-6 flex flex-col ${i === 2 ? "border-primary/40 ring-1 ring-primary/20" : ""}`}>
              {i === 1 && <span className="self-start px-2.5 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-medium mb-3">Most popular</span>}
              <h3 className="font-heading text-xl font-semibold mb-1">{t.name}</h3>
              <p className="font-heading text-2xl font-semibold mb-1">{t.price}</p>
              <p className="text-sm text-muted-foreground mb-4">{t.desc}</p>
              <ul className="space-y-2 mb-6 flex-1">
                {t.points.map((p) => (
                  <li key={p} className="flex items-start gap-2 text-sm">
                    <Check size={16} className="text-accent shrink-0 mt-0.5" /> {p}
                  </li>
                ))}
              </ul>
              <Link to="/billing" className="w-full py-2.5 rounded-xl bg-primary/10 text-primary text-sm font-medium text-center hover:bg-primary/20 transition">
                See plan details
              </Link>
            </div>
          ))}
        </div>
      </Section>

      {/* CTA band */}
      <Section className="py-16">
        <div className="rounded-3xl bg-gradient-to-br from-primary to-accent p-10 md:p-14 text-center text-primary-foreground">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-3">Bring WayPoint to your practice</h2>
          <p className="opacity-90 max-w-xl mx-auto mb-7">Book a personalized walkthrough or start a 7-day demo to see WayPoint with your clients and clinicians.</p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link to="/contact-sales" className="px-6 py-3 rounded-xl bg-card text-primary font-medium hover:shadow-md transition flex items-center gap-2">
              <Calendar size={16} /> Book a walkthrough
            </Link>
            <Link to="/demo" className="px-6 py-3 rounded-xl bg-white/15 text-primary-foreground font-medium hover:bg-white/25 transition border border-white/20">
              Start a demo
            </Link>
          </div>
        </div>
      </Section>

      {/* Footer */}
      <footer className="border-t border-border/60 bg-card">
        <Section className="py-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-8">
            <div className="flex items-center gap-2">
              <span className="font-display text-2xl font-bold text-primary">WayPoint</span>
            </div>
            <div className="flex gap-6 text-sm text-muted-foreground">
              <Link to="/about" className="hover:text-foreground transition">About</Link>
              <Link to="/contact" className="hover:text-foreground transition">Contact</Link>
              <Link to="/contact-sales" className="hover:text-foreground transition">Sales</Link>
              <Link to="/references" className="hover:text-foreground transition">References</Link>
              <Link to="/pitch-deck" className="hover:text-foreground transition">Pitch Deck</Link>
            </div>
          </div>
          <div className="p-4 rounded-xl border-2 border-primary/25 bg-primary/5 text-center">
            <div className="flex items-center justify-center gap-2 text-primary mb-1">
              <Phone size={15} /><span className="text-sm font-semibold">In crisis?</span>
            </div>
            <p className="text-sm text-foreground/60">Call or text <span className="font-bold text-foreground">988</span> for the Suicide &amp; Crisis Lifeline, 24/7.</p>
          </div>
          <p className="text-xs text-muted-foreground text-center mt-6">
            © {new Date().getFullYear()} WayPoint. For clinical and educational use. Not a substitute for emergency care.
          </p>
        </Section>
      </footer>
    </div>
  );
}