import React, { useState, useEffect, useMemo } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import ClinicianGate from "@/components/ClinicianGate";
import { ASSESSMENTS } from "@/lib/assessments";
import { NEGATIVE_ITEMS, MAX_IMPAIRMENT } from "@/lib/functionalImpairment";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { TrendingUp, TrendingDown, Minus, Activity, ClipboardList, ArrowLeft, CalendarClock } from "lucide-react";

const CHART_COLORS = {
  BAI: "#E07856", BDI: "#6B7280", "PCL-5": "#8B5CF6", PHQ9: "#3B82F6",
  GAD7: "#EF4444", ISI: "#6366F1", K6: "#F59E0B", WHO5: "#10B981",
  SENSORY: "#14B8A6", ASRS: "#EC4899",
};

const NINETY_DAYS = 90 * 24 * 60 * 60 * 1000;

export default function ClientTrends() {
  return <ClinicianGate><ClientTrendsContent /></ClinicianGate>;
}

function ClientTrendsContent() {
  const { clientEmail } = useParams();
  const [searchParams] = useSearchParams();
  const clientName = searchParams.get("name") || "";
  const decodedEmail = decodeURIComponent(clientEmail || "");

  const [assessments, setAssessments] = useState([]);
  const [impairments, setImpairments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [hiddenTests, setHiddenTests] = useState(new Set());

  useEffect(() => {
    (async () => {
      let me = null;
      try { me = await base44.auth.me(); } catch {}
      if (me?.email && decodedEmail) {
        try {
          await base44.entities.AuditLog.create({
            action: "view_client_trends",
            client_email: decodedEmail,
            therapist_email: me.email,
            details: "Viewed 90-day assessment & functional impairment trends",
          });
        } catch (e) { console.error("Audit log error:", e); }
        try {
          const a = await base44.entities.AssessmentResult.filter(
            { client_email: decodedEmail }, "-created_date", 500
          );
          setAssessments(a || []);
        } catch (e) { console.error("Assessment fetch error:", e); }
        try {
          const f = await base44.entities.FunctionalImpairment.filter(
            { client_email: decodedEmail }, "-created_date", 500
          );
          setImpairments(f || []);
        } catch (e) { console.error("Impairment fetch error:", e); }
      }
      setLoading(false);
    })();
  }, [decodedEmail]);

  const cutoff = useMemo(() => Date.now() - NINETY_DAYS, []);

  const recentAssessments = useMemo(
    () => assessments.filter((a) => new Date(a.created_date).getTime() >= cutoff),
    [assessments, cutoff]
  );
  const recentImpairments = useMemo(
    () => impairments.filter((e) => new Date(e.created_date).getTime() >= cutoff),
    [impairments, cutoff]
  );

  const testTypes = useMemo(
    () => [...new Set(recentAssessments.map((a) => a.test_type))],
    [recentAssessments]
  );

  const assessmentChart = useMemo(() => {
    const grouped = {};
    recentAssessments.forEach((a) => {
      const d = new Date(a.created_date);
      const key = d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
      if (!grouped[key]) grouped[key] = { date: key, _sort: d.getTime() };
      grouped[key][a.test_type] = a.score;
    });
    return Object.values(grouped).sort((a, b) => a._sort - b._sort);
  }, [recentAssessments]);

  const impairmentChart = useMemo(() => {
    return recentImpairments
      .map((e) => {
        const d = new Date(e.created_date);
        const raw = NEGATIVE_ITEMS.reduce((sum, i) => sum + (e[i.key] || 0), 0);
        return {
          date: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
          _sort: d.getTime(),
          impairment: Math.round((raw / MAX_IMPAIRMENT) * 100),
          engagement: e.enjoyable_activities ?? 0,
        };
      })
      .sort((a, b) => a._sort - b._sort);
  }, [recentImpairments]);

  const summaries = useMemo(() => {
    return testTypes
      .map((type) => {
        const typeResults = recentAssessments
          .filter((a) => a.test_type === type)
          .sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
        const first = typeResults[0];
        const latest = typeResults[typeResults.length - 1];
        const test = ASSESSMENTS[type];
        const delta = latest.score - first.score;
        const isWellbeing = type === "WHO5";
        const improving = isWellbeing ? delta > 0 : delta < 0;
        return {
          type,
          name: test?.name || type,
          abbr: test?.abbr || type,
          first,
          latest,
          delta,
          improving,
          count: typeResults.length,
          color: CHART_COLORS[type] || "#999",
          latestScored: test?.score(latest.score),
        };
      })
      .sort((a, b) => a.abbr.localeCompare(b.abbr));
  }, [recentAssessments, testTypes]);

  const impairmentSummary = useMemo(() => {
    if (recentImpairments.length === 0) return null;
    const sorted = [...recentImpairments].sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    const pct = (rec) => Math.round((NEGATIVE_ITEMS.reduce((s, i) => s + (rec[i.key] || 0), 0) / MAX_IMPAIRMENT) * 100);
    const firstPct = pct(sorted[0]);
    const latestPct = pct(sorted[sorted.length - 1]);
    return {
      firstPct,
      latestPct,
      delta: latestPct - firstPct,
      count: sorted.length,
      latestEngagement: sorted[sorted.length - 1].enjoyable_activities ?? 0,
    };
  }, [recentImpairments]);

  function toggleTest(type) {
    const next = new Set(hiddenTests);
    if (next.has(type)) next.delete(type);
    else next.add(type);
    setHiddenTests(next);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const hasData = recentAssessments.length > 0 || recentImpairments.length > 0;

  return (
    <div className="p-6 md:p-10 max-w-7xl mx-auto">
      <Link
        to="/therapist"
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-4"
      >
        <ArrowLeft size={16} /> Back to Clients
      </Link>

      <div className="mb-6 flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="font-heading text-2xl md:text-3xl font-semibold">{clientName || decodedEmail}</h1>
          <p className="text-sm text-muted-foreground">{decodedEmail}</p>
        </div>
        <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-medium shrink-0">
          <CalendarClock size={14} /> Last 90 days
        </span>
      </div>

      {!hasData ? (
        <div className="pp-card p-10 text-center">
          <Activity className="mx-auto mb-4 text-muted-foreground/40" size={48} />
          <h3 className="font-heading text-xl font-semibold mb-2">No trend data in this window</h3>
          <p className="text-muted-foreground">
            This client has no assessments or function check-ins logged in the last 90 days.
          </p>
        </div>
      ) : (
        <>
          {/* Assessment progression chart */}
          {recentAssessments.length > 0 && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-5 mb-6 overflow-hidden">
              <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <Activity className="text-primary" size={18} />
                  <h2 className="font-heading text-lg font-semibold">Assessment Scores</h2>
                </div>
                <span className="text-xs text-muted-foreground">
                  {recentAssessments.length} assessments · {testTypes.length} measures
                </span>
              </div>

              <div className="flex flex-wrap gap-2 mb-4">
                {testTypes.map((type) => {
                  const hidden = hiddenTests.has(type);
                  const test = ASSESSMENTS[type];
                  return (
                    <button
                      key={type}
                      onClick={() => toggleTest(type)}
                      className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium transition whitespace-nowrap
                        ${hidden ? "bg-secondary/40 text-muted-foreground/50" : "bg-secondary text-foreground"}`}
                    >
                      <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: hidden ? "#ccc" : CHART_COLORS[type] }} />
                      {test?.abbr || type}
                    </button>
                  );
                })}
              </div>

              <div className="w-full" style={{ height: 320, minWidth: 0 }}>
                <ResponsiveContainer width="100%" height="100%" debounce={100}>
                  <LineChart data={assessmentChart} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" interval="preserveStartEnd" />
                    <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" width={32} />
                    <Tooltip contentStyle={{ borderRadius: "12px", border: "1px solid hsl(var(--border))", fontSize: "12px" }} />
                    {testTypes
                      .filter((type) => !hiddenTests.has(type))
                      .map((type) => (
                        <Line key={type} type="monotone" dataKey={type} stroke={CHART_COLORS[type]} strokeWidth={2} dot={{ r: 4 }} connectNulls />
                      ))}
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          )}

          {/* Functional impairment trend chart */}
          {recentImpairments.length > 0 && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-5 mb-6 overflow-hidden">
              <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <ClipboardList className="text-primary" size={18} />
                  <h2 className="font-heading text-lg font-semibold">Functional Impairment Trend</h2>
                </div>
                <span className="text-xs text-muted-foreground">{recentImpairments.length} check-ins</span>
              </div>

              <div className="flex flex-wrap gap-4 mb-4">
                <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: "#E07856" }} /> Impairment % (lower is better)
                </span>
                <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: "#10B981" }} /> Engagement (0–4)
                </span>
              </div>

              <div className="w-full" style={{ height: 320, minWidth: 0 }}>
                <ResponsiveContainer width="100%" height="100%" debounce={100}>
                  <LineChart data={impairmentChart} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" interval="preserveStartEnd" />
                    <YAxis yAxisId="left" domain={[0, 100]} tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" width={36} unit="%" />
                    <YAxis yAxisId="right" orientation="right" domain={[0, 4]} tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" width={24} />
                    <Tooltip contentStyle={{ borderRadius: "12px", border: "1px solid hsl(var(--border))", fontSize: "12px" }} />
                    <Line yAxisId="left" type="monotone" dataKey="impairment" name="Impairment %" stroke="#E07856" strokeWidth={2} dot={{ r: 4 }} />
                    <Line yAxisId="right" type="monotone" dataKey="engagement" name="Engagement" stroke="#10B981" strokeWidth={2} dot={{ r: 4 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          )}

          {/* Impairment summary card */}
          {impairmentSummary && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-5 mb-6">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <ClipboardList className="text-primary" size={18} />
                  <h2 className="font-heading text-lg font-semibold">Function Summary</h2>
                </div>
                <span className="text-xs text-muted-foreground">{impairmentSummary.count} check-ins</span>
              </div>
              <div className="flex items-end justify-between gap-3 flex-wrap">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Latest Impairment</p>
                  <div className="flex items-center gap-2">
                    <span className="font-heading text-2xl font-semibold">{impairmentSummary.latestPct}%</span>
                    <span className="text-xs text-muted-foreground">Engagement {impairmentSummary.latestEngagement}/4</span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground mb-1">Change from first</p>
                  <div className={`flex items-center gap-1 font-semibold text-sm ${
                    impairmentSummary.delta === 0 ? "text-muted-foreground" : impairmentSummary.delta < 0 ? "text-green-600" : "text-red-600"}`}>
                    {impairmentSummary.delta === 0 ? <Minus size={14} /> : impairmentSummary.delta < 0 ? <TrendingDown size={14} /> : <TrendingUp size={14} />}
                    {impairmentSummary.delta > 0 ? `+${impairmentSummary.delta}%` : `${impairmentSummary.delta}%`}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Assessment breakdown cards */}
          {summaries.length > 0 && (
            <div>
              <h2 className="font-heading text-lg font-semibold mb-3">Assessment Breakdown</h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {summaries.map((s) => {
                  const deltaColor = s.delta === 0 ? "text-muted-foreground" : s.improving ? "text-green-600" : "text-red-600";
                  return (
                    <motion.div key={s.type} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-5">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="px-2 py-0.5 rounded-md text-xs font-bold shrink-0" style={{ backgroundColor: `${s.color}15`, color: s.color }}>
                            {s.abbr}
                          </span>
                          <span className="text-sm font-medium truncate">{s.name}</span>
                        </div>
                        <span className="text-xs text-muted-foreground shrink-0">{s.count}×</span>
                      </div>
                      <div className="flex items-end justify-between gap-3">
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Latest</p>
                          <div className="flex items-center gap-2">
                            <span className="font-heading text-2xl font-semibold">{s.latest.score}</span>
                            {s.latestScored && (
                              <span className="px-2 py-0.5 rounded-full text-xs font-medium" style={{ backgroundColor: `${s.latestScored.color}15`, color: s.latestScored.color }}>
                                {s.latestScored.severity}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground mb-1">Change</p>
                          <div className={`flex items-center gap-1 font-semibold text-sm ${deltaColor}`}>
                            {s.delta === 0 ? <Minus size={14} /> : s.delta > 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                            {s.delta > 0 ? `+${s.delta}` : s.delta}
                          </div>
                        </div>
                      </div>
                      <div className="mt-3 pt-3 border-t border-border/60 flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">First: {s.first.score}</span>
                        <span className={`font-medium ${deltaColor}`}>
                          {s.delta === 0 ? "No change" : s.improving ? "Improving" : "Worsening"}
                        </span>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}