import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { QUIZ_QUESTIONS } from "@/lib/activitiesQuiz";
import { Sparkles, ArrowRight, ArrowLeft, Check, Heart, Target, Repeat, Trophy } from "lucide-react";

const CATEGORY_META = {
  enjoyable: { label: "Enjoyable", icon: Heart, color: "accent" },
  valuable: { label: "Valuable", icon: Target, color: "primary" },
  routine: { label: "Routine", icon: Repeat, color: "subtleAccent" },
};

function activityKey(a) {
  return `${a.name}|${a.category}`;
}

export default function ActivitiesQuiz() {
  const [step, setStep] = useState(0); // 0..QUIZ_QUESTIONS.length -> results
  const [picks, setPicks] = useState({}); // questionId -> option index
  const [recommended, setRecommended] = useState([]);
  const [selected, setSelected] = useState({}); // activityKey -> bool
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  const total = QUIZ_QUESTIONS.length;
  const isResults = step === total;

  function choose(optionIndex) {
    const q = QUIZ_QUESTIONS[step];
    setPicks({ ...picks, [q.id]: optionIndex });
    setStep((s) => s + 1);
    if (step + 1 === total) buildResults({ ...picks, [q.id]: optionIndex });
  }

  function buildResults(allPicks) {
    const seen = new Set();
    const recs = [];
    QUIZ_QUESTIONS.forEach((q) => {
      const idx = allPicks[q.id];
      if (idx === undefined) return;
      q.options[idx].activities.forEach((a) => {
        const key = activityKey(a);
        if (!seen.has(key)) {
          seen.add(key);
          recs.push(a);
        }
      });
    });
    setRecommended(recs);
    const sel = {};
    recs.forEach((a) => { sel[activityKey(a)] = true; });
    setSelected(sel);
  }

  function toggle(a) {
    setSelected((prev) => ({ ...prev, [activityKey(a)]: !prev[activityKey(a)] }));
  }

  async function addSelected() {
    const chosen = recommended.filter((a) => selected[activityKey(a)]);
    if (chosen.length === 0) return;
    setSaving(true);
    try {
      const me = await base44.auth.me();
      let therapistEmail = "";
      try {
        const hw = await base44.entities.HomeworkAssignment.list("-created_date", 1);
        if (hw[0]?.therapist_email) therapistEmail = hw[0].therapist_email;
      } catch {}
      const records = chosen.map((a) => ({
        name: a.name,
        category: a.category,
        linked_value: a.value || "",
        frequency: "weekly",
        status: "planned",
        client_email: me?.email || "",
        therapist_email: therapistEmail,
      }));
      await base44.entities.BehaviorActivationActivity.bulkCreate(records);
      setDone(true);
    } catch {}
    setSaving(false);
  }

  // --- Results screen ---
  if (isResults && !done) {
    const grouped = { enjoyable: [], valuable: [], routine: [] };
    recommended.forEach((a) => grouped[a.category]?.push(a));
    const chosenCount = recommended.filter((a) => selected[activityKey(a)]).length;

    return (
      <div className="p-6 md:p-10 max-w-2xl mx-auto">
        <div className="flex items-start gap-3 mb-6">
          <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
            <Trophy className="text-primary" size={22} />
          </div>
          <div>
            <h1 className="font-heading text-3xl font-semibold">Your Activity Picks</h1>
            <p className="text-muted-foreground text-lg">Based on your answers, here are activities worth trying. Select the ones you'd like to add to your behavior activation plan.</p>
          </div>
        </div>

        {recommended.length === 0 ? (
          <div className="pp-card p-8 text-center">
            <p className="text-muted-foreground mb-4">No activities matched. Try answering a few questions!</p>
            <button onClick={() => setStep(0)} className="px-5 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium">Restart quiz</button>
          </div>
        ) : (
          <>
            <div className="space-y-6 mb-6">
              {Object.entries(grouped).map(([cat, items]) => {
                if (items.length === 0) return null;
                const meta = CATEGORY_META[cat];
                const Icon = meta.icon;
                return (
                  <div key={cat}>
                    <div className="flex items-center gap-2 mb-3">
                      <Icon size={18} className={`text-${meta.color}`} />
                      <h3 className="font-heading text-lg font-semibold">{meta.label}</h3>
                    </div>
                    <div className="space-y-2">
                      {items.map((a) => {
                        const key = activityKey(a);
                        const on = selected[key];
                        return (
                          <button
                            key={key}
                            onClick={() => toggle(a)}
                            className={`w-full flex items-center gap-3 p-3.5 rounded-xl border text-left transition ${
                              on ? "border-primary/40 bg-primary/5" : "border-border/60 bg-secondary/20"
                            }`}
                          >
                            <span className={`w-6 h-6 rounded-md flex items-center justify-center shrink-0 ${on ? "bg-primary text-primary-foreground" : "border-2 border-border"}`}>
                              {on && <Check size={14} />}
                            </span>
                            <div className="min-w-0 flex-1">
                              <p className={`text-sm font-medium ${on ? "" : "text-muted-foreground"}`}>{a.name}</p>
                              {a.value && <span className="text-xs text-muted-foreground">tied to {a.value}</span>}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

            <button
              onClick={addSelected}
              disabled={chosenCount === 0 || saving}
              className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {saving ? "Adding…" : <><Sparkles size={16} /> Add {chosenCount} activit{chosenCount === 1 ? "y" : "ies"} to my plan</>}
            </button>
            <button onClick={() => setStep(0)} className="w-full mt-2 py-2 text-sm text-muted-foreground hover:text-foreground transition">
              Retake quiz
            </button>
          </>
        )}
      </div>
    );
  }

  // --- Success screen ---
  if (done) {
    return (
      <div className="p-6 md:p-10 max-w-md mx-auto text-center">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", duration: 0.5 }}>
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <Trophy className="text-primary" size={32} />
          </div>
          <h1 className="font-heading text-2xl font-semibold mb-2">Activities added!</h1>
          <p className="text-muted-foreground mb-6">Your picks are now part of your behavior activation plan. Your therapist can see them too.</p>
          <Link to="/behavior-activation" className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition">
            View my activities <ArrowRight size={16} />
          </Link>
        </motion.div>
      </div>
    );
  }

  // --- Question screen ---
  const q = QUIZ_QUESTIONS[step];
  const progress = (step / total) * 100;

  return (
    <div className="p-6 md:p-10 max-w-2xl mx-auto">
      <Link to="/behavior-activation" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-6">
        <ArrowLeft size={16} /> Back to Behavior Activation
      </Link>

      <div className="flex items-center gap-3 mb-6">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Sparkles className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-2xl font-semibold">Activities Quiz</h1>
          <p className="text-sm text-muted-foreground">Find enjoyable and valuable activities that matter to you.</p>
        </div>
      </div>

      {/* Progress */}
      <div className="mb-6">
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-1.5">
          <span>Question {step + 1} of {total}</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <div className="h-2 rounded-full bg-secondary overflow-hidden">
          <div className="h-full bg-primary transition-all duration-300" style={{ width: `${progress}%` }} />
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={q.id}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.25 }}
        >
          <div className="pp-card p-6">
            <div className="text-4xl mb-3">{q.emoji}</div>
            <h2 className="font-heading text-xl font-semibold mb-5">{q.prompt}</h2>
            <div className="space-y-2.5">
              {q.options.map((opt, i) => (
                <button
                  key={i}
                  onClick={() => choose(i)}
                  className="w-full flex items-center justify-between gap-3 p-4 rounded-xl border border-border/60 hover:border-primary/50 hover:bg-primary/5 transition text-left group"
                >
                  <span className="text-sm font-medium">{opt.label}</span>
                  <ArrowRight size={18} className="text-muted-foreground group-hover:text-primary transition shrink-0" />
                </button>
              ))}
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {step > 0 && (
        <button onClick={() => setStep((s) => s - 1)} className="mt-4 flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition">
          <ArrowLeft size={16} /> Back
        </button>
      )}
    </div>
  );
}