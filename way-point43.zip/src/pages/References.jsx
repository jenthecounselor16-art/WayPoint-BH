import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { BookOpen, ArrowLeft } from "lucide-react";
import { REFERENCE_SECTIONS } from "@/lib/references";

export default function References() {
  return (
    <div className="p-6 md:p-10 max-w-4xl mx-auto">
      <Link to="/" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-6">
        <ArrowLeft size={16} /> Back to Home
      </Link>

      <div className="flex items-start gap-3 mb-3">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <BookOpen className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Evidence-Based References</h1>
          <p className="text-muted-foreground text-lg">All interventions and assessments in WayPoint are grounded in peer-reviewed, evidence-based clinical literature.</p>
        </div>
      </div>

      <div className="p-4 rounded-xl bg-secondary/50 border border-border/60 mb-8">
        <p className="text-sm text-muted-foreground leading-relaxed">
          References are provided in APA format (7th edition). These materials are for educational and clinical tracking purposes and do not replace professional evaluation or treatment.
        </p>
      </div>

      <div className="space-y-10">
        {REFERENCE_SECTIONS.map((section, sIdx) => (
          <motion.div key={section.title} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: sIdx * 0.05 }}>
            <h2 className="font-heading text-xl font-semibold mb-4 pb-2 border-b border-border/60">{section.title}</h2>
            <div className="space-y-3">
              {section.references.map((ref, idx) => (
                <p
                  key={idx}
                  className="text-sm text-foreground/80 leading-relaxed pl-6 -indent-6"
                  dangerouslySetInnerHTML={{ __html: ref.replace(/\*(.+?)\*/g, "<em>$1</em>") }}
                />
              ))}
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-10 text-center">
        <Link to="/billing" className="text-sm text-primary hover:underline">View plans & billing</Link>
      </div>
    </div>
  );
}