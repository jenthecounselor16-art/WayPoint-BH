import React, { useState } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { SENSORY_QUADRANTS, SENSORY_SCALE, getQuadrantLevel, getAllItems } from "@/lib/sensoryProfile";
import { Activity, ChevronRight, RotateCcw, Check, Wrench } from "lucide-react";
import { Link } from "react-router-dom";
import { copingTools } from "@/lib/copingTools";
import { getMyTherapistEmail } from "@/lib/myTherapist";

export default function SensoryProfile() {
  const [started, setStarted] = useState(false);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [saving, setSaving] = useState(false);

  const allItems = getAllItems();
  const answeredCount = Object.keys(answers).length;
  const allAnswered = answeredCount === allItems.length;

  function setAnswer(index, value) {
    setAnswers({ ...answers, [index]: value });
  }

  function getQuadrantScore(quadrantKey) {
    let score = 0;
    let count = 0;
    allItems.forEach((item, i) => {
      if (item.quadrant === quadrantKey) {
        score += answers[i] || 0;
        count++;
      }
    });
    return { score, maxScore: count * 5 };
  }

  async function submit() {
    setSubmitted(true);
    setSaving(true);
    try {
      const totalScore = Object.values(answers).reduce((a, b) => a + b, 0);
      const highest = SENSORY_QUADRANTS.map((q) => {
        const { score } = getQuadrantScore(q.key);
        return { name: q.name, score };
      }).reduce((max, q) => (q.score > max.score ? q : max));
      const level = getQuadrantLevel(highest.score);
      const me = await base44.auth.me();
      const therapistEmail = await getMyTherapistEmail();
      await base44.entities.AssessmentResult.create({
        test_type: "SENSORY",
        score: totalScore,
        severity: `${highest.name} — ${level.label}`,
        answers: [],
        client_email: me?.email || "",
        therapist_email: therapistEmail,
      });
    } catch {}
    setSaving(false);
  }

  function reset() {
    setAnswers({});
    setSubmitted(false);
    setStarted(false);
  }

  if (!started) {
    return (
      <div className="p-6 md:p-10 max-w-3xl mx-auto">
        <div className="flex items-start gap-3 mb-8">
          <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
            <Activity className="text-primary" size={22} />
          </div>
          <div>
            <h1 className="font-heading text-3xl md:text-4xl font-semibold">Sensory Profile</h1>
            <p className="text-muted-foreground text-lg">Understand how you process sensory input.</p>
          </div>
        </div>

        <div className="pp-card p-6 md:p-8">
          <p className="text-foreground/80 leading-relaxed mb-4">
            This assessment is based on the Adolescent/Adult Sensory Profile framework. It measures how you
            respond to everyday sensory experiences across four patterns: Low Registration, Sensation Seeking,
            Sensory Sensitivity, and Sensation Avoiding.
          </p>
          <p className="text-sm text-muted-foreground mb-6">
            There are 24 statements. For each, choose how often it applies to you. It takes about 5 minutes.
            Your results will include personalized recommendations based on your sensory patterns.
          </p>
          <button
            onClick={() => setStarted(true)}
            className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition flex items-center justify-center gap-2"
          >
            Start Assessment <ChevronRight size={18} />
          </button>
        </div>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="p-6 md:p-10 max-w-3xl mx-auto">
        <div className="flex items-start justify-between gap-3 mb-8">
          <div className="flex items-start gap-3">
            <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <Activity className="text-primary" size={22} />
            </div>
            <div>
              <h1 className="font-heading text-3xl md:text-4xl font-semibold">Your Sensory Profile</h1>
              <p className="text-muted-foreground text-lg">Personalized results and recommendations.</p>
            </div>
          </div>
          <button
            onClick={reset}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm text-muted-foreground hover:text-foreground transition shrink-0"
          >
            <RotateCcw size={16} /> Retake
          </button>
        </div>

        <div className="space-y-4">
          {SENSORY_QUADRANTS.map((q) => {
            const { score, maxScore } = getQuadrantScore(q.key);
            const level = getQuadrantLevel(score);
            const pct = (score / maxScore) * 100;
            return (
              <motion.div
                key={q.key}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="pp-card p-5 md:p-6"
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    <h3 className="font-heading text-lg font-semibold" style={{ color: q.color }}>
                      {q.name}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-0.5">{q.description}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="font-heading text-2xl font-semibold">{score}</span>
                    <span className="text-sm text-muted-foreground">/{maxScore}</span>
                  </div>
                </div>

                <div className="h-2.5 rounded-full bg-secondary overflow-hidden mb-2">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${pct}%`, backgroundColor: q.color }}
                  />
                </div>

                <span
                  className="inline-block px-3 py-1 rounded-full text-xs font-medium mb-3"
                  style={{ backgroundColor: `${q.color}15`, color: q.color }}
                >
                  {level.label}
                </span>

                {level.elevated ? (
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-foreground/80">Recommendations:</p>
                    <ul className="space-y-1.5">
                      {q.recommendations.map((rec, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <Check size={15} className="shrink-0 mt-0.5" style={{ color: q.color }} />
                          <span>{rec}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="space-y-3 mt-4 pt-4 border-t border-border/60">
                      <p className="text-sm font-medium text-foreground/80 flex items-center gap-1.5">
                        <Wrench size={15} /> Suggested Tools from Your Toolbox
                      </p>
                      <div className="grid sm:grid-cols-2 gap-2">
                        {q.suggestedTools.map((toolKey) => {
                          const tool = copingTools.find((t) => t.key === toolKey);
                          if (!tool) return null;
                          return (
                            <Link
                              key={toolKey}
                              to="/toolbox"
                              className="flex items-center gap-2 p-3 rounded-xl bg-secondary/40 hover:bg-secondary transition group"
                            >
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium truncate">{tool.name}</p>
                                <p className="text-xs text-muted-foreground">{tool.duration} • {tool.category}</p>
                              </div>
                              <ChevronRight size={16} className="text-muted-foreground group-hover:text-primary transition shrink-0" />
                            </Link>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    Your response pattern in this area is within the typical range. No specific recommendations needed.
                  </p>
                )}
              </motion.div>
            );
          })}
        </div>

        <p className="text-xs text-muted-foreground text-center mt-6">
          {saving ? "Saving results…" : "Results saved to your assessment history."} Consider sharing these with your
          therapist or support system.
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto">
      <div className="flex items-start justify-between gap-3 mb-6">
        <div className="flex items-start gap-3">
          <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
            <Activity className="text-primary" size={22} />
          </div>
          <div>
            <h1 className="font-heading text-3xl md:text-4xl font-semibold">Sensory Profile</h1>
            <p className="text-muted-foreground text-lg">Rate how often each statement applies to you.</p>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <div className="flex justify-between text-xs text-muted-foreground mb-2">
          <span>{answeredCount} of {allItems.length} answered</span>
          <span>{Math.round((answeredCount / allItems.length) * 100)}%</span>
        </div>
        <div className="h-2 rounded-full bg-secondary overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all duration-300"
            style={{ width: `${(answeredCount / allItems.length) * 100}%` }}
          />
        </div>
      </div>

      {SENSORY_QUADRANTS.map((q) => {
        const quadrantItems = allItems
          .map((item, i) => ({ ...item, index: i }))
          .filter((item) => item.quadrant === q.key);
        return (
          <div key={q.key} className="mb-8">
            <h2 className="font-heading text-lg font-semibold mb-3" style={{ color: q.color }}>
              {q.name}
            </h2>
            <div className="space-y-4">
              {quadrantItems.map((item) => (
                <div key={item.index} className="pp-card p-4">
                  <p className="text-sm mb-3">{item.text}</p>
                  <div className="flex flex-wrap gap-2">
                    {SENSORY_SCALE.map((opt) => {
                      const selected = answers[item.index] === opt.value;
                      return (
                        <button
                          key={opt.value}
                          onClick={() => setAnswer(item.index, opt.value)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition border ${
                            selected
                              ? "bg-primary text-primary-foreground border-primary"
                              : "bg-card border-border text-muted-foreground hover:border-primary/40"
                          }`}
                        >
                          {opt.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      <button
        onClick={submit}
        disabled={!allAnswered}
        className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2"
      >
        View Results <ChevronRight size={18} />
      </button>
      {!allAnswered && (
        <p className="text-xs text-muted-foreground text-center mt-2">
          Answer all {allItems.length} statements to see your results.
        </p>
      )}
    </div>
  );
}