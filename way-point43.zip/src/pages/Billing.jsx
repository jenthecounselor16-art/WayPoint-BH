import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { CreditCard, Check, ArrowLeft, Heart, Sparkles } from "lucide-react";
import EnterpriseTiers from "@/components/billing/EnterpriseTiers";
import { PLANS } from "@/lib/plans";

export default function Billing() {
  const [loading, setLoading] = useState(null);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [user, setUser] = useState(null);
  const [isDemo, setIsDemo] = useState(false);
  const [demoDaysLeft, setDemoDaysLeft] = useState(null);
  const [seats, setSeats] = useState(null);

  const SEAT_OPTIONS = [
    { label: "1", planKey: "solo" },
    { label: "2–3", planKey: "starter" },
    { label: "4–10", planKey: "growth" },
    { label: "11–25", planKey: "professional" },
  ];
  const recommendedKey = seats;

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("status") === "success") setSuccess("Subscription activated! Welcome to WayPoint.");
    if (params.get("status") === "cancelled") setError("Checkout was cancelled. You can try again anytime.");
    base44.auth.me().then(async (me) => {
      setUser(me);
      if (me?.email) {
        try {
          const list = await base44.entities.DemoParticipant.filter({ email: me.email });
          const p = (list || []).find((x) => x.status === "active");
          if (p) {
            setIsDemo(true);
            if (p.expires_at) {
              const days = Math.ceil((new Date(p.expires_at) - Date.now()) / 86400000);
              setDemoDaysLeft(Math.max(days, 0));
            }
          }
        } catch {}
      }
    }).catch(() => {});
  }, []);

  const CLINICIAN_ROLES = ["admin", "therapist", "supervisor"];
  const isClinician =
    CLINICIAN_ROLES.includes(user?.role) || CLINICIAN_ROLES.includes(user?.account_type);

  async function subscribe(plan, period) {
    const isInIframe = window.self !== window.top;
    if (isInIframe) {
      setError("Checkout works only from a published app. Please open the app in a new tab to subscribe.");
      return;
    }

    setLoading(plan.key + "_" + period);
    setError(null);

    try {
      const response = await base44.functions.invoke("create-checkout", {
        plan: plan.key + "_" + period,
      });
      if (response.data?.redirectUrl) {
        window.location.href = response.data.redirectUrl;
      } else {
        setError("Unable to start checkout. Please try again.");
      }
    } catch {
      setError("Something went wrong. Please try again.");
    }
    setLoading(null);
  }

  return (
    <div className="p-6 md:p-10 max-w-7xl mx-auto">
      <Link to="/" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-6">
        <ArrowLeft size={16} /> Back to Home
      </Link>

      <div className="text-center mb-10">
        <h1 className="font-heading text-3xl md:text-4xl font-semibold mb-3">
          {isDemo && isClinician ? "Keep Your WayPoint Access" : isClinician ? "Plans for Clinicians" : "Plans for Individuals"}
        </h1>
        <p className="text-muted-foreground text-lg">
          {isClinician
            ? "Choose the plan that fits your practice. Running 26+ clinicians? Ask us about Enterprise."
            : "Your client account is always free — explore every self-guided wellness tool at no cost."}
        </p>
      </div>

      {success && (
        <div className="mb-6 p-4 rounded-xl bg-primary/10 border border-primary/20 text-primary text-sm">{success}</div>
      )}
      {error && (
        <div className="mb-6 p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm">{error}</div>
      )}
      {isDemo && (
        <div className="mb-6 p-4 rounded-xl bg-primary/10 border border-primary/20 text-primary text-sm flex items-start gap-2">
          <Sparkles size={18} className="shrink-0 mt-0.5" />
          <span>
            Your 7-day demo includes full clinician access — explore everything, no payment needed.
            {demoDaysLeft !== null && (
              <>
                {" "}There {demoDaysLeft === 1 ? "is" : "are"}{" "}
                <strong>{demoDaysLeft} {demoDaysLeft === 1 ? "day" : "days"}</strong>{" "}
                left in your trial — pick your plan below to keep your access when it ends.
              </>
            )}
          </span>
        </div>
      )}
      {!isClinician && (
        <div className="mb-6 p-4 rounded-xl bg-accent/10 border border-accent/20 text-accent text-sm flex items-start gap-2">
          <Heart size={18} className="shrink-0 mt-0.5" />
          <span>Your client account is always free — no subscription required. Enjoy all your self-guided wellness tools at no cost.</span>
        </div>
      )}

      {isClinician && (
        <div className="mb-10 text-center">
          <p className="text-sm font-medium mb-3">How many clinicians need a seat?</p>
          <div className="inline-flex flex-wrap justify-center gap-2">
            {SEAT_OPTIONS.map((o) => (
              <button
                key={o.planKey}
                onClick={() => setSeats(seats === o.planKey ? null : o.planKey)}
                className={`px-4 py-2 rounded-full text-sm font-medium border transition ${
                  seats === o.planKey
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card text-foreground border-border hover:border-primary/50"
                }`}
              >
                {o.label}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className={isClinician ? "grid md:grid-cols-2 xl:grid-cols-4 gap-6" : "grid gap-6 max-w-md mx-auto"}>
        {(isClinician ? PLANS.filter((p) => !p.isFree) : PLANS.filter((p) => p.isFree)).map((plan) => {
          const Icon = plan.icon;
          return (
            <motion.div
              key={plan.key}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`pp-card p-6 flex flex-col relative mt-2 ${
                recommendedKey === plan.key ? "ring-2 ring-primary border-primary/40" : ""
              }`}
            >
              {recommendedKey === plan.key && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-semibold whitespace-nowrap z-10">
                  Best fit for your team
                </span>
              )}
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Icon className="text-primary" size={20} />
                </div>
                <h2 className="font-heading text-xl font-semibold">{plan.name}</h2>
              </div>
              <p className="text-sm text-muted-foreground mb-4 min-h-[40px]">{plan.description}</p>

              {plan.isFree ? (
                <div className="mb-4 p-4 rounded-xl bg-secondary/50">
                  <div className="flex items-baseline gap-1">
                    <span className="font-heading text-3xl font-semibold">$0</span>
                    <span className="text-sm text-muted-foreground">/forever</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">No credit card required</p>
                </div>
              ) : (
                <div className="mb-4 p-4 rounded-xl bg-secondary/50">
                  <div className="flex items-baseline gap-1">
                    <span className="font-heading text-3xl font-semibold">${plan.monthly.amount}</span>
                    <span className="text-sm text-muted-foreground">/month</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1 min-h-[16px]">
                    {plan.clinicians} · Cancel anytime
                  </p>
                </div>
              )}

              <ul className="space-y-2 mb-6 flex-1">
                {plan.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm min-h-[42px]">
                    <Check size={16} className="text-primary shrink-0 mt-0.5" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>

              {plan.isFree ? (
                <div className="py-3 rounded-xl border border-border text-center text-sm font-medium text-muted-foreground bg-secondary/30">
                  Free Forever
                </div>
              ) : (
                <button
                  onClick={() => subscribe(plan, "monthly")}
                  disabled={!!loading}
                  className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-1.5"
                >
                  {loading === plan.key + "_monthly" ? "Redirecting…" : (
                    <><CreditCard size={16} /> Subscribe — ${plan.monthly.amount}/mo</>
                  )}
                </button>
              )}
            </motion.div>
          );
        })}
      </div>

      <EnterpriseTiers />

      {isClinician && (
        <p className="text-center text-xs text-muted-foreground mt-8">
          All plans include a 14-day free trial. No credit card required to start. Cancel anytime.
        </p>
      )}
      <p className="text-center text-xs text-muted-foreground/60 mt-2">
        Payments processed securely by Base44 Payments.
      </p>
    </div>
  );
}