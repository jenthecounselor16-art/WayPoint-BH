import React, { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Send, Sparkles, ClipboardList } from "lucide-react";
import MessageBubble from "@/components/chat/MessageBubble";

const AGENT_NAME = "assessment_setup_guide";

const STARTERS = [
  "Walk me through my first assessment",
  "What has my therapist assigned me?",
  "How do these assessments work?",
  "I finished my assessment — what's next?",
];

export default function AssessmentSetupGuide() {
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const scrollRef = useRef(null);

  useEffect(() => {
    let unsub = () => {};
    (async () => {
      try {
        let conv = null;
        try {
          const list = await base44.agents.listConversations({ agent_name: AGENT_NAME });
          if (list && list.length) conv = list[0];
        } catch {}
        if (!conv) {
          conv = await base44.agents.createConversation({
            agent_name: AGENT_NAME,
            metadata: { name: "Assessment Setup Guide", description: "Your first assessment walkthrough" },
          });
        }
        setConversation(conv);
        if (conv?.messages) setMessages(conv.messages);

        unsub = base44.agents.subscribeToConversation(conv.id, (data) => {
          setMessages(data.messages || []);
        });
      } catch (e) {
        setError("Couldn't start your setup guide. Please try again in a moment.");
      } finally {
        setLoading(false);
      }
    })();
    return () => unsub();
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  async function send(text) {
    const content = text || input;
    if (!content.trim() || !conversation || loading) return;
    setInput("");
    setLoading(true);
    try {
      await base44.agents.addMessage(conversation, { role: "user", content });
    } catch {
      setError("Message failed to send. Please try again.");
    }
    setLoading(false);
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] md:h-[calc(100vh-9rem)]">
      <div className="px-6 md:px-10 py-4 border-b border-border/60 bg-card/50 backdrop-blur-sm">
        <div className="max-w-3xl mx-auto flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <ClipboardList className="text-primary" size={20} />
          </div>
          <div>
            <h1 className="font-heading text-lg font-semibold">Assessment Setup Guide</h1>
            <p className="text-xs text-muted-foreground">Your simple, step-by-step walkthrough</p>
          </div>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto pp-scroll-hide px-4 md:px-10 py-6">
        <div className="max-w-3xl mx-auto space-y-4">
          {error && (
            <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-xl px-4 py-2.5">
              {error}
            </div>
          )}

          {loading && messages.length === 0 && (
            <div className="flex justify-start">
              <div className="bg-card border border-border/60 rounded-2xl rounded-bl-md px-4 py-3 flex gap-1.5">
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    className="w-2 h-2 rounded-full bg-muted-foreground/40"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.2 }}
                  />
                ))}
              </div>
            </div>
          )}

          {messages.map((msg, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
              <MessageBubble message={msg} />
            </motion.div>
          ))}

          {messages.length <= 1 && !loading && (
            <div className="pt-4 space-y-2">
              {STARTERS.map((s) => (
                <button
                  key={s}
                  onClick={() => send(s)}
                  className="block w-full text-left text-sm px-4 py-2.5 rounded-xl border border-border/60 bg-card hover:border-primary/40 hover:bg-primary/5 transition flex items-center gap-2"
                >
                  <Sparkles size={14} className="text-primary shrink-0" />
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="border-t border-border/60 bg-card/50 backdrop-blur-sm px-4 md:px-10 py-3">
        <div className="max-w-3xl mx-auto flex items-center gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") send(); }}
            placeholder="Ask your setup guide…"
            className="pp-input flex-1"
            disabled={!conversation}
          />
          <button
            onClick={() => send()}
            disabled={!input.trim() || !conversation}
            className="w-11 h-11 rounded-xl bg-primary text-primary-foreground flex items-center justify-center hover:opacity-90 transition disabled:opacity-40 shrink-0"
          >
            <Send size={18} />
          </button>
        </div>
        <p className="text-xs text-muted-foreground/60 text-center mt-2">
          In crisis? Call or text <span className="font-semibold">988</span> — available 24/7.
        </p>
      </div>
    </div>
  );
}