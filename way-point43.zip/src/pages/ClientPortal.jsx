import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import {
  ClipboardCheck, Target, Check, Clock, Calendar, Send, TrendingUp, Shield, ArrowRight
} from "lucide-react";
import { checkAndAwardBadges } from "@/lib/badges";
import BadgeCelebration from "@/components/BadgeCelebration";
import { useSubscribeRefresh } from "@/hooks/useSubscribeRefresh";
import { logGoalCheckin } from "@/lib/goalProgress";

function StatCard({ icon: Icon, label, value, sub, color }) {
  return (
    <div className="pp-card p-5">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${color}15` }}>
          <Icon size={18} style={{ color }} />
        </div>
        <span className="text-sm text-muted-foreground">{label}</span>
      </div>
      <p className="font-heading text-3xl font-semibold">{value}</p>
      {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
    </div>
  );
}

function RatingRow({ label, value, onChange, color }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-muted-foreground">{label}</span>
        <span className="text-xs font-semibold" style={{ color }}>{value || 0}/10</span>
      </div>
      <input
        type="range"
        min="0"
        max="10"
        value={value || 0}
        onChange={(e) => onChange(parseInt(e.target.value))}
        className="w-full h-2 rounded-full appearance-none cursor-pointer"
        style={{ accentColor: color }}
      />
    </div>
  );
}

export default function ClientPortal() {
  const [user, setUser] = useState(null);
  const [assignments, setAssignments] = useState([]);
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [responses, setResponses] = useState({});
  const [taskStates, setTaskStates] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [earnedBadges, setEarnedBadges] = useState([]);

  async function loadData() {
    try {
      const [hw, gl] = await Promise.all([
        base44.entities.HomeworkAssignment.list("-created_date", 50),
        base44.entities.TherapyGoal.list("-created_date", 100),
      ]);
      setAssignments(hw || []);
      setGoals(gl || []);
    } catch {}
  }

  useEffect(() => {
    (async () => {
      try { const me = await base44.auth.me(); setUser(me); } catch {}
      await loadData();
      setLoading(false);
    })();
  }, []);
  // Live sync: a homework assignment or goal change by the therapist (or this
  // client) re-fetches both lists so the portal stays current without a reload.
  useSubscribeRefresh("HomeworkAssignment", loadData);
  useSubscribeRefresh("TherapyGoal", loadData);

  function toggleTask(assignmentId, taskIndex) {
    const key = `${assignmentId}-${taskIndex}`;
    setTaskStates({ ...taskStates, [key]: !taskStates[key] });
  }

  async function submitHomework(assignment) {
    setSubmitting(true);
    try {
      const response = responses[assignment.id] || "";
      await base44.entities.HomeworkAssignment.update(assignment.id, {
        status: "completed",
        completion_percentage: 100,
        client_response: response,
      });
      if (assignment.therapist_email) {
        try {
          await base44.integrations.Core.SendEmail({
            to: assignment.therapist_email,
            subject: `Homework completed: ${assignment.title}`,
            body: `Hi,\n\nA client has completed the homework assignment "${assignment.title}".\n\nFor privacy, their written reflection isn't included in this email — read it in your WayPoint therapist portal.\n\nDue date: ${assignment.due_date || "not set"}\n\nView details in your WayPoint therapist portal.`,
          });
        } catch {}
      }
      const data = await base44.entities.HomeworkAssignment.list("-created_date", 50);
      setAssignments(data);
      const newBadges = await checkAndAwardBadges();
      if (newBadges.length > 0) setEarnedBadges(newBadges);
    } catch {}
    setSubmitting(false);
  }

  async function updateGoalRating(goal, value) {
    try {
      await base44.entities.TherapyGoal.update(goal.id, { client_rating: value });
      await logGoalCheckin(goal, "client", { client_rating: value });
      setGoals(goals.map((g) => (g.id === goal.id ? { ...g, client_rating: value } : g)));
    } catch {}
  }

  const hwTotal = assignments.length;
  const hwDone = assignments.filter((a) => a.status === "completed").length;
  const hwPct = hwTotal ? Math.round((hwDone / hwTotal) * 100) : 0;

  const goalsTotal = goals.length;
  const goalsAchieved = goals.filter((g) => g.status === "achieved").length;
  const activeGoals = goals.filter((g) => g.status !== "achieved");
  const goalsPct = goalsTotal ? Math.round((goalsAchieved / goalsTotal) * 100) : 0;

  const avgClientProgress = activeGoals.length
    ? Math.round((activeGoals.reduce((s, g) => s + (g.client_rating || 0), 0) / activeGoals.length) * 10) / 10
    : 0;

  const pending = assignments.filter((a) => a.status !== "completed");
  const completed = assignments.filter((a) => a.status === "completed");

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <div className="flex items-start gap-3 mb-2">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <ClipboardCheck className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">My Portal</h1>
          <p className="text-muted-foreground text-lg">Your assignments, goals, and therapy progress in one place.</p>
        </div>
      </div>

      <p className="text-xs text-muted-foreground flex items-center gap-1.5 mb-8">
        <Shield size={12} className="text-primary" /> Private to you and your therapist.
      </p>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : (
        <>
          {/* Progress summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
            <StatCard icon={ClipboardCheck} label="Homework Done" value={`${hwDone}/${hwTotal}`} sub={`${hwPct}% complete`} color="#1995A1" />
            <StatCard icon={Target} label="Goals Achieved" value={`${goalsAchieved}/${goalsTotal}`} sub={`${goalsPct}% of goals`} color="#D4A055" />
            <StatCard icon={TrendingUp} label="Avg Progress" value={avgClientProgress} sub="self-rated /10 (active)" color="#1995A1" />
            <StatCard icon={Clock} label="Pending Tasks" value={pending.length} sub="assignments to do" color="#E0854A" />
          </div>

          {/* Homework */}
          <section className="mb-10">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-heading text-xl font-semibold flex items-center gap-2">
                <ClipboardCheck size={20} className="text-primary" /> Assigned Homework
              </h2>
              <Link to="/homework" className="text-sm text-primary flex items-center gap-1 hover:underline">
                Full view <ArrowRight size={14} />
              </Link>
            </div>

            {pending.length === 0 && completed.length === 0 ? (
              <div className="pp-card p-10 text-center">
                <ClipboardCheck className="mx-auto mb-4 text-muted-foreground/40" size={48} />
                <h3 className="font-heading text-xl font-semibold mb-2">No homework assigned</h3>
                <p className="text-muted-foreground">Your therapist hasn't assigned any homework yet.</p>
              </div>
            ) : (
              <>
                {pending.length > 0 && (
                  <div className="mb-6">
                    <h3 className="font-heading text-base font-semibold mb-3 text-muted-foreground">To Do</h3>
                    <div className="space-y-3">
                      {pending.map((a) => (
                        <motion.div key={a.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-5">
                          <div className="flex items-start justify-between gap-3 mb-2">
                            <div className="flex-1">
                              <h4 className="font-heading text-lg font-semibold">{a.title}</h4>
                              {a.due_date && (
                                <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                                  <Calendar size={12} /> Due: {new Date(a.due_date).toLocaleDateString("en-US", { month: "long", day: "numeric" })}
                                </p>
                              )}
                            </div>
                            <span className="px-3 py-1 rounded-full bg-amber-500/10 text-amber-600 text-xs font-medium flex items-center gap-1 shrink-0">
                              <Clock size={12} /> Pending
                            </span>
                          </div>

                          {a.description && <p className="text-sm text-muted-foreground mb-4">{a.description}</p>}

                          {a.tasks?.length > 0 && (
                            <div className="mb-4 space-y-2">
                              {a.tasks.map((task, i) => {
                                const key = `${a.id}-${i}`;
                                const checked = taskStates[key];
                                return (
                                  <button key={i} onClick={() => toggleTask(a.id, i)} className="flex items-center gap-2 text-sm text-left w-full group">
                                    <span className={`w-5 h-5 rounded border flex items-center justify-center transition shrink-0 ${checked ? "bg-primary border-primary" : "border-border group-hover:border-primary/50"}`}>
                                      {checked && <Check size={12} className="text-primary-foreground" />}
                                    </span>
                                    <span className={checked ? "line-through text-muted-foreground" : ""}>{task}</span>
                                  </button>
                                );
                              })}
                            </div>
                          )}

                          <textarea
                            value={responses[a.id] || ""}
                            onChange={(e) => setResponses({ ...responses, [a.id]: e.target.value })}
                            placeholder="Write your reflection or response…"
                            className="pp-input min-h-[80px] resize-none mb-3"
                          />

                          <button
                            onClick={() => submitHomework(a)}
                            disabled={submitting}
                            className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2"
                          >
                            {submitting ? "Submitting…" : <>Submit Homework <Send size={16} /></>}
                          </button>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {completed.length > 0 && (
                  <div>
                    <h3 className="font-heading text-base font-semibold mb-3 text-muted-foreground">Completed</h3>
                    <div className="space-y-2">
                      {completed.map((a) => (
                        <div key={a.id} className="pp-card p-4 flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                            <Check className="text-primary" size={16} />
                          </div>
                          <span className="font-heading text-base font-semibold truncate">{a.title}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </section>

          {/* Goals */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-heading text-xl font-semibold flex items-center gap-2">
                <Target size={20} className="text-primary" /> Therapy Goals
              </h2>
              <Link to="/therapy-goals" className="text-sm text-primary flex items-center gap-1 hover:underline">
                Full view <ArrowRight size={14} />
              </Link>
            </div>

            {goalsTotal === 0 ? (
              <div className="pp-card p-10 text-center">
                <Target className="mx-auto mb-4 text-muted-foreground/40" size={48} />
                <h3 className="font-heading text-xl font-semibold mb-2">No goals yet</h3>
                <p className="text-muted-foreground">Your therapist hasn't set any goals yet.</p>
              </div>
            ) : (
              <>
                {activeGoals.length > 0 && (
                  <div className="mb-6">
                    <h3 className="font-heading text-base font-semibold mb-3 text-muted-foreground">In Progress</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      {activeGoals.map((goal) => (
                        <motion.div key={goal.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="pp-card p-5">
                          <div className="flex items-start justify-between gap-3 mb-2">
                            <div className="flex-1">
                              <h4 className="font-heading text-lg font-semibold">{goal.title}</h4>
                              {goal.description && <p className="text-sm text-muted-foreground mt-1">{goal.description}</p>}
                            </div>
                            <span className="px-3 py-1 rounded-full bg-amber-500/10 text-amber-600 text-xs font-medium flex items-center gap-1 shrink-0">
                              <TrendingUp size={12} /> Active
                            </span>
                          </div>
                          <div className="mt-4 pt-4 border-t border-border/60 space-y-3">
                            <RatingRow label="Your Progress" value={goal.client_rating} onChange={(v) => updateGoalRating(goal, v)} color="#1995A1" />
                            <RatingRow label="Therapist's Rating" value={goal.therapist_rating} color="#D4A055" />
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {goalsAchieved > 0 && (
                  <div>
                    <h3 className="font-heading text-base font-semibold mb-3 text-muted-foreground">Achieved</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      {goals.filter((g) => g.status === "achieved").map((goal) => (
                        <div key={goal.id} className="pp-card p-4 flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                            <Check className="text-primary" size={16} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-heading text-base font-semibold truncate">{goal.title}</h4>
                            <p className="text-xs text-muted-foreground">Final: {goal.client_rating || 0}/10 (you) · {goal.therapist_rating || 0}/10 (therapist)</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </section>
        </>
      )}

      <BadgeCelebration badges={earnedBadges} onClose={() => setEarnedBadges([])} />
    </div>
  );
}