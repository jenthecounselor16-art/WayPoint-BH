import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { LineChart as LineIcon, Users } from "lucide-react";
import ClinicianGate from "@/components/ClinicianGate";
import EmotionTrendChart from "@/components/therapist/EmotionTrendChart";
import BehaviorTrendChart from "@/components/therapist/BehaviorTrendChart";
import ClientGoalsPanel from "@/components/therapist/ClientGoalsPanel";
import GoalTrendChart from "@/components/therapist/GoalTrendChart";

// Composite emotional wellbeing (0-100) from the latest check-in.
function wellbeingOf(n) {
  const distress = ((n.anxiety_level ?? 0) + (n.depression_level ?? 0) + (n.stress_level ?? 0)) / 3;
  const vitality = ((n.energy_level ?? 0) + (n.social_interaction ?? 0)) / 2;
  return Math.round((((vitality + (10 - distress)) / 2) * 10));
}

function Spinner() {
  return (
    <div className="flex items-center justify-center py-20">
      <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
    </div>
  );
}

function StatCard({ label, value, suffix, color }) {
  return (
    <div className="pp-card p-4">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={`font-heading text-2xl font-semibold ${color || ""}`}>
        {value}{suffix && <span className="text-sm text-muted-foreground">{suffix}</span>}
      </p>
    </div>
  );
}

function Dashboard() {
  const [user, setUser] = useState(null);
  const [clients, setClients] = useState([]);
  const [selected, setSelected] = useState(null);
  const [metrics, setMetrics] = useState([]);
  const [activities, setActivities] = useState([]);
  const [homework, setHomework] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingData, setLoadingData] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        if (me?.email) {
          const cl = await base44.entities.Client.list("-created_date", 200);
          setClients(cl || []);
          if (cl && cl.length) setSelected(cl[0].client_email);
        }
      } catch {}
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    if (!selected || !user?.email) {
      setMetrics([]); setActivities([]); setHomework([]);
      return;
    }
    setLoadingData(true);
    (async () => {
      try {
        const [m, a, h] = await Promise.all([
          base44.entities.NervousSystemMetric.filter({ client_email: selected }, "-created_date", 500),
          base44.entities.BehaviorActivationActivity.filter({ client_email: selected }, "-created_date", 200),
          base44.entities.HomeworkAssignment.filter({ client_email: selected }, "-created_date", 200),
        ]);
        setMetrics(m || []);
        setActivities(a || []);
        setHomework(h || []);
      } catch {}
      setLoadingData(false);
    })();
  }, [selected, user]);

  const checkins = metrics.length;
  const actsDone = activities.filter((a) => a.status === "done").length;
  const hwDone = homework.filter((h) => h.status === "completed").length;
  const hwTotal = homework.length;
  const latest = metrics.length
    ? wellbeingOf([...metrics].sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0])
    : null;
  const wellbeingColor = latest == null ? "" : latest >= 60 ? "text-accent" : latest >= 40 ? "text-amber-600" : "text-destructive";
  const selectedName = clients.find((c) => c.client_email === selected)?.client_name || selected;

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <div className="flex items-start gap-3 mb-6">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <LineIcon className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Progress Dashboard</h1>
          <p className="text-muted-foreground text-lg">How your clients' emotions and behaviors are changing over time.</p>
        </div>
      </div>

      {loading ? (
        <Spinner />
      ) : clients.length === 0 ? (
        <div className="pp-card p-10 text-center">
          <Users className="mx-auto mb-4 text-muted-foreground/40" size={48} />
          <h3 className="font-heading text-xl font-semibold mb-2">No clients yet</h3>
          <p className="text-muted-foreground">Add clients from the Therapist Portal to see their progress here.</p>
        </div>
      ) : (
        <>
          <div className="flex flex-wrap items-center gap-3 mb-6">
            <label className="text-sm font-medium">Client:</label>
            <select value={selected || ""} onChange={(e) => setSelected(e.target.value)} className="pp-input !w-auto">
              {clients.map((c) => (
                <option key={c.client_email} value={c.client_email}>{c.client_name || c.client_email}</option>
              ))}
            </select>
            <span className="text-sm text-muted-foreground ml-auto hidden sm:block">{selectedName}</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            <StatCard label="Check-ins" value={checkins} />
            <StatCard label="Activities done" value={actsDone} color="text-accent" />
            <StatCard label="Homework done" value={`${hwDone}/${hwTotal || 0}`} color="text-primary" />
            <StatCard label="Latest wellbeing" value={latest ?? "—"} suffix={latest != null ? "/100" : ""} color={wellbeingColor} />
          </div>

          {loadingData ? (
            <Spinner />
          ) : (
            <div className="space-y-6">
              <EmotionTrendChart metrics={metrics} />
              <BehaviorTrendChart activities={activities} homework={homework} />
              <GoalTrendChart clientEmail={selected} />
              <ClientGoalsPanel clientEmail={selected} therapistEmail={user?.email} />
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default function ClinicianProgressDashboard() {
  return (
    <ClinicianGate>
      <Dashboard />
    </ClinicianGate>
  );
}