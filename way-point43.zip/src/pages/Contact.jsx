import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Mail, Send, Linkedin, Twitter } from "lucide-react";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    const subject = encodeURIComponent(`WayPoint contact from ${form.name}`);
    const body = encodeURIComponent(`${form.message}\n\n— ${form.name} (${form.email})`);
    window.location.href = `mailto:hello@waypoint.health?subject=${subject}&body=${body}`;
    setSent(true);
  }

  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto">
      <Link to="/" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-6">
        <ArrowLeft size={16} /> Back to Home
      </Link>

      <h1 className="font-heading text-3xl md:text-4xl font-semibold mb-3">Contact Us</h1>
      <p className="text-muted-foreground text-lg mb-8">
        Have a question about WayPoint? We'd love to hear from you.
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Contact form */}
        <div className="pp-card p-5 md:p-6">
          <h2 className="font-heading text-lg font-semibold mb-4">Send us a message</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Name</label>
              <input
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="pp-input"
                placeholder="Your name"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Email</label>
              <input
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="pp-input"
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Message</label>
              <textarea
                required
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="pp-input min-h-[100px] resize-none"
                placeholder="How can we help?"
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:opacity-90 transition flex items-center justify-center gap-2"
            >
              <Send size={16} /> {sent ? "Opening email…" : "Send message"}
            </button>
          </form>
        </div>

        {/* Contact methods */}
        <div className="space-y-4">
          <div className="pp-card p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <Mail className="text-primary" size={20} />
              </div>
              <h3 className="font-heading text-lg font-semibold">Email</h3>
            </div>
            <a href="mailto:hello@waypoint.health" className="text-primary hover:underline">
              hello@waypoint.health
            </a>
            <p className="text-sm text-muted-foreground mt-1">We typically respond within 1–2 business days.</p>
          </div>

          <div className="pp-card p-5">
            <h3 className="font-heading text-lg font-semibold mb-3">Follow us</h3>
            <div className="flex gap-3">
              <a href="#" className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center hover:bg-secondary transition" aria-label="LinkedIn">
                <Linkedin size={18} className="text-foreground/70" />
              </a>
              <a href="#" className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center hover:bg-secondary transition" aria-label="Twitter">
                <Twitter size={18} className="text-foreground/70" />
              </a>
            </div>
          </div>

          <div className="p-4 rounded-xl border-2 border-destructive/25 bg-destructive/5">
            <p className="text-sm font-semibold text-destructive mb-1">In a crisis?</p>
            <p className="text-sm text-muted-foreground">
              Call or text <span className="font-bold text-foreground">988</span> for the Suicide &amp; Crisis Lifeline, available 24/7.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}