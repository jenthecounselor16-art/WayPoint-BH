import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { copingTools } from "@/lib/copingTools";
import { getMyTherapistEmail } from "@/lib/myTherapist";
import {
  Wind, Eye, Activity, PersonStanding, Music, Sparkles,
  PenLine, Hand, Palette, Heart, Trees, Thermometer, Brain,
  Repeat, MessageSquare, Scale, Shield, X, Star, Clock, Tag,
  ListChecks, Shuffle, Zap,
  HelpCircle, AlertTriangle, ArrowDown, FlaskConical, ListOrdered,
  Calendar, Puzzle, TrendingUp, Route,
  Compass, Footprints, GitFork, Target, Flag
} from "lucide-react";

const ICON_MAP = {
  Wind, Eye, Activity, PersonStanding, Music, Sparkles, PenLine, Hand, Palette, Heart, Trees, Thermometer, Brain, Repeat, MessageSquare, Scale, Shield, ListChecks, Shuffle, Zap,
  HelpCircle, AlertTriangle, ArrowDown, FlaskConical, ListOrdered, Calendar, Puzzle, TrendingUp, Route,
  Compass, Footprints, GitFork, Target, Flag,
};

export default function CopingToolbox() {
  const [favorites, setFavorites] = useState([]);
  const [activeTool, setActiveTool] = useState(null);
  const [filter, setFilter] = useState("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const favs = await base44.entities.CopingFavorite.list();
        setFavorites(favs.map((f) => f.tool_key));
      } catch {
        // ignore
      }
      setLoading(false);
    })();
  }, []);

  const categories = ["all", ...Array.from(new Set(copingTools.map((t) => t.category)))];
  const isFav = (key) => favorites.includes(key);

  async function toggleFavorite(tool) {
    if (isFav(tool.key)) {
      setFavorites(favorites.filter((k) => k !== tool.key));
      try {
        const favs = await base44.entities.CopingFavorite.filter({ tool_key: tool.key });
        if (favs[0]) await base44.entities.CopingFavorite.delete(favs[0].id);
      } catch {
        // ignore
      }
    } else {
      setFavorites([...favorites, tool.key]);
      try {
        // Stamp ownership so this update bridges to the therapist's clinical view.
        const me = await base44.auth.me();
        let therapistEmail = "";
        try { therapistEmail = await getMyTherapistEmail(); } catch {}
        await base44.entities.CopingFavorite.create({
          tool_key: tool.key,
          client_email: me?.email || "",
          therapist_email: therapistEmail,
        });
      } catch {
        // ignore
      }
    }
  }

  const filtered = filter === "all" ? copingTools : copingTools.filter((t) => t.category === filter);
  const favTools = copingTools.filter((t) => isFav(t.key));

  function ToolCard({ tool }) {
    const Icon = ICON_MAP[tool.icon] || Activity;
    return (
      <div className="pp-card p-5 hover:shadow-md hover:-translate-y-0.5 transition-all group">
        <div className="flex items-start justify-between mb-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Icon className="text-primary" size={20} />
          </div>
          <button
            onClick={() => toggleFavorite(tool)}
            className={`p-1.5 rounded-lg transition ${isFav(tool.key) ? "text-amber-500" : "text-muted-foreground/40 hover:text-amber-500"}`}
          >
            <Star size={18} fill={isFav(tool.key) ? "currentColor" : "none"} />
          </button>
        </div>
        <h3 className="font-heading text-lg font-semibold mb-1">{tool.name}</h3>
        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{tool.description}</p>
        <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
          <span className="flex items-center gap-1"><Clock size={12} /> {tool.duration}</span>
          <span className="flex items-center gap-1"><Tag size={12} /> {tool.category}</span>
        </div>
        <button
          onClick={() => setActiveTool(tool)}
          className="w-full py-2 rounded-lg bg-secondary text-secondary-foreground text-sm font-medium hover:bg-secondary/70 transition"
        >
          Start
        </button>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <div className="mb-8">
        <h1 className="font-heading text-3xl md:text-4xl font-semibold mb-2">Coping Toolbox</h1>
        <p className="text-muted-foreground text-lg">Guided tools you can use right now. Star your favorites for quick access.</p>
      </div>

      {/* Favorites */}
      {favTools.length > 0 && (
        <div className="mb-8">
          <h2 className="font-heading text-lg font-semibold mb-3 flex items-center gap-2">
            <Star size={16} className="text-amber-500" fill="currentColor" /> Your Favorites
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {favTools.map((tool) => <ToolCard key={tool.key} tool={tool} />)}
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-2 flex-wrap mb-5">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium capitalize transition
              ${filter === cat ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:opacity-80"}`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* All tools */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((tool, i) => (
          <motion.div
            key={tool.key}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}
          >
            <ToolCard tool={tool} />
          </motion.div>
        ))}
      </div>

      {/* Tool detail modal */}
      <AnimatePresence>
        {activeTool && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setActiveTool(null)}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-end md:items-center justify-center p-0 md:p-4"
          >
            <motion.div
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 40, opacity: 0 }}
              transition={{ type: "spring", damping: 28, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-card w-full md:max-w-lg md:rounded-2xl rounded-t-2xl max-h-[85vh] overflow-y-auto pp-scroll-hide"
            >
              <div className="sticky top-0 bg-card/90 backdrop-blur-md flex items-center justify-between p-5 border-b border-border/60">
                <div className="flex items-center gap-3">
                  {(() => { const Icon = ICON_MAP[activeTool.icon] || Activity; return <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center"><Icon className="text-primary" size={20} /></div>; })()}
                  <div>
                    <h3 className="font-heading text-lg font-semibold">{activeTool.name}</h3>
                    <p className="text-xs text-muted-foreground">{activeTool.duration} · {activeTool.category}</p>
                  </div>
                </div>
                <button onClick={() => setActiveTool(null)} className="p-2 rounded-lg hover:bg-secondary transition">
                  <X size={20} />
                </button>
              </div>

              <div className="p-5">
                <p className="text-muted-foreground mb-6">{activeTool.description}</p>

                <div className="space-y-4">
                  {activeTool.steps.map((step, i) => (
                    <div key={i} className="flex gap-3">
                      <div className="w-7 h-7 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm font-semibold shrink-0">
                        {i + 1}
                      </div>
                      <p className="text-sm text-foreground pt-0.5 leading-relaxed">{step}</p>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => toggleFavorite(activeTool)}
                  className={`mt-6 w-full py-2.5 rounded-xl font-medium text-sm transition flex items-center justify-center gap-2
                    ${isFav(activeTool.key) ? "bg-amber-500/10 text-amber-600" : "bg-secondary text-secondary-foreground hover:opacity-80"}`}
                >
                  <Star size={16} fill={isFav(activeTool.key) ? "currentColor" : "none"} />
                  {isFav(activeTool.key) ? "In your favorites" : "Add to favorites"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}