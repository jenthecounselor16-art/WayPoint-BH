import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { TrendingUp, Moon, Activity, Brain, Zap, ClipboardList, Check, Clock } from "lucide-react";

const RANGES = [
  { label: "7 days", value: 7 },
  { label: "30 days", value: 30 },
  { label: "90 days", value: 90 },
];

const METRIC_CONFIG = [
  { key: "sleep_hours", label: "Sleep", unit: "hrs", icon: Moon, color: "#5B8FB9" },
  { key: "stress_level", label: "Stress", unit: "/10", icon: Activity, color: "#E07856" },
  { key: "anxiety_level", label: "Anxiety", unit: "/10", icon: Brain, color: "#8B7CB6" },
  { key: "energy_level", label: "Energy", unit: "/10", icon: Zap, color: "#D4A055" },
];

export default function ProgressReports() {
  const [range, setRange] = useState(30);
  const [moodEntries, setMoodEntries] = useState([]);
  const [metrics, setMetrics] = useState([]);
  const [assessments, setAssessments] = useState([]);
  const [homework, setHomework] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() - range);

      const results = await Promise.allSettled([
        base44.entities.MoodEntry.list("-created_date", 100),
        base44.entities.NervousSystemMetric.list("-created_date", 100),
        base44.entities.AssessmentResult.list("-created_date", 50),
        base44.entities.HomeworkAssignment.list("-created_date", 50),
      ]);

      const filterByDate = (r) => (r.status === "fulfilled" ? r.value.filter((e) => new Date(e.created_date) >= cutoff) : []);
      setMoodEntries(filterByDate(results[0]));
      setMetrics(filterByDate(results[1]));
      setAssessments(filterByDate(results[2]));
      setHomework(filterByDate(results[3]));
      setLoading(false);
    })();
  }, [range]);

  const avgMetric = (key) => {
    const vals = metrics.map((m) => m[key]).filter((v) => v != null);
    return vals.length ? (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1) : "—";
  };

  const emotionCounts = {};
  moodEntries.forEach((e) => {
    if (e.emotion) emotionCounts[e.emotion] = (emotionCounts[e.emotion] || 0) + 1;
  });
  const topEmotion = Object.entries(emotionCounts).sort((a, b) => b[1] - a[1])[0];
  const avgIntensity = moodEntries.length
    ? (moodEntries.reduce((sum, e) => sum + (e.intensity || 0), 0) / moodEntries.length).toFixed(1)
    : "—";

  const hwTotal = homework.length;
  const hwCompleted = homework.filter((h) => h.status === "completed").length;
  const hwRate = hwTotal > 0 ? Math.round((hwCompleted / hwTotal) * 100) : 0;

  const assessmentChart = assessments.map((a) => ({
    date: new Date(a.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
    score: a.score,
    type: a.test_type,
  }));

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <div className="flex items-start gap-3 mb-8">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <TrendingUp className="text-primary" size={22} />
        </div>
        <div className="flex-1">
          <h1 className="font-heading text-3xl md:text-4xl font-semibold">Progress Reports</h1>
          <p className="text-muted-foreground text-lg">A snapshot of your wellbeing trends over time.</p>
        </div>
      </div>

      <div className="flex gap-2 mb-6">
        {RANGES.map((r) => (
          <button
            key={r.value}
            onClick={() => setRange(r.value)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition ${range === r.value ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:opacity-80"}`}
          >
            {r.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          {moodEntries.length === 0 && metrics.length === 0 && assessments.length === 0 && hwTotal === 0 ? (
            <div className="pp-card p-10 text-center">
              <TrendingUp className="mx-auto mb-4 text-muted-foreground/40" size={48} />
              <h3 className="font-heading text-xl font-semibold mb-2">No data yet</h3>
              <p className="text-muted-foreground">Start logging moods, check-ins, or assessments to see your progress here.</p>
            </div>
          ) : (
            <>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
                <div className="pp-card p-4">
                  <p className="text-xs text-muted-foreground mb-1">Mood Entries</p>
                  <p className="font-heading text-2xl font-semibold">{moodEntries.length}</p>
                </div>
                <div className="pp-card p-4">
                  <p className="text-xs text-muted-foreground mb-1">Most Common</p>
                  <p className="font-heading text-lg font-semibold capitalize">{topEmotion ? topEmotion[0] : "—"}</p>
                </div>
                <div className="pp-card p-4">
                  <p className="text-xs text-muted-foreground mb-1">Avg Intensity</p>
                  <p className="font-heading text-2xl font-semibold">{avgIntensity}<span className="text-sm text-muted-foreground">/5</span></p>
                </div>
                <div className="pp-card p-4">
                  <p className="text-xs text-muted-foreground mb-1">Check-ins</p>
                  <p className="font-heading text-2xl font-semibold">{metrics.length}</p>
                </div>
              </div>

              {metrics.length > 0 && (
                <div className="pp-card p-5 mb-6">
                  <h2 className="font-heading text-lg font-semibold mb-4">Nervous System Averages</h2>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    {METRIC_CONFIG.map((m) => (
                      <div key={m.key} className="text-center">
                        <div className="w-10 h-10 rounded-xl mx-auto mb-2 flex items-center justify-center" style={{ backgroundColor: `${m.color}15` }}>
                          <m.icon size={18} style={{ color: m.color }} />
                        </div>
                        <p className="font-heading text-xl font-semibold">{avgMetric(m.key)}<span className="text-xs text-muted-foreground ml-0.5">{m.unit}</span></p>
                        <p className="text-xs text-muted-foreground">{m.label}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {assessments.length > 0 && (
                <div className="pp-card p-5 mb-6">
                  <h2 className="font-heading text-lg font-semibold mb-4 flex items-center gap-2">
                    <ClipboardList size={18} className="text-muted-foreground" /> Assessment Trends
                  </h2>
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={assessmentChart}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                      <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                      <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                      <Tooltip contentStyle={{ borderRadius: "12px", border: "1px solid hsl(var(--border))", fontSize: "12px" }} />
                      <Line type="monotone" dataKey="score" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 4 }} />
                    </LineChart>
                  </ResponsiveContainer>
                  <p className="text-xs text-muted-foreground mt-2">Note: Scores from different assessments (BAI, BDI, PCL-5) have different ranges and should not be directly compared.</p>
                </div>
              )}

              {hwTotal > 0 && (
                <div className="pp-card p-5">
                  <h2 className="font-heading text-lg font-semibold mb-4">Homework</h2>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="w-10 h-10 rounded-xl mx-auto mb-2 flex items-center justify-center bg-secondary">
                        <Clock size={18} className="text-muted-foreground" />
                      </div>
                      <p className="font-heading text-xl font-semibold">{hwTotal - hwCompleted}</p>
                      <p className="text-xs text-muted-foreground">Pending</p>
                    </div>
                    <div className="text-center">
                      <div className="w-10 h-10 rounded-xl mx-auto mb-2 flex items-center justify-center bg-primary/10">
                        <Check size={18} className="text-primary" />
                      </div>
                      <p className="font-heading text-xl font-semibold">{hwCompleted}</p>
                      <p className="text-xs text-muted-foreground">Completed</p>
                    </div>
                    <div className="text-center">
                      <div className="w-10 h-10 rounded-xl mx-auto mb-2 flex items-center justify-center bg-primary/10">
                        <TrendingUp size={18} className="text-primary" />
                      </div>
                      <p className="font-heading text-xl font-semibold">{hwRate}%</p>
                      <p className="text-xs text-muted-foreground">Completion</p>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </motion.div>
      )}
    </div>
  );
}