import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { MessageSquare, CheckCircle2, Clock, Inbox } from "lucide-react";

const FILTERS = [
  { key: "all", label: "All" },
  { key: "received", label: "Feedback received" },
  { key: "awaiting", label: "Awaiting feedback" },
];

export default function DemoFeedback() {
  const [user, setUser] = useState(null);
  const [participants, setParticipants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(null);
  const [filter, setFilter] = useState("all");

  async function load() {
    const list = await base44.entities.DemoParticipant.list("-seat_number", 100);
    setParticipants(list || []);
  }

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        if (me?.role === "admin") await load();
      } catch (e) {
        console.error("Demo feedback load error:", e);
      }
      setLoading(false);
    })();
  }, []);

  async function toggleFeedback(p) {
    setUpdating(p.id);
    const next = !p.feedback_received;
    try {
      await base44.entities.DemoParticipant.update(p.id, {
        feedback_received: next,
        feedback_received_at: next ? new Date().toISOString() : "",
      });
      await load();
    } catch (e) {
      console.error("Update failed:", e);
    }
    setUpdating(null);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (user?.role !== "admin") {
    return (
      <div className="p-10 max-w-2xl mx-auto text-center">
        <p className="text-muted-foreground">Admins only. This page tracks 7-day demo feedback.</p>
      </div>
    );
  }

  const now = Date.now();
  const received = participants.filter((p) => p.feedback_received);
  const awaiting = participants.filter((p) => !p.feedback_received);

  const visible = participants.filter((p) => {
    if (filter === "received") return p.feedback_received;
    if (filter === "awaiting") return !p.feedback_received;
    return true;
  });

  const stats = [
    { label: "Total participants", value: participants.length, icon: Inbox, tone: "text-muted-foreground" },
    { label: "Feedback received", value: received.length, icon: MessageSquare, tone: "text-primary" },
    { label: "Awaiting feedback", value: awaiting.length, icon: Clock, tone: "text-amber-600" },
  ];

  return (
    <div className="p-6 md:p-10 max-w-6xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <MessageSquare className="text-primary" size={22} />
        </div>
        <div>
          <h1 className="font-heading text-3xl font-semibold">Demo Feedback</h1>
          <p className="text-muted-foreground">
            Track which clinicians have sent their honest 7-day feedback.
          </p>
        </div>
      </div>

      <div className="grid sm:grid-cols-3 gap-3 mb-6">
        {stats.map((s) => (
          <div key={s.label} className="pp-card p-4 flex items-center gap-3">
            <s.icon className={s.tone} size={20} />
            <div>
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className="font-heading text-2xl font-semibold">{s.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
              filter === f.key ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-secondary/70"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <div className="pp-card p-8 text-center text-muted-foreground">
          {participants.length === 0
            ? "No demo signups yet."
            : "Nothing in this view right now."}
        </div>
      ) : (
        <div className="pp-card overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-xs text-muted-foreground">
                <th className="p-3">Seat</th>
                <th className="p-3">Clinician</th>
                <th className="p-3">Email</th>
                <th className="p-3">Demo</th>
                <th className="p-3">Feedback received</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((p) => {
                const expired = p.expires_at && new Date(p.expires_at).getTime() <= now;
                return (
                  <tr key={p.id} className="border-b border-border/50">
                    <td className="p-3 font-medium">#{p.seat_number}</td>
                    <td className="p-3">{p.name}</td>
                    <td className="p-3 text-muted-foreground">{p.email}</td>
                    <td className="p-3">
                      {expired ? (
                        <span className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-700 text-xs font-medium">Expired</span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full bg-accent/15 text-accent text-xs font-medium">Active</span>
                      )}
                    </td>
                    <td className="p-3">
                      <button
                        onClick={() => toggleFeedback(p)}
                        disabled={updating === p.id}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition disabled:opacity-50 flex items-center gap-1.5 ${
                          p.feedback_received ? "bg-primary/15 text-primary" : "bg-secondary text-secondary-foreground hover:bg-secondary/70"
                        }`}
                      >
                        {p.feedback_received ? (
                          <><CheckCircle2 size={13} /> Received{p.feedback_received_at ? ` · ${new Date(p.feedback_received_at).toLocaleDateString("en-US", { month: "short", day: "numeric" })}` : ""}</>
                        ) : (
                          <><MessageSquare size={13} /> Mark received</>
                        )}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}