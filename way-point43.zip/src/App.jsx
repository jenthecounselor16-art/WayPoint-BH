import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import Layout from '@/components/Layout';
import Home from '@/pages/Home';
import EmotionWheel from '@/pages/EmotionWheel';
import Dashboard from '@/pages/Dashboard';
import CopingToolbox from '@/pages/CopingToolbox';
import CopingCoach from '@/pages/CopingCoach';
import CrisisPlan from '@/pages/CrisisPlan';
import TherapistPortal from '@/pages/TherapistPortal';
import ClientHomework from '@/pages/ClientHomework';
import Assessments from '@/pages/Assessments';
import ProgressReports from '@/pages/ProgressReports';
import Billing from '@/pages/Billing';
import CBTJournal from '@/pages/CBTJournal';
import SensoryProfile from '@/pages/SensoryProfile';
import TherapyGoals from '@/pages/TherapyGoals';
import Badges from '@/pages/Badges';
import TherapistInsights from '@/pages/TherapistInsights';
import References from '@/pages/References';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import ProtectedRoute from '@/components/ProtectedRoute';
import OrganizationDashboard from '@/pages/OrganizationDashboard';
import FunctionalImpairment from '@/pages/FunctionalImpairment';
import About from '@/pages/About';
import Contact from '@/pages/Contact';
import ClientReport from '@/pages/ClientReport';
import ThoughtCoach from '@/pages/ThoughtCoach';
import CrisisPlanCoach from '@/pages/CrisisPlanCoach';
import GoalCheckin from '@/pages/GoalCheckin';
import GoalSelfCheckin from '@/pages/GoalSelfCheckin';
import NervousSystemCoach from '@/pages/NervousSystemCoach';
import ClientTrends from '@/pages/ClientTrends';
import ClientPortal from '@/pages/ClientPortal';
import BehaviorActivation from '@/pages/BehaviorActivation';
import ActivitiesQuiz from '@/pages/ActivitiesQuiz';
import ValuesInventory from '@/pages/ValuesInventory';
import ContactSales from '@/pages/ContactSales';
import Demo from '@/pages/Demo';
import DemoAdmin from '@/pages/DemoAdmin';
import DemoFeedback from '@/pages/DemoFeedback';
import ClientDemo from '@/pages/ClientDemo';
import ClientDemoSurvey from '@/pages/ClientDemoSurvey';
import ClientDemoAdmin from '@/pages/ClientDemoAdmin';
import DemoEngagement from '@/pages/DemoEngagement';
import PitchDeck from '@/pages/PitchDeck';
import Tutorial from '@/pages/Tutorial';
import Website from '@/pages/Website';
import Pricing from '@/pages/Pricing';
import Onboarding from '@/pages/Onboarding';
import BurnoutCheckin from '@/pages/BurnoutCheckin';
import DemoSurvey from '@/pages/DemoSurvey';
import ParentPortal from '@/pages/ParentPortal';
import AssessmentCharts from '@/pages/AssessmentCharts';
import CareLibrary from '@/pages/CareLibrary';
import ClientRegistrations from '@/pages/ClientRegistrations';
import OnboardingGuide from '@/pages/OnboardingGuide';
import AssessmentSetupGuide from '@/pages/AssessmentSetupGuide';
import ClinicianProgressDashboard from '@/pages/ClinicianProgressDashboard';
// Add page imports here

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle user_not_registered error at top level
  if (authError?.type === 'user_not_registered') {
    return <UserNotRegisteredError />;
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      {/* Pitch deck is a standalone full-screen presentation — no app nav/footer */}
      <Route path="/pitch-deck" element={<PitchDeck />} />
      <Route path="/tutorial" element={<Tutorial />} />
      <Route element={<Layout />}>
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/contact-sales" element={<ContactSales />} />
        <Route path="/demo" element={<Demo />} />
        <Route path="/client-demo" element={<ClientDemo />} />
        <Route path="/website" element={<Website />} />
        <Route path="/pricing" element={<Pricing />} />
      </Route>
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<Layout />}>
          <Route path="/" element={<Home />} />
          <Route path="/emotions" element={<EmotionWheel />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/toolbox" element={<CopingToolbox />} />
          <Route path="/coach" element={<CopingCoach />} />
          <Route path="/crisis-plan" element={<CrisisPlan />} />
          <Route path="/therapist" element={<TherapistPortal />} />
          <Route path="/homework" element={<ClientHomework />} />
          <Route path="/assessments" element={<Assessments />} />
          <Route path="/reports" element={<ProgressReports />} />
          <Route path="/billing" element={<Billing />} />
          <Route path="/cbt-journal" element={<CBTJournal />} />
          <Route path="/sensory-profile" element={<SensoryProfile />} />
          <Route path="/therapy-goals" element={<TherapyGoals />} />
          <Route path="/badges" element={<Badges />} />
          <Route path="/insights" element={<TherapistInsights />} />
          <Route path="/references" element={<References />} />
          <Route path="/organization" element={<OrganizationDashboard />} />
          <Route path="/functional-impairment" element={<FunctionalImpairment />} />
          <Route path="/report/:clientEmail" element={<ClientReport />} />
          <Route path="/thought-coach" element={<ThoughtCoach />} />
          <Route path="/crisis-coach" element={<CrisisPlanCoach />} />
          <Route path="/goal-checkin" element={<GoalCheckin />} />
          <Route path="/goal-self-checkin" element={<GoalSelfCheckin />} />
          <Route path="/nervous-system-coach" element={<NervousSystemCoach />} />
          <Route path="/client-trends/:clientEmail" element={<ClientTrends />} />
          <Route path="/client-portal" element={<ClientPortal />} />
          <Route path="/behavior-activation" element={<BehaviorActivation />} />
          <Route path="/activities-quiz" element={<ActivitiesQuiz />} />
          <Route path="/values-inventory" element={<ValuesInventory />} />
          <Route path="/demo-admin" element={<DemoAdmin />} />
          <Route path="/demo-engagement" element={<DemoEngagement />} />
          <Route path="/demo-feedback" element={<DemoFeedback />} />
          <Route path="/client-demo-survey" element={<ClientDemoSurvey />} />
          <Route path="/client-demo-admin" element={<ClientDemoAdmin />} />
          <Route path="/onboarding" element={<Onboarding />} />
          <Route path="/burnout-checkin" element={<BurnoutCheckin />} />
          <Route path="/demo-survey" element={<DemoSurvey />} />
          <Route path="/parent-portal" element={<ParentPortal />} />
          <Route path="/assessment-charts" element={<AssessmentCharts />} />
          <Route path="/care-library" element={<CareLibrary />} />
          <Route path="/client-registrations" element={<ClientRegistrations />} />
          <Route path="/onboarding-guide" element={<OnboardingGuide />} />
          <Route path="/assessment-setup-guide" element={<AssessmentSetupGuide />} />
          <Route path="/progress-dashboard" element={<ClinicianProgressDashboard />} />
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App