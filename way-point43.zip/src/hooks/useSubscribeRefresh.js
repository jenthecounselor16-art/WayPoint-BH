import { useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";

/**
 * Subscribes to real-time create/update/delete events for an entity and
 * re-runs `refreshFn` whenever one arrives. This keeps any list/dashboard
 * live without a manual refresh. `refreshFn` is held in a ref so the
 * subscription is set up once per entity while always calling the latest
 * version of the callback (which closes over current props/state).
 */
export function useSubscribeRefresh(entityName, refreshFn) {
  const ref = useRef(refreshFn);
  ref.current = refreshFn;

  useEffect(() => {
    const entity = base44.entities[entityName];
    if (!entity || typeof entity.subscribe !== "function") return;
    let unsub;
    try {
      unsub = entity.subscribe(() => {
        try {
          ref.current();
        } catch (e) {
          /* ignore refresh errors */
        }
      });
    } catch (e) {
      /* subscribe not available — fail silently, initial fetch still works */
    }
    return () => {
      if (typeof unsub === "function") unsub();
    };
  }, [entityName]);
}