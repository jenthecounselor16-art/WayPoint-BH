import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

const CLINICIAN_ROLES = ["admin", "therapist", "supervisor"];

// Determines whether the current user may open premium clinician features
// (the workbook library and progress analytics). Access follows the app's
// hard paywall: the therapist role is granted on payment (via the Wix
// webhook) and on active demo enrollment, and revoked when a demo trial
// expires — so paid subscribers and active demo clinicians pass, while
// clients and expired/unpaid users are blocked. Admins and supervisors pass.
export function useClinicianAccess() {
  const [loading, setLoading] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        setHasAccess(
          CLINICIAN_ROLES.includes(me?.role) || CLINICIAN_ROLES.includes(me?.account_type)
        );
      } catch {
        setHasAccess(false);
      }
      setLoading(false);
    })();
  }, []);

  return { loading, hasAccess, user };
}