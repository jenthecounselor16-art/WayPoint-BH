import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

/**
 * Reads the clinician-managed ClientFeatureAccess record for the current user.
 * Returns { access, loading, can }.
 *  - access: the record, or `undefined` when none exists (=> all features allowed by default)
 *  - can(featureKey): true when no record exists or the feature is enabled
 */
export function useClientAccess() {
  const [access, setAccess] = useState(null); // null = loading
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const me = await base44.auth.me();
        if (!me) {
          if (!cancelled) setAccess(undefined);
          return;
        }
        const data = await base44.entities.ClientFeatureAccess.filter({ client_email: me.email }, "-created_date", 1);
        if (!cancelled) setAccess(data?.[0] || undefined);
      } catch {
        if (!cancelled) setAccess(undefined);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  function can(featureKey) {
    if (access === null) return true; // still loading — don't flicker
    if (!access) return true; // no record => all allowed
    return Array.isArray(access.enabled_features) ? access.enabled_features.includes(featureKey) : true;
  }

  return { access, loading, can };
}