// Sends a branded email through the builder's connected Gmail connector as a
// multipart/alternative message (plain text + HTML) so both Gmail and other
// clients render correctly. Reused by any backend function that needs to send
// from the connected Gmail account (e.g. the new-user welcome sequence).
//
// Returns { ok: true, id } on success; throws on failure.

// UTF-8-safe helpers, also exported for backend functions that build Gmail
// MIME themselves. Subject headers go in as RFC 2047 encoded words and body
// parts are base64-encoded, so non-ASCII characters (em dashes, curly
// quotes, accents) never turn into mojibake.
export function utf8Base64(str) {
  const bytes = new TextEncoder().encode(str);
  let bin = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    bin += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(bin);
}
export function encodeHeader(value) {
  return `=?UTF-8?B?${utf8Base64(value)}?=`;
}
export function wrap76(b64) {
  return b64.match(/.{1,76}/g).join("\r\n");
}

export async function sendGmail(base44, { to, subject, html, text }) {
  const conn = await base44.asServiceRole.connectors.getConnection("gmail");
  const token = conn?.accessToken;
  if (!token) {
    throw new Error("Gmail connector not connected");
  }

  // Resolve the sender address from the access token (Gmail always sends as the
  // connected account).
  const tokenInfoRes = await fetch(`https://oauth2.googleapis.com/tokeninfo?access_token=${token}`);
  if (!tokenInfoRes.ok) {
    throw new Error(`Gmail tokeninfo failed: ${tokenInfoRes.status}`);
  }
  const info = await tokenInfoRes.json();
  const from = info.email;
  if (!from) {
    throw new Error("Gmail tokeninfo returned no email");
  }

  const boundary = "waypoint_" + Math.random().toString(36).slice(2);
  const mimeMessage = [
    `From: WayPoint <${from}>`,
    `To: ${to}`,
    `Subject: ${encodeHeader(subject)}`,
    "MIME-Version: 1.0",
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    "",
    `--${boundary}`,
    "Content-Type: text/plain; charset=UTF-8",
    "Content-Transfer-Encoding: base64",
    "",
    wrap76(utf8Base64(text)),
    "",
    `--${boundary}`,
    "Content-Type: text/html; charset=UTF-8",
    "Content-Transfer-Encoding: base64",
    "",
    wrap76(utf8Base64(html)),
    "",
    `--${boundary}--`,
  ].join("\r\n");

  const bytes = new TextEncoder().encode(mimeMessage);
  let rawBin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) {
    rawBin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  const raw = btoa(rawBin)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");

  const sendRes = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ raw }),
  });

  if (!sendRes.ok) {
    const detail = await sendRes.text();
    throw new Error(`Gmail send failed: ${sendRes.status} ${detail}`);
  }
  const data = await sendRes.json();
  return { ok: true, id: data.id };
}