// Single source of truth for subscription plan keys, tier names, and monthly
// amounts. Used by checkout creation, purchase-notification emails, and the
// weekly revenue report so pricing can never drift between them.

export const PLAN_CATALOG = {
  solo_monthly: {
    name: "Solo — Monthly",
    tier: "Solo",
    price: "59",
    amount: 59,
    frequency: "MONTH",
    description: "Solo plan for 1 clinician, billed monthly",
  },
  starter_monthly: {
    name: "Starter — Monthly",
    tier: "Starter",
    price: "129",
    amount: 129,
    frequency: "MONTH",
    description: "Starter plan for 2–3 clinicians, billed monthly",
  },
  growth_monthly: {
    name: "Growth — Monthly",
    tier: "Growth",
    price: "249",
    amount: 249,
    frequency: "MONTH",
    description: "Growth plan for 4–10 clinicians, billed monthly",
  },
  professional_monthly: {
    name: "Professional — Monthly",
    tier: "Professional",
    price: "499",
    amount: 499,
    frequency: "MONTH",
    description: "Professional plan for 11–25 clinicians, billed monthly",
  },
};

export function getPlan(planKey) {
  return PLAN_CATALOG[planKey] || null;
}