// Shared helpers for therapist-facing report emails (monthly + quarterly).
// Plain module — exported, no Deno.serve.

const TEAL = "#26A69A";
const TEAL_DARK = "#1E8378";
const INK = "#2C3E45";
const SOFT_BG = "#F2F7F6";

// Therapists receive reports: admins plus any user carrying a "therapist" role.
export function filterTherapists(users) {
  return (users || []).filter((u) => u.role === "admin" || u.role === "therapist");
}

// Group managed clients by their therapist's email.
export function groupClientsByTherapist(clients) {
  const map = {};
  (clients || []).forEach((c) => {
    if (!c.therapist_email) return;
    (map[c.therapist_email] = map[c.therapist_email] || []).push(c);
  });
  return map;
}

export function avg(nums, field) {
  const vals = nums.map((n) => n[field]).filter((v) => typeof v === "number" && !Number.isNaN(v));
  if (!vals.length) return null;
  return vals.reduce((a, b) => a + b, 0) / vals.length;
}

export function fmtAvg(v, suffix = "") {
  if (v === null || v === undefined) return "—";
  return `${Math.round(v * 10) / 10}${suffix}`;
}

export function statPill(label, value) {
  return `<span style="display:inline-block;margin:0 8px 6px 0;padding:5px 11px;background:${SOFT_BG};border-radius:8px;font-size:13px;color:${INK};"><strong style="color:${TEAL_DARK};">${label}</strong> ${value}</span>`;
}