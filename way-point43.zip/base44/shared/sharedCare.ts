// Shared-care support: lets providers at different practices co-treat the
// same client. The Client entity is the single source of truth — a client's
// `shared_therapist_emails` lists every co-treating provider alongside the
// primary. This module projects that into each provider's user-level
// `shared_client_emails` list, which the clinical entities' read rules match
// against (`client_email` $in the user's list). Because the rule matches on
// `client_email`, co-treating providers see the client's full history — past
// and future records — with no per-record stamping.
export async function syncSharedCare(serviceRole, email) {
  const target = String(email || '').trim().toLowerCase();
  if (!target) return { shared_client_emails: [], user_found: false };

  const clients = await serviceRole.entities.Client.list('-created_date', 500);
  const list = [...new Set(
    (clients || [])
      .filter((c) => {
        const primary = String(c.therapist_email || '').toLowerCase();
        const team = (c.shared_therapist_emails || []).map((e) => String(e).toLowerCase());
        return primary === target || team.includes(target);
      })
      .map((c) => String(c.client_email || '').toLowerCase())
      .filter(Boolean)
  )];

  const users = await serviceRole.entities.User.filter({ email: target }, '-created_date', 5);
  const u = (users || []).find((x) => String(x.email || '').toLowerCase() === target);
  if (u && JSON.stringify(u.shared_client_emails || []) !== JSON.stringify(list)) {
    await serviceRole.entities.User.update(u.id, { shared_client_emails: list });
  }
  return { shared_client_emails: list, user_found: !!u };
}