// Shared client-record backfill used by both `link-client-records` (called
// when a therapist adds/invites a client from the portal) and
// `claim-client-invitation` (called when a client registers through an
// invitation). Stamps the therapist's email onto every existing record that
// belongs to the client — across all shared clinical entities — so the
// therapist can see the client's full history from the moment they're linked,
// regardless of who created the record or when. Idempotent and safe to re-run.
const SHARED_ENTITIES = [
  'AssessmentResult',
  'ValuesChecklist',
  'NervousSystemMetric',
  'TherapyGoal',
  'HomeworkAssignment',
  'BehaviorActivationActivity',
  'CrisisPlan',
  'FunctionalImpairment',
  'ThoughtRecord',
  'CopingFavorite',
];

export async function linkClientRecords(serviceRole, clientEmail, therapistEmail) {
  const summary = {};
  for (const name of SHARED_ENTITIES) {
    const entity = serviceRole.entities[name];
    const [byClient, byCreator] = await Promise.all([
      entity.filter({ client_email: clientEmail }, '-created_date', 1000).catch(() => []),
      entity.filter({ created_by: clientEmail }, '-created_date', 1000).catch(() => []),
    ]);
    const seen = new Map();
    [...(byClient || []), ...(byCreator || [])].forEach((r) => { if (r?.id) seen.set(r.id, r); });
    const toUpdate = [];
    seen.forEach((r) => {
      if (r.therapist_email === therapistEmail && (r.client_email || clientEmail) === clientEmail) return;
      const patch = { id: r.id, therapist_email: therapistEmail };
      if (!r.client_email) patch.client_email = clientEmail;
      toUpdate.push(patch);
    });
    summary[name] = { found: seen.size, updated: toUpdate.length };
    if (toUpdate.length) {
      try {
        await entity.bulkUpdate(toUpdate);
      } catch (e) {
        console.error(`link-client-records: backfill ${name} failed`, e);
        summary[name].error = e?.message || String(e);
      }
    }
  }
  return summary;
}