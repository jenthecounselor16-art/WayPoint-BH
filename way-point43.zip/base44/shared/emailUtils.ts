// Shared helpers for email-sending backend functions.

// Resolve the public app URL from the platform-injected header.
export function getAppUrl(req) {
  return (req.headers.get("X-Base44-App-Url") || "").replace(/\/$/, "");
}

// First name for an email greeting, with a warm fallback.
export function firstNameOf(fullName, fallback = "there") {
  return String(fullName || "").split(" ")[0] || fallback;
}

// Minimal HTML escaper for safe interpolation of user-provided strings.
export function escapeHtml(s) {
  return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}