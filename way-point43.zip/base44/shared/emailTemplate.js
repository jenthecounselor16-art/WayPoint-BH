// Shared WayPoint email template.
// Adds the branded banner header + warm, well-spaced HTML wrapping to every
// outgoing email. Used by all email-sending backend functions so the look and
// wording stay consistent for clients and therapists alike.

export const BANNER_URL =
  "https://media.base44.com/images/public/6a5d9b9fe72fabffdfd16c68/2454ca81c_BlueandWhiteModernNetworkingTwitterXHeader.png";

const TEAL = "#26A69A";
const TEAL_DARK = "#1E8378";
const INK = "#2C3E45";
const MUTED = "#5E7278";
const SOFT_BG = "#F2F7F6";

// ---- tiny content helpers (returned as HTML fragments) --------------------

export function alertCallout(label, innerHtml) {
  return `
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 22px 0;">
    <tr>
      <td style="background:${SOFT_BG};border-left:4px solid ${TEAL};border-radius:8px;padding:16px 18px;">
        <p style="margin:0 0 6px 0;font-size:12px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;color:${TEAL_DARK};">${label}</p>
        <div style="font-size:15px;line-height:1.6;color:${INK};">${innerHtml}</div>
      </td>
    </tr>
  </table>`;
}

export function softNote(innerHtml) {
  return `
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:18px 0;">
    <tr>
      <td style="background:#FBF7F0;border-radius:10px;padding:16px 18px;">
        <div style="font-size:15px;line-height:1.65;color:${INK};font-style:italic;">${innerHtml}</div>
      </td>
    </tr>
  </table>`;
}

export function primaryButton(label, url) {
  return `
  <table role="presentation" cellpadding="0" cellspacing="0" style="margin:24px 0 8px 0;">
    <tr>
      <td style="border-radius:10px;background:${TEAL};">
        <a href="${url}" style="display:inline-block;padding:13px 28px;font-family:Georgia,'Hoefler Text',serif;font-size:16px;color:#ffffff;text-decoration:none;border-radius:10px;">${label}</a>
      </td>
    </tr>
  </table>`;
}

const UPLIFT_MESSAGES = [
  "Moments like these are why you do this work. Your steady, compassionate presence is helping someone heal &mdash; one small win at a time. Thank you for the care you give.",
  "Every breakthrough your client reaches started with the safety you created. You are the steady ground they return to.",
  "Progress rarely arrives all at once &mdash; and your willingness to sit with the slow parts is its own kind of mastery.",
  "You don't have to move mountains to matter today. Even one quiet, kind intervention ripples further than you'll ever know.",
  "Healing happens in relationship &mdash; and yours is the relationship making it possible. That's no small thing.",
  "On the days the work feels heavy, remember: someone sleeps a little easier tonight because you showed up.",
  "The small, ordinary moments of attunement are the real therapy. You're doing more of it than you realize.",
  "You carry hard stories with remarkable grace. Be as gentle with yourself as you are with the people you serve.",
  "You teach people that their pain can be witnessed and survived. That lesson outlives every single session.",
  "The hope you hold for your clients when they can't hold it themselves &mdash; that's the work. And you do it beautifully.",
];

// A randomized, cozy uplift note for therapist-facing emails so the encouragement
// varies each send instead of repeating the same line.
export function therapistUplift() {
  const msg = UPLIFT_MESSAGES[Math.floor(Math.random() * UPLIFT_MESSAGES.length)];
  return softNote(msg);
}

export function para(text, opts = {}) {
  const lead = opts.lead ? `font-size:17px;` : `font-size:15px;`;
  const weight = opts.bold ? `font-weight:700;` : ``;
  return `<p style="margin:0 0 14px 0;${lead}${weight}line-height:1.7;color:${INK};">${text}</p>`;
}

// ---- core renderer ---------------------------------------------------------

function stripHtml(html) {
  return String(html)
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<br\s*\/?>(\r?\n)?/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<\/li>/gi, "\n")
    .replace(/<li[^>]*>/gi, "• ")
    .replace(/<a[^>]*href="([^"]*)"[^>]*>([^<]*)<\/a>/gi, "$2 ($1)")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function footerFor(recipientType) {
  if (recipientType === "client") {
    return `
      <p style="margin:0 0 8px 0;font-size:13px;line-height:1.6;color:${MUTED};">In a crisis? Call or text <strong style="color:${INK};">988</strong> — the Suicide &amp; Crisis Lifeline, available 24/7. You don't have to face this alone.</p>
      <p style="margin:0;font-size:13px;line-height:1.6;color:${MUTED};">This message was sent by WayPoint. If you no longer wish to receive these reminders, let your therapist know at your next session.</p>`;
  }
  if (recipientType === "general") {
    return `
      <p style="margin:0 0 8px 0;font-size:13px;line-height:1.6;color:${MUTED};">You're receiving this because you're part of the WayPoint clinician demo. Questions or feedback? Just reply to this email &mdash; we'd love to hear from you.</p>
      <p style="margin:0;font-size:13px;line-height:1.6;color:${MUTED};">Sent by WayPoint &mdash; Evidence-Based Care Beyond the Therapy Session.</p>`;
  }
  if (recipientType === "onboarding") {
    return `
      <p style="margin:0 0 8px 0;font-size:13px;line-height:1.6;color:${MUTED};">You're receiving this because you created a WayPoint account. Questions? Just reply to this email &mdash; we'd love to help.</p>
      <p style="margin:0;font-size:13px;line-height:1.6;color:${MUTED};">In a crisis? Call or text <strong style="color:${INK};">988</strong> &mdash; the Suicide &amp; Crisis Lifeline, 24/7. Sent by WayPoint &mdash; Evidence-Based Care Beyond the Therapy Session.</p>`;
  }
  return `
    <p style="margin:0 0 8px 0;font-size:13px;line-height:1.6;color:${MUTED};">This is an automated clinical alert from WayPoint. Please follow your safety protocols; for emergencies call <strong style="color:${INK};">988</strong> (Suicide &amp; Crisis Lifeline).</p>
    <p style="margin:0;font-size:13px;line-height:1.6;color:${MUTED};">Sent via WayPoint — Evidence-Based Care Beyond the Therapy Session.</p>`;
}

export function renderEmail({ recipientType = "therapist", contentHtml, contentText }) {
  const isClient = recipientType === "client";
  const bodyFont = "Georgia, 'Hoefler Text', 'Times New Roman', serif";
  const headingFont = "Georgia, 'Hoefler Text', serif";
  const greetingColor = TEAL_DARK;

  const closingText = isClient
    ? "In a crisis? Call or text 988 — the Suicide & Crisis Lifeline, 24/7.\nSent via WayPoint."
    : recipientType === "general"
    ? "You're receiving this because you're part of the WayPoint clinician demo.\nSent by WayPoint — Evidence-Based Care Beyond the Therapy Session."
    : recipientType === "onboarding"
    ? "You're receiving this because you created a WayPoint account.\nIn a crisis? Call or text 988 — the Suicide & Crisis Lifeline, 24/7.\nSent by WayPoint — Evidence-Based Care Beyond the Therapy Session."
    : "Automated clinical alert from WayPoint. Follow your safety protocols; for emergencies call 988.";

  const textBody =
    "WayPoint — Evidence-Based Care Beyond the Therapy Session\n" +
    "------------------------------------------------------------\n\n" +
    (contentText || stripHtml(contentHtml)) +
    "\n\n" +
    closingText;

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>WayPoint</title>
</head>
<body style="margin:0;padding:0;background:${SOFT_BG};">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:${SOFT_BG};">
    <tr>
      <td align="center" style="padding:28px 12px;">
        <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:14px;overflow:hidden;box-shadow:0 2px 10px rgba(38,166,154,.08);">
          <tr>
            <td style="padding:0;line-height:0;">
              <img src="${BANNER_URL}" width="600" alt="WayPoint — Evidence-Based Care Beyond the Therapy Session" style="display:block;width:100%;max-width:600px;height:auto;border:0;" />
            </td>
          </tr>
          <tr>
            <td style="padding:40px 44px 32px 44px;font-family:${bodyFont};color:${INK};">
              ${contentHtml}
            </td>
          </tr>
          <tr>
            <td style="padding:20px 40px 26px 40px;border-top:1px solid #EAF1F0;background:#FCFEFD;">
              <p style="margin:0 0 6px 0;font-family:${headingFont};font-size:14px;font-weight:700;color:${greetingColor};letter-spacing:.02em;">WayPoint</p>
              ${footerFor(recipientType)}
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

  return { html, text: textBody };
}