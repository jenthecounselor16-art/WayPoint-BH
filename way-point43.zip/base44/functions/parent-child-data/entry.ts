import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

// Returns assessment scores, therapy goals, and saved coping tools for every
// child the calling parent/guardian is actively linked to. Access is verified
// against the Parent entity first; clinical records are then read as service
// role so a parent never sees data for a child they aren't explicitly linked
// to. This is the ONLY surface that exposes a child's data to a parent — the
// role is distinct from client/therapist and scoped to linked children only.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const parentEmail = user.email;

    const links = await base44.asServiceRole.entities.Parent.filter({
      parent_email: parentEmail,
      status: 'active',
    });
    if (!links || links.length === 0) {
      return Response.json({ children: [] });
    }

    const children = await Promise.all(
      links.map(async (link) => {
        const childEmail = link.child_email;
        const [assessments, goals, childUsers, nervous] = await Promise.all([
          base44.asServiceRole.entities.AssessmentResult.filter(
            { client_email: childEmail }, '-created_date', 200
          ),
          base44.asServiceRole.entities.TherapyGoal.filter(
            { client_email: childEmail }, '-created_date', 50
          ),
          base44.asServiceRole.entities.User.filter({ email: childEmail }, '-created_date', 1),
          base44.asServiceRole.entities.NervousSystemMetric.filter(
            { client_email: childEmail }, '-created_date', 60
          ),
        ]);

        // CopingFavorite stores only tool_key (+ created_by_id); resolve the
        // child's user id so we can pull the tools they've saved.
        let copingFavorites = [];
        const childId = childUsers?.[0]?.id;
        if (childId) {
          try {
            const favs = await base44.asServiceRole.entities.CopingFavorite.filter(
              { created_by_id: childId }, '-created_date', 50
            );
            copingFavorites = (favs || []).map((f) => ({
              tool_key: f.tool_key,
              created_date: f.created_date,
            }));
          } catch (e) {
            console.error('coping favorites fetch failed:', e);
          }
        }

        return {
          link,
          assessments: assessments || [],
          goals: goals || [],
          nervous: nervous || [],
          copingFavorites,
        };
      })
    );

    return Response.json({ children });
  } catch (error) {
    console.error('parent-child-data error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}