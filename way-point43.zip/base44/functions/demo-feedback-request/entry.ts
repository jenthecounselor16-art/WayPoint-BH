import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para } from '../../shared/emailTemplate.js';
import { escapeHtml } from '../../shared/emailUtils.ts';

// Invoked by the "Demo Feedback Request" workflow exactly 7 days after a new
// DemoParticipant is created. Emails the demo clinician asking them to reply
// with their honest feedback to the demo owner's address.

const DEMO_OWNER_EMAIL = "jenthecounselor16@gmail.com";

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const { participant_id } = body || {};
    if (!participant_id) return Response.json({ error: "participant_id is required" }, { status: 400 });

    let p;
    try {
      p = await base44.asServiceRole.entities.DemoParticipant.get(participant_id);
    } catch (e) {
      console.error("DemoParticipant fetch failed:", e.message);
      return Response.json({ error: "participant not found" }, { status: 404 });
    }
    if (!p) return Response.json({ error: "participant not found" }, { status: 404 });
    if (!p.email) return Response.json({ error: "participant has no email" }, { status: 400 });

    // Skip if their trial window has already closed (the expiry batch handles those).
    if (p.status === "expired") {
      return Response.json({ ok: false, reason: "participant already expired" });
    }

    const firstName = (p.name || "").split(" ")[0].trim() || "there";

    const contentHtml = [
      para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
      para(`Your 7-day WayPoint demo just wrapped up — thank you for taking it for a spin.`),
      para(
        `We'd love your honest feedback about the experience. ` +
        `Just reply to this email — or send your thoughts straight to <strong>${DEMO_OWNER_EMAIL}</strong> — and tell us what you really think.`
      ),
      para(`A few quick prompts to guide your feedback (answer as many or as few as you like):`),
      para(
        `• What worked well during your demo?<br/>` +
        `• What was confusing or could be improved?<br/>` +
        `• Which feature was most valuable to you?<br/>` +
        `• Would you consider using WayPoint in your practice?`
      ),
      para(`Thanks again for trying WayPoint — we genuinely appreciate your time and input.`),
      para(`Warmly,<br/><strong>The WayPoint Team</strong>`, { bold: false }),
    ].join("");

    const { html } = renderEmail({ recipientType: "general", contentHtml });
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: p.email,
      subject: `Your WayPoint demo is done — we'd love your honest feedback`,
      body: html,
    });
    console.log(`demo-feedback-request sent to ${p.email} for participant ${p.id}`);
    return Response.json({ ok: true, to: p.email });
  } catch (error) {
    console.error("demo-feedback-request error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}