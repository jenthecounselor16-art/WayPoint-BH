import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

const DEMO_DAYS = 7;
const DEMO_OWNER_EMAIL = "jenthecounselor16@gmail.com";

// Public signup for the 7-day client demo. Creates a ClientDemoParticipant,
// invites the client as an app user so they can register and explore, and
// notifies the demo owner. No gift card, no seat limit.

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { name, email } = body || {};

    if (!name || !email) {
      return Response.json({ error: "Name and email are required" }, { status: 400 });
    }

    // --- Anti-bot guard (same shape as the clinician demo signup) ---------
    if (body.website) {
      console.warn("Client demo signup blocked: honeypot triggered", email);
      return Response.json({ error: "Submission could not be verified. Please refresh and try again." }, { status: 403 });
    }
    const a = Number(body.a), b = Number(body.b), ans = Number(body.verify);
    if (!Number.isFinite(a) || !Number.isFinite(b) || !Number.isFinite(ans) || ans !== a + b) {
      return Response.json({ error: "Please complete the quick-check question at the bottom of the form." }, { status: 400 });
    }
    const t0 = Number(body.t0);
    if (!Number.isFinite(t0) || Date.now() - t0 < 4000) {
      return Response.json({ error: "Whoa, that was fast! Please take a moment to review the form and try again." }, { status: 400 });
    }
    const emailLower = email.toLowerCase();
    if (emailLower.endsWith("@example.com") || emailLower.endsWith("@example.org") || emailLower.endsWith("@test.com")) {
      return Response.json({ error: "Please use a valid email address." }, { status: 400 });
    }

    const all = await base44.asServiceRole.entities.ClientDemoParticipant.list("-created_date", 200);

    // Burst brake: refuse if 5+ signups arrived in the last 15 minutes.
    const cutoff = Date.now() - 15 * 60 * 1000;
    const recentCount = (all || []).filter((p) => new Date(p.created_date).getTime() >= cutoff).length;
    if (recentCount >= 5) {
      return Response.json({ error: "We're receiving a lot of requests right now. Please try again in a few minutes." }, { status: 429 });
    }

    if (all.some((p) => (p.email || "").toLowerCase() === emailLower)) {
      return Response.json({ error: "This email is already registered for the demo." }, { status: 409 });
    }

    const startedAt = new Date();
    const expiresAt = new Date(startedAt.getTime() + DEMO_DAYS * 24 * 60 * 60 * 1000);

    const participant = await base44.asServiceRole.entities.ClientDemoParticipant.create({
      name,
      email,
      started_at: startedAt.toISOString(),
      expires_at: expiresAt.toISOString(),
      status: "active",
      feedback_received: false,
    });

    // Best-effort: invite the client as an app user so they can register and
    // access the demo. Role "user" = client in this app.
    let invited = false;
    let inviteError = "";
    try {
      await base44.users.inviteUser(email, "user");
      invited = true;
    } catch (e) {
      inviteError = e.message || String(e);
      console.error("Client invite failed:", inviteError);
    }

    // Notify the demo owner.
    try {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: DEMO_OWNER_EMAIL,
        subject: `[WayPoint Client Demo] New signup — ${name}`,
        body: [
          "A client signed up for the 7-day demo.",
          "",
          `Name: ${name}`,
          `Email: ${email}`,
          `Demo expires: ${expiresAt.toLocaleDateString()}`,
          `Invited automatically: ${invited ? "yes" : "no"}`,
          invited ? "" : `Auto-invite failed (${inviteError}) — invite ${email} manually as a user.`,
          "",
          "Their feedback survey link will be emailed to them automatically in 7 days.",
        ].join("\n"),
      });
    } catch (e) {
      console.error("Owner notify failed:", e.message);
    }

    console.log(`Client demo signup: ${email}, invited=${invited}`);
    return Response.json({
      ok: true,
      expires_at: expiresAt.toISOString(),
      invited,
    });
  } catch (error) {
    console.error("Client demo signup error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}