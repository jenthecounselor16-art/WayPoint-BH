import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para } from '../../shared/emailTemplate.js';
import { escapeHtml } from '../../shared/emailUtils.ts';

// Invoked by the "Demo 7-Day Feedback Alert" workflow exactly 7 days after a
// new DemoParticipant is created. Sends an email to the demo owner
// (jenthecounselor16@gmail.com) so they know it's time to check their inbox for
// the clinician's honest 7-day feedback.

const DEMO_OWNER_EMAIL = "jenthecounselor16@gmail.com";

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const { participant_id } = body || {};
    if (!participant_id) return Response.json({ error: "participant_id is required" }, { status: 400 });

    let p;
    try {
      p = await base44.asServiceRole.entities.DemoParticipant.get(participant_id);
    } catch (e) {
      console.error("DemoParticipant fetch failed:", e.message);
      return Response.json({ error: "participant not found" }, { status: 404 });
    }
    if (!p) return Response.json({ error: "participant not found" }, { status: 404 });

    const fmt = (iso) => iso
      ? new Date(iso).toLocaleString("en-US", { timeZone: "America/Chicago" })
      : "—";

    const contentHtml = [
      para(`It's been 7 days since a clinician signed up for a WayPoint demo — time to check for their honest feedback.`, { lead: true }),
      para(
        `<strong>Name:</strong> ${escapeHtml(p.name || "")}<br/>` +
        `<strong>Email:</strong> ${escapeHtml(p.email || "")}<br/>` +
        `<strong>Seat #:</strong> ${p.seat_number ?? "—"}<br/>` +
        `<strong>Signed up:</strong> ${fmt(p.started_at)}<br/>` +
        `<strong>Demo ended:</strong> ${fmt(p.expires_at)}<br/>` +
        `<strong>Feedback received:</strong> ${p.feedback_received ? "Yes" : "No — check your inbox for their feedback email"}`
      ),
      para(
        `If they've emailed their honest 7-day feedback to ${DEMO_OWNER_EMAIL}, mark it received on the Demo Feedback dashboard. ` +
        `If you haven't heard from them yet, you can follow up from your email thread with them.`
      ),
    ].join("");

    const { html } = renderEmail({ recipientType: "general", contentHtml });
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: DEMO_OWNER_EMAIL,
      subject: `7-day demo finished — check for feedback from ${p.name || p.email}`,
      body: html,
    });
    console.log(`demo-7day-feedback-alert sent to ${DEMO_OWNER_EMAIL} for ${p.email}`);
    return Response.json({ ok: true, to: DEMO_OWNER_EMAIL, participant: p.email });
  } catch (error) {
    console.error("demo-7day-feedback-alert error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}