import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para, alertCallout, therapistUplift } from '../../shared/emailTemplate.js';
import { encodeHeader, utf8Base64, wrap76 } from '../../shared/gmailSend.ts';

// Base64url-encode a UTF-8 string (RFC 2045 / RFC 4648) for Gmail's `raw` field.
function base64urlUtf8(str) {
  const b64 = btoa(unescape(encodeURIComponent(str)));
  return b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function buildMultipartMessage(to, subject, text, html) {
  // Multipart/alternative so Gmail offers both a plain-text and a branded HTML view.
  const boundary = "waypoint_" + Math.random().toString(36).slice(2);
  const lines = [
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    "MIME-Version: 1.0",
    `To: ${to}`,
    `Subject: ${encodeHeader(subject)}`,
    "",
    `--${boundary}`,
    "Content-Type: text/plain; charset=utf-8",
    "Content-Transfer-Encoding: base64",
    "",
    wrap76(utf8Base64(text)),
    "",
    `--${boundary}`,
    "Content-Type: text/html; charset=utf-8",
    "Content-Transfer-Encoding: base64",
    "",
    wrap76(utf8Base64(html)),
    "",
    `--${boundary}--`,
  ];
  return lines.join("\r\n");
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { test_type, score, severity, client_email, therapist_email } = body;

    if (!test_type || score === undefined || score === null) {
      return Response.json({ sent: false, reason: "incomplete_data" });
    }

    // Resolve the therapist to notify — prefer the submitted link, fall back to the Client record.
    let therapistEmail = therapist_email || "";
    if (!therapistEmail && client_email) {
      try {
        const clients = await base44.asServiceRole.entities.Client.filter({ client_email });
        if (clients[0]?.therapist_email) therapistEmail = clients[0].therapist_email;
      } catch (e) {
        console.error("Therapist lookup failed:", e.message);
      }
    }

    if (!therapistEmail) {
      // De-identified log (no client identifier) — HIPAA minimum-necessary.
      console.error("Assessment alert: no therapist linked for assessment", test_type);
      return Response.json({ sent: false, reason: "no_therapist" });
    }

    // HIPAA minimum-necessary: routine result emails carry no client details —
    // scores, severity, and client identity stay in the portal. (Safety-critical
    // alerts are handled separately by safety-risk-alert / crisis-symptom-alert.)
    const subject = `[WayPoint] New ${test_type} completed`;
    const contentHtml = [
      para("A client has completed a new assessment in WayPoint.", { lead: true }),
      alertCallout("New Assessment Result", [
        `<p style="margin:0;"><strong>Assessment:</strong> ${escapeHtml(test_type)}</p>`,
      ].join("")),
      para("To protect client privacy, scores and client details are never included in email. Sign in to your WayPoint therapist portal to view the result, severity, and full history."),
      therapistUplift(),
    ].join("");
    const { html, text } = renderEmail({ recipientType: "therapist", contentHtml });

    const { accessToken } = await base44.asServiceRole.connectors.getConnection("gmail");
    if (!accessToken) {
      console.error("Assessment alert: no Gmail access token available");
      return Response.json({ sent: false, reason: "no_gmail_token" }, { status: 502 });
    }

    const raw = base64urlUtf8(buildMultipartMessage(therapistEmail, subject, text, html));
    const res = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ raw }),
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error("Gmail send failed:", res.status, errText);
      return Response.json({ sent: false, reason: "gmail_send_failed", status: res.status, detail: errText }, { status: 502 });
    }

    const data = await res.json();
    // De-identified log (recipient therapist only, no client identifier).
    console.log("Assessment alert sent to", therapistEmail, "for", test_type, "message", data.id);
    return Response.json({ sent: true, message_id: data.id, therapist_email: therapistEmail });
  } catch (error) {
    console.error("Assessment alert error:", error.message);
    return Response.json({ sent: false, error: error.message }, { status: 500 });
  }
}

function escapeHtml(s) {
  return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}