import jwt from "npm:jsonwebtoken@9.0.2";
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { secrets } from 'base44:runtime';
import { renderEmail, para, alertCallout, primaryButton } from '../../shared/emailTemplate.js';
import { escapeHtml } from '../../shared/emailUtils.ts';
import { getPlan } from '../../shared/planCatalog.ts';

const OWNER_EMAIL = "jenthecounselor16@gmail.com";
const APP_URL_FALLBACK = "https://way-point43.base44.app";

export default async function(req) {
  try {
    const requestBody = await req.text();
    const publicKey = secrets.get("WIX_CHECKOUT_WEBHOOK_PUBLIC_KEY") || secrets.get("WIX_PAYMENTS_WEBHOOK_PUBLIC_KEY");

    if (!publicKey) {
      console.error("Missing webhook public key");
      return new Response("Unauthorized", { status: 401 });
    }

    // Step 1: Verify JWT signature — fail closed if verification fails
    const rawPayload = jwt.verify(requestBody, publicKey, { algorithms: ["RS256"] });

    // Step 2: Parse double-nested JSON (WebhookEnvelope -> event data)
    const event = JSON.parse(rawPayload.data);
    const eventData = JSON.parse(event.data);

    const base44 = createClientFromRequest(req);

    // Step 3: Route by event type
    if (event.eventType === "wix.ecom.v1.order_approved") {
      const order = eventData.actionEvent.body.order;
      console.log("Order approved:", order.id, "checkout:", order.checkoutId);

      // Extract the subscription ID — the only way to match future cancel/expire webhooks
      let subscriptionId = "";
      for (const lineItem of order.lineItems || []) {
        if (lineItem.subscriptionInfo?.id) {
          subscriptionId = lineItem.subscriptionInfo.id;
          break;
        }
      }

      // Resolve the pending purchase by checkout session ID
      const purchases = await base44.asServiceRole.entities.Base44Purchase.filter({
        checkoutSessionId: order.checkoutId
      });

      if (purchases.length > 0) {
        const purchase = purchases[0];
        const needsPaid = purchase.status !== "paid";
        const needsSubId = subscriptionId && !purchase.subscription_id;

        // Grant therapist access to the buyer BEFORE marking the purchase paid
        // (idempotent — gated on needsPaid so Wix redeliveries skip it). The buyer
        // is linked via purchase.buyer_email (captured at checkout from the logged-in
        // app user), never the Wix checkout-typed email.
        if (needsPaid && purchase.buyer_email) {
          try {
            const users = await base44.asServiceRole.entities.User.filter({ email: purchase.buyer_email });
            const u = (users || [])[0];
            if (u) {
              try { await base44.asServiceRole.entities.User.update(u.id, { account_type: "therapist" }); } catch (e) { console.error("grant account_type failed:", e.message); }
              try { await base44.asServiceRole.entities.User.update(u.id, { role: "therapist" }); } catch (e) { console.error("grant role failed:", e.message); }
              console.log("Therapist role granted to:", u.email);
            } else {
              console.log("No registered user found for buyer_email:", purchase.buyer_email);
            }
          } catch (e) {
            console.error("Role grant lookup failed:", e.message);
          }
        }

        // Mark paid + store subscription ID — idempotent against Wix redeliveries.
        if (needsPaid || needsSubId) {
          const update = {};
          if (needsPaid) update.status = "paid";
          if (needsSubId) update.subscription_id = subscriptionId;
          await base44.asServiceRole.entities.Base44Purchase.update(purchase.id, update);
          console.log("Purchase granted:", purchase.id, "plan:", purchase.plan, "subscription:", subscriptionId || "(none)");

          // Notify the WayPoint owner of the new subscription (tier + monthly
          // amount). Gated on needsPaid so Wix redeliveries never double-send.
          if (needsPaid) {
            try {
              const planInfo = getPlan(purchase.plan);
              const tier = planInfo ? planInfo.tier : (purchase.plan || "Unknown plan");
              const amountLine = planInfo ? `$${planInfo.amount} / month` : "Unknown amount";

              const contentHtml = [
                para(`A new WayPoint subscription was just purchased.`, { lead: true }),
                alertCallout(
                  "New subscription",
                  `<strong>Tier:</strong> ${escapeHtml(tier)}<br/>` +
                    `<strong>Monthly amount:</strong> ${escapeHtml(amountLine)}` +
                    (purchase.buyer_email ? `<br/><strong>Buyer:</strong> ${escapeHtml(purchase.buyer_email)}` : "")
                ),
                para(`The clinician now has full therapist access. This email was sent automatically when the payment was approved.`),
              ].join("");
              const { html } = renderEmail({ recipientType: "general", contentHtml });
              await base44.asServiceRole.integrations.Core.SendEmail({
                to: OWNER_EMAIL,
                subject: `New subscription — ${tier}${planInfo ? ` ($${planInfo.amount}/mo)` : ""}`,
                body: html,
              });
              console.log("Purchase notification sent to owner for:", tier);
            } catch (e) {
              console.error("Purchase notification email failed:", e.message);
            }

            // Branded confirmation to the buyer themselves (only when we have
            // their account email from checkout creation).
            if (purchase.buyer_email) {
              try {
                const appUrl = (req.headers.get("X-Base44-App-Url") || "").replace(/\/$/, "") || APP_URL_FALLBACK;
                const portalUrl = `${appUrl}/therapist`;
                const buyerContentHtml = [
                  para(`Your WayPoint subscription is active.`, { lead: true }),
                  para(`Thank you for subscribing to WayPoint! Your payment was approved and your clinician account now has full access.`),
                  alertCallout(
                    "Your subscription",
                    `<strong>Plan:</strong> ${escapeHtml(tier)}<br/>` +
                      `<strong>Monthly amount:</strong> ${escapeHtml(amountLine)}`
                  ),
                  primaryButton("Open your Therapist Portal", portalUrl),
                  para(`You can manage your subscription anytime from the Billing page. Questions? Just reply to this email.<br/><br/>Warmly,<br/>The WayPoint Team`),
                ].join("");
                const { html: buyerHtml } = renderEmail({ recipientType: "onboarding", contentHtml: buyerContentHtml });
                await base44.asServiceRole.integrations.Core.SendEmail({
                  to: purchase.buyer_email,
                  subject: `Your WayPoint subscription is active — ${tier}`,
                  body: buyerHtml,
                });
                console.log("Purchase confirmation sent to buyer:", purchase.buyer_email);
              } catch (e) {
                console.error("Buyer confirmation email failed:", e.message);
              }
            }
          }
        } else {
          console.log("Purchase already paid (idempotent skip):", purchase.id);
        }
      } else {
        console.log("No purchase found for checkout:", order.checkoutId);
      }
    } else if (
      event.eventType === "wix.ecom.subscription_contracts.v1.subscription_contract_canceled" ||
      event.eventType === "wix.ecom.subscription_contracts.v1.subscription_contract_expired"
    ) {
      const subscriptionContract = eventData.actionEvent.body.subscriptionContract;
      const subscriptionId = subscriptionContract.id;
      console.log("Subscription ended:", subscriptionId, "reason:", event.eventType);

      // Match the original purchase by subscription ID and revoke access
      const purchases = await base44.asServiceRole.entities.Base44Purchase.filter({
        subscription_id: subscriptionId
      });

      if (purchases.length > 0) {
        const purchase = purchases[0];
        if (purchase.status !== "cancelled") {
          await base44.asServiceRole.entities.Base44Purchase.update(purchase.id, { status: "cancelled" });
          console.log("Purchase cancelled:", purchase.id, "plan:", purchase.plan);
        } else {
          console.log("Purchase already cancelled (idempotent skip):", purchase.id);
        }
      } else {
        console.log("No purchase found for subscription:", subscriptionId);
      }
    } else {
      console.log("Unknown webhook event:", event.eventType);
    }

    return new Response("OK", { status: 200 });
  } catch (error) {
    console.error("Webhook error:", error.message);
    return new Response("Unauthorized", { status: 401 });
  }
}