import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para, primaryButton } from '../../shared/emailTemplate.js';
import { firstNameOf, escapeHtml } from '../../shared/emailUtils.ts';
import { sendGmail } from '../../shared/gmailSend.ts';

// Invoked by the "Welcome Email" workflow when a new user signs up, then again
// for two follow-up onboarding tips. Sends each message through the builder's
// connected Gmail account as a branded multipart/alternative email.
//
// step values: "welcome" (immediate), "tip2" (day 2), "tip3" (day 5).

const APP_URL_FALLBACK = "https://way-point43.base44.app";

function appUrl(req) {
  return (req.headers.get("X-Base44-App-Url") || "").replace(/\/$/, "") || APP_URL_FALLBACK;
}

function contentFor(isClinician, step, firstName, url) {
  if (isClinician) {
    const portal = `${url}/therapist`;
    const careLib = `${url}/care-library`;
    const onboarding = `${url}/onboarding-guide`;
    if (step === "welcome") {
      return {
        subject: "Welcome to WayPoint — let's set up your practice",
        html: [
          para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
          para(`Welcome to WayPoint. We're glad to have you. WayPoint extends evidence-based care beyond the session &mdash; assessments, homework, coping tools, and clinical insights, all in one place your clients can reach between visits.`),
          para(`<strong>First step:</strong> open your Therapist Portal and invite your first client. They&rsquo;ll register through WayPoint and link securely to you, so their progress flows into your dashboard.`),
          primaryButton("Open your Therapist Portal", portal),
          para(`Prefer a step-by-step tour? The <a href="${onboarding}" style="color:#1E8378;font-weight:700;">Onboarding Guide</a> walks you through everything &mdash; from inviting your first client to reading your Insights dashboard.`),
          para("You can explore everything during your trial &mdash; no payment needed yet. We&rsquo;ll send a couple of short tips over the next few days to help you get the most out of it.<br/><br/>Warmly,<br/>The WayPoint Team"),
        ].join(""),
      };
    }
    if (step === "tip2") {
      return {
        subject: "WayPoint tip: assign care in one click",
        html: [
          para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
          para(`Here&rsquo;s a quick way to save time: the Care Library holds ready-made bundles of therapy goals, homework, and coping tools. Apply a whole bundle to a client in one click, then customize.`),
          para(`You can also assign standardized assessments (GAD-7, PHQ-9, and more) and homework with due dates from your portal &mdash; clients get reminders automatically.`),
          primaryButton("Explore the Care Library", careLib),
          para("Warmly,<br/>The WayPoint Team"),
        ].join(""),
      };
    }
    return {
      subject: "WayPoint tip: track progress at a glance",
      html: [
        para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
        para(`Once your clients are checking in and completing assessments, open Insights and Assessment Charts to see symptom trends, nervous-system patterns, and functional impairment over time &mdash; everything you need for treatment planning and progress notes.`),
        para(`For the full walkthrough, our Onboarding Guide walks you through every step.`),
        primaryButton("Open the Onboarding Guide", onboarding),
        para("Warmly,<br/>The WayPoint Team"),
      ].join(""),
    };
  }

  // Client onboarding
  const portal = `${url}/client-portal`;
  const emotions = `${url}/emotions`;
  const toolbox = `${url}/toolbox`;
  const onboardingWalk = `${url}/onboarding`;
  const dashboard = `${url}/dashboard`;
  if (step === "welcome") {
    return {
      subject: "Welcome to WayPoint — let's begin",
      html: [
        para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
        para(`Welcome to WayPoint &mdash; a companion for the work you&rsquo;re doing with your therapist, between sessions. Everything here is private to you and shared only with your therapist.`),
        para(`<strong>First step:</strong> a 60-second nervous-system check-in from your Home dashboard. It builds a gentle baseline your therapist can use to understand how you&rsquo;re doing over time.`),
        primaryButton("Go to My Portal", portal),
        para(`New to WayPoint? The <a href="${onboardingWalk}" style="color:#1E8378;font-weight:700;">onboarding walkthrough</a> gives you a friendly step-by-step tour, and your <a href="${dashboard}" style="color:#1E8378;font-weight:700;">daily check-in dashboard</a> is where your progress story begins.`),
        para("Over the next few days we&rsquo;ll send short tips to help you get the most out of WayPoint. You&rsquo;re not alone in this.<br/><br/>Warmly,<br/>The WayPoint Team"),
      ].join(""),
    };
  }
  if (step === "tip2") {
    return {
      subject: "WayPoint tip: name what you're feeling",
      html: [
        para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
        para(`Sometimes just naming an emotion softens it. Try the Emotion Wheel to find the word that fits, then capture it as a thought record &mdash; a few minutes that can shift your whole day.`),
        primaryButton("Open the Emotion Wheel", emotions),
        para("Warmly,<br/>The WayPoint Team"),
      ].join(""),
    };
  }
  return {
    subject: "WayPoint tip: skills for the hard moments",
    html: [
      para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
      para(`The Coping Toolbox has ready-to-use DBT, CBT, and grounding skills for the moments you need them. You can also check any assessments your therapist has assigned you &mdash; they take just a few minutes.`),
      primaryButton("Open the Coping Toolbox", toolbox),
      para("If you&rsquo;re ever in crisis, call or text 988 anytime, 24/7.<br/><br/>Warmly,<br/>The WayPoint Team"),
    ].join(""),
  };
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const { email, full_name, role, step } = body || {};

    if (!email) return Response.json({ error: "email is required" }, { status: 400 });
    if (!step) return Response.json({ error: "step is required" }, { status: 400 });

    // Treat demo clinicians as clinicians even before their role grant lands,
    // so they receive the clinician onboarding sequence.
    let isClinician = role === "therapist" || role === "admin" || role === "supervisor";
    if (!isClinician) {
      try {
        const demos = await base44.asServiceRole.entities.DemoParticipant.filter({ email });
        if (demos && demos.length) isClinician = true;
      } catch (e) {
        console.error("DemoParticipant lookup failed:", e.message);
      }
    }

    const firstName = firstNameOf(full_name, String(email).split("@")[0]);
    const url = appUrl(req);
    const recipientType = isClinician ? "therapist" : "client";
    const { subject, html: contentHtml } = contentFor(isClinician, step, firstName, url);
    const { html, text } = renderEmail({ recipientType: "onboarding", contentHtml });

    const result = await sendGmail(base44, { to: email, subject, html, text });
    console.log(`welcome-email sent: step=${step} to=${email} clinician=${isClinician}`);
    return Response.json({ ok: true, step, to: email, id: result.id });
  } catch (error) {
    console.error("welcome-email error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}