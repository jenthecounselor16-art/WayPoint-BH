import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { name, email, organization, title, clinician_count, phone, interest_level, message } = body;

    if (!name || !email || !organization) {
      return Response.json({ error: "Name, email, and organization are required" }, { status: 400 });
    }

    // Notify the team — SendEmail only reaches registered app users, so email every admin.
    // Route all demo/sales requests to jenthecounselor16@gmail.com as well.
    const DEMO_REQUEST_EMAIL = "jenthecounselor16@gmail.com";
    let recipients = [];
    try {
      const users = await base44.asServiceRole.entities.User.list("-created_date", 200);
      recipients = (users || [])
        .filter((u) => u.role === "admin")
        .map((u) => u.email)
        .filter(Boolean);
    } catch (e) {
      console.error("Failed to load admin users:", e.message);
    }
    if (!recipients.some((e) => e.toLowerCase() === DEMO_REQUEST_EMAIL.toLowerCase())) {
      recipients.push(DEMO_REQUEST_EMAIL);
    }

    if (recipients.length === 0) {
      console.error("Contact sales: no admin recipients available");
      return Response.json(
        { error: "We couldn't route your inquiry. Please email us directly." },
        { status: 500 }
      );
    }

    const subject = `[WayPoint Enterprise Sales] New inquiry from ${organization}`;
    const bodyText = [
      "A new enterprise sales inquiry was submitted.",
      "",
      `Name: ${name}`,
      `Title: ${title || "—"}`,
      `Organization: ${organization}`,
      `Email: ${email}`,
      `Phone: ${phone || "—"}`,
      `Clinician count: ${clinician_count || "—"}`,
      `Interest level: ${interest_level || "—"}`,
      "",
      "Message:",
      message || "(none)",
      "",
      "Follow up with custom pricing and onboarding details.",
    ].join("\n");

    let sent = 0;
    for (const to of recipients) {
      try {
        await base44.asServiceRole.integrations.Core.SendEmail({ to, subject, body: bodyText });
        sent++;
      } catch (e) {
        console.error(`SendEmail to ${to} failed:`, e.message);
      }
    }

    if (sent === 0) {
      return Response.json(
        { error: "Unable to send your inquiry. Please try again or email us directly." },
        { status: 500 }
      );
    }

    // Best-effort audit trail of the public submission
    try {
      await base44.asServiceRole.entities.AuditLog.create({
        action: "contact_sales_inquiry",
        client_email: email,
        therapist_email: "",
        details: `Enterprise inquiry from ${name} @ ${organization} (${clinician_count || "unknown"} clinicians).`,
      });
    } catch (e) {
      console.error("Audit log error:", e.message);
    }

    console.log(`Contact-sales inquiry from ${organization} notified ${sent} admin(s).`);
    return Response.json({ ok: true, notified: sent });
  } catch (error) {
    console.error("Contact sales error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}