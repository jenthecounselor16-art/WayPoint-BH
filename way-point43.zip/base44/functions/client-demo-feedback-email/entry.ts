import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para, primaryButton } from '../../shared/emailTemplate.js';
import { escapeHtml } from '../../shared/emailUtils.ts';

// Invoked by the "Client Demo Feedback Request" workflow exactly 7 days after a
// new ClientDemoParticipant is created. Emails the client a link to the in-app
// feedback survey. No gift card incentive.

function appUrlFromReq(req) {
  try {
    const h = (req.headers && (req.headers.get ? req.headers.get("X-Base44-App-Url") : req.headers["X-Base44-App-Url"])) || "";
    if (h) return String(h).replace(/\/+$/, "");
  } catch {}
  return "";
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const { participant_id } = body || {};
    if (!participant_id) return Response.json({ error: "participant_id is required" }, { status: 400 });

    let p;
    try {
      p = await base44.asServiceRole.entities.ClientDemoParticipant.get(participant_id);
    } catch (e) {
      console.error("ClientDemoParticipant fetch failed:", e.message);
      return Response.json({ error: "participant not found" }, { status: 404 });
    }
    if (!p) return Response.json({ error: "participant not found" }, { status: 404 });
    if (!p.email) return Response.json({ error: "participant has no email" }, { status: 400 });

    // Skip if their trial window has already closed or they already gave feedback.
    if (p.status === "expired") {
      return Response.json({ ok: false, reason: "participant already expired" });
    }
    if (p.feedback_received) {
      return Response.json({ ok: false, reason: "feedback already received" });
    }

    const appUrl = appUrlFromReq(req);
    const surveyUrl = appUrl ? `${appUrl}/client-demo-survey` : "/client-demo-survey";

    const firstName = (p.name || "").split(" ")[0].trim() || "there";

    const contentHtml = [
      para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
      para(`Your 7-day WayPoint trial just wrapped up — thank you for spending that time with us.`),
      para(`We'd love to hear what you thought. It takes about two minutes, and your honest feedback helps us make WayPoint better for people like you.`),
      primaryButton("Share your feedback", surveyUrl),
      para(`No catch — just your voice helping us improve.`, { bold: false }),
      para(`Warmly,<br/><strong>The WayPoint Team</strong>`, { bold: false }),
    ].join("");

    const { html } = renderEmail({ recipientType: "client", contentHtml });
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: p.email,
      subject: `Your WayPoint trial is done — we'd love your feedback`,
      body: html,
    });
    console.log(`client-demo-feedback-email sent to ${p.email} for participant ${p.id}`);
    return Response.json({ ok: true, to: p.email, survey_url: surveyUrl });
  } catch (error) {
    console.error("client-demo-feedback-email error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}