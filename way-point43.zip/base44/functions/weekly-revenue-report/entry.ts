import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para } from '../../shared/emailTemplate.js';
import { escapeHtml } from '../../shared/emailUtils.ts';
import { getPlan } from '../../shared/planCatalog.ts';

const OWNER_EMAIL = "jenthecounselor16@gmail.com";

// Invoked every Monday at 9am (America/Chicago) by the "Weekly Revenue Report"
// workflow. Sums the new paid subscriptions from the past 7 days and emails a
// revenue summary (tier breakdown + total monthly revenue) to the WayPoint owner.

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const since = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

    const purchases = await base44.asServiceRole.entities.Base44Purchase.list('-created_date', 500);

    // New paid subscriptions from the past week
    const weekPurchases = (purchases || []).filter(
      (p) => p.status === "paid" && p.created_date && new Date(p.created_date) >= since
    );

    // Per-tier breakdown: count + total monthly revenue
    const byTier = {};
    for (const p of weekPurchases) {
      const planInfo = getPlan(p.plan);
      const tier = planInfo ? planInfo.tier : (p.plan || "Unknown plan");
      if (!byTier[tier]) byTier[tier] = { count: 0, monthly: 0 };
      byTier[tier].count++;
      byTier[tier].monthly += planInfo ? planInfo.amount : 0;
    }

    const totalSales = weekPurchases.length;
    const totalMonthly = weekPurchases.reduce(
      (sum, p) => sum + (getPlan(p.plan)?.amount || 0), 0
    );

    // All active subscriptions (paid, not cancelled) — total recurring revenue
    const activePurchases = (purchases || []).filter((p) => p.status === "paid");
    const activeByTier = {};
    for (const p of activePurchases) {
      const planInfo = getPlan(p.plan);
      const tier = planInfo ? planInfo.tier : (p.plan || "Unknown plan");
      if (!activeByTier[tier]) activeByTier[tier] = { count: 0, monthly: 0 };
      activeByTier[tier].count++;
      activeByTier[tier].monthly += planInfo ? planInfo.amount : 0;
    }
    const activeTotal = activePurchases.length;
    const activeMonthly = activePurchases.reduce(
      (sum, p) => sum + (getPlan(p.plan)?.amount || 0), 0
    );

    // Build the summary email
    const buildTable = (byTier, countHeader) =>
      Object.entries(byTier)
        .map(
          ([tier, v]) =>
            `<tr>` +
            `<td style="padding:8px 12px 8px 0;font-size:15px;line-height:1.5;color:#2C3E45;border-bottom:1px solid #EAF1F0;">${escapeHtml(tier)}</td>` +
            `<td style="padding:8px 12px;text-align:center;font-size:15px;line-height:1.5;color:#2C3E45;border-bottom:1px solid #EAF1F0;">${v.count}</td>` +
            `<td style="padding:8px 0;text-align:right;font-size:15px;line-height:1.5;color:#2C3E45;border-bottom:1px solid #EAF1F0;">$${v.monthly} / mo</td>` +
            `</tr>`
        )
        .join("");

    const sectionTable = (byTier, countHeader) =>
      para(
        `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:6px 0 10px 0;">` +
          `<tr>` +
          `<td style="padding:8px 12px 8px 0;font-size:12px;letter-spacing:.06em;text-transform:uppercase;font-weight:700;color:#1E8378;border-bottom:2px solid #EAF1F0;">Tier</td>` +
          `<td style="padding:8px 12px;text-align:center;font-size:12px;letter-spacing:.06em;text-transform:uppercase;font-weight:700;color:#1E8378;border-bottom:2px solid #EAF1F0;">${countHeader}</td>` +
          `<td style="padding:8px 0;text-align:right;font-size:12px;letter-spacing:.06em;text-transform:uppercase;font-weight:700;color:#1E8378;border-bottom:2px solid #EAF1F0;">Monthly revenue</td>` +
          `</tr>${buildTable(byTier, countHeader)}</table>`
      );

    const weekStart = since.toLocaleDateString("en-US", { month: "long", day: "numeric", timeZone: "America/Chicago" });

    const contentHtml = [
      para(`Here's your WayPoint revenue summary for the past week (since ${weekStart}).`, { lead: true }),
      para(`<strong style="color:#1E8378;">New subscriptions this week</strong>`),
      totalSales === 0
        ? para(`No new subscriptions were purchased this week.`)
        : sectionTable(byTier, "New subs"),
      para(
        `<strong>Total new subscriptions:</strong> ${totalSales}<br/>` +
          `<strong>Total new monthly revenue:</strong> $${totalMonthly} / month`
      ),
      para(`<strong style="color:#1E8378;">All active subscription tiers</strong>`),
      activeTotal === 0
        ? para(`You currently have no active paid subscriptions.`)
        : sectionTable(activeByTier, "Active subs"),
      para(
        `<strong>Active subscriptions:</strong> ${activeTotal}<br/>` +
          `<strong>Total monthly recurring revenue:</strong> $${activeMonthly} / month`
      ),
    ].join("");

    const { html } = renderEmail({ recipientType: "general", contentHtml });
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: OWNER_EMAIL,
      subject: `WayPoint weekly revenue — $${activeMonthly}/mo active from ${activeTotal} subscription${activeTotal === 1 ? "" : "s"}, ${totalSales} new this week`,
      body: html,
    });

    console.log(`weekly-revenue-report: newPaid=${totalSales} weeklyMonthlyRevenue=${totalMonthly} activeSubs=${activeTotal} activeMonthlyRevenue=${activeMonthly}`);
    return Response.json({ ok: true, newPaid: totalSales, weeklyMonthlyRevenue: totalMonthly, activeSubs: activeTotal, activeMonthlyRevenue: activeMonthly });
  } catch (error) {
    console.error("weekly-revenue-report error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}