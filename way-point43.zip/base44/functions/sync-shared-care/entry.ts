import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { syncSharedCare } from '../../shared/sharedCare.ts';

// Invoked by the "Shared Care Sync" workflow whenever a user signs up or
// logs in. Rebuilds that user's `shared_client_emails` list from the Client
// entity's care teams, so a co-treating provider gets read access to shared
// clients the moment they register (or after the primary therapist added
// them while they had no account yet). Idempotent; returns only a count so a
// direct call reveals no client emails.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    let email = '';
    try { const body = await req.json(); email = body?.email || ''; } catch {}
    email = String(email).trim().toLowerCase();
    if (!email) return Response.json({ error: 'email is required' }, { status: 400 });

    const result = await syncSharedCare(base44.asServiceRole, email);
    return Response.json({ ok: true, synced: (result.shared_client_emails || []).length, user_found: result.user_found });
  } catch (error) {
    console.error('sync-shared-care error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}