import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para, primaryButton, softNote, therapistUplift } from '../../shared/emailTemplate.js';
import { getAppUrl, firstNameOf, escapeHtml } from '../../shared/emailUtils.ts';

// Invoked daily by the "Demo Trial Sequence" workflow.
// Sends warm, idempotent mid-trial check-in emails to active demo clinicians:
//   ~Day 2 — getting-started check-in (Therapist Portal + Clinical Insights)
//   ~Day 4 — mid-trial exploration (Coping Toolbox, Behavior Activation, Parent Portal)
//   ~Day 5 — "one day left" nudge that previews the upcoming survey
// The final-day recap email (usage stats, pricing, upgrade CTAs) is handled
// separately by the "Demo Last Day Email" workflow + demo-last-day-email, so
// this sequence never races the recap. Idempotency: checkin_emails_sent[]
// tracks which mid-trial sends have gone out.
const HOUR = 3600000;

const CHECKINS = [
  {
    key: 'day2',
    minH: 48, maxH: 72,
    subject: 'Two days in — how is your WayPoint demo going?',
    build: (firstName, appUrl) => [
      para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
      para("You're two days into your WayPoint demo, and I wanted to check in to make sure you're finding your footing."),
      para("If you haven't yet, take a few minutes to explore the <strong>Therapist Portal</strong> &mdash; add a client, assign a piece of homework or an assessment &mdash; then open <strong>Clinical Insights</strong> to watch those symptom scores chart automatically. That's where most clinicians feel the difference."),
      primaryButton('Open the Therapist Portal', appUrl ? `${appUrl}/therapist` : '/therapist'),
      therapistUplift(),
      para("Reply to this email if anything's unclear &mdash; I'm glad to help you get the most out of the days ahead."),
      para('Warm regards,<br/>The WayPoint Team'),
    ].join(''),
  },
  {
    key: 'day4',
    minH: 96, maxH: 120,
    subject: 'Halfway through your demo — a few features worth a look',
    build: (firstName, appUrl) => [
      para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
      para("You're about halfway through your WayPoint demo &mdash; a good moment to look beyond the basics."),
      para("A few pieces clinicians love once they find them: the <strong>Coping Toolbox</strong> and AI Coping Coach for between-session support, <strong>Behavior Activation</strong> tied to a client's values, and the <strong>Parent Portal</strong> for sharing read-only progress with a family member. Each takes just a couple of minutes to try."),
      primaryButton('Explore the Coping Toolbox', appUrl ? `${appUrl}/toolbox` : '/toolbox'),
      therapistUplift(),
      para("If you'd like a quick walkthrough of any of these, just reply here."),
      para('Warm regards,<br/>The WayPoint Team'),
    ].join(''),
  },
  {
    key: 'day5',
    minH: 120, maxH: 138,
    subject: 'One day left in your demo — a quick favor',
    build: (firstName, appUrl) => [
      para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
      para("Tomorrow your 7-day WayPoint demo wraps up. Before it does, take one last pass through anything you haven't tried &mdash; the coping tools, behavior activation, and parent portal are easy to miss."),
      primaryButton('Jump back in', appUrl ? `${appUrl}/` : '/'),
      para("One small heads-up: tomorrow you'll receive a one-minute feedback survey. Your honest take directly shapes what we build next &mdash; we'd genuinely value it."),
      therapistUplift(),
      para('Warm regards,<br/>The WayPoint Team'),
    ].join(''),
  },
];

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const appUrl = getAppUrl(req);
    const now = Date.now();
    const participants = await base44.asServiceRole.entities.DemoParticipant.list('-created_date', 200) || [];
    let sent = 0, failed = 0, skipped = 0;

    for (const p of participants) {
      if (p.status !== 'active') { skipped++; continue; }

      // Mid-trial progress check-in — by hours since the trial started.
      // (The final-day recap email is handled by demo-last-day-email.)
      if (p.started_at) {
        const elapsedH = Math.floor((now - new Date(p.started_at).getTime()) / HOUR);
        const sentMilestones = Array.isArray(p.checkin_emails_sent) ? p.checkin_emails_sent : [];
        const checkin = CHECKINS.find(
          (c) => elapsedH >= c.minH && elapsedH < c.maxH && !sentMilestones.includes(c.key)
        );
        if (checkin) {
          try {
            const firstName = firstNameOf(p.name);
            const { html } = renderEmail({ recipientType: 'general', contentHtml: checkin.build(firstName, appUrl) });
            await base44.asServiceRole.integrations.Core.SendEmail({ to: p.email, subject: checkin.subject, body: html });
            await base44.asServiceRole.entities.DemoParticipant.update(p.id, {
              checkin_emails_sent: [...sentMilestones, checkin.key],
            });
            sent++;
          } catch (e) {
            console.error(`trial checkin to ${p.email} failed:`, e.message);
            failed++;
          }
          continue;
        }
      }

      skipped++;
    }

    console.log(`demo-trial-sequence: sent=${sent} skipped=${skipped} failed=${failed}`);
    return Response.json({ ok: true, sent, skipped, failed });
  } catch (error) {
    console.error('demo-trial-sequence error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}