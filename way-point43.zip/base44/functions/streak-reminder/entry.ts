import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para, primaryButton, softNote } from '../../shared/emailTemplate.js';
import { getAppUrl, firstNameOf, escapeHtml } from '../../shared/emailUtils.ts';

// Invoked daily by the "Streak Reminder" workflow.
// Finds clients who had a mood check-in streak of >= 3 days but haven't logged
// a mood in the last 3 days, and sends a compassionate nudge to keep the streak
// alive. The 3-4 day window makes each lapse fire exactly once (idempotent),
// so a daily run never re-spams the same client.
const DAY = 86400000;
const THREE_DAYS = 3 * DAY;
const FOUR_DAYS = 4 * DAY;

function dayKey(d) {
  const x = new Date(d);
  return `${x.getFullYear()}-${x.getMonth()}-${x.getDate()}`;
}

// Consecutive-day streak ending at (and including) the most recent entry.
function endingStreak(dateStrings) {
  if (!dateStrings || !dateStrings.length) return 0;
  const set = new Set(dateStrings.map((d) => dayKey(d)));
  let last = 0;
  for (const d of dateStrings) {
    const t = new Date(d).getTime();
    if (t > last) last = t;
  }
  const cursor = new Date(last);
  cursor.setHours(0, 0, 0, 0);
  let streak = 0;
  while (set.has(dayKey(cursor))) {
    streak++;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const dryRun = body && body.dry_run === true;

    const appUrl = getAppUrl(req);
    const moodUrl = appUrl ? `${appUrl}/emotions` : "/emotions";

    const now = Date.now();
    const [moods, users] = await Promise.all([
      base44.asServiceRole.entities.MoodEntry.list("-created_date", 5000),
      base44.asServiceRole.entities.User.list("-created_date", 1000),
    ]);

    const userMap = {};
    (users || []).forEach((u) => { if (u.id) userMap[u.id] = u; });

    // Group mood entries by the client who logged them
    const byUser = {};
    (moods || []).forEach((m) => {
      const uid = m.created_by_id;
      if (!uid) return;
      if (!byUser[uid]) byUser[uid] = [];
      byUser[uid].push(m.created_date);
    });

    const eligible = [];
    for (const [uid, dates] of Object.entries(byUser)) {
      const lastMs = Math.max(...dates.map((d) => new Date(d).getTime()));
      const age = now - lastMs;
      if (age < THREE_DAYS || age >= FOUR_DAYS) continue; // fire once at the 3-day mark
      const streak = endingStreak(dates);
      if (streak < 3) continue; // only nudge clients who had a real streak going
      const u = userMap[uid];
      if (!u || u.role !== "user") continue; // clients only, never therapists
      eligible.push({ email: u.email, name: u.full_name || u.email, streak });
    }

    if (dryRun) {
      return Response.json({ ok: true, dry_run: true, eligible: eligible.map((e) => ({ email: e.email, streak: e.streak })) });
    }

    let sent = 0;
    let failed = 0;
    for (const c of eligible) {
      try {
        const firstName = firstNameOf(c.name);
        const subject = "Your WayPoint streak is waiting for you";
        const contentHtml = [
          para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
          para(`You built a <strong>${c.streak}-day check-in streak</strong> in WayPoint &mdash; that takes real commitment, and it matters. Every check-in is a small act of showing up for yourself.`),
          softNote("It's been a few days since your last mood check-in. That's okay &mdash; life gets full, and progress isn't about being perfect. It's about gently coming back."),
          para("Logging even one quick check-in today helps keep that momentum alive. Your streak is ready whenever you are &mdash; no pressure, just an open door."),
          primaryButton("Check in now", moodUrl),
          para("Take a breath, notice how you're feeling, and let WayPoint hold the rest. We're glad you're here.<br/><br/>Warm regards,<br/>The WayPoint Team"),
        ].join("");

        const { html } = renderEmail({ recipientType: "client", contentHtml });
        await base44.asServiceRole.integrations.Core.SendEmail({ to: c.email, subject, body: html });
        sent++;
      } catch (e) {
        console.error(`Streak reminder to ${c.email} failed:`, e.message);
        failed++;
      }
    }

    console.log(`streak-reminder: eligible=${eligible.length} sent=${sent} failed=${failed}`);
    return Response.json({ ok: true, eligible: eligible.length, sent, failed });
  } catch (error) {
    console.error("streak-reminder error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}