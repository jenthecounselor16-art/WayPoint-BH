import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para, primaryButton, therapistUplift } from '../../shared/emailTemplate.js';
import { getAppUrl, firstNameOf, escapeHtml } from '../../shared/emailUtils.ts';

// Invoked weekly by the "Burnout Tips" workflow.
// Sends each therapist a short, branded self-care email with a rotating
// burnout-prevention tip and an uplifting note, so clinicians get ongoing
// support alongside the care they give their clients.

const TIP_CARD = (title, body) => `
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:18px 0;">
    <tr>
      <td style="background:#F2F7F6;border-left:4px solid #26A69A;border-radius:8px;padding:16px 18px;">
        <p style="margin:0 0 6px 0;font-size:12px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;color:#1E8378;">This week's self-care tip</p>
        <p style="margin:0;font-size:16px;font-weight:700;color:#2C3E45;font-family:Georgia,'Hoefler Text',serif;">${escapeHtml(title)}</p>
        <p style="margin:8px 0 0 0;font-size:15px;line-height:1.65;color:#2C3E45;">${escapeHtml(body)}</p>
      </td>
    </tr>
  </table>`;

const CBI_SCALE = ["Always", "Often", "Sometimes", "Seldom", "Never"];

function cbiSection(title, items) {
  const header = `<tr>
    <th style="width:35%;text-align:left;padding:6px 0;font-size:11px;color:#5E7278;font-weight:600;">${escapeHtml(title)}</th>
    ${CBI_SCALE.map((s) => `<th style="width:13%;text-align:center;padding:6px 2px;font-size:10px;color:#5E7278;font-weight:600;">${s}</th>`).join("")}
  </tr>`;
  const rows = items.map((it, i) => {
    const cells = CBI_SCALE.map(() => `<td style="width:13%;text-align:center;border:1px solid #E3EDEB;height:22px;background:#ffffff;">&nbsp;</td>`).join("");
    return `<tr><td style="padding:6px 10px 6px 0;font-size:13px;color:#2C3E45;line-height:1.4;">${i + 1}. ${escapeHtml(it)}</td>${cells}</tr>`;
  }).join("");
  return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin:8px 0 14px 0;">${header}${rows}</table>`;
}

// Copenhagen Burnout Inventory (Kristensen et al., 2005) — free to use. A brief,
// validated self-rating clinicians can complete inline to gauge their burnout.
const CBI_BLOCK = () => `
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:18px 0;">
    <tr>
      <td style="background:#FCFEFD;border:1px solid #EAF1F0;border-radius:10px;padding:20px 20px;">
        <p style="margin:0 0 4px 0;font-size:12px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;color:#1E8378;">Weekly burnout check-in</p>
        <p style="margin:0 0 14px 0;font-size:15px;font-weight:700;color:#2C3E45;font-family:Georgia,'Hoefler Text',serif;">How burned out are you this week?</p>
        <p style="margin:0 0 12px 0;font-size:14px;line-height:1.6;color:#2C3E45;">A quick self-rating from the <strong>Copenhagen Burnout Inventory</strong> &mdash; an evidence-based, free-to-use measure (Kristensen et&nbsp;al., 2005). Thinking about the past few months, mark how often each statement has been true for you.</p>

        ${cbiSection("Personal burnout", [
          "How often do you feel tired?",
          "How often are you physically exhausted?",
          "How often are you emotionally exhausted?",
          "How often do you think, \u201cI can\u2019t take it anymore\u201d?",
          "How often do you feel worn out?",
          "How often do you feel weak and susceptible to illness?",
        ])}

        ${cbiSection("Work burnout", [
          "Is your work physically exhausting?",
          "Does your work frustrate you?",
          "Do you feel burned out by your work?",
          "Do you feel worn out after a day at work?",
          "Are you exhausted in the morning at the thought of another day at work?",
          "Do you feel that every working hour is tiring for you?",
          "Do you have enough energy for family and friends during leisure time?",
        ])}

        <p style="margin:14px 0 6px 0;font-size:13px;font-weight:700;color:#1E8378;">Reading your score</p>
        <p style="margin:0 0 10px 0;font-size:13px;line-height:1.55;color:#2C3E45;">Score each item 0&ndash;100 (Always=100, Often=75, Sometimes=50, Seldom=25, Never=0) and average the items in each section. The leisure-energy item is reverse-scored.</p>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin:6px 0 12px 0;">
          <tr>
            <td style="padding:6px 10px;font-size:12px;color:#2C3E45;border:1px solid #E3EDEB;"><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#7CB69D;margin-right:6px;vertical-align:middle;"></span>Low (0&ndash;24)</td>
            <td style="padding:6px 10px;font-size:12px;color:#2C3E45;border:1px solid #E3EDEB;"><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#D4A055;margin-right:6px;vertical-align:middle;"></span>Moderate (25&ndash;49)</td>
          </tr>
          <tr>
            <td style="padding:6px 10px;font-size:12px;color:#2C3E45;border:1px solid #E3EDEB;"><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#E07856;margin-right:6px;vertical-align:middle;"></span>High (50&ndash;74)</td>
            <td style="padding:6px 10px;font-size:12px;color:#2C3E45;border:1px solid #E3EDEB;"><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#D9534F;margin-right:6px;vertical-align:middle;"></span>Very high (75&ndash;100)</td>
          </tr>
        </table>
        <p style="margin:0;font-size:13px;line-height:1.6;color:#2C3E45;">If your score is in the <strong>high</strong> or <strong>very high</strong> range, treat it as a signal: lean on peer consultation, talk with a supervisor about your caseload, and consider your own therapy. Caring for the caregiver is part of ethical practice.</p>
      </td>
    </tr>
  </table>`;

const BURNOUT_TIPS = [
  {
    title: "Protect a hard stop at the end of your day",
    body: "Pick a consistent time to close your notes and step away — and treat it like a client boundary you wouldn't break. The chart will still be there tomorrow; your nervous system needs the exit.",
  },
  {
    title: "Bookend your day with three slow breaths",
    body: "Before your first session and after your last, pause for three long exhales. These tiny bookends signal to your body that you're shifting gears — out of clinician mode and back to being a person.",
  },
  {
    title: "Schedule a peer consultation this week",
    body: "Vicarious trauma grows in isolation. A 20-minute peer consult — even just one case — reminds you that you're not carrying this work alone. Reach out and book it today.",
  },
  {
    title: "Move your body between sessions",
    body: "Even five minutes of stretching or a walk around the block between clients resets your physiology. Somatic movement isn't a luxury — it's how you metabolize what you hold.",
  },
  {
    title: "Name what you're feeling — without fixing it",
    body: "Compassion fatigue often starts as unnamed tension. Try a one-line check-in: \"Right now I'm feeling ____.\" Naming it, without immediately solving it, is its own release.",
  },
  {
    title: "Protect one client-free lunch",
    body: "Eating while charting isn't a break — it's an extension of the work. Block 30 minutes this week with no clients and no notes. Food, daylight, and quiet count as clinical self-care.",
  },
  {
    title: "Notice the wins, however small",
    body: "Our brains are wired to fixate on the hard cases. End each week by writing down one moment of growth you witnessed — a client's insight, a risk that passed. Let it land.",
  },
  {
    title: "Set a 'no new commitments' evening",
    body: "Therapists give all day. Choose one evening a week where you give nothing — no favors, no extra tasks, no emotional labor. Replenishment is a professional obligation.",
  },
  {
    title: "Use your own crisis plan",
    body: "You teach clients to lean on coping tools — use yours. Whether it's movement, a friend, or a breath practice, the strategies you recommend are meant for you too.",
  },
  {
    title: "Take a real day off — no charting",
    body: "A day where you catch up on notes isn't a day off. Plan one full day this month with zero clinical work, and protect it the way you'd protect a client's hour.",
  },
];

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const dryRun = body && body.dry_run === true;

    const appUrl = getAppUrl(req);
    const homeUrl = appUrl ? `${appUrl}/` : "/";
    const checkinUrl = appUrl ? `${appUrl}/burnout-checkin` : "/burnout-checkin";

    // Therapists = admin or therapist role; exclude client 'user' accounts.
    const users = await base44.asServiceRole.entities.User.list("-created_date", 500) || [];
    const therapists = users.filter((u) => u.role === "admin" || u.role === "therapist");

    const tip = BURNOUT_TIPS[Math.floor(Math.random() * BURNOUT_TIPS.length)];
    const subject = `Therapist self-care: ${tip.title}`;

    if (dryRun) {
      return Response.json({ ok: true, dry_run: true, therapist_count: therapists.length, tip_title: tip.title });
    }

    let sent = 0;
    let failed = 0;
    for (const u of therapists) {
      try {
        const firstName = firstNameOf(u.full_name || u.email);
        const contentHtml = [
          para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
          para("A small, weekly reminder to take care of the person taking care of everyone else &mdash; you."),
          TIP_CARD(tip.title, tip.body),
          para("Wondering how burned out you really are this week? Take a two-minute scored check-in &mdash; based on the Copenhagen Burnout Inventory below &mdash; and WayPoint will calculate your Personal and Work burnout scores instantly and track your trend over time."),
          primaryButton("Take the weekly burnout check-in", checkinUrl),
          CBI_BLOCK(),
          therapistUplift(),
          primaryButton("Open WayPoint", homeUrl),
          para("You can't pour from an empty cup. We see how much you give &mdash; please give a little back to yourself this week.<br/><br/>Warmly,<br/>The WayPoint Team"),
        ].join("");
        const { html } = renderEmail({ recipientType: "therapist", contentHtml });
        await base44.asServiceRole.integrations.Core.SendEmail({ to: u.email, subject, body: html });
        sent++;
      } catch (e) {
        console.error(`Burnout tip to ${u.email} failed:`, e.message);
        failed++;
      }
    }

    console.log(`burnout-tips: therapists=${therapists.length} sent=${sent} failed=${failed} tip="${tip.title}"`);
    return Response.json({ ok: true, therapists: therapists.length, sent, failed, tip: tip.title });
  } catch (error) {
    console.error("burnout-tips error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}