import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para } from '../../shared/emailTemplate.js';
import { escapeHtml } from '../../shared/emailUtils.ts';

// Invoked by the "Demo Feedback Notify" workflow whenever a demo clinician
// submits the feedback survey (a DemoFeedback record is created). Emails the
// full survey results to the WayPoint team.
const NOTIFY_EMAIL = "jenthecounselor16@gmail.com";

function row(label, value) {
  if (value === null || value === undefined || value === "") return "";
  return `<p style="margin:0 0 10px 0;font-size:15px;line-height:1.6;color:#2C3E45;"><strong style="color:#1E8378;">${label}:</strong> ${value}</p>`;
}

function rating(value) {
  return value ? `${value}/5` : "—";
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const {
      participant_name, participant_email,
      overall_rating, ease_rating, nps,
      most_valuable_feature, would_use,
      worked_well, improvements, additional,
      submitted_at,
    } = body || {};

    const displayName = participant_name || participant_email || "A demo clinician";
    const subject = `New demo feedback from ${participant_name || participant_email || "a clinician"}`;

    const contentHtml = [
      para(`Hi team,`, { lead: true }),
      para(`${escapeHtml(displayName)} just submitted their WayPoint demo feedback. Here are the full results:`),
      row("Clinician", escapeHtml(participant_name || "—")),
      row("Email", escapeHtml(participant_email || "—")),
      row("Overall experience", rating(overall_rating)),
      row("Ease of getting started", rating(ease_rating)),
      row("NPS (0–10)", nps != null && nps !== "" ? nps : "—"),
      row("Most valuable feature", most_valuable_feature ? escapeHtml(most_valuable_feature) : "—"),
      row("Would use WayPoint?", would_use ? escapeHtml(would_use) : "—"),
      worked_well ? para(`<strong style="color:#1E8378;">What worked well:</strong><br/>${escapeHtml(worked_well)}`) : "",
      improvements ? para(`<strong style="color:#1E8378;">What to improve:</strong><br/>${escapeHtml(improvements)}`) : "",
      additional ? para(`<strong style="color:#1E8378;">Anything else:</strong><br/>${escapeHtml(additional)}`) : "",
      submitted_at ? para(`<span style="color:#5E7278;font-size:13px;">Submitted ${new Date(submitted_at).toLocaleString("en-US")}</span>`) : "",
      para(`Remember to mark their feedback as received on the Demo Feedback dashboard.`),
    ].join("");

    const { html } = renderEmail({ recipientType: "general", contentHtml });

    await base44.asServiceRole.integrations.Core.SendEmail({ to: NOTIFY_EMAIL, subject, body: html });
    console.log(`demo-feedback-notify: sent feedback for ${participant_email} to ${NOTIFY_EMAIL}`);
    return Response.json({ ok: true });
  } catch (error) {
    console.error("demo-feedback-notify error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}