import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

export default async function(req) {
  try {
    const body = await req.json();
    const { title, description, dueDate, clientName } = body;

    if (!dueDate) {
      return Response.json({ error: "Due date is required" }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);

    let accessToken;
    try {
      const connection = await base44.asServiceRole.connectors.getConnection("googlecalendar");
      accessToken = connection.accessToken;
    } catch (e) {
      console.error("Google Calendar not connected:", e.message);
      return Response.json({ error: "Google Calendar is not connected" }, { status: 503 });
    }

    const startDate = new Date(dueDate + "T09:00:00");
    const endDate = new Date(startDate.getTime() + 60 * 60 * 1000);

    const response = await fetch(
      "https://www.googleapis.com/calendar/v3/calendars/primary/events",
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          summary: `WayPoint Homework: ${title}`,
          description: description
            ? `${description}\n\nClient: ${clientName || "—"}`
            : `Homework assigned to ${clientName || "client"}`,
          start: {
            dateTime: startDate.toISOString(),
          },
          end: {
            dateTime: endDate.toISOString(),
          },
          reminders: {
            useDefault: true,
          },
        }),
      }
    );

    const data = await response.json();

    if (!response.ok) {
      console.error("Google Calendar API error:", JSON.stringify(data));
      return Response.json({ error: "Failed to create calendar event" }, { status: 500 });
    }

    return Response.json({ eventId: data.id, htmlLink: data.htmlLink });
  } catch (error) {
    console.error("Calendar sync error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}