import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para, primaryButton, softNote } from '../../shared/emailTemplate.js';
import { getAppUrl, firstNameOf, escapeHtml } from '../../shared/emailUtils.ts';

// Notifies a client that their therapist has assigned them an assessment to
// complete through their WayPoint portal. Invoked from the therapist's
// ClientAssessmentPanel right after the AssessmentAssignment is created.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const sr = base44.asServiceRole;
    const body = await req.json().catch(() => ({}));
    const { client_email, test_type, therapist_email, due_date } = body || {};

    if (!client_email || !test_type) {
      return Response.json({ error: "client_email and test_type are required" }, { status: 400 });
    }

    // Resolve the client's display name and the therapist's name for a warm,
    // personalized email.
    let clientName = "";
    let therapistName = "";
    try {
      const query = { client_email };
      if (therapist_email) query.therapist_email = therapist_email;
      const clients = await sr.entities.Client.filter(query, "-created_date", 10);
      const c = (clients || []).find((x) => (x.client_email || "").toLowerCase() === String(client_email).toLowerCase());
      if (c?.client_name) clientName = c.client_name;
    } catch (e) {
      console.error("resolve client name failed:", e.message);
    }
    if (therapist_email) {
      try {
        const users = await sr.entities.User.list("-created_date", 200);
        const u = (users || []).find((x) => (x.email || "").toLowerCase() === String(therapist_email).toLowerCase());
        if (u?.full_name) therapistName = u.full_name;
      } catch (e) {
        console.error("resolve therapist name failed:", e.message);
      }
    }

    const appUrl = getAppUrl(req);
    const portalUrl = appUrl ? `${appUrl}/assessments` : "/assessments";
    const firstName = firstNameOf(clientName) || "there";
    const dueLine = due_date
      ? `It would help your care team if you could complete it by <strong>${new Date(due_date).toLocaleDateString("en-US", { month: "long", day: "numeric" })}</strong>.`
      : "There&rsquo;s no firm deadline — complete it whenever you have a quiet moment.";

    const therapistLine = therapistName ? `, ${escapeHtml(therapistName)}` : "";
    const contentHtml = [
      para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
      para(`Your therapist${therapistLine} has added a brief screening tool for you to complete in WayPoint:`),
      para(`<strong>${escapeHtml(test_type)}</strong>`),
      softNote("These check-ins help you and your care team understand how you&rsquo;re doing and track your progress over time. There are no right or wrong answers &mdash; just respond honestly, based on how you&rsquo;ve been feeling recently."),
      para(dueLine),
      primaryButton("Complete your assessment", portalUrl),
      para("You can finish it anytime from your WayPoint portal. Reach out to your therapist if anything comes up for you along the way.<br/><br/>Warmly,<br/>The WayPoint Team"),
    ].join("");

    const { html } = renderEmail({ recipientType: "client", contentHtml });
    await sr.integrations.Core.SendEmail({
      to: client_email,
      subject: "A new assessment is ready for you in WayPoint",
      body: html,
    });
    return Response.json({ ok: true, sent: true });
  } catch (error) {
    console.error("assessment-assignment-notify error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}