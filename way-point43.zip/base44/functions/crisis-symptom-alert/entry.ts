import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para, alertCallout } from '../../shared/emailTemplate.js';

// Sends an immediate safety alert email to a client's therapist when:
//   1. The client creates or updates their crisis plan (alert_type: "crisis_plan")
//   2. The client logs a high-risk symptom level (alert_type: "high_risk_symptom")
//
// Invoked by entity-triggered workflows (service role, no user auth).
// Falls back to the Client record when the trigger payload has no therapist_email.

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { alert_type, client_email, therapist_email, details } = body;

    if (!alert_type) {
      return Response.json({ sent: false, reason: "alert_type required" }, { status: 400 });
    }

    const clientEmail = client_email || "";

    // Resolve the therapist to notify — prefer the submitted link, fall back to the Client record
    let therapistEmail = therapist_email || "";
    if (!therapistEmail && clientEmail) {
      try {
        const clients = await base44.asServiceRole.entities.Client.filter({ client_email: clientEmail });
        if (clients[0]?.therapist_email) therapistEmail = clients[0].therapist_email;
      } catch (e) {
        console.error("Therapist lookup failed:", e.message);
      }
    }

    if (!therapistEmail) {
      // De-identified log — the AuditLog record below captures the full details.
      console.error("Crisis/symptom alert: no therapist linked for", alert_type);
      try {
        await base44.asServiceRole.entities.AuditLog.create({
          action: "safety_alert_no_therapist",
          client_email: clientEmail,
          therapist_email: "",
          details: `${alert_type} alert — no therapist linked. ${details || ""}`,
        });
      } catch (e) {
        console.error("Audit log error:", e.message);
      }
      return Response.json({ sent: false, reason: "no_therapist" });
    }

    const isCrisis = alert_type === "crisis_plan";
    const subject = isCrisis
      ? `[WayPoint Safety Alert] ${clientEmail || "A client"} updated their crisis plan`
      : `[WayPoint Safety Alert] High-risk symptom level logged for ${clientEmail || "a client"}`;

    const leadPara = isCrisis
      ? "A client has created or updated their crisis plan in WayPoint — please review it at your next opportunity."
      : "A client has logged a high-risk symptom level in WayPoint that needs your attention.";
    const calloutBody = isCrisis
      ? `<p style="margin:0 0 4px 0;"><strong>Client:</strong> ${escapeHtml(clientEmail || "n/a")}</p><p style="margin:0;"><strong>Change:</strong> ${escapeHtml(details || "Crisis plan created or updated")}</p>`
      : `<p style="margin:0 0 4px 0;"><strong>Client:</strong> ${escapeHtml(clientEmail || "n/a")}</p><p style="margin:0;"><strong>Flagged:</strong> ${escapeHtml(details || "High-risk symptom level")}</p>`;
    const followPara = isCrisis
      ? "Please review the updated plan in the client&rsquo;s dashboard and follow up as needed. If you have immediate concerns, call or text 988 (Suicide &amp; Crisis Lifeline)."
      : "Please conduct a safety assessment and review the client&rsquo;s crisis plan promptly. If you have immediate concerns, call or text 988 (Suicide &amp; Crisis Lifeline).";

    const contentHtml = [
      para(leadPara, { lead: true }),
      alertCallout(isCrisis ? "Crisis Plan Update" : "Safety Flag", calloutBody),
      para(followPara),
      para("Log in to WayPoint to view the client&rsquo;s dashboard and full history."),
    ].join("");
    const { html } = renderEmail({ recipientType: "therapist", contentHtml });

    try {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: therapistEmail,
        subject,
        body: html,
      });
    } catch (e) {
      console.error("SendEmail failed:", e.message);
      return Response.json({ sent: false, reason: "email_failed", error: e.message }, { status: 502 });
    }

    try {
      await base44.asServiceRole.entities.AuditLog.create({
        action: isCrisis ? "crisis_plan_alert_sent" : "high_risk_symptom_alert_sent",
        client_email: clientEmail,
        therapist_email: therapistEmail,
        details: `${alert_type} alert. ${details || ""}`,
      });
    } catch (e) {
      console.error("Audit log error:", e.message);
    }

    console.log("Safety alert sent to", therapistEmail, "for", alert_type);
    return Response.json({ sent: true, alert_type, therapist_email: therapistEmail });
  } catch (error) {
    console.error("Crisis/symptom alert error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

function escapeHtml(s) {
  return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}