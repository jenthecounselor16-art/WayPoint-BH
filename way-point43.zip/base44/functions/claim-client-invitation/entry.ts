import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { linkClientRecords } from '../../shared/linkClientRecords.ts';

// Called after a client completes registration. Marks their invitation as
// claimed (so it can't be reused) and ensures a Client link exists to the
// inviting therapist. Requires an authenticated user whose email matches the
// invitation. Idempotent against Wix-style redelivers.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const invitationId = body.invitation_id;
    if (!invitationId) return Response.json({ error: 'missing invitation_id' }, { status: 400 });

    const inv = await base44.asServiceRole.entities.ClientInvitation.get(invitationId);
    if (!inv) return Response.json({ error: 'Invitation not found' }, { status: 404 });

    if ((inv.client_email || '').toLowerCase() !== (user.email || '').toLowerCase()) {
      return Response.json({ error: 'Email mismatch' }, { status: 403 });
    }

    if (inv.status !== 'claimed') {
      await base44.asServiceRole.entities.ClientInvitation.update(invitationId, { status: 'claimed' });
    }

    const existing = await base44.asServiceRole.entities.Client.filter(
      { client_email: inv.client_email, therapist_email: inv.therapist_email }, '-created_date', 5
    );
    if (!existing || existing.length === 0) {
      await base44.asServiceRole.entities.Client.create({
        client_email: inv.client_email,
        client_name: inv.client_name,
        therapist_email: inv.therapist_email,
      });
    }

    // Carry the client's full pre-existing history over to the therapist the
    // moment they claim their invitation, so nothing recorded before the
    // invite (or before the link existed) is hidden from the therapist's view.
    let backfill = null;
    try {
      backfill = await linkClientRecords(base44.asServiceRole, inv.client_email, inv.therapist_email);
    } catch (e) {
      console.error('claim-client-invitation: backfill failed', e);
    }

    return Response.json({ ok: true, therapist_email: inv.therapist_email, linked: backfill });
  } catch (error) {
    console.error('claim-client-invitation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}