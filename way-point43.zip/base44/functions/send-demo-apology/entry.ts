import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para, primaryButton, therapistUplift } from '../../shared/emailTemplate.js';
import { firstNameOf, escapeHtml } from '../../shared/emailUtils.ts';
import { encodeHeader, utf8Base64, wrap76 } from '../../shared/gmailSend.ts';

// Sends a branded (logo banner) apology email to every ACTIVE demo participant,
// re-linking them to the demo, with jenthecounselor16@gmail.com CC'd on every
// message. Uses the connected Gmail connector so delivery reaches any address
// (registered or not). Supports a `dryRun` payload to preview recipients + the
// resolved demo link without sending.

const CC_EMAIL = "jenthecounselor16@gmail.com";
const SUBJECT = "We're sorry — your WayPoint demo is ready for you";

function b64Url(bytes) {
  return btoa(String.fromCharCode(...bytes))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

function buildMime(fromEmail, toEmail, ccEmail, subject, textBody, htmlBody) {
  const mime = [
    `From: ${fromEmail}`,
    `To: ${toEmail}`,
    `Cc: ${ccEmail}`,
    `Subject: ${encodeHeader(subject)}`,
    "MIME-Version: 1.0",
    'Content-Type: multipart/alternative; boundary="wpboundary"',
    "",
    "--wpboundary",
    "Content-Type: text/plain; charset=UTF-8",
    "Content-Transfer-Encoding: base64",
    "",
    wrap76(utf8Base64(textBody)),
    "",
    "--wpboundary",
    "Content-Type: text/html; charset=UTF-8",
    "Content-Transfer-Encoding: base64",
    "",
    wrap76(utf8Base64(htmlBody)),
    "",
    "--wpboundary--",
    "",
  ].join("\r\n");
  return b64Url(new TextEncoder().encode(mime));
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const sr = base44.asServiceRole;
    const body = await req.json().catch(() => ({}));

    const appUrl =
      (body.appUrl && String(body.appUrl).replace(/\/$/, "")) ||
      (req.headers.get("X-Base44-App-Url") || "").replace(/\/$/, "");

    const all = await sr.entities.DemoParticipant.list("-created_date", 200);
    const participants = (all || []).filter((p) => p.status === "active" && p.email);

    if (body.dryRun) {
      return Response.json({
        dryRun: true,
        appUrl: appUrl || null,
        demoUrl: appUrl ? `${appUrl}/demo` : null,
        activeCount: participants.length,
        participants: participants.map((p) => ({ name: p.name, email: p.email, seat_number: p.seat_number })),
      });
    }

    if (!appUrl) {
      return Response.json({ error: "Unable to determine app URL", activeCount: participants.length }, { status: 400 });
    }

    const demoUrl = `${appUrl}/demo`;

    const conn = await sr.connectors.getConnection("gmail");
    const token = conn?.accessToken;
    if (!token) {
      return Response.json({ error: "Gmail connector not connected", activeCount: participants.length }, { status: 500 });
    }

    const tokenInfoRes = await fetch(`https://oauth2.googleapis.com/tokeninfo?access_token=${token}`);
    if (!tokenInfoRes.ok) {
      return Response.json({ error: `Gmail tokeninfo failed: ${tokenInfoRes.status}`, activeCount: participants.length }, { status: 500 });
    }
    const info = await tokenInfoRes.json();
    const fromEmail = info.email;
    if (!fromEmail) {
      return Response.json({ error: "Gmail token returned no email", activeCount: participants.length }, { status: 500 });
    }

    let sent = 0;
    let failed = 0;
    const failures = [];

    for (const p of participants) {
      try {
        const firstName = firstNameOf(p.name, p.email);
        const contentHtml = [
          para(`Hi ${escapeHtml(firstName)},`, { lead: true, bold: true }),
          para("We owe you an apology. Some clinicians in our 7-day demo ran into a technical hiccup that briefly blocked access to the portal &mdash; and if that interrupted your experience, we are genuinely sorry."),
          para("The good news: it&rsquo;s fixed. Your demo is fully active, and your clinician experience &mdash; client dashboards, evidence-based assessments, clinical insights, and progress reports &mdash; is ready and waiting for you."),
          para("Your seat is still yours. Tap below to pick right back up where you left off."),
          primaryButton("Return to your demo", demoUrl),
          para("Thank you for your patience, and for the care you bring to your clients every day. We&rsquo;re honored to support your work."),
          therapistUplift(),
          para("Warmly,<br/>The WayPoint Team"),
        ].join("");

        const { html, text } = renderEmail({ recipientType: "general", contentHtml });

        const raw = buildMime(fromEmail, p.email, CC_EMAIL, SUBJECT, text, html);

        const sendRes = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
          method: "POST",
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ raw }),
        });

        if (sendRes.ok) {
          sent++;
        } else {
          failed++;
          const errText = await sendRes.text();
          failures.push({ email: p.email, status: sendRes.status, error: errText });
          console.error(`Gmail send failed for ${p.email}:`, sendRes.status, errText);
        }
      } catch (e) {
        failed++;
        failures.push({ email: p.email, error: e.message });
        console.error(`Send error for ${p.email}:`, e.message);
      }
    }

    console.log(`Demo apology: sent=${sent}, failed=${failed}, appUrl=${appUrl}, cc=${CC_EMAIL}`);
    return Response.json({
      ok: true,
      appUrl,
      demoUrl,
      fromEmail,
      cc: CC_EMAIL,
      activeCount: participants.length,
      sent,
      failed,
      failures,
    });
  } catch (error) {
    console.error("send-demo-apology error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});