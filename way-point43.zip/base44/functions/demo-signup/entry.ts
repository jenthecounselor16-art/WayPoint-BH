import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { encodeHeader, utf8Base64, wrap76 } from '../../shared/gmailSend.ts';

const SEAT_LIMIT = 100;
const DEMO_DAYS = 7;

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { name, email, license } = body || {};

    if (!name || !email) {
      return Response.json({ error: "Name and email are required" }, { status: 400 });
    }

    // --- Anti-bot guard --------------------------------------------------
    // Honeypot: a hidden field humans never fill. Reject silently.
    if (body.website) {
      console.warn("Demo signup blocked: honeypot triggered", email);
      return Response.json({ error: "Submission could not be verified. Please refresh and try again." }, { status: 403 });
    }
    // Arithmetic verification: the form shows "a + b = ?". The bot that hit us
    // only posts name/email/license, so it fails this check.
    const a = Number(body.a), b = Number(body.b), ans = Number(body.verify);
    if (!Number.isFinite(a) || !Number.isFinite(b) || !Number.isFinite(ans) || ans !== a + b) {
      return Response.json({ error: "Please complete the quick-check question at the bottom of the form." }, { status: 400 });
    }
    // Minimum fill time: real humans take a few seconds; scripts post instantly.
    const t0 = Number(body.t0);
    if (!Number.isFinite(t0) || Date.now() - t0 < 4000) {
      return Response.json({ error: "Whoa, that was fast! Please take a moment to review the form and try again." }, { status: 400 });
    }
    // Block obvious test / non-clinician email domains.
    const emailLower = email.toLowerCase();
    if (emailLower.endsWith("@example.com") || emailLower.endsWith("@example.org") || emailLower.endsWith("@test.com")) {
      return Response.json({ error: "Please use a valid work email address." }, { status: 400 });
    }

    const all = await base44.asServiceRole.entities.DemoParticipant.list("-created_date", 200);

    // Burst brake: refuse if 3+ signups arrived in the last 15 minutes so a
    // scripted burst can't exhaust the seats.
    const cutoff = Date.now() - 15 * 60 * 1000;
    const recentCount = (all || []).filter((p) => new Date(p.created_date).getTime() >= cutoff).length;
    if (recentCount >= 3) {
      return Response.json({ error: "We're receiving a lot of demo requests right now. Please try again in a few minutes." }, { status: 429 });
    }

    if (all.some((p) => (p.email || "").toLowerCase() === email.toLowerCase())) {
      return Response.json({ error: "This email is already registered for the demo." }, { status: 409 });
    }
    if (all.length >= SEAT_LIMIT) {
      return Response.json({ error: "All 100 demo seats are full. Thank you for your interest!" }, { status: 409 });
    }

    const startedAt = new Date();
    const expiresAt = new Date(startedAt.getTime() + DEMO_DAYS * 24 * 60 * 60 * 1000);

    const participant = await base44.asServiceRole.entities.DemoParticipant.create({
      name,
      email,
      license: license || "",
      seat_number: all.length + 1,
      started_at: startedAt.toISOString(),
      expires_at: expiresAt.toISOString(),
      status: "active",
    });

    // Best-effort: invite the clinician as an app user so they can register and
    // access the demo. (Platform roles are "user" / "admin" only — this app
    // grants therapist functionality to every registered clinician.)
    let invited = false;
    let inviteError = "";
    try {
      await base44.users.inviteUser(email, "user");
      invited = true;
    } catch (e) {
      inviteError = e.message || String(e);
      console.error("Invite failed:", inviteError);
    }

    // Best-effort: if a User record already exists for this email (an admin
    // triggered the invite, or they've already registered), grant the therapist
    // role now. The "Grant Demo Therapist Role" workflow is the backstop that
    // grants it automatically when they register later. inviteUser cannot set
    // custom roles, so the role is applied directly on the User entity here.
    let roleGranted = false;
    try {
      const users = await base44.asServiceRole.entities.User.list("-created_date", 200);
      const u = (users || []).find((x) => (x.email || "").toLowerCase() === email.toLowerCase());
      if (u) {
        try { await base44.asServiceRole.entities.User.update(u.id, { account_type: "therapist" }); } catch (e) { console.error("set account_type failed:", e.message); }
        try { await base44.asServiceRole.entities.User.update(u.id, { role: "therapist" }); roleGranted = true; } catch (e) { console.error("set role failed:", e.message); }
      }
    } catch (e) {
      console.error("Role grant lookup failed:", e.message);
    }

    // Notify the admin team (and invite manually if auto-invite failed)
    let notified = 0;
    try {
      const users = await base44.asServiceRole.entities.User.list("-created_date", 200);
      let admins = (users || [])
        .filter((u) => u.role === "admin")
        .map((u) => u.email)
        .filter(Boolean);
      // Route every demo request to jenthecounselor16@gmail.com.
      const DEMO_REQUEST_EMAIL = "jenthecounselor16@gmail.com";
      if (!admins.some((e) => e.toLowerCase() === DEMO_REQUEST_EMAIL.toLowerCase())) {
        admins.push(DEMO_REQUEST_EMAIL);
      }

      const subject = `[WayPoint Demo] New demo signup — ${name} (seat ${participant.seat_number})`;
      const bodyText = [
        "A clinician signed up for the 7-day demo.",
        "",
        `Name: ${name}`,
        `Email: ${email}`,
        `License: ${license || "—"}`,
        `Seat: ${participant.seat_number} of ${SEAT_LIMIT}`,
        `Demo expires: ${expiresAt.toLocaleDateString()}`,
        `Invited automatically: ${invited ? "yes" : "no"}`,
        invited ? "" : `Auto-invite failed (${inviteError}) — invite ${email} manually as a user.`,
        `Therapist role granted automatically: ${roleGranted ? "yes" : "no (will grant automatically on registration)"}`,
        "",
        "No incentive is attached — their honest feedback is requested automatically on day 7.",
      ].join("\n");

      for (const to of admins) {
        try {
          await base44.asServiceRole.integrations.Core.SendEmail({ to, subject, body: bodyText });
          notified++;
        } catch (e) {
          console.error(`Notify ${to} failed:`, e.message);
        }
      }
    } catch (e) {
      console.error("Admin notify failed:", e.message);
    }

    // Best-effort: send a Gmail notification to the builder's connected account
    let gmailSent = false;
    let gmailStatus = "init";
    try {
      const conn = await base44.asServiceRole.connectors.getConnection("gmail");
      const token = conn?.accessToken;
      if (!token) {
        gmailStatus = "no_token";
        console.error("Gmail connector not connected — skipping Gmail notification");
      } else {
        gmailStatus = "have_token";
        const tokenInfoRes = await fetch(`https://oauth2.googleapis.com/tokeninfo?access_token=${token}`);
        if (!tokenInfoRes.ok) {
          gmailStatus = `tokeninfo_${tokenInfoRes.status}`;
          console.error("Gmail tokeninfo failed:", tokenInfoRes.status, await tokenInfoRes.text());
        } else {
          const info = await tokenInfoRes.json();
          const to = info.email;
          if (!to) {
            gmailStatus = "no_email";
            console.error("Gmail tokeninfo returned no email");
          } else {
            gmailStatus = `sending_to_${to}`;
            const subject = `[WayPoint Demo] New demo signup — ${name} (seat ${participant.seat_number})`;
            const text = [
              "A clinician signed up for the 7-day demo.",
              "",
              `Name: ${name}`,
              `Email: ${email}`,
              `License: ${license || "—"}`,
              `Seat: ${participant.seat_number} of ${SEAT_LIMIT}`,
              `Demo expires: ${expiresAt.toLocaleDateString()}`,
              `Invited automatically: ${invited ? "yes" : "no"}`,
              "",
              "Sent via your connected Gmail account.",
            ].join("\n");

            const mimeMessage = [
              `From: ${to}`,
              `To: ${to}`,
              `Subject: ${encodeHeader(subject)}`,
              "MIME-Version: 1.0",
              "Content-Type: text/plain; charset=UTF-8",
              "Content-Transfer-Encoding: base64",
              "",
              wrap76(utf8Base64(text)),
            ].join("\r\n");

            const bytes = new TextEncoder().encode(mimeMessage);
            const raw = btoa(String.fromCharCode(...bytes))
              .replace(/\+/g, "-")
              .replace(/\//g, "_")
              .replace(/=+$/, "");

            const sendRes = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
              method: "POST",
              headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
              body: JSON.stringify({ raw }),
            });
            if (sendRes.ok) {
              gmailSent = true;
              console.log(`Gmail signup notification sent to ${to}`);
            } else {
              console.error("Gmail send failed:", sendRes.status, await sendRes.text());
            }
          }
        }
      }
    } catch (e) {
      console.error("Gmail notify failed:", e.message);
    }

    console.log(`Demo signup: ${email} seat ${participant.seat_number}, invited=${invited}, role_granted=${roleGranted}, admins notified=${notified}, gmail=${gmailSent}`);
    return Response.json({
      ok: true,
      seat_number: participant.seat_number,
      expires_at: expiresAt.toISOString(),
      invited,
      role_granted: roleGranted,
      notified,
      gmail_sent: gmailSent,
    });
  } catch (error) {
    console.error("Demo signup error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}