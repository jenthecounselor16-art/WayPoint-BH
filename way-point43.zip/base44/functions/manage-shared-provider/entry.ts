import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para } from '../../shared/emailTemplate.js';
import { escapeHtml } from '../../shared/emailUtils.ts';
import { syncSharedCare } from '../../shared/sharedCare.ts';

const APP_URL = 'https://way-point43.base44.app';

// Shared care: adds or removes a co-treating provider (possibly at another
// practice) from a client's care team. Only the client's primary therapist
// (or an admin) may manage the team. The Client record's
// `shared_therapist_emails` is the durable source of truth; both providers'
// user-level `shared_client_emails` lists are re-synced immediately so RLS
// picks up the change — including for a co-provider who registers later (the
// Shared Care Sync workflow re-syncs on their first login).
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user?.email) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    let body = {};
    try { body = await req.json(); } catch {}
    const action = body.action === 'remove' ? 'remove' : 'add';
    const clientEmail = String(body.client_email || '').trim().toLowerCase();
    const providerEmail = String(body.provider_email || '').trim().toLowerCase();
    if (!clientEmail || !providerEmail) {
      return Response.json({ error: 'client_email and provider_email are required' }, { status: 400 });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(providerEmail)) {
      return Response.json({ error: 'Please enter a valid provider email address' }, { status: 400 });
    }

    const clients = await base44.asServiceRole.entities.Client.filter({ client_email: clientEmail }, '-created_date', 20);
    const client = (clients || []).find((c) => c.client_email);
    if (!client) return Response.json({ error: 'Client not found' }, { status: 404 });

    const callerEmail = String(user.email).toLowerCase();
    const primaryEmail = String(client.therapist_email || '').toLowerCase();
    if (primaryEmail !== callerEmail && user.role !== 'admin') {
      return Response.json({ error: "Only the primary therapist can manage this client's care team" }, { status: 403 });
    }
    if (providerEmail === primaryEmail) {
      return Response.json({ error: "That provider is already this client's primary therapist" }, { status: 400 });
    }
    if (providerEmail === clientEmail) {
      return Response.json({ error: "The client can't be added to their own care team" }, { status: 400 });
    }

    const team = (client.shared_therapist_emails || []).map((e) => String(e).toLowerCase());
    if ((action === 'add' && team.includes(providerEmail)) || (action === 'remove' && !team.includes(providerEmail))) {
      return Response.json({ ok: true, already: true, shared_therapist_emails: team });
    }

    const updatedTeam = action === 'add' ? [...team, providerEmail] : team.filter((e) => e !== providerEmail);
    await base44.asServiceRole.entities.Client.update(client.id, { shared_therapist_emails: updatedTeam });

    // Refresh both providers' user-level lists so RLS reflects the change now.
    const providerSync = await syncSharedCare(base44.asServiceRole, providerEmail)
      .catch((e) => ({ error: e?.message || String(e) }));
    const ownerSync = await syncSharedCare(base44.asServiceRole, callerEmail)
      .catch((e) => ({ error: e?.message || String(e) }));

    // Best-effort notification to the co-provider (may not be a registered
    // user yet — email providers may refuse; that's non-blocking).
    if (action === 'add') {
      try {
        const clientName = client.client_name || clientEmail;
        const contentHtml = [
          para(`You've been added to a client's shared care team on WayPoint.`, { lead: true }),
          para(
            `<strong>Client:</strong> ${escapeHtml(clientName)}<br/>` +
            `<strong>Shared by:</strong> ${escapeHtml(user.full_name || callerEmail)}`
          ),
          para(
            `Shared care lets co-treating clinicians at different practices view the same client's account — assessments, goals, homework, and progress — and contribute by assigning homework and goals. Each provider's clinical notes stay private to their author.`
          ),
          para(`Sign in at ${APP_URL} and open your Therapist Portal to see ${escapeHtml(clientName)} in your client list.`),
        ].join('');
        const { html } = renderEmail({ recipientType: 'general', contentHtml });
        await base44.asServiceRole.integrations.Core.SendEmail({
          to: providerEmail,
          subject: `Shared care access on WayPoint — ${clientName}`,
          body: html,
        });
      } catch (e) {
        console.error(`Shared-care notify to ${providerEmail} failed:`, e.message);
      }
    }

    return Response.json({ ok: true, action, shared_therapist_emails: updatedTeam });
  } catch (error) {
    console.error('manage-shared-provider error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}