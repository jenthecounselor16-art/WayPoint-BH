import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para, primaryButton, therapistUplift } from '../../shared/emailTemplate.js';
import { getAppUrl, firstNameOf, escapeHtml } from '../../shared/emailUtils.ts';
import { filterTherapists, groupClientsByTherapist, avg, fmtAvg, statPill } from '../../shared/clientReportUtils.ts';

// Invoked monthly by the "Monthly Clinical Report" workflow.
// For each therapist, emails a branded per-client clinical summary + progress
// report (assessment change, nervous-system trends, goals, functional
// impairment) with a one-click link to the full PDF report.

const DAY = 24 * 60 * 60 * 1000;
const MONTH_MS = 30 * DAY;

const TEAL = "#26A69A";
const TEAL_DARK = "#1E8378";
const INK = "#2C3E45";
const MUTED = "#5E7278";
const SOFT_BG = "#F2F7F6";
const CARD_BORDER = "#EAF1F0";

// Functional-impairment negative items (mirrors src/lib/functionalImpairment.js)
const NEGATIVE_KEYS = [
  "sleep_hygiene", "eating_habits", "napping", "alcohol_use", "drug_use",
  "neglecting_chores", "neglecting_self_care", "isolation", "self_harm",
  "medication_nonadherence",
];
const MAX_IMPAIRMENT = NEGATIVE_KEYS.length * 4; // 40



// Latest + first assessment score per test type (severity is stored on the record)
function summarizeAssessments(results) {
  const latest = {}, first = {};
  (results || []).forEach((r) => {
    const t = r.created_date ? new Date(r.created_date).getTime() : 0;
    if (!latest[r.test_type] || t > new Date(latest[r.test_type].created_date).getTime()) latest[r.test_type] = r;
    if (!first[r.test_type] || t < new Date(first[r.test_type].created_date).getTime()) first[r.test_type] = r;
  });
  return Object.keys(latest).map((type) => {
    const l = latest[type];
    const f = first[type];
    const change = f && f.id !== l.id ? l.score - f.score : null;
    return { type, score: l.score, severity: l.severity || "—", date: l.created_date, change };
  }).sort((a, b) => new Date(b.date) - new Date(a.date));
}

function assessmentTable(rows) {
  if (!rows.length) return `<p style="margin:0;font-size:13px;color:${MUTED};font-style:italic;">No assessments on record.</p>`;
  const head = `<tr style="background:${SOFT_BG};">
    <th style="text-align:left;padding:7px 10px;font-size:11px;letter-spacing:.05em;text-transform:uppercase;color:${TEAL_DARK};">Assessment</th>
    <th style="text-align:center;padding:7px 10px;font-size:11px;letter-spacing:.05em;text-transform:uppercase;color:${TEAL_DARK};">Initial</th>
    <th style="text-align:center;padding:7px 10px;font-size:11px;letter-spacing:.05em;text-transform:uppercase;color:${TEAL_DARK};">Latest</th>
    <th style="text-align:center;padding:7px 10px;font-size:11px;letter-spacing:.05em;text-transform:uppercase;color:${TEAL_DARK};">Change</th>
    <th style="text-align:left;padding:7px 10px;font-size:11px;letter-spacing:.05em;text-transform:uppercase;color:${TEAL_DARK};">Severity</th>
  </tr>`;
  const body = rows.map((r) => {
    const chg = r.change === null ? "—" : (r.change > 0 ? `+${r.change}` : `${r.change}`);
    const initial = r.change === null ? "—" : String(r.score - r.change);
    return `<tr style="border-top:1px solid ${CARD_BORDER};">
      <td style="padding:7px 10px;font-size:13px;font-weight:700;color:${INK};">${escapeHtml(r.type)}</td>
      <td style="padding:7px 10px;font-size:13px;text-align:center;color:${MUTED};">${escapeHtml(initial)}</td>
      <td style="padding:7px 10px;font-size:13px;text-align:center;font-weight:700;color:${INK};">${escapeHtml(String(r.score))}</td>
      <td style="padding:7px 10px;font-size:13px;text-align:center;color:${MUTED};">${escapeHtml(chg)}</td>
      <td style="padding:7px 10px;font-size:13px;color:${MUTED};">${escapeHtml(r.severity)}</td>
    </tr>`;
  }).join("");
  return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid ${CARD_BORDER};border-radius:8px;overflow:hidden;border-collapse:collapse;">${head}${body}</table>`;
}

function clientSection(name, email, assessments, nervous, goals, impairments, reportUrl) {
  const now = Date.now();
  const recent = (nervous || []).filter((n) => now - new Date(n.created_date).getTime() <= MONTH_MS);
  const checkIns = recent.length;
  const aAnx = avg(recent, "anxiety_level");
  const aDep = avg(recent, "depression_level");
  const aStr = avg(recent, "stress_level");
  const aEng = avg(recent, "energy_level");

  const goalsActive = (goals || []).filter((g) => g.status !== "achieved").length;
  const goalsAchieved = (goals || []).filter((g) => g.status === "achieved").length;

  const latestImp = (impairments || [])[0];
  let impPct = null;
  if (latestImp) {
    const score = NEGATIVE_KEYS.reduce((s, k) => s + (latestImp[k] || 0), 0);
    impPct = Math.round((score / MAX_IMPAIRMENT) * 100);
  }

  const assRows = summarizeAssessments(assessments);
  const top = assRows[0];

  const bits = [];
  if (checkIns > 0) bits.push(`${checkIns} nervous-system check-in${checkIns === 1 ? "" : "s"} in the past 30 days`);
  else bits.push("no nervous-system check-ins in the past 30 days");
  if (top) {
    const changeTxt = top.change !== null ? `, ${top.change > 0 ? "+" : ""}${top.change} from initial` : "";
    bits.push(`most recent assessment ${top.type} (${top.severity}, score ${top.score}${changeTxt})`);
  }
  if (impPct !== null) bits.push(`functional impairment at ${impPct}%`);
  if (goalsActive + goalsAchieved > 0) bits.push(`${goalsAchieved} of ${goalsActive + goalsAchieved} goals achieved`);
  const narrative = bits.length ? bits.join("; ").replace(/^./, (c) => c.toUpperCase()) + "." : "Limited data on record for this client this month.";

  const pills = [
    statPill("Check-ins (30d)", checkIns),
    statPill("Avg anxiety", fmtAvg(aAnx, "/10")),
    statPill("Avg depression", fmtAvg(aDep, "/10")),
    statPill("Avg stress", fmtAvg(aStr, "/10")),
    statPill("Avg energy", fmtAvg(aEng, "/10")),
    statPill("Goals", goalsActive + goalsAchieved > 0 ? `${goalsAchieved}/${goalsActive + goalsAchieved}` : "—"),
    statPill("Impairment", impPct !== null ? `${impPct}%` : "—"),
  ].join("");

  return `
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 18px 0;border:1px solid ${CARD_BORDER};border-radius:10px;overflow:hidden;">
    <tr>
      <td style="background:${SOFT_BG};padding:12px 16px;border-bottom:1px solid ${CARD_BORDER};">
        <p style="margin:0;font-size:16px;font-weight:700;color:${INK};font-family:Georgia,'Hoefler Text',serif;">${escapeHtml(name)}</p>
        <p style="margin:2px 0 0 0;font-size:13px;color:${MUTED};">${escapeHtml(email)}</p>
      </td>
    </tr>
    <tr>
      <td style="padding:14px 16px;">
        <p style="margin:0 0 10px 0;font-size:14px;line-height:1.6;color:${INK};">${escapeHtml(narrative)}</p>
        <p style="margin:0 0 8px 0;font-size:12px;letter-spacing:.06em;text-transform:uppercase;font-weight:700;color:${TEAL_DARK};">Snapshot</p>
        <div style="margin:0 0 14px 0;">${pills}</div>
        <p style="margin:0 0 8px 0;font-size:12px;letter-spacing:.06em;text-transform:uppercase;font-weight:700;color:${TEAL_DARK};">Assessment progress</p>
        ${assessmentTable(assRows)}
        <table role="presentation" cellpadding="0" cellspacing="0" style="margin-top:14px;">
          <tr><td style="border-radius:8px;background:${TEAL};">
            <a href="${escapeHtml(reportUrl)}" style="display:inline-block;padding:10px 20px;font-family:Georgia,'Hoefler Text',serif;font-size:14px;color:#ffffff;text-decoration:none;border-radius:8px;">Open full PDF report &rarr;</a>
          </td></tr>
        </table>
      </td>
    </tr>
  </table>`;
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const dryRun = body && body.dry_run === true;

    const appUrl = getAppUrl(req);

    const [users, clients, assessments, nervous, goals, impairments] = await Promise.all([
      base44.asServiceRole.entities.User.list("-created_date", 500),
      base44.asServiceRole.entities.Client.list("-created_date", 1000),
      base44.asServiceRole.entities.AssessmentResult.list("-created_date", 1000),
      base44.asServiceRole.entities.NervousSystemMetric.list("-created_date", 1000),
      base44.asServiceRole.entities.TherapyGoal.list("-created_date", 1000),
      base44.asServiceRole.entities.FunctionalImpairment.list("-created_date", 1000),
    ]);

    const byClient = (arr) => {
      const m = {};
      (arr || []).forEach((r) => {
        if (!r.client_email) return;
        (m[r.client_email] = m[r.client_email] || []).push(r);
      });
      return m;
    };
    const assBy = byClient(assessments);
    const nsBy = byClient(nervous);
    const goalsBy = byClient(goals);
    const impBy = byClient(impairments);

    const clientsByTherapist = groupClientsByTherapist(clients);
    const therapists = filterTherapists(users);

    if (dryRun) {
      const summary = therapists.map((t) => ({ therapist: t.email, clients: (clientsByTherapist[t.email] || []).length }));
      return Response.json({ ok: true, dry_run: true, therapist_count: therapists.length, summary });
    }

    let sent = 0, failed = 0;
    const monthLabel = new Date().toLocaleDateString("en-US", { month: "long" });

    for (const t of therapists) {
      const myClients = clientsByTherapist[t.email] || [];
      if (!myClients.length) continue;

      const sections = myClients.map((c) => {
        const reportUrl = appUrl
          ? `${appUrl}/report/${encodeURIComponent(c.client_email)}?name=${encodeURIComponent(c.client_name || "")}`
          : `/report/${encodeURIComponent(c.client_email)}`;
        return clientSection(
          c.client_name || c.client_email,
          c.client_email,
          assBy[c.client_email] || [],
          nsBy[c.client_email] || [],
          goalsBy[c.client_email] || [],
          impBy[c.client_email] || [],
          reportUrl
        );
      }).join("");

      const firstName = firstNameOf(t.full_name || t.email);
      const subject = `Your monthly client clinical report — ${monthLabel}`;
      const portalUrl = appUrl ? `${appUrl}/therapist` : "/therapist";
      const contentHtml = [
        para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
        para(`Here&rsquo;s your monthly clinical snapshot for each of your active clients in WayPoint. Every section summarizes their latest assessment progress, nervous-system trends, goals, and functional impairment &mdash; with a one-click link to the full PDF report.`),
        sections,
        therapistUplift(),
        primaryButton("Open your therapist portal", portalUrl),
        para("Review these trends between sessions to celebrate progress and flag where extra support may help.<br/><br/>Warmly,<br/>The WayPoint Team"),
      ].join("");

      try {
        const { html } = renderEmail({ recipientType: "therapist", contentHtml });
        await base44.asServiceRole.integrations.Core.SendEmail({ to: t.email, subject, body: html });
        sent++;
      } catch (e) {
        console.error(`Monthly report to ${t.email} failed:`, e.message);
        failed++;
      }
    }

    console.log(`monthly-clinical-report: therapists=${therapists.length} sent=${sent} failed=${failed}`);
    return Response.json({ ok: true, therapists: therapists.length, sent, failed });
  } catch (error) {
    console.error("monthly-clinical-report error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}