import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';
import { renderEmail, para, primaryButton, softNote } from '../../shared/emailTemplate.js';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const sr = base44.asServiceRole;
    const appUrl = (req.headers.get("X-Base44-App-Url") || "").replace(/\/$/, "");
    const homeworkUrl = appUrl ? `${appUrl}/homework` : "/homework";

    const assignments = await sr.entities.HomeworkAssignment.filter(
      { status: "assigned", reminder_sent: false },
      "-created_date",
      500
    );

    const now = new Date();
    const twentyFourHoursFromNow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    let alertsSent = 0;

    for (const hw of assignments) {
      if (!hw.due_date) continue;

      const dueDate = new Date(hw.due_date);
      const isDueSoon = dueDate >= now && dueDate <= twentyFourHoursFromNow;
      const isOverdue = dueDate < now;

      if (!isDueSoon && !isOverdue) continue;

      if (hw.client_email) {
        try {
          const firstName = (hw.client_name || "").split(" ")[0] || "there";
          const dueStr = dueDate.toLocaleDateString("en-US", { month: "long", day: "numeric" });
          const reminderLine = isOverdue
            ? `Your practice <strong>${escapeHtml(hw.title)}</strong> was due on <strong>${dueStr}</strong> and is still waiting for you.`
            : `Your practice <strong>${escapeHtml(hw.title)}</strong> is coming up on <strong>${dueStr}</strong>.`;
          const nudge = isOverdue
            ? "That&rsquo;s okay — progress isn&rsquo;t about being perfect. Whenever you&rsquo;re ready, you can pick it right back up."
            : "A few minutes a day goes a long way. There&rsquo;s no pressure — just a gentle nudge to keep you on track.";

          const contentHtml = [
            para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
            para("A gentle reminder from your WayPoint toolkit —"),
            para(reminderLine),
            softNote(nudge),
            primaryButton("Open WayPoint", homeworkUrl),
            para("Your therapist is in your corner. Take your time, and reach out if anything comes up."),
            para("Warmly,<br/>The WayPoint Team"),
          ].join("");

          const { html } = renderEmail({ recipientType: "client", contentHtml });

          await sr.integrations.Core.SendEmail({
            to: hw.client_email,
            subject: isOverdue
              ? `A gentle nudge: "${hw.title}"`
              : `Coming up soon: "${hw.title}"`,
            body: html,
          });
        } catch (e) {
          console.error("Failed to email client homework reminder:", e.message);
        }
      }

      try {
        await sr.entities.HomeworkAssignment.update(hw.id, { reminder_sent: true });
        alertsSent++;
      } catch (e) {
        console.error(`Failed to mark reminder_sent for ${hw.id}:`, e.message);
      }
    }

    return Response.json({ success: true, checked: assignments.length, alertsSent });
  } catch (error) {
    console.error("Homework alerts error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function escapeHtml(s) {
  return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}