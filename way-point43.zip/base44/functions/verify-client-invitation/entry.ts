import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

// Public (pre-registration) verification: confirms that a client's entered
// email, full name, date of birth, and state match a pending therapist
// invitation. Clients can only register when a match exists. Runs as service
// role because the caller is not yet authenticated. The name+DOB+state trio is
// the gating secret, so only a matching caller receives the therapist email.
const norm = (s) => (s == null ? '' : String(s).trim().toLowerCase());
const normDate = (s) => (s ? String(s).slice(0, 10) : '');

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const clientEmail = norm(body.client_email);
    const clientName = norm(body.client_name);
    const dob = normDate(body.date_of_birth);
    const state = norm(body.state);
    if (!clientEmail || !clientName || !dob || !state) {
      return Response.json({ valid: false, reason: 'missing_fields' }, { status: 400 });
    }

    const invitations = await base44.asServiceRole.entities.ClientInvitation.filter(
      { client_email: clientEmail }, '-created_date', 20
    );

    const match = (invitations || []).find((inv) =>
      inv.status === 'pending' &&
      norm(inv.client_name) === clientName &&
      normDate(inv.date_of_birth) === dob &&
      norm(inv.state) === state
    );

    if (!match) {
      return Response.json({ valid: false });
    }
    return Response.json({
      valid: true,
      invitation_id: match.id,
      therapist_email: match.therapist_email,
      therapist_name: match.therapist_name,
    });
  } catch (error) {
    console.error('verify-client-invitation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}