import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para, primaryButton, softNote, therapistUplift } from '../../shared/emailTemplate.js';
import { getAppUrl, firstNameOf, escapeHtml } from '../../shared/emailUtils.ts';

// Invoked from the client whenever checkAndAwardBadges() awards new badges.
// Sends a celebratory, branded email to the client (and a heads-up to their
// therapist when one is linked), so clients feel motivated and recognized.
const TIER_COLORS = {
  bronze: "#CD7F32",
  silver: "#9CA3AF",
  gold: "#F59E0B",
  platinum: "#06B6D4",
};

function tierColor(tier) {
  return TIER_COLORS[tier] || "#26A69A";
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const dryRun = body && body.dry_run === true;

    const badges = Array.isArray(body?.badges) ? body.badges : [];
    const clientEmail = body?.client_email;
    const clientName = body?.client_name || clientEmail || "there";
    const therapistEmail = body?.therapist_email;

    if (!badges.length || !clientEmail) {
      return Response.json({ ok: false, reason: "incomplete" });
    }

    const appUrl = getAppUrl(req);
    const badgesUrl = appUrl ? `${appUrl}/badges` : "/badges";
    const firstName = firstNameOf(clientName);

    const badgeListHtml = badges
      .map(
        (b) =>
          `<li style="margin:0 0 8px 0;"><strong>${escapeHtml(b.title)}</strong> &mdash; ${escapeHtml(b.description)} <span style="color:${tierColor(b.tier)};font-size:12px;text-transform:uppercase;letter-spacing:.06em;font-weight:700;">${escapeHtml(b.tier || "")}</span></li>`
      )
      .join("");

    if (dryRun) {
      return Response.json({ ok: true, dry_run: true, badge_count: badges.length, client_email: clientEmail, therapist_email: therapistEmail || null });
    }

    let sentClient = false;
    let sentTherapist = false;

    // ---- Client email: celebratory and motivating ----
    try {
      const subject = badges.length > 1 ? `You earned ${badges.length} new WayPoint badges!` : `New WayPoint badge: ${badges[0].title}`;
      const contentHtml = [
        para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
        para(badges.length > 1 ? "You just earned new badges in WayPoint &mdash; and that's worth celebrating." : "You just earned a new badge in WayPoint &mdash; and that's worth celebrating."),
        `<ul style="margin:0 0 16px 0;padding-left:20px;font-size:15px;line-height:1.7;color:#2C3E45;">${badgeListHtml}</ul>`,
        softNote("Healing isn't a straight line, and showing up &mdash; even on the hard days &mdash; is real progress. You're building something that lasts."),
        primaryButton("See your badges", badgesUrl),
        para("Keep going at your own pace. We're proud to be walking alongside you.<br/><br/>Warm regards,<br/>The WayPoint Team"),
      ].join("");
      const { html } = renderEmail({ recipientType: "client", contentHtml });
      await base44.asServiceRole.integrations.Core.SendEmail({ to: clientEmail, subject, body: html });
      sentClient = true;
    } catch (e) {
      console.error("badge-notification client email failed:", e.message);
    }

    // ---- Therapist email: heads-up ----
    if (therapistEmail) {
      try {
        const subject = `Milestone: ${clientName} earned ${badges.length > 1 ? `${badges.length} new badges` : "a new badge"}`;
        const contentHtml = [
          para(`Hi,`, { lead: true }),
          para(`Your client <strong>${escapeHtml(clientName)}</strong> just reached a new milestone in WayPoint:`),
          `<ul style="margin:0 0 16px 0;padding-left:20px;font-size:15px;line-height:1.7;color:#2C3E45;">${badgeListHtml}</ul>`,
          therapistUplift(),
          para("This is a wonderful opportunity to acknowledge their progress in your next session &mdash; a little recognition can go a long way."),
        ].join("");
        const { html } = renderEmail({ recipientType: "therapist", contentHtml });
        await base44.asServiceRole.integrations.Core.SendEmail({ to: therapistEmail, subject, body: html });
        sentTherapist = true;
      } catch (e) {
        console.error("badge-notification therapist email failed:", e.message);
      }
    }

    console.log(`badge-notification: badges=${badges.length} client=${sentClient} therapist=${sentTherapist}`);
    return Response.json({ ok: true, sent_client: sentClient, sent_therapist: sentTherapist });
  } catch (error) {
    console.error("badge-notification error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}