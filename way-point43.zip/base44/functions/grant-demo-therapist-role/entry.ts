import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

// Invoked by the "Grant Demo Therapist Role" workflow on signup/login.
// If the authenticating user is an active 7-day demo participant, upgrade their
// app user to the therapist role (and set account_type=therapist) so they are
// correctly associated as a clinician. `inviteUser` cannot set custom roles
// (platform only accepts "user"/"admin"), so the role is applied here once the
// user has registered and a User record exists. Idempotent.

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const { user_id, email, dry_run } = body || {};

    if (!email) {
      return Response.json({ ok: false, error: "email is required" }, { status: 400 });
    }

    const lower = String(email).toLowerCase();

    // Only grant the therapist role to registered, active demo participants.
    const participants = await base44.asServiceRole.entities.DemoParticipant.list("-created_date", 200);
    const isDemo = (participants || []).some(
      (p) => (p.email || "").toLowerCase() === lower && p.status !== "expired"
    );
    if (!isDemo) {
      return Response.json({ ok: true, granted: false, reason: "not_a_demo_participant" });
    }

    if (dry_run) {
      return Response.json({ ok: true, dry_run: true, would_grant: true, user_id: user_id || null });
    }

    // Resolve the app user. The workflow passes user_id; fall back to an email
    // lookup if invoked directly (e.g., from demo-signup).
    let uid = user_id;
    if (!uid) {
      const users = await base44.asServiceRole.entities.User.list("-created_date", 200);
      const u = (users || []).find((x) => (x.email || "").toLowerCase() === lower);
      if (!u) {
        return Response.json({ ok: true, granted: false, reason: "user_not_registered_yet" });
      }
      uid = u.id;
    }

    // Set account_type first (always allowed), then attempt the role upgrade
    // separately so a role restriction can't block the account_type write.
    let accountTypeSet = false;
    let roleSet = false;
    try {
      await base44.asServiceRole.entities.User.update(uid, { account_type: "therapist" });
      accountTypeSet = true;
    } catch (e) {
      console.error("grant-demo-therapist-role: set account_type failed:", e.message);
    }
    try {
      await base44.asServiceRole.entities.User.update(uid, { role: "therapist" });
      roleSet = true;
    } catch (e) {
      console.error("grant-demo-therapist-role: set role failed:", e.message);
    }

    return Response.json({ ok: true, granted: roleSet || accountTypeSet, role_set: roleSet, account_type_set: accountTypeSet, user_id: uid });
  } catch (error) {
    console.error("grant-demo-therapist-role error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}