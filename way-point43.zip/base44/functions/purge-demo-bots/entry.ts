import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

// One-time cleanup: the scripted demo-signup burst created real User accounts
// that were auto-granted therapist access. The platform blocks BULK user
// delete/update (405), so we loop single-record operations here.
// Run once via test_backend_function; safe to leave for future use.

const BOT_EMAILS = [
  "gmail-alert-test+demo@example.com",
  "gmail-alert-test2+demo@example.com",
  "gmail-alert-test3+demo@example.com",
  "gmail-alert-test4+demo@example.com",
  "erichanson028@gmail.com",
  "lindapadillia01@gmail.com",
  "beckylynnts@gmail.com",
  "karenmosess21@gmail.com",
  "gunterjennifer88@gmail.com",
  "sarahsmithssss990@gmail.com",
  "jessicarobert99990@gmail.com",
  "reedmia48@gmail.com",
  "morganelena465@gmail.com",
  "naomiharris612@gmail.com",
  "michellescottt281@gmail.com",
  "jessicamillerc222@gmail.com",
  "bryandavidm35@gmail.com",
  "davidwright0139@gmail.com",
  "danielboehner011@gmail.com",
];

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const users = await base44.asServiceRole.entities.User.list("-created_date", 500);
    const targets = (users || []).filter((u) =>
      BOT_EMAILS.includes((u.email || "").toLowerCase())
    );

    const results = { found: targets.length, deleted: 0, downgraded: 0, failed: 0, details: [] };

    for (const u of targets) {
      // Try a hard single-record delete first; if the platform blocks it,
      // fall back to stripping therapist access + disabling the account.
      try {
        await base44.asServiceRole.entities.User.delete(u.id);
        results.deleted++;
        results.details.push({ email: u.email, action: "deleted" });
      } catch (delErr) {
        try {
          await base44.asServiceRole.entities.User.update(u.id, {
            role: "user",
            account_type: "user",
            disabled: true,
            disabled_reason: "Removed: scripted demo signup",
          });
          results.downgraded++;
          results.details.push({ email: u.email, action: "downgraded", deleteError: delErr.message });
        } catch (updErr) {
          results.failed++;
          results.details.push({ email: u.email, action: "failed", error: updErr.message });
        }
      }
    }

    console.log("purge-demo-bots result:", JSON.stringify(results));
    return Response.json(results);
  } catch (error) {
    console.error("purge-demo-bots error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}