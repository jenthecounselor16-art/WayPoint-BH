import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para } from '../../shared/emailTemplate.js';
import { escapeHtml } from '../../shared/emailUtils.ts';

const DEMO_OWNER_EMAIL = "jenthecounselor16@gmail.com";

// Invoked daily by the "Expire Demo Trials" workflow. Flips any active
// DemoParticipant whose 7-day window has closed to status "expired".
//
// This is the ONLY place status is flipped, so without it demo clinicians keep
// the demo designation (badge, therapist/client view toggle, feature tracking)
// indefinitely after their trial ends.
//
// A 2h grace mirrors the trial-sequence email window so the final-day survey
// email still goes out just before expiry.
//
// PAYWALL: This also revokes the therapist role for expired demo clinicians who
// have NOT paid for a subscription. Paying clinicians are protected — the Wix
// Payments webhook grants the therapist role on ORDER_APPROVED, and a paid
// Base44Purchase keeps them off the revoke list here. Only role === "therapist"
// users are touched; admins/supervisors are never downgraded.

const GRACE_MS = 2 * 60 * 60 * 1000; // 2h past expiry

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const now = Date.now();

    const [participants, purchases, users] = await Promise.all([
      base44.asServiceRole.entities.DemoParticipant.list('-created_date', 200),
      base44.asServiceRole.entities.Base44Purchase.list('-created_date', 500),
      base44.asServiceRole.entities.User.list('-created_date', 200),
    ]);

    // Emails with an active (paid) subscription — these demo clinicians keep
    // therapist access after their trial. Cancelled/expired purchases are excluded.
    const paidEmails = new Set(
      (purchases || [])
        .filter((p) => p.status === "paid" && p.buyer_email)
        .map((p) => String(p.buyer_email).toLowerCase())
    );

    const userByEmail = new Map();
    for (const u of users || []) {
      if (u.email) userByEmail.set(u.email.toLowerCase(), u);
    }

    let expired = 0;
    let revoked = 0;
    let failed = 0;

    for (const p of participants || []) {
      if (p.status !== 'active') continue;
      if (!p.expires_at) continue;
      if (now <= new Date(p.expires_at).getTime() + GRACE_MS) continue;

      const emailLower = (p.email || "").toLowerCase();

      // Flip the demo designation to expired.
      try {
        await base44.asServiceRole.entities.DemoParticipant.update(p.id, { status: "expired" });
        console.log(`Expired demo participant: ${p.email}`);
        expired++;

        // Notify the team owner that this 7-day demo has finished so they can
        // watch for the participant's emailed feedback.
        try {
          const startedStr = p.started_at ? new Date(p.started_at).toLocaleString("en-US", { timeZone: "America/Chicago" }) : "—";
          const expiredStr = p.expires_at ? new Date(p.expires_at).toLocaleString("en-US", { timeZone: "America/Chicago" }) : "—";
          const contentHtml = [
            para(`A 7-day WayPoint demo has just ended.`, { lead: true }),
            para(
              `<strong>Name:</strong> ${escapeHtml(p.name || "")}<br/>` +
              `<strong>Email:</strong> ${escapeHtml(p.email || "")}<br/>` +
              `<strong>Seat #:</strong> ${p.seat_number ?? "—"}<br/>` +
              `<strong>Started:</strong> ${startedStr}<br/>` +
              `<strong>Ended:</strong> ${expiredStr}`
            ),
            para(
              `Their honest 7-day feedback will arrive by email at ${DEMO_OWNER_EMAIL} — mark it received on the Demo Feedback dashboard when it lands.`
            ),
          ].join("");
          const { html } = renderEmail({ recipientType: "general", contentHtml });
          await base44.asServiceRole.integrations.Core.SendEmail({
            to: DEMO_OWNER_EMAIL,
            subject: `7-day demo ended — ${p.name || p.email}`,
            body: html,
          });
        } catch (e) {
          console.error(`Demo-end notify to ${DEMO_OWNER_EMAIL} failed:`, e.message);
        }
      } catch (e) {
        console.error(`Failed to expire ${p.email}:`, e.message);
        failed++;
        continue;
      }

      // Revoke therapist access if they never paid (full paywall). Only touches
      // users whose role is "therapist" — admins/supervisors are left alone, and
      // paying clinicians are protected by the paidEmails check.
      if (paidEmails.has(emailLower)) continue;
      const u = userByEmail.get(emailLower);
      if (!u || u.role !== "therapist") continue;
      try {
        try { await base44.asServiceRole.entities.User.update(u.id, { account_type: "user" }); } catch (e) { console.error(`revoke account_type ${p.email}:`, e.message); }
        try { await base44.asServiceRole.entities.User.update(u.id, { role: "user" }); } catch (e) { console.error(`revoke role ${p.email}:`, e.message); }
        console.log(`Revoked therapist role for expired, unpaid demo: ${p.email}`);
        revoked++;
      } catch (e) {
        console.error(`Role revoke failed for ${p.email}:`, e.message);
      }
    }

    console.log(`expire-demo-trials: expired=${expired} revoked=${revoked} failed=${failed}`);
    return Response.json({ ok: true, expired, revoked, failed });
  } catch (error) {
    console.error("expire-demo-trials error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}