import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para, alertCallout } from '../../shared/emailTemplate.js';

const SELF_HARM_ITEMS = {
  PHQ9: { index: 8, label: "Thoughts of being better off dead or of hurting yourself" },
  BDI: { index: 8, label: "Suicidal thoughts or wishes" },
};

const VALUE_LABELS = {
  PHQ9: ["Not at all", "Several days", "More than half the days", "Nearly every day"],
  BDI: ["Not at all", "Some of the time", "Much of the time", "Most or all of the time"],
};

// Total-score thresholds that independently warrant an immediate alert
const SEVERE_TOTAL = { PHQ9: 20, BDI: 29 };

function evaluateRisk(testType, score, answers) {
  const reasons = [];

  // C-SSRS — any endorsed item is clinically significant; behavior is critical.
  if (testType === "CSSRS" && Array.isArray(answers)) {
    const yesCount = answers.filter((a) => Number(a) >= 1).length;
    if (yesCount > 0) {
      if (Number(answers[5]) >= 1) {
        reasons.push({ type: "self_harm", label: "Suicidal behavior or preparation (C-SSRS item 6)", val: 1, valLabel: "Yes" });
      }
      if ([1, 2, 3, 4].some((i) => Number(answers[i]) >= 1)) {
        reasons.push({ type: "self_harm", label: "Active suicidal ideation (C-SSRS)", val: 1, valLabel: "Yes" });
      } else if (Number(answers[0]) >= 1) {
        reasons.push({ type: "self_harm", label: "Passive suicidal ideation (C-SSRS item 1)", val: 1, valLabel: "Yes" });
      }
    }
    return reasons.length ? { highRisk: true, reasons } : { highRisk: false, reasons: [] };
  }

  const cfg = SELF_HARM_ITEMS[testType];
  if (cfg && Array.isArray(answers)) {
    const val = Number(answers[cfg.index]);
    if (Number.isFinite(val) && val >= 1) {
      reasons.push({
        type: "self_harm",
        label: cfg.label,
        val,
        valLabel: (VALUE_LABELS[testType] || [])[val] || `Level ${val}`,
      });
    }
  }
  if (SEVERE_TOTAL[testType] && Number(score) >= SEVERE_TOTAL[testType]) {
    reasons.push({ type: "severe_score", label: `Severe total score (${score})` });
  }
  return reasons.length ? { highRisk: true, reasons } : { highRisk: false, reasons: [] };
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const { test_type, score, answers, client_email, therapist_email } = body;
    if (!test_type) return Response.json({ error: "test_type required" }, { status: 400 });

    const clientEmail = client_email || user.email;
    const risk = evaluateRisk(test_type, Number(score), answers);

    if (!risk.highRisk) {
      return Response.json({ alerted: false, highRisk: false });
    }

    // Resolve the therapist to notify — prefer the submitted link, fall back to the Client record
    let therapistEmail = therapist_email || "";
    if (!therapistEmail) {
      try {
        const clients = await base44.asServiceRole.entities.Client.filter({ client_email: clientEmail });
        if (clients[0]?.therapist_email) therapistEmail = clients[0].therapist_email;
      } catch (e) {
        console.error("Therapist lookup failed:", e.message);
      }
    }

    const reasonText = risk.reasons
      .map((r) => (r.type === "self_harm"
        ? `Self-harm item endorsed: "${r.label}" (${r.valLabel})`
        : r.label))
      .join(" · ");

    if (!therapistEmail) {
      // De-identified log — the AuditLog record below captures the full details.
      console.error("No therapist linked for high-risk result:", test_type, score);
      try {
        await base44.asServiceRole.entities.AuditLog.create({
          action: "safety_risk_alert_no_therapist",
          client_email: clientEmail,
          therapist_email: "",
          details: `High-risk ${test_type} score ${score} — no therapist linked. ${reasonText}`,
        });
      } catch (e) {
        console.error("Audit log error:", e.message);
      }
      return Response.json({ alerted: false, highRisk: true, reason: "no_therapist" });
    }

    const subject = `[WayPoint Safety Alert] High-risk ${test_type} result for ${clientEmail}`;
    const contentHtml = [
      para("A client&rsquo;s assessment has triggered a high-risk safety flag that needs your attention.", { lead: true }),
      alertCallout("Safety Flag", [
        `<p style="margin:0 0 4px 0;"><strong>Client:</strong> ${escapeHtml(clientEmail)}</p>`,
        `<p style="margin:0 0 4px 0;"><strong>Assessment:</strong> ${escapeHtml(test_type)} &middot; <strong>Score:</strong> ${escapeHtml(String(score))}</p>`,
        `<p style="margin:0;"><strong>Flagged:</strong> ${escapeHtml(reasonText)}</p>`,
      ].join("")),
      para("Please conduct a safety assessment and review the client&rsquo;s crisis plan promptly. If you have immediate concerns, call or text 988 (Suicide &amp; Crisis Lifeline)."),
      para("Log in to WayPoint to view the client&rsquo;s dashboard and full history."),
    ].join("");
    const { html } = renderEmail({ recipientType: "therapist", contentHtml });

    try {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: therapistEmail,
        subject,
        body: html,
      });
    } catch (e) {
      console.error("SendEmail failed:", e.message);
      return Response.json({ alerted: false, highRisk: true, reason: "email_failed", error: e.message });
    }

    try {
      await base44.asServiceRole.entities.AuditLog.create({
        action: "safety_risk_alert_sent",
        client_email: clientEmail,
        therapist_email: therapistEmail,
        details: `High-risk ${test_type} score ${score}. ${reasonText}`,
      });
    } catch (e) {
      console.error("Audit log error:", e.message);
    }

    console.log("Safety alert sent to", therapistEmail, "for", test_type, score);
    return Response.json({ alerted: true, highRisk: true, therapist_email: therapistEmail });
  } catch (error) {
    console.error("Safety alert error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

function escapeHtml(s) {
  return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}