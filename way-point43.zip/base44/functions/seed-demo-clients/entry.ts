import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

// Seeds a small set of sample clients (with assessments, homework, goals, and
// nervous-system check-ins) for a demo clinician whose Therapist Portal is
// empty, so they can explore a populated experience during their 7-day trial.
//
// Runs in the clinician's own context (createClientFromRequest) so every
// record is owned by them (created_by = their email) and visible under RLS.
// Idempotent: skips non-demo participants and clinicians who already have clients.

const DAY = 86400000;

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const therapist_email = body?.therapist_email;
    if (!therapist_email) {
      return Response.json({ error: "therapist_email is required" }, { status: 400 });
    }

    // Only seed for active demo participants.
    const participants = await base44.entities.DemoParticipant.list("-created_date", 200);
    const isDemo = (participants || []).some(
      (p) => (p.email || "").toLowerCase() === String(therapist_email).toLowerCase() && p.status === "active"
    );
    if (!isDemo) {
      return Response.json({ ok: true, skipped: true, reason: "not_a_demo_participant" });
    }

    // Don't reseed if the clinician already has clients.
    const existing = await base44.entities.Client.filter({ therapist_email }, "-created_date", 5);
    if (existing && existing.length > 0) {
      return Response.json({ ok: true, skipped: true, reason: "already_has_clients" });
    }

    const t = therapist_email;
    const dueDate = new Date(Date.now() + 7 * DAY).toISOString().slice(0, 10);

    const clients = [
      { name: "Alex Rivera", email: "alex.demo@sample.waypoint" },
      { name: "Jordan Chen", email: "jordan.demo@sample.waypoint" },
      { name: "Sam Parker", email: "sam.demo@sample.waypoint" },
    ];

    await base44.entities.Client.bulkCreate(
      clients.map((c) => ({ client_email: c.email, client_name: c.name, therapist_email: t }))
    );

    await base44.entities.AssessmentResult.bulkCreate([
      { client_email: clients[0].email, therapist_email: t, test_type: "GAD7", score: 12, severity: "Moderate", answers: [3, 2, 3, 2, 1, 1, 0] },
      { client_email: clients[0].email, therapist_email: t, test_type: "PHQ9", score: 9, severity: "Mild", answers: [2, 1, 2, 1, 1, 1, 1, 0, 0] },
      { client_email: clients[1].email, therapist_email: t, test_type: "PHQ9", score: 14, severity: "Moderate", answers: [2, 2, 2, 2, 1, 2, 1, 1, 1] },
      { client_email: clients[1].email, therapist_email: t, test_type: "WHO5", score: 28, severity: "Low wellbeing", answers: [1, 1, 0, 2, 1, 3, 2, 1, 1, 2] },
      { client_email: clients[2].email, therapist_email: t, test_type: "GAD7", score: 5, severity: "Mild", answers: [1, 1, 1, 1, 0, 1, 0] },
      { client_email: clients[2].email, therapist_email: t, test_type: "PHQ9", score: 4, severity: "Minimal", answers: [1, 1, 0, 1, 0, 0, 1, 0, 0] },
    ]);

    await base44.entities.HomeworkAssignment.bulkCreate([
      {
        title: "Practice the STOP skill",
        description: "When you notice anxiety rising, pause and use the STOP skill: Stop, Take a breath, Observe, Proceed.",
        client_email: clients[0].email, client_name: clients[0].name, therapist_email: t,
        due_date: dueDate, tasks: ["Notice 2 anxiety moments this week", "Write what triggered each", "Try STOP once daily"],
        status: "assigned", completion_percentage: 0,
      },
      {
        title: "Behavior activation: schedule one enjoyable activity",
        description: "Pick one activity you've been avoiding because of low energy and schedule it for this week.",
        client_email: clients[1].email, client_name: clients[1].name, therapist_email: t,
        due_date: dueDate, tasks: ["List 3 activities you used to enjoy", "Choose one and pick a day", "Do it and note how you felt after"],
        status: "assigned", completion_percentage: 0,
      },
      {
        title: "Daily thought record",
        description: "Catch one automatic thought this week and reframe it using the thought record.",
        client_email: clients[2].email, client_name: clients[2].name, therapist_email: t,
        due_date: dueDate, tasks: ["Complete one thought record"],
        status: "completed", completion_percentage: 100,
        client_response: "Caught a thought that I'm 'behind on everything' — reframed it to 'I'm doing what I can today.' Felt lighter after.",
      },
    ]);

    await base44.entities.TherapyGoal.bulkCreate([
      { title: "Reduce panic episodes to once a week", description: "Use coping tools to lower the frequency of panic episodes over the next month.", client_email: clients[0].email, therapist_email: t, status: "active", client_rating: 4, therapist_rating: 3 },
      { title: "Reengage with a weekly hobby", description: "Reconnect with one enjoyable activity each week to rebuild energy and meaning.", client_email: clients[1].email, therapist_email: t, status: "active", client_rating: 3, therapist_rating: 2 },
      { title: "Maintain a steady sleep routine", description: "Keep a consistent bedtime and morning to support mood stability.", client_email: clients[2].email, therapist_email: t, status: "active", client_rating: 7, therapist_rating: 7 },
    ]);

    await base44.entities.NervousSystemMetric.bulkCreate([
      { client_email: clients[0].email, therapist_email: t, sleep_hours: 5.5, stress_level: 8, movement_minutes: 10, hydration_glasses: 4, anxiety_level: 8, depression_level: 4, energy_level: 4, social_interaction: 3, note: "Rough night, anxious about work." },
      { client_email: clients[0].email, therapist_email: t, sleep_hours: 6, stress_level: 7, movement_minutes: 15, hydration_glasses: 5, anxiety_level: 7, depression_level: 3, energy_level: 5, social_interaction: 4, note: "Slightly better today." },
      { client_email: clients[1].email, therapist_email: t, sleep_hours: 9, stress_level: 6, movement_minutes: 0, hydration_glasses: 3, anxiety_level: 4, depression_level: 7, energy_level: 3, social_interaction: 2, note: "Slept a lot but still tired. Didn't leave the house." },
      { client_email: clients[1].email, therapist_email: t, sleep_hours: 8, stress_level: 5, movement_minutes: 20, hydration_glasses: 4, anxiety_level: 3, depression_level: 6, energy_level: 4, social_interaction: 3, note: "Short walk helped a little." },
      { client_email: clients[2].email, therapist_email: t, sleep_hours: 7.5, stress_level: 4, movement_minutes: 30, hydration_glasses: 6, anxiety_level: 3, depression_level: 2, energy_level: 7, social_interaction: 7, note: "Good day, saw a friend." },
      { client_email: clients[2].email, therapist_email: t, sleep_hours: 7, stress_level: 3, movement_minutes: 25, hydration_glasses: 6, anxiety_level: 2, depression_level: 2, energy_level: 8, social_interaction: 6, note: "Steady and productive." },
    ]);

    return Response.json({ ok: true, seeded: true, clients: clients.length });
  } catch (error) {
    console.error("seed-demo-clients error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}