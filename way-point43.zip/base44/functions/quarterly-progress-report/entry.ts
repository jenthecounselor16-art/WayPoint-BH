import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para, primaryButton, therapistUplift } from '../../shared/emailTemplate.js';
import { getAppUrl, firstNameOf, escapeHtml } from '../../shared/emailUtils.ts';
import { filterTherapists, groupClientsByTherapist, avg, fmtAvg, statPill } from '../../shared/clientReportUtils.ts';

// Invoked quarterly by the "Quarterly Progress Report" workflow.
// For each therapist, aggregates the trailing 90 days of their active clients'
// nervous-system check-ins and earned badges, then emails a branded per-client
// progress report so clinicians get a periodic snapshot of client trends.

const DAY = 24 * 60 * 60 * 1000;
const QUARTER_MS = 90 * DAY;

const TEAL = "#26A69A";
const TEAL_DARK = "#1E8378";
const INK = "#2C3E45";
const MUTED = "#5E7278";
const SOFT_BG = "#F2F7F6";
const CARD_BORDER = "#EAF1F0";

function prettify(key) {
  return String(key || "")
    .replace(/_/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}



function clientCard(name, email, metrics, badges) {
  const checkIns = metrics.length;
  const a = {
    sleep: avg(metrics, "sleep_hours"),
    stress: avg(metrics, "stress_level"),
    movement: avg(metrics, "movement_minutes"),
    anxiety: avg(metrics, "anxiety_level"),
    depression: avg(metrics, "depression_level"),
    energy: avg(metrics, "energy_level"),
    social: avg(metrics, "social_interaction"),
  };

  const pills = [
    statPill("Check-ins", checkIns),
    statPill("Avg sleep", fmtAvg(a.sleep, "h")),
    statPill("Avg stress", fmtAvg(a.stress, "/10")),
    statPill("Avg anxiety", fmtAvg(a.anxiety, "/10")),
    statPill("Avg energy", fmtAvg(a.energy, "/10")),
    statPill("Avg movement", fmtAvg(a.movement, "min")),
  ].join("");

  const badgeLine = badges.length
    ? badges.map((b) => `<span style="display:inline-block;margin:0 8px 6px 0;padding:5px 11px;background:#FBF7F0;border-radius:8px;font-size:13px;color:${INK};">&#10024; ${escapeHtml(prettify(b.badge_key))}</span>`).join("")
    : `<span style="font-size:13px;color:${MUTED};font-style:italic;">No new badges this quarter.</span>`;

  return `
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 16px 0;border:1px solid ${CARD_BORDER};border-radius:10px;overflow:hidden;">
    <tr>
      <td style="background:${SOFT_BG};padding:12px 16px;border-bottom:1px solid ${CARD_BORDER};">
        <p style="margin:0;font-size:16px;font-weight:700;color:${INK};font-family:Georgia,'Hoefler Text',serif;">${escapeHtml(name)}</p>
        <p style="margin:2px 0 0 0;font-size:13px;color:${MUTED};">${escapeHtml(email)}</p>
      </td>
    </tr>
    <tr>
      <td style="padding:14px 16px;">
        <p style="margin:0 0 8px 0;font-size:12px;letter-spacing:.06em;text-transform:uppercase;font-weight:700;color:${TEAL_DARK};">Nervous-system metrics</p>
        <div style="margin:0 0 12px 0;">${pills}</div>
        <p style="margin:0 0 8px 0;font-size:12px;letter-spacing:.06em;text-transform:uppercase;font-weight:700;color:${TEAL_DARK};">Badges earned this quarter (${badges.length})</p>
        <div>${badgeLine}</div>
      </td>
    </tr>
  </table>`;
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const dryRun = body && body.dry_run === true;
    const force = body && body.force === true;

    // Workflow fires monthly; only send on quarter-start months (Jan/Apr/Jul/Oct).
    if (!dryRun && !force) {
      const month = new Date().getMonth() + 1;
      if (![1, 4, 7, 10].includes(month)) {
        return Response.json({ ok: true, skipped: true, reason: "not_a_quarter_month" });
      }
    }

    const appUrl = getAppUrl(req);
    const portalUrl = appUrl ? `${appUrl}/therapist` : "/therapist";

    const now = Date.now();
    const quarterStart = now - QUARTER_MS;
    const inWindow = (d) => {
      const t = d ? new Date(d).getTime() : 0;
      return t >= quarterStart && t <= now;
    };

    const [users, clients, metrics, badges] = await Promise.all([
      base44.asServiceRole.entities.User.list("-created_date", 500),
      base44.asServiceRole.entities.Client.list("-created_date", 1000),
      base44.asServiceRole.entities.NervousSystemMetric.list("-created_date", 1000),
      base44.asServiceRole.entities.UserBadge.list("-created_date", 1000),
    ]);

    // Resolve badge creators -> client emails via the user map.
    const userIdToEmail = {};
    (users || []).forEach((u) => { if (u.id) userIdToEmail[u.id] = u.email; });

    const badgesByClientEmail = {};
    (badges || []).forEach((b) => {
      if (!inWindow(b.created_date)) return;
      const email = userIdToEmail[b.created_by_id];
      if (!email) return;
      if (!badgesByClientEmail[email]) badgesByClientEmail[email] = [];
      badgesByClientEmail[email].push(b);
    });

    const metricsByClientEmail = {};
    (metrics || []).forEach((m) => {
      if (!inWindow(m.created_date)) return;
      if (!m.client_email) return;
      if (!metricsByClientEmail[m.client_email]) metricsByClientEmail[m.client_email] = [];
      metricsByClientEmail[m.client_email].push(m);
    });

    // Group managed clients by therapist email.
    const clientsByTherapist = groupClientsByTherapist(clients);
    const therapists = filterTherapists(users);

    if (dryRun) {
      const summary = therapists.map((t) => ({
        therapist: t.email,
        clients: (clientsByTherapist[t.email] || []).length,
      }));
      return Response.json({ ok: true, dry_run: true, therapist_count: therapists.length, summary });
    }

    let sent = 0;
    let failed = 0;
    const quarterLabel = new Date(quarterStart).toLocaleDateString("en-US", { month: "short", day: "numeric" });

    for (const t of therapists) {
      const myClients = clientsByTherapist[t.email] || [];
      if (!myClients.length) continue;

      const cards = myClients
        .map((c) => clientCard(
          c.client_name || c.client_email,
          c.client_email,
          metricsByClientEmail[c.client_email] || [],
          badgesByClientEmail[c.client_email] || []
        ))
        .join("");

      const firstName = firstNameOf(t.full_name || t.email);
      const subject = `Your quarterly client progress report (since ${quarterLabel})`;

      const contentHtml = [
        para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
        para(`Here&rsquo;s a quarterly snapshot of your active clients&rsquo; progress in WayPoint, covering the last 90 days (since ${escapeHtml(quarterLabel)}). Each card summarizes their nervous-system check-ins and any badges earned this quarter.`),
        cards,
        therapistUplift(),
        primaryButton("Open your therapist portal", portalUrl),
        para("Use these trends to celebrate growth and spot where a client may need extra support between sessions.<br/><br/>Warmly,<br/>The WayPoint Team"),
      ].join("");

      try {
        const { html } = renderEmail({ recipientType: "therapist", contentHtml });
        await base44.asServiceRole.integrations.Core.SendEmail({ to: t.email, subject, body: html });
        sent++;
      } catch (e) {
        console.error(`Quarterly report to ${t.email} failed:`, e.message);
        failed++;
      }
    }

    console.log(`quarterly-progress-report: therapists=${therapists.length} sent=${sent} failed=${failed}`);
    return Response.json({ ok: true, therapists: therapists.length, sent, failed });
  } catch (error) {
    console.error("quarterly-progress-report error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}