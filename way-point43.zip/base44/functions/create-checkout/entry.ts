import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { secrets } from 'base44:runtime';
import { PLAN_CATALOG } from '../../shared/planCatalog.ts';

export default async function(req) {
  try {
    const body = await req.json();
    const { plan } = body;

    const planConfig = PLAN_CATALOG[plan];
    if (!planConfig) {
      return Response.json({ error: "Invalid plan specified" }, { status: 400 });
    }

    if (parseFloat(planConfig.price) < 0.5) {
      return Response.json({ error: "Amount must be at least $0.50" }, { status: 400 });
    }

    const appUrl = req.headers.get("X-Base44-App-Url") || secrets.get("WIX_CHECKOUT_APP_URL") || "";

    if (!appUrl) {
      return Response.json({ error: "Unable to determine app URL" }, { status: 400 });
    }

    const response = await fetch(
      "https://www.wixapis.com/payments/platform/v1/checkout-sessions/construct",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": secrets.get("WIX_PAYMENTS_API_KEY"),
          "wix-site-id": secrets.get("WIX_PAYMENTS_SITE_ID"),
        },
        body: JSON.stringify({
          cart: {
            items: [
              {
                name: planConfig.name,
                quantity: 1,
                price: planConfig.price,
                subscriptionInfo: {
                  subscriptionSettings: {
                    frequency: planConfig.frequency,
                  },
                  title: planConfig.name,
                  description: planConfig.description,
                },
              },
            ],
          },
          callbackUrls: {
            postFlowUrl: `${appUrl}/billing`,
            thankYouPageUrl: `${appUrl}/billing?status=success`,
          },
        }),
      }
    );

    const data = await response.json();

    if (!response.ok) {
      console.error("Wix checkout error:", JSON.stringify(data));
      return Response.json({ error: "Failed to create checkout session" }, { status: 500 });
    }

    // Persist purchase record with checkout session ID (the only link back to the buyer)
    const base44 = createClientFromRequest(req);

    // Capture the logged-in buyer's email (best-effort) so the purchase can be
    // attributed and the webhook can grant access to the right user. Checkout
    // stays public — we never gate on auth, and we never use the Wix checkout-typed email.
    let buyerEmail = "";
    try {
      const me = await base44.auth.me();
      buyerEmail = me?.email || "";
    } catch (e) {
      // Not logged in — proceed without a buyer link (storefront case).
    }

    try {
      await base44.asServiceRole.entities.Base44Purchase.create({
        checkoutSessionId: data.checkoutSession.id,
        status: "pending",
        plan: plan,
        buyer_email: buyerEmail,
      });
    } catch (e) {
      console.error("Failed to persist purchase:", e.message);
    }

    return Response.json({ redirectUrl: data.checkoutSession.redirectUrl });
  } catch (error) {
    console.error("Checkout error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}