import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { linkClientRecords } from '../../shared/linkClientRecords.ts';

// Called the moment a therapist links a client (creates a Client record).
// Stamps the therapist's email onto every existing record that belongs to that
// client — across all shared clinical entities — so the therapist can see the
// client's full history at all times, regardless of who created the record or
// whether the therapist ever sent an assignment. Idempotent and safe to re-run.
export default async function(req) {
  try {
    const body = await req.json().catch(() => ({}));
    const clientEmail = body?.client_email;
    const therapistEmail = body?.therapist_email;
    if (!clientEmail || !therapistEmail) {
      return Response.json({ error: 'client_email and therapist_email are required' }, { status: 400 });
    }
    const base44 = createClientFromRequest(req);
    const summary = await linkClientRecords(base44.asServiceRole, clientEmail, therapistEmail);
    return Response.json({ ok: true, summary });
  } catch (error) {
    console.error('link-client-records error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}