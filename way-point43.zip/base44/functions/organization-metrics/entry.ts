import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

const WELLBEING_TESTS = ['WHO5'];

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const role = user.role || '';
    const accountType = user.account_type || '';
    const isSupervisor = role === 'supervisor' || role === 'admin' || accountType === 'supervisor';
    if (!isSupervisor) {
      return Response.json({ error: 'Forbidden — supervisor access required' }, { status: 403 });
    }

    const sr = base44.asServiceRole;
    const limit = 2000;

    const [assessments, homework, assessmentAssignments, goals, metrics, journals] = await Promise.all([
      sr.entities.AssessmentResult.list("-created_date", limit),
      sr.entities.HomeworkAssignment.list("-created_date", limit),
      sr.entities.AssessmentAssignment.list("-created_date", limit),
      sr.entities.TherapyGoal.list("-created_date", limit),
      sr.entities.NervousSystemMetric.list("-created_date", limit),
      sr.entities.JournalEntry.list("-created_date", limit),
    ]);

    const arr = (x) => x || [];

    // --- Average symptom improvement ---
    const assessmentGroups = {};
    arr(assessments).forEach(a => {
      if (!a.client_email) return;
      const key = a.client_email + '|' + a.test_type;
      if (!assessmentGroups[key]) assessmentGroups[key] = [];
      assessmentGroups[key].push(a);
    });

    let totalDeltaAbs = 0;
    let improvementCount = 0;
    let declineCount = 0;
    let totalComparisons = 0;
    const clientOutcomes = {};

    Object.entries(assessmentGroups).forEach(([, results]) => {
      if (results.length < 2) return;
      const sorted = results.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
      const first = sorted[0];
      const latest = sorted[sorted.length - 1];
      const delta = latest.score - first.score;
      const isWellbeing = WELLBEING_TESTS.includes(first.test_type);
      const isImprovement = isWellbeing ? delta > 0 : delta < 0;
      const isDecline = isWellbeing ? delta < 0 : delta > 0;

      totalDeltaAbs += Math.abs(delta);
      if (isImprovement) improvementCount++;
      if (isDecline) declineCount++;
      totalComparisons++;

      const client = first.client_email;
      if (!clientOutcomes[client]) clientOutcomes[client] = { improvements: 0, declines: 0 };
      if (isImprovement) clientOutcomes[client].improvements++;
      if (isDecline) clientOutcomes[client].declines++;
    });

    const avgChange = totalComparisons > 0 ? totalDeltaAbs / totalComparisons : 0;
    const clientsImproved = Object.values(clientOutcomes).filter(c => c.improvements > c.declines).length;
    const clientsTotal = Object.keys(clientOutcomes).length;
    const improvementRate = clientsTotal > 0 ? (clientsImproved / clientsTotal) * 100 : 0;

    // --- Homework completion ---
    const hwList = arr(homework);
    const hwCompleted = hwList.filter(h => h.status === 'completed').length;
    const hwRate = hwList.length > 0 ? (hwCompleted / hwList.length) * 100 : 0;

    // --- Assessment completion ---
    const aaList = arr(assessmentAssignments);
    const aaCompleted = aaList.filter(a => a.status === 'completed').length;
    const aaRate = aaList.length > 0 ? (aaCompleted / aaList.length) * 100 : 0;

    // --- Client engagement ---
    const activeClients = new Set();
    arr(metrics).forEach(m => { if (m.client_email) activeClients.add(m.client_email); });
    arr(assessments).forEach(a => { if (a.client_email) activeClients.add(a.client_email); });
    hwList.forEach(h => { if (h.client_email) activeClients.add(h.client_email); });

    const totalEngagement = arr(metrics).length + arr(assessments).length + arr(journals).length;
    const avgEngagement = activeClients.size > 0 ? totalEngagement / activeClients.size : 0;

    // --- Therapist utilization ---
    const therapistMap = {};
    const addTherapist = (email) => {
      if (!email) return null;
      if (!therapistMap[email]) therapistMap[email] = { clients: new Set(), homework: 0, assessments: 0, goals: 0 };
      return therapistMap[email];
    };

    hwList.forEach(h => {
      const t = addTherapist(h.therapist_email);
      if (t) { t.homework++; if (h.client_email) t.clients.add(h.client_email); }
    });
    aaList.forEach(a => {
      const t = addTherapist(a.therapist_email);
      if (t) { t.assessments++; if (a.client_email) t.clients.add(a.client_email); }
    });
    arr(goals).forEach(g => {
      const t = addTherapist(g.therapist_email);
      if (t) { t.goals++; if (g.client_email) t.clients.add(g.client_email); }
    });

    const therapistKeys = Object.keys(therapistMap);
    const therapistCount = therapistKeys.length;
    const totalClientsAcross = therapistKeys.reduce((sum, k) => sum + therapistMap[k].clients.size, 0);
    const totalAssignments = therapistKeys.reduce((sum, k) => sum + therapistMap[k].homework + therapistMap[k].assessments, 0);

    const breakdown = therapistKeys
      .map((email) => ({
        clients: therapistMap[email].clients.size,
        homework: therapistMap[email].homework,
        assessments: therapistMap[email].assessments,
        totalAssignments: therapistMap[email].homework + therapistMap[email].assessments,
      }))
      .sort((a, b) => b.totalAssignments - a.totalAssignments)
      .map((t, idx) => ({ ...t, label: 'Therapist ' + (idx + 1) }));

    // --- Program outcomes ---
    const goalsList = arr(goals);
    const goalsAchieved = goalsList.filter(g => g.status === 'achieved').length;
    const goalRate = goalsList.length > 0 ? (goalsAchieved / goalsList.length) * 100 : 0;

    const round1 = (n) => Math.round(n * 10) / 10;

    return Response.json({
      symptomImprovement: {
        avgChange: round1(avgChange),
        comparisons: totalComparisons,
        clientsImproved,
        clientsTotal,
        improvementRate: round1(improvementRate),
        improvementCount,
        declineCount,
      },
      homework: {
        completionRate: round1(hwRate),
        completed: hwCompleted,
        total: hwList.length,
      },
      assessments: {
        completionRate: round1(aaRate),
        completed: aaCompleted,
        total: aaList.length,
      },
      engagement: {
        activeClients: activeClients.size,
        avgEngagementPerClient: round1(avgEngagement),
        metricEntries: arr(metrics).length,
        journalEntries: arr(journals).length,
      },
      therapistUtilization: {
        therapistCount,
        avgClientsPerTherapist: round1(therapistCount > 0 ? totalClientsAcross / therapistCount : 0),
        avgAssignmentsPerTherapist: round1(therapistCount > 0 ? totalAssignments / therapistCount : 0),
        totalAssignments,
        breakdown,
      },
      programOutcomes: {
        goalAchievementRate: round1(goalRate),
        goalsAchieved,
        goalsTotal: goalsList.length,
        clientsImproved,
        clientsTotal,
      },
    });
  } catch (error) {
    console.error('Organization metrics error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}