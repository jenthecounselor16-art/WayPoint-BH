import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

const SEAT_LIMIT = 100;

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const all = await base44.asServiceRole.entities.DemoParticipant.list("-created_date", 200);
    const used = (all || []).length;
    return Response.json({ total: SEAT_LIMIT, used, remaining: Math.max(0, SEAT_LIMIT - used) });
  } catch (error) {
    console.error("Demo status error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}