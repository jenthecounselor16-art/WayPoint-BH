import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { renderEmail, para, primaryButton, softNote, alertCallout, therapistUplift } from '../../shared/emailTemplate.js';
import { getAppUrl, firstNameOf, escapeHtml } from '../../shared/emailUtils.ts';

// Invoked daily by the "Demo Last Day Email" workflow.
//
// On a demo participant's final trial day (within a ~30h window so the daily
// run catches every timezone), sends a rich recap email:
//   - Usage stats: the features they interacted with most (from
//     DemoFeatureInteraction), with a short note on why each benefits their
//     practice.
//   - Subscription pricing with one-click upgrade buttons to /billing.
//   - A clear statement that clients never pay — every plan covers the
//     clinician only.
//   - A link to the feedback survey.
//
// Idempotent: last_day_email_sent gates the send across redelivery / re-runs.
// The mid-trial check-ins are handled separately by demo-trial-sequence, so
// the two never race.

const HOUR = 3600000;

// Why each feature matters in a real practice — shown beside the usage count.
const FEATURE_BENEFIT = {
  therapist_portal: "Every client, assignment, and progress signal in one secure place &mdash; so nothing falls through the cracks between sessions.",
  clinical_insights: "Symptom scores chart automatically from check-ins and assessments, giving you objective progress data for treatment planning and notes.",
  assessments: "Standardized measures (GAD-7, PHQ-9, and more) with auto-scoring and severity bands &mdash; less admin, more clinical signal.",
  coping_toolbox: "Ready-to-use DBT, CBT, and grounding skills your clients reach between sessions, extending your care beyond the hour.",
  ai_coach: "An AI Coping Coach that role-plays skills with your clients on demand, reinforcing the work you do together.",
  nervous_system: "Daily check-ins surface baseline patterns and early warning signs before your next session.",
  emotion_wheel: "A guided emotion wheel helps clients name what they feel &mdash; the first step in any CBT or DBT intervention.",
  thought_record: "Structured CBT thought records clients complete between sessions, ready to review together.",
  therapy_goals: "Collaborative goals with client and therapist ratings, so progress is visible and shared.",
  homework: "Assign homework with due dates and automatic reminders &mdash; and watch completion flow back to your dashboard.",
  behavior_activation: "Activities tied to a client's values, with completion tracking that builds real momentum.",
  values_inventory: "A values inventory that anchors goals and behavior activation in what matters to each client.",
  crisis_plan: "A collaborative safety plan your client carries everywhere &mdash; warning signs, coping skills, and contacts at hand.",
  sensory_profile: "A sensory profile that informs regulation strategies tailored to each client's nervous system.",
  function_checkin: "Functional impairment tracking that supports medical-necessity documentation and outcomes reporting.",
  client_portal: "A private client portal that keeps every self-guided tool in one place, branded to your practice.",
  badges: "Milestone celebrations that keep clients engaged and reinforce consistent use of skills.",
  activities_quiz: "An activities quiz that surfaces enjoyable and valuable actions for behavior activation.",
};

// Clinician subscription plans (mirrors src/pages/Billing.jsx). Clients are
// always free, so only clinician tiers are shown here.
const PLANS = [
  { name: "Solo Clinician", price: "$29/mo &middot; or $290/yr (save 2 months)" },
  { name: "Counseling Practice", price: "$99/mo &middot; or $990/yr (save 2 months)" },
  { name: "Small Private Practice", price: "$249/mo &middot; or $2490/yr" },
];

const FALLBACK_FEATURES = ["clinical_insights", "coping_toolbox", "therapist_portal"];

function heading(text) {
  return `<p style="margin:24px 0 10px 0;font-size:13px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;color:#1E8378;">${text}</p>`;
}

function featureStatHtml(label, count, benefit) {
  const countLabel = count > 0
    ? ` <span style="font-weight:400;color:#5E7278;font-size:13px;">&mdash; ${count} interaction${count === 1 ? "" : "s"}</span>`
    : "";
  return `
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 12px 0;">
    <tr>
      <td style="background:#F2F7F6;border-radius:10px;padding:14px 16px;">
        <p style="margin:0 0 4px 0;font-size:15px;font-weight:700;color:#1E8378;">${escapeHtml(label)}${countLabel}</p>
        <p style="margin:0;font-size:14px;line-height:1.6;color:#2C3E45;">${benefit}</p>
      </td>
    </tr>
  </table>`;
}

function planCardHtml(name, priceLine, url) {
  return `
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 14px 0;">
    <tr>
      <td style="background:#ffffff;border:1px solid #EAF1F0;border-radius:12px;padding:16px 18px;">
        <p style="margin:0 0 2px 0;font-size:16px;font-weight:700;color:#2C3E45;">${name}</p>
        <p style="margin:0 0 8px 0;font-size:14px;color:#5E7278;">${priceLine}</p>
        ${primaryButton("Upgrade", url)}
      </td>
    </tr>
  </table>`;
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const appUrl = getAppUrl(req);
    const billingUrl = appUrl ? `${appUrl}/billing` : "/billing";
    const salesUrl = appUrl ? `${appUrl}/contact-sales` : "/contact-sales";
    const surveyUrl = appUrl ? `${appUrl}/demo-survey` : "/demo-survey";

    const now = Date.now();
    const GRACE_MS = 2 * 60 * 60 * 1000;      // allow a 2h grace past expiry
    const HORIZON_MS = 30 * 60 * 60 * 1000;   // look ~30h ahead = "last day"

    const participants = await base44.asServiceRole.entities.DemoParticipant.list("-created_date", 200) || [];

    const eligible = participants.filter((p) => {
      if (p.status !== "active") return false;
      if (p.last_day_email_sent === true) return false;
      if (!p.expires_at) return false;
      const exp = new Date(p.expires_at).getTime();
      return exp > now - GRACE_MS && exp < now + HORIZON_MS;
    });

    let sent = 0;
    let failed = 0;
    for (const p of eligible) {
      try {
        const firstName = firstNameOf(p.name);

        // ---- Usage stats: most-interacted features ----
        let topFeatures = [];
        try {
          const interactions = await base44.asServiceRole.entities.DemoFeatureInteraction.filter({ participant_email: p.email }) || [];
          const counts = {};
          interactions.forEach((i) => {
            const k = i.feature_key;
            if (!k) return;
            if (!counts[k]) counts[k] = { key: k, label: i.feature_label || k, count: 0 };
            counts[k].count++;
          });
          topFeatures = Object.values(counts).sort((a, b) => b.count - a.count).slice(0, 3);
        } catch (e) {
          console.error(`usage fetch for ${p.email} failed:`, e.message);
        }
        if (!topFeatures.length) {
          topFeatures = FALLBACK_FEATURES.map((key) => ({ key, label: labelFor(key), count: 0 }));
        }

        const statsHtml = topFeatures
          .map((f) => featureStatHtml(f.label, f.count, FEATURE_BENEFIT[f.key] || ""))
          .join("");

        // ---- Pricing + upgrade buttons ----
        const plansHtml = PLANS
          .map((pl) => planCardHtml(pl.name, pl.price, billingUrl))
          .join("");

        const contentHtml = [
          para(`Hi ${escapeHtml(firstName)},`, { lead: true }),
          para("Your 7-day WayPoint demo comes to a close today. Thank you for taking the time to explore the platform &mdash; we hope it gave you a real sense of how WayPoint can support your practice."),
          heading("What you used most &mdash; and why it matters"),
          statsHtml,
          heading("Plans to continue"),
          para("Ready to keep the full toolkit? Pick the plan that fits your practice &mdash; every tier below unlocks the complete platform, with annual billing saving you two months."),
          plansHtml,
          planCardHtml("6+ clinicians or a health system", "Custom pricing &mdash; let's find the right fit.", salesUrl),
          alertCallout(
            "Clients always use WayPoint for free",
            "Every plan covers <strong>you, the clinician</strong>. Your clients never see a paywall and never pay a cent &mdash; they get the full self-guided experience at no cost, always."
          ),
          para("We'd genuinely value your honest feedback &mdash; it takes about a minute and directly shapes what we build next. You can share it via the survey below, or by emailing jenthecounselor16@gmail.com directly."),
          primaryButton("Share your feedback", surveyUrl),
          therapistUplift(),
          para("If you have any questions or want to talk through the right plan, just reply to this email &mdash; we're happy to help."),
          para("Warm regards,<br/>The WayPoint Team"),
        ].join("");

        const { html } = renderEmail({ recipientType: "general", contentHtml });
        await base44.asServiceRole.integrations.Core.SendEmail({
          to: p.email,
          subject: "Your WayPoint demo recap — your usage, the benefits, and plans to continue",
          body: html,
        });
        await base44.asServiceRole.entities.DemoParticipant.update(p.id, {
          last_day_email_sent: true,
          last_day_email_sent_at: new Date().toISOString(),
        });
        sent++;
      } catch (e) {
        console.error(`Last-day recap email to ${p.email} failed:`, e.message);
        failed++;
      }
    }

    console.log(`demo-last-day-email: eligible=${eligible.length} sent=${sent} failed=${failed}`);
    return Response.json({ ok: true, eligible: eligible.length, sent, failed });
  } catch (error) {
    console.error("demo-last-day-email error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// Label lookup for fallback features when no interaction data was logged.
function labelFor(key) {
  const map = {
    clinical_insights: "Clinical Insights",
    coping_toolbox: "Coping Toolbox",
    therapist_portal: "Therapist Portal",
  };
  return map[key] || key;
}