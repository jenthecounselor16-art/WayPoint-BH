import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

// Uploads a base64-encoded PDF to the builder's Google Drive, inside a
// dedicated "WayPoint Reports" folder (created on first use). Invoked from
// the client dashboard's "Save to Drive" button.

const FOLDER_NAME = "WayPoint Reports";
const DRIVE_API = "https://www.googleapis.com/drive/v3";

async function findOrCreateFolder(accessToken) {
  const q = encodeURIComponent(
    `mimeType='application/vnd.google-apps.folder' and name='${FOLDER_NAME}' and trashed=false`
  );
  const searchRes = await fetch(`${DRIVE_API}/files?q=${q}&fields=files(id,name)`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!searchRes.ok) {
    const err = await searchRes.text();
    throw new Error(`Drive folder search failed: ${err}`);
  }
  const searchData = await searchRes.json();
  if (searchData.files && searchData.files.length > 0) {
    return searchData.files[0].id;
  }
  const createRes = await fetch(`${DRIVE_API}/files?fields=id`, {
    method: "POST",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ name: FOLDER_NAME, mimeType: "application/vnd.google-apps.folder" }),
  });
  if (!createRes.ok) {
    const err = await createRes.text();
    throw new Error(`Drive folder create failed: ${err}`);
  }
  const createData = await createRes.json();
  return createData.id;
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { fileBase64, fileName } = body;
    if (!fileBase64 || !fileName) {
      return Response.json({ error: "Missing fileBase64 or fileName" }, { status: 400 });
    }

    const { accessToken } = await base44.asServiceRole.connectors.getConnection("googledrive");
    if (!accessToken) {
      return Response.json({ error: "Google Drive is not connected" }, { status: 500 });
    }

    const folderId = await findOrCreateFolder(accessToken);

    // Multipart/related upload: JSON metadata + raw PDF bytes
    const metadata = JSON.stringify({ name: fileName, parents: [folderId] });
    const boundary = "waypoint_" + Math.random().toString(36).slice(2);
    const prefix =
      `--${boundary}\r\n` +
      `Content-Type: application/json; charset=UTF-8\r\n\r\n` +
      `${metadata}\r\n` +
      `--${boundary}\r\n` +
      `Content-Type: application/pdf\r\n\r\n`;
    const suffix = `\r\n--${boundary}--`;

    const binStr = atob(fileBase64);
    const pdfBytes = new Uint8Array(binStr.length);
    for (let i = 0; i < binStr.length; i++) pdfBytes[i] = binStr.charCodeAt(i);

    const encoder = new TextEncoder();
    const prefixBytes = encoder.encode(prefix);
    const suffixBytes = encoder.encode(suffix);
    const fullBody = new Uint8Array(prefixBytes.length + pdfBytes.length + suffixBytes.length);
    fullBody.set(prefixBytes, 0);
    fullBody.set(pdfBytes, prefixBytes.length);
    fullBody.set(suffixBytes, prefixBytes.length + pdfBytes.length);

    const uploadRes = await fetch(
      `${DRIVE_API}/files?uploadType=multipart&fields=id,webViewLink`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": `multipart/related; boundary=${boundary}`,
        },
        body: fullBody,
      }
    );

    if (!uploadRes.ok) {
      const err = await uploadRes.text();
      console.error(`save-report-to-drive: upload failed for ${fileName}:`, err);
      return Response.json({ error: `Drive upload failed: ${err}` }, { status: 502 });
    }

    const uploadData = await uploadRes.json();
    console.log(`save-report-to-drive: uploaded ${fileName} (id=${uploadData.id}) by ${user.email}`);
    return Response.json({
      ok: true,
      fileId: uploadData.id,
      webViewLink: uploadData.webViewLink,
      folderId,
    });
  } catch (error) {
    console.error("save-report-to-drive error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}